using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[CompilerGenerated]
internal sealed class l
{
	[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 6)]
	private struct a
	{
	}

	internal static readonly a a/* Not supported: data(2F 00 2C 00 3A 00) */;
}
