using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace MSHTML
{
	[ComImport]
	[TypeIdentifier]
	[CompilerGenerated]
	[Guid("3050F55F-98B5-11CF-BB82-00AA00BDCE0B")]
	[CoClass(typeof(object))]
	public interface HTMLDocument : DispHTMLDocument, HTMLDocumentEvents_Event
	{
	}
}
