using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace MSHTML
{
	[ComImport]
	[Guid("3050F1FF-98B5-11CF-BB82-00AA00BDCE0B")]
	[CompilerGenerated]
	[TypeIdentifier]
	public interface IHTMLElement
	{
		override void _VtblGap1_1();

		[MethodImpl(MethodImplOptions.InternalCall)]
		[DispId(-2147417610)]
		[return: MarshalAs(UnmanagedType.Struct)]
		object getAttribute([In] [MarshalAs(UnmanagedType.BStr)] string strAttributeName, [In] int lFlags = 0);
	}
}
