using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace MSHTML
{
	[ComImport]
	[CompilerGenerated]
	[TypeIdentifier]
	[InterfaceType(2)]
	[Guid("3050F55F-98B5-11CF-BB82-00AA00BDCE0B")]
	public interface DispHTMLDocument
	{
		[DispId(1025)]
		string url
		{
			[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall)]
			[DispId(1025)]
			[return: MarshalAs(UnmanagedType.BStr)]
			get;
			[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall)]
			[DispId(1025)]
			[param: MarshalAs(UnmanagedType.BStr)]
			set;
		}

		override void _VtblGap1_32();

		override void _VtblGap2_113();

		[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall)]
		[DispId(1088)]
		[return: MarshalAs(UnmanagedType.Interface)]
		IHTMLElement getElementById([In] [MarshalAs(UnmanagedType.BStr)] string v);
	}
}
