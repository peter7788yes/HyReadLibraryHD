using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace MSHTML
{
	[ComImport]
	[ComEventInterface(typeof(HTMLDocumentEvents), typeof(HTMLDocumentEvents))]
	[TypeIdentifier("3050f1c5-98b5-11cf-bb82-00aa00bdce0b", "MSHTML.HTMLDocumentEvents_Event")]
	[CompilerGenerated]
	public interface HTMLDocumentEvents_Event
	{
	}
}
