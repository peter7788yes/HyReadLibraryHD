using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace MSHTML
{
	[ComImport]
	[Guid("3050F260-98B5-11CF-BB82-00AA00BDCE0B")]
	[CompilerGenerated]
	[TypeIdentifier]
	[InterfaceType(2)]
	public interface HTMLDocumentEvents
	{
	}
}
