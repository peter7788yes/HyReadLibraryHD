using CefSharp;

internal class f : IDownloadHandler
{
	public bool OnBeforeDownload(DownloadItem downloadItem, out string downloadPath, out bool showDialog)
	{
		downloadPath = downloadItem.SuggestedFileName;
		showDialog = true;
		return false;
	}

	public bool OnDownloadUpdated(DownloadItem downloadItem)
	{
		return true;
	}
}
