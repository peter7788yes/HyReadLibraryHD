using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace HyReadLibraryHD.Properties
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
	[CompilerGenerated]
	[DebuggerNonUserCode]
	public class Resources
	{
		private static ResourceManager a;

		private static CultureInfo b;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static ResourceManager ResourceManager
		{
			get
			{
				if (a == null)
				{
					a = new ResourceManager("HyReadLibraryHD.Properties.Resources", typeof(Resources).Assembly);
				}
				return a;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		public static CultureInfo Culture
		{
			get
			{
				return b;
			}
			set
			{
				b = value;
			}
		}

		public static string account
		{
			get
			{
				return ResourceManager.GetString("account", b);
			}
		}

		public static string add
		{
			get
			{
				return ResourceManager.GetString("add", b);
			}
		}

		public static string aheadReturn
		{
			get
			{
				return ResourceManager.GetString("aheadReturn", b);
			}
		}

		public static string all
		{
			get
			{
				return ResourceManager.GetString("all", b);
			}
		}

		public static string alongOpposite
		{
			get
			{
				return ResourceManager.GetString("alongOpposite", b);
			}
		}

		public static string appTitle
		{
			get
			{
				return ResourceManager.GetString("appTitle", b);
			}
		}

		public static string author
		{
			get
			{
				return ResourceManager.GetString("author", b);
			}
		}

		public static string backMyBookcase
		{
			get
			{
				return ResourceManager.GetString("backMyBookcase", b);
			}
		}

		public static string backReadMode
		{
			get
			{
				return ResourceManager.GetString("backReadMode", b);
			}
		}

		public static string book
		{
			get
			{
				return ResourceManager.GetString("book", b);
			}
		}

		public static string bookFormat
		{
			get
			{
				return ResourceManager.GetString("bookFormat", b);
			}
		}

		public static string bookLoop
		{
			get
			{
				return ResourceManager.GetString("bookLoop", b);
			}
		}

		public static string bookMarks
		{
			get
			{
				return ResourceManager.GetString("bookMarks", b);
			}
		}

		public static string bookOfBuy
		{
			get
			{
				return ResourceManager.GetString("bookOfBuy", b);
			}
		}

		public static string bookOfLend
		{
			get
			{
				return ResourceManager.GetString("bookOfLend", b);
			}
		}

		public static string books
		{
			get
			{
				return ResourceManager.GetString("books", b);
			}
		}

		public static string bookSize
		{
			get
			{
				return ResourceManager.GetString("bookSize", b);
			}
		}

		public static string bookSource
		{
			get
			{
				return ResourceManager.GetString("bookSource", b);
			}
		}

		public static string bookSpecies
		{
			get
			{
				return ResourceManager.GetString("bookSpecies", b);
			}
		}

		public static string bookType
		{
			get
			{
				return ResourceManager.GetString("bookType", b);
			}
		}

		public static string borrowHistory
		{
			get
			{
				return ResourceManager.GetString("borrowHistory", b);
			}
		}

		public static string browse
		{
			get
			{
				return ResourceManager.GetString("browse", b);
			}
		}

		public static string bugsReport
		{
			get
			{
				return ResourceManager.GetString("bugsReport", b);
			}
		}

		public static string cancel
		{
			get
			{
				return ResourceManager.GetString("cancel", b);
			}
		}

		public static string circulPolicy
		{
			get
			{
				return ResourceManager.GetString("circulPolicy", b);
			}
		}

		public static string close
		{
			get
			{
				return ResourceManager.GetString("close", b);
			}
		}

		public static string closeThumbnail
		{
			get
			{
				return ResourceManager.GetString("closeThumbnail", b);
			}
		}

		public static string confirm
		{
			get
			{
				return ResourceManager.GetString("confirm", b);
			}
		}

		public static string confirmEmail
		{
			get
			{
				return ResourceManager.GetString("confirmEmail", b);
			}
		}

		public static string contents
		{
			get
			{
				return ResourceManager.GetString("contents", b);
			}
		}

		public static string copyright
		{
			get
			{
				return ResourceManager.GetString("copyright", b);
			}
		}

		public static string copyrightMessage
		{
			get
			{
				return ResourceManager.GetString("copyrightMessage", b);
			}
		}

		public static string curve
		{
			get
			{
				return ResourceManager.GetString("curve", b);
			}
		}

		public static string dataPreparation
		{
			get
			{
				return ResourceManager.GetString("dataPreparation", b);
			}
		}

		public static string defaultLibName
		{
			get
			{
				return ResourceManager.GetString("defaultLibName", b);
			}
		}

		public static string delAllStrokes
		{
			get
			{
				return ResourceManager.GetString("delAllStrokes", b);
			}
		}

		public static string delBook
		{
			get
			{
				return ResourceManager.GetString("delBook", b);
			}
		}

		public static string delete
		{
			get
			{
				return ResourceManager.GetString("delete", b);
			}
		}

		public static string delFavorite
		{
			get
			{
				return ResourceManager.GetString("delFavorite", b);
			}
		}

		public static string delThisBook
		{
			get
			{
				return ResourceManager.GetString("delThisBook", b);
			}
		}

		public static string down
		{
			get
			{
				return ResourceManager.GetString("down", b);
			}
		}

		public static string download
		{
			get
			{
				return ResourceManager.GetString("download", b);
			}
		}

		public static string downloaded
		{
			get
			{
				return ResourceManager.GetString("downloaded", b);
			}
		}

		public static string downloading
		{
			get
			{
				return ResourceManager.GetString("downloading", b);
			}
		}

		public static string downloadStatus
		{
			get
			{
				return ResourceManager.GetString("downloadStatus", b);
			}
		}

		public static string ecourse
		{
			get
			{
				return ResourceManager.GetString("ecourse", b);
			}
		}

		public static string ecourseAnswer
		{
			get
			{
				return ResourceManager.GetString("ecourseAnswer", b);
			}
		}

		public static string ePubTryRead
		{
			get
			{
				return ResourceManager.GetString("ePubTryRead", b);
			}
		}

		public static string eraser
		{
			get
			{
				return ResourceManager.GetString("eraser", b);
			}
		}

		public static string factoryReset
		{
			get
			{
				return ResourceManager.GetString("factoryReset", b);
			}
		}

		public static string favorites
		{
			get
			{
				return ResourceManager.GetString("favorites", b);
			}
		}

		public static string fileLoop
		{
			get
			{
				return ResourceManager.GetString("fileLoop", b);
			}
		}

		public static string filter
		{
			get
			{
				return ResourceManager.GetString("filter", b);
			}
		}

		public static string filterBook
		{
			get
			{
				return ResourceManager.GetString("filterBook", b);
			}
		}

		public static string freeBook
		{
			get
			{
				return ResourceManager.GetString("freeBook", b);
			}
		}

		public static string fullScreen
		{
			get
			{
				return ResourceManager.GetString("fullScreen", b);
			}
		}

		public static string fullText
		{
			get
			{
				return ResourceManager.GetString("fullText", b);
			}
		}

		public static string fullTextSearch
		{
			get
			{
				return ResourceManager.GetString("fullTextSearch", b);
			}
		}

		public static string goInstallV3
		{
			get
			{
				return ResourceManager.GetString("goInstallV3", b);
			}
		}

		public static string hideThumbnails
		{
			get
			{
				return ResourceManager.GetString("hideThumbnails", b);
			}
		}

		public static string hightlighter
		{
			get
			{
				return ResourceManager.GetString("hightlighter", b);
			}
		}

		public static string hyreadEbookStore
		{
			get
			{
				return ResourceManager.GetString("hyreadEbookStore", b);
			}
		}

		public static string installV3
		{
			get
			{
				return ResourceManager.GetString("installV3", b);
			}
		}

		public static string jpgTryRead
		{
			get
			{
				return ResourceManager.GetString("jpgTryRead", b);
			}
		}

		public static string leftPage
		{
			get
			{
				return ResourceManager.GetString("leftPage", b);
			}
		}

		public static string lendAndReserve
		{
			get
			{
				return ResourceManager.GetString("lendAndReserve", b);
			}
		}

		public static string lendRules
		{
			get
			{
				return ResourceManager.GetString("lendRules", b);
			}
		}

		public static string lendSuccess
		{
			get
			{
				return ResourceManager.GetString("lendSuccess", b);
			}
		}

		public static string library
		{
			get
			{
				return ResourceManager.GetString("library", b);
			}
		}

		public static string loading
		{
			get
			{
				return ResourceManager.GetString("loading", b);
			}
		}

		public static string loanPeriod
		{
			get
			{
				return ResourceManager.GetString("loanPeriod", b);
			}
		}

		public static string locklock
		{
			get
			{
				return ResourceManager.GetString("locklock", b);
			}
		}

		public static string logged
		{
			get
			{
				return ResourceManager.GetString("logged", b);
			}
		}

		public static string loggedOut
		{
			get
			{
				return ResourceManager.GetString("loggedOut", b);
			}
		}

		public static string login
		{
			get
			{
				return ResourceManager.GetString("login", b);
			}
		}

		public static string logout
		{
			get
			{
				return ResourceManager.GetString("logout", b);
			}
		}

		public static string magazine
		{
			get
			{
				return ResourceManager.GetString("magazine", b);
			}
		}

		public static string more
		{
			get
			{
				return ResourceManager.GetString("more", b);
			}
		}

		public static string multimediaList
		{
			get
			{
				return ResourceManager.GetString("multimediaList", b);
			}
		}

		public static string myBookcase
		{
			get
			{
				return ResourceManager.GetString("myBookcase", b);
			}
		}

		public static string news
		{
			get
			{
				return ResourceManager.GetString("news", b);
			}
		}

		public static string NoFilterResult
		{
			get
			{
				return ResourceManager.GetString("NoFilterResult", b);
			}
		}

		public static string NoTagsExist
		{
			get
			{
				return ResourceManager.GetString("NoTagsExist", b);
			}
		}

		public static string note
		{
			get
			{
				return ResourceManager.GetString("note", b);
			}
		}

		public static string noteExport
		{
			get
			{
				return ResourceManager.GetString("noteExport", b);
			}
		}

		public static string noteReport
		{
			get
			{
				return ResourceManager.GetString("noteReport", b);
			}
		}

		public static string notProvideLend
		{
			get
			{
				return ResourceManager.GetString("notProvideLend", b);
			}
		}

		public static string nowLending
		{
			get
			{
				return ResourceManager.GetString("nowLending", b);
			}
		}

		public static string numberOfAvailable
		{
			get
			{
				return ResourceManager.GetString("numberOfAvailable", b);
			}
		}

		public static string onePageMode
		{
			get
			{
				return ResourceManager.GetString("onePageMode", b);
			}
		}

		public static string onlineReserve
		{
			get
			{
				return ResourceManager.GetString("onlineReserve", b);
			}
		}

		public static string opaque
		{
			get
			{
				return ResourceManager.GetString("opaque", b);
			}
		}

		public static string other
		{
			get
			{
				return ResourceManager.GetString("other", b);
			}
		}

		public static string page
		{
			get
			{
				return ResourceManager.GetString("page", b);
			}
		}

		public static string palette
		{
			get
			{
				return ResourceManager.GetString("palette", b);
			}
		}

		public static string password
		{
			get
			{
				return ResourceManager.GetString("password", b);
			}
		}

		public static string pdfTryRead
		{
			get
			{
				return ResourceManager.GetString("pdfTryRead", b);
			}
		}

		public static string Play
		{
			get
			{
				return ResourceManager.GetString("Play", b);
			}
		}

		public static string playExpireDate
		{
			get
			{
				return ResourceManager.GetString("playExpireDate", b);
			}
		}

		public static string PlayTrailer
		{
			get
			{
				return ResourceManager.GetString("PlayTrailer", b);
			}
		}

		public static string preferences
		{
			get
			{
				return ResourceManager.GetString("preferences", b);
			}
		}

		public static string print
		{
			get
			{
				return ResourceManager.GetString("print", b);
			}
		}

		public static string printPermission
		{
			get
			{
				return ResourceManager.GetString("printPermission", b);
			}
		}

		public static string printThisPage
		{
			get
			{
				return ResourceManager.GetString("printThisPage", b);
			}
		}

		public static string promoNextTime
		{
			get
			{
				return ResourceManager.GetString("promoNextTime", b);
			}
		}

		public static string promoV3Hidden
		{
			get
			{
				return ResourceManager.GetString("promoV3Hidden", b);
			}
		}

		public static string promoV3Msg
		{
			get
			{
				return ResourceManager.GetString("promoV3Msg", b);
			}
		}

		public static string proxySetting
		{
			get
			{
				return ResourceManager.GetString("proxySetting", b);
			}
		}

		public static string publishDate
		{
			get
			{
				return ResourceManager.GetString("publishDate", b);
			}
		}

		public static string publisher
		{
			get
			{
				return ResourceManager.GetString("publisher", b);
			}
		}

		public static string read
		{
			get
			{
				return ResourceManager.GetString("read", b);
			}
		}

		public static string readTimes
		{
			get
			{
				return ResourceManager.GetString("readTimes", b);
			}
		}

		public static string renewDay
		{
			get
			{
				return ResourceManager.GetString("renewDay", b);
			}
		}

		public static string reserveNumber
		{
			get
			{
				return ResourceManager.GetString("reserveNumber", b);
			}
		}

		public static string rightPage
		{
			get
			{
				return ResourceManager.GetString("rightPage", b);
			}
		}

		public static string searchLib
		{
			get
			{
				return ResourceManager.GetString("searchLib", b);
			}
		}

		public static string serviceInfo
		{
			get
			{
				return ResourceManager.GetString("serviceInfo", b);
			}
		}

		public static string serviceLib
		{
			get
			{
				return ResourceManager.GetString("serviceLib", b);
			}
		}

		public static string setting
		{
			get
			{
				return ResourceManager.GetString("setting", b);
			}
		}

		public static string share
		{
			get
			{
				return ResourceManager.GetString("share", b);
			}
		}

		public static string showAllthumbnails
		{
			get
			{
				return ResourceManager.GetString("showAllthumbnails", b);
			}
		}

		public static string showAnnotation
		{
			get
			{
				return ResourceManager.GetString("showAnnotation", b);
			}
		}

		public static string showBookmarks
		{
			get
			{
				return ResourceManager.GetString("showBookmarks", b);
			}
		}

		public static string showFreeBook
		{
			get
			{
				return ResourceManager.GetString("showFreeBook", b);
			}
		}

		public static string showThumbnails
		{
			get
			{
				return ResourceManager.GetString("showThumbnails", b);
			}
		}

		public static string skipContentPage
		{
			get
			{
				return ResourceManager.GetString("skipContentPage", b);
			}
		}

		public static string softwareVersion
		{
			get
			{
				return ResourceManager.GetString("softwareVersion", b);
			}
		}

		public static string straight
		{
			get
			{
				return ResourceManager.GetString("straight", b);
			}
		}

		public static string stroke
		{
			get
			{
				return ResourceManager.GetString("stroke", b);
			}
		}

		public static string submit
		{
			get
			{
				return ResourceManager.GetString("submit", b);
			}
		}

		public static string syncBookcase
		{
			get
			{
				return ResourceManager.GetString("syncBookcase", b);
			}
		}

		public static string tagsList
		{
			get
			{
				return ResourceManager.GetString("tagsList", b);
			}
		}

		public static string the
		{
			get
			{
				return ResourceManager.GetString("the", b);
			}
		}

		public static string thickness
		{
			get
			{
				return ResourceManager.GetString("thickness", b);
			}
		}

		public static string thumbnailOverview
		{
			get
			{
				return ResourceManager.GetString("thumbnailOverview", b);
			}
		}

		public static string toBorrow
		{
			get
			{
				return ResourceManager.GetString("toBorrow", b);
			}
		}

		public static string toBuy
		{
			get
			{
				return ResourceManager.GetString("toBuy", b);
			}
		}

		public static string transparent
		{
			get
			{
				return ResourceManager.GetString("transparent", b);
			}
		}

		public static string tryRead
		{
			get
			{
				return ResourceManager.GetString("tryRead", b);
			}
		}

		public static string twoPageMode
		{
			get
			{
				return ResourceManager.GetString("twoPageMode", b);
			}
		}

		public static string up
		{
			get
			{
				return ResourceManager.GetString("up", b);
			}
		}

		public static string welcome
		{
			get
			{
				return ResourceManager.GetString("welcome", b);
			}
		}

		public static string YetDownloaded
		{
			get
			{
				return ResourceManager.GetString("YetDownloaded", b);
			}
		}

		public static string zoomIn
		{
			get
			{
				return ResourceManager.GetString("zoomIn", b);
			}
		}

		public static string zoomOut
		{
			get
			{
				return ResourceManager.GetString("zoomOut", b);
			}
		}

		internal Resources()
		{
		}
	}
}
