internal delegate void h();
