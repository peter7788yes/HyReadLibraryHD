using System.Runtime.CompilerServices;

namespace HyReadLibraryHD
{
	public class TagListCountData
	{
		[CompilerGenerated]
		private string a;

		[CompilerGenerated]
		private int b;

		public string tagName
		{
			[CompilerGenerated]
			get
			{
				return a;
			}
			[CompilerGenerated]
			set
			{
				a = value;
			}
		}

		public int tagCount
		{
			[CompilerGenerated]
			get
			{
				return b;
			}
			[CompilerGenerated]
			set
			{
				b = value;
			}
		}
	}
}
