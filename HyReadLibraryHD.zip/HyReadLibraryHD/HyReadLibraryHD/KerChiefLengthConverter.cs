using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace HyReadLibraryHD
{
	public class KerChiefLengthConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (targetType != typeof(Brush))
			{
				throw new InvalidOperationException("it is not a double");
			}
			value = ((value == null) ? Brushes.Transparent : ((!value.ToString().Equals("Aqua")) ? Brushes.White : Brushes.Black));
			return value;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return null;
		}
	}
}
