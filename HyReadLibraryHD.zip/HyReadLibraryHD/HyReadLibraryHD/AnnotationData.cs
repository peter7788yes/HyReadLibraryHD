namespace HyReadLibraryHD
{
	public class AnnotationData
	{
		public string itemId;

		public int itemIndex;

		public int sno;

		public string rangyRange;

		public string handleBounds;

		public string menuBounds;

		public string htmlContent;

		public int locationX;

		public int locationY;

		public string colorRGBA;

		public int annoType;

		public string noteText;

		public string orgHandle;
	}
}
