using Microsoft.Win32;
using NLog;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Threading;

namespace HyReadLibraryHD
{
	public class SplashWindow : Window, IComponentConnector
	{
		[CompilerGenerated]
		private sealed class a
		{
			public IAsyncResult a;

			public SplashWindow b;

			internal void c(IAsyncResult A_0)
			{
				App.Current.c.EndInvoke(a);
				b.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new k(c));
			}

			internal void c()
			{
				b.Close();
			}
		}

		[CompilerGenerated]
		private sealed class b
		{
			public SplashWindow a;

			public double b;

			internal void c()
			{
				a.d.Value = b;
			}
		}

		[CompilerGenerated]
		private sealed class c
		{
			public SplashWindow a;

			public string b;

			internal void c()
			{
				a.c.Text = b;
			}
		}

		private static Logger m_a = LogManager.GetCurrentClassLogger();

		internal SplashWindow b;

		internal TextBlock c;

		internal ProgressBar d;

		private bool e;

		[DllImport("user32.dll")]
		[DebuggerStepThrough]
		private static extern bool IsWindowEnabled(IntPtr A_0);

		public SplashWindow()
		{
			InitializeComponent();
			base.Loaded += new RoutedEventHandler(a);
			if (Global.regPath.Equals("NCLReader"))
			{
				base.Height = 280.0;
				Thickness margin = d.Margin;
				margin.Left = 120.0;
				margin.Bottom = 20.0;
				d.Margin = margin;
			}
		}

		private void a(object A_0, RoutedEventArgs A_1)
		{
			a obj = new a();
			obj.b = this;
			SplashWindow.m_a.Trace("begin Splash_Loaded");
			a();
			obj.a = null;
			SplashWindow.m_a.Trace("");
			AsyncCallback a_ = new AsyncCallback(obj.c);
			obj.a = App.Current.c.BeginInvoke(this, a_, null);
			SplashWindow.m_a.Trace("end Splash_Loaded");
		}

		public void SetProgress(double progress)
		{
			b b = new b();
			b.a = this;
			b.b = progress;
			base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new k(b.c));
		}

		public void OpenLoadingPanel(string canvasText)
		{
			c c = new c();
			c.a = this;
			c.b = canvasText;
			base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new k(c.c));
		}

		private void b()
		{
			if (!Environment.Is64BitOperatingSystem)
			{
				string value = "C:\\Program Files\\HyReadLibraryHD\\HyReadLibraryHD.exe /url \"%1\"";
				Registry.SetValue("HKEY_CURRENT_USER\\SOFTWARE\\Classes\\hyread\\shell\\open\\command", "", value, RegistryValueKind.String);
			}
		}

		private void a()
		{
			b();
			OperatingSystem oSVersion = Environment.OSVersion;
			if (oSVersion.Platform.GetHashCode() != 2 || oSVersion.Version.Major.GetHashCode() != 5 || oSVersion.Version.Minor.GetHashCode() != 1)
			{
				return;
			}
			if (Directory.Exists("c:\\windows\\prefetch\\"))
			{
				string[] files = Directory.GetFiles("c:\\windows\\prefetch\\", "*.pf");
				foreach (string path in files)
				{
					try
					{
						File.Delete(path);
					}
					catch
					{
					}
				}
			}
			object value = Registry.GetValue("HKEY_CURRENT_USER\\SOFTWARE\\" + Global.regPath, "FirstRun", "");
			if (value != null && value.ToString().Equals("TRUE"))
			{
				try
				{
					Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\Schedule", "Start", 4, RegistryValueKind.DWord);
					Registry.SetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters", "EnablePrefetcher", 2, RegistryValueKind.DWord);
				}
				catch
				{
				}
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!e)
			{
				e = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/splashwindow.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.b = (SplashWindow)target;
				break;
			case 2:
				this.c = (TextBlock)target;
				break;
			case 3:
				d = (ProgressBar)target;
				break;
			default:
				e = true;
				break;
			}
		}
	}
}
