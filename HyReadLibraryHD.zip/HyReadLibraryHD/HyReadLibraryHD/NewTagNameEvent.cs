namespace HyReadLibraryHD
{
	public delegate void NewTagNameEvent(string newTagName);
}
