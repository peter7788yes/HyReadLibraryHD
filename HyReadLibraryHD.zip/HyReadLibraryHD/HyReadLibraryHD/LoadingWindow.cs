using DownloadManagerModule;
using LoadingPage.Control;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Threading;

namespace HyReadLibraryHD
{
	public class LoadingWindow : Window, IComponentConnector
	{
		[CompilerGenerated]
		private sealed class a
		{
			public IAsyncResult a;

			public LoadingWindow b;

			internal void c(IAsyncResult A_0)
			{
				MainWindow.ae.EndInvoke(a);
				b.textInLoadingRing = "";
				b.m_b = null;
				b.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new h(c));
			}

			internal void c()
			{
				b.Close();
			}
		}

		public string textInLoadingRing = "";

		public bool closedByCancelButton;

		private BookType m_a;

		private object m_b;

		private string c;

		internal LoadingAnimation d;

		internal Button e;

		private bool f;

		public LoadingWindow(BookType _bookType, object _bookInfo, string _textInLoadingRing)
		{
			textInLoadingRing = _textInLoadingRing;
			InitializeComponent();
			d.LoadingPageText.Text = textInLoadingRing;
			this.m_a = _bookType;
			this.m_b = _bookInfo;
			base.Loaded += new RoutedEventHandler(b);
		}

		private void b(object A_0, RoutedEventArgs A_1)
		{
			IAsyncResult a = null;
		}

		private void a(object A_0, RoutedEventArgs A_1)
		{
			textInLoadingRing = "";
			closedByCancelButton = true;
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!f)
			{
				f = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/loadingwindow.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				d = (LoadingAnimation)target;
				break;
			case 2:
				e = (Button)target;
				e.Click += new RoutedEventHandler(a);
				break;
			default:
				f = true;
				break;
			}
		}
	}
}
