using BookManagerModule;

namespace HyReadLibraryHD
{
	public delegate void CategoryChangedEvent(Category category);
}
