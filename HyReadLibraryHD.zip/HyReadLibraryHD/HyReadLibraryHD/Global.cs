using BookManagerModule;
using SyncCenterModule;
using System;

namespace HyReadLibraryHD
{
	public static class Global
	{
		private const string a = "http://openebook.hyread.com.tw/ebook-entrance/vendors/pc/1.0.0?colibLimit=N&appCode=hyread";

		public static string appVersionUrl = "http://ebook.hyread.com.tw/hyread/updateNew.htm";

		private const string b = "http://openebook.hyread.com.tw/ebook-entrance/libtype/all?appCode=hyread";

		public const string cloudService = "https://cloudservice.ebook.hyread.com.tw/DataService/1/classes/";

		public static string localDataPath = "HyRead";

		public static string regPath = "HyReadLibraryHD";

		public static string langName = "zh-TW";

		public const string serviceEchoUrl = "";

		public static BookManager bookManager = new BookManager("http://openebook.hyread.com.tw/ebook-entrance/vendors/pc/1.0.0?colibLimit=N&appCode=hyread", "", localDataPath, regPath, langName, appVersionUrl, "http://openebook.hyread.com.tw/ebook-entrance/libtype/all?appCode=hyread");

		public static SyncCenter syncCenter = new SyncCenter();

		public static DateTime serverTime = DateTime.Now;

		public const int minRetryInterval = 2000;

		public const int maxRetryInterval = 300000;

		public static bool networkAvailable = true;
	}
}
