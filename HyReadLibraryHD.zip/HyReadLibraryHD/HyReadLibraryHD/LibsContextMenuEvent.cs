namespace HyReadLibraryHD
{
	public delegate void LibsContextMenuEvent(string clickItemId);
}
