using CACodec;
using CefSharp;
using CefSharp.WinForms;
using ConfigureManagerModule;
using DataAccessObject;
using DigitalBookData.Portable.DataObject;
using HtmlAgilityPack;
using Microsoft.Runtime.CompilerServices;
using ReadPageModule;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using Utility;

namespace HyReadLibraryHD
{
	[ComVisible(true)]
	[PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
	public class epubReadPage : Form
	{
		public class JSBindingObject
		{
			[Serializable]
			[CompilerGenerated]
			private sealed class _003C_003Ec
			{
				public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

				public static Comparison<int> _003C_003E9__39_1;

				public static Comparison<int> _003C_003E9__39_0;

				public static Comparison<int> _003C_003E9__39_3;

				public static Comparison<int> _003C_003E9__39_2;

				public static Action<Task<JavascriptResponse>> _003C_003E9__46_0;

				public static Action<Task<JavascriptResponse>> _003C_003E9__46_1;

				internal int a(int A_0, int A_1)
				{
					return A_0.CompareTo(A_1);
				}

				internal int b(int A_0, int A_1)
				{
					return A_0.CompareTo(A_1);
				}

				internal int c(int A_0, int A_1)
				{
					return A_0.CompareTo(A_1);
				}

				internal int d(int A_0, int A_1)
				{
					return A_0.CompareTo(A_1);
				}

				internal void a(Task<JavascriptResponse> A_0)
				{
					if (!A_0.IsFaulted)
					{
						JavascriptResponse result = A_0.Result;
						if (!result.Success)
						{
							string message = result.Message;
						}
						else
						{
							object result2 = result.Result;
						}
					}
				}

				internal void b(Task<JavascriptResponse> A_0)
				{
					if (!A_0.IsFaulted)
					{
						JavascriptResponse result = A_0.Result;
						if (!result.Success)
						{
							string message = result.Message;
						}
						else
						{
							object result2 = result.Result;
						}
					}
				}
			}

			[CompilerGenerated]
			private bool a;

			public ChromiumWebBrowser web_view;

			public static epubReadPage form;

			[CompilerGenerated]
			private int b;

			[CompilerGenerated]
			private int c;

			[CompilerGenerated]
			private int d;

			public int CurLeft;

			public int CurTop;

			public int CurPage;

			public static ArrayList annotList;

			public static List<NOTE_ARRAYLIST> leftNoteList;

			public static List<NOTE_ARRAYLIST> rightNoteList;

			private bool e;

			public bool isMouseDown;

			public static string leftStartAndEnd = string.Empty;

			public static string rightStartAndEnd = string.Empty;

			public bool state
			{
				[CompilerGenerated]
				get
				{
					return a;
				}
				[CompilerGenerated]
				set
				{
					a = value;
				}
			}

			public int ContentsWidth
			{
				[CompilerGenerated]
				get
				{
					return b;
				}
				[CompilerGenerated]
				set
				{
					b = value;
				}
			}

			public int ContentsHeight
			{
				[CompilerGenerated]
				get
				{
					return c;
				}
				[CompilerGenerated]
				set
				{
					c = value;
				}
			}

			public int TotalPages
			{
				[CompilerGenerated]
				get
				{
					return d;
				}
				[CompilerGenerated]
				set
				{
					d = value;
				}
			}

			[DllImport("shell32.dll")]
			public static extern int ShellExecute(int hwnd, string lpOperation, string lpFile, string lpParameters, string lpDirectory, int nShowCmd);

			public void mediaClicked(string url)
			{
				if (url.Contains("file:///"))
				{
					url = url.Remove(0, 8);
				}
				if (!url.Contains("C:/User"))
				{
					url = pathToBookOEBPS + url;
				}
				ShellExecute(0, "open", url, string.Empty, string.Empty, 5);
			}

			public void setWebview(ChromiumWebBrowser wv)
			{
				web_view = wv;
			}

			public static void setForm(epubReadPage f)
			{
				form = f;
			}

			public void setCurLeftAndCurPage(int left, int page)
			{
				CurLeft = left;
				CurPage = page;
				Console.WriteLine("page={0}", page);
			}

			public void setCurTopAndCurPage(int top, int page)
			{
				CurTop = top;
				CurPage = page;
			}

			public void getImgPos(string posStr)
			{
			}

			public void returnSelectionStartAndEnd(string webviewName, int start, int end, int x, int y, string handleBounds, string textContent)
			{
				Console.WriteLine(webviewName);
				Console.WriteLine("start:" + start + ", end:" + end);
				Console.WriteLine("x:" + x + ", y:" + y);
				Console.WriteLine(handleBounds);
				form.a(0, 0);
				if (bp && !form.FXL_CanHighlight)
				{
					return;
				}
				if (start != end)
				{
					if (!e)
					{
						LoadNoteFromDB();
					}
					e = true;
					form.az = true;
				}
				form.processStartAndEnd(webviewName, start, end, x, y, handleBounds, textContent);
			}

			public void LoadNoteFromDB()
			{
				form.c();
				foreach (AnnotationData item in form.bookAnnotation)
				{
					if (item.itemIndex == form.m_p)
					{
						for (int i = 0; i < leftNoteList.Count; i++)
						{
							for (int j = 0; j < leftNoteList[i].items.Count; j++)
							{
								if (leftNoteList[i].items[j].rangy == item.rangyRange)
								{
									leftNoteList[i].items[j].noteText = item.noteText;
									leftNoteList[i].items[j].selectText = item.htmlContent;
									leftNoteList[i].items[j].penColorIndex = form.l(item.colorRGBA);
									break;
								}
							}
						}
						for (int k = 0; k < rightNoteList.Count; k++)
						{
							for (int l = 0; l < rightNoteList[k].items.Count; l++)
							{
								if (rightNoteList[k].items[l].rangy == item.rangyRange)
								{
									rightNoteList[k].items[l].noteText = item.noteText;
									rightNoteList[k].items[l].selectText = item.htmlContent;
									rightNoteList[k].items[l].penColorIndex = form.l(item.colorRGBA);
									break;
								}
							}
						}
					}
					else
					{
						if (!bp || item.itemIndex != form.m_p + 1)
						{
							continue;
						}
						for (int m = 0; m < rightNoteList.Count; m++)
						{
							for (int n = 0; n < rightNoteList[m].items.Count; n++)
							{
								if (rightNoteList[m].items[n].rangy == item.rangyRange)
								{
									rightNoteList[m].items[n].noteText = item.noteText;
									rightNoteList[m].items[n].selectText = item.htmlContent;
									rightNoteList[m].items[n].penColorIndex = form.l(item.colorRGBA);
									break;
								}
							}
						}
					}
				}
			}

			public void afterAddNoteMark()
			{
				if (form.a0)
				{
					form.f();
				}
			}

			public void showNote(string webviewName, string id)
			{
				Console.WriteLine(webviewName + ":" + id);
				form.a0 = true;
				if (!e)
				{
					e = true;
					LoadNoteFromDB();
				}
				List<START_END_PAIR> modifyNoteList = new List<START_END_PAIR>();
				int num = 0;
				if (bp)
				{
					if (webviewName == "LEFT_WEBVIEW")
					{
						form.cq = true;
						if (!bj)
						{
							foreach (NOTE_ARRAYLIST leftNote in leftNoteList)
							{
								if (leftNote.top == int.Parse(id))
								{
									form.cr = num;
									modifyNoteList = leftNote.items;
									break;
								}
								num++;
							}
						}
						else
						{
							foreach (NOTE_ARRAYLIST leftNote2 in leftNoteList)
							{
								if (leftNote2.right == int.Parse(id))
								{
									form.cr = num;
									modifyNoteList = leftNote2.items;
									break;
								}
								num++;
							}
						}
					}
					else
					{
						form.cq = false;
						if (!bj)
						{
							foreach (NOTE_ARRAYLIST rightNote in rightNoteList)
							{
								if (rightNote.top == int.Parse(id))
								{
									form.cr = num;
									modifyNoteList = rightNote.items;
									break;
								}
								num++;
							}
						}
						else
						{
							foreach (NOTE_ARRAYLIST rightNote2 in rightNoteList)
							{
								if (rightNote2.right == int.Parse(id))
								{
									form.cr = num;
									modifyNoteList = rightNote2.items;
									break;
								}
								num++;
							}
						}
					}
				}
				else
				{
					string[] array = id.Split('-');
					int num2 = int.Parse(array[0]);
					int num3 = int.Parse(array[1]);
					if (webviewName == "LEFT_WEBVIEW")
					{
						if (!bj)
						{
							foreach (NOTE_ARRAYLIST leftNote3 in leftNoteList)
							{
								if (leftNote3.left != num2 || leftNote3.top != num3)
								{
									continue;
								}
								foreach (START_END_PAIR item in leftNote3.items)
								{
									Console.WriteLine(item.start + "-" + item.end);
									form.cr = num;
									modifyNoteList = leftNote3.items;
								}
								break;
							}
						}
						else
						{
							foreach (NOTE_ARRAYLIST leftNote4 in leftNoteList)
							{
								if (leftNote4.left != num2 || leftNote4.top != num3)
								{
									continue;
								}
								foreach (START_END_PAIR item2 in leftNote4.items)
								{
									Console.WriteLine(item2.start + "-" + item2.end);
									form.cr = num;
									modifyNoteList = leftNote4.items;
								}
								break;
							}
						}
					}
					else if (!bj)
					{
						foreach (NOTE_ARRAYLIST rightNote3 in rightNoteList)
						{
							if (rightNote3.left != num2 || rightNote3.top != num3)
							{
								continue;
							}
							foreach (START_END_PAIR item3 in rightNote3.items)
							{
								Console.WriteLine(item3.start + "-" + item3.end);
								form.cr = num;
								modifyNoteList = rightNote3.items;
							}
							break;
						}
					}
					else
					{
						foreach (NOTE_ARRAYLIST rightNote4 in rightNoteList)
						{
							if (rightNote4.left != num2 || rightNote4.top != num3)
							{
								continue;
							}
							foreach (START_END_PAIR item4 in rightNote4.items)
							{
								Console.WriteLine(item4.start + "-" + item4.end);
								form.cr = num;
								modifyNoteList = rightNote4.items;
							}
							break;
						}
					}
				}
				form.formShowNote(modifyNoteList, webviewName, id);
			}

			public void clickHighlight(string webviewName, int x, int y, int start, int end, string className)
			{
				form.a0 = true;
				Console.WriteLine(webviewName);
				Console.WriteLine(start + "," + end);
				Console.WriteLine(x + "," + y);
				Console.WriteLine(className);
				if (!className.Equals("highlight_yellow"))
				{
					if (!e)
					{
						e = true;
						LoadNoteFromDB();
					}
					form.formclickHighlight(webviewName, x, y, start, end, className);
				}
			}

			public void serializeHighlights(string webviewName, string serializedHighlights)
			{
				Console.WriteLine(webviewName);
				Console.WriteLine(serializedHighlights);
			}

			public void returnResultsOfRemoveHighlights(string webviewName, int start, int end)
			{
				Console.WriteLine(webviewName);
				Console.WriteLine(start);
				Console.WriteLine(end);
				if (webviewName == "LEFT_WEBVIEW")
				{
					List<NOTE_ARRAYLIST> list = leftNoteList;
					List<int> list2 = new List<int>();
					for (int i = 0; i < list.Count; i++)
					{
						NOTE_ARRAYLIST nOTE_ARRAYLIST = Enumerable.ElementAt(list, i);
						List<int> list3 = new List<int>();
						for (int j = 0; j < nOTE_ARRAYLIST.items.Count; j++)
						{
							START_END_PAIR sTART_END_PAIR = Enumerable.ElementAt(nOTE_ARRAYLIST.items, j);
							if (sTART_END_PAIR.start >= start && sTART_END_PAIR.end <= end)
							{
								list3.Add(j);
							}
						}
						if (list3.Count > 0)
						{
							list3.Sort(_003C_003Ec._003C_003E9__39_1 ?? (_003C_003Ec._003C_003E9__39_1 = new Comparison<int>(_003C_003Ec._003C_003E9.a)));
							for (int k = 0; k < list3.Count; k++)
							{
								nOTE_ARRAYLIST.items.RemoveAt(Enumerable.ElementAt(list3, k));
							}
							if (nOTE_ARRAYLIST.items.Count == 0)
							{
								list2.Add(i);
							}
						}
					}
					if (list2.Count > 0)
					{
						list2.Sort(_003C_003Ec._003C_003E9__39_0 ?? (_003C_003Ec._003C_003E9__39_0 = new Comparison<int>(_003C_003Ec._003C_003E9.b)));
						for (int l = 0; l < list2.Count; l++)
						{
							a7.ExecuteScriptAsync("android.selection.removeNoteMarkByID(" + Enumerable.ElementAt(list, Enumerable.ElementAt(list2, l)).top + ");");
							list.RemoveAt(Enumerable.ElementAt(list2, l));
						}
					}
					return;
				}
				List<NOTE_ARRAYLIST> list4 = rightNoteList;
				List<int> list5 = new List<int>();
				for (int i = 0; i < list4.Count; i++)
				{
					NOTE_ARRAYLIST nOTE_ARRAYLIST2 = Enumerable.ElementAt(list4, i);
					List<int> list6 = new List<int>();
					for (int j = 0; j < nOTE_ARRAYLIST2.items.Count; j++)
					{
						START_END_PAIR sTART_END_PAIR2 = Enumerable.ElementAt(nOTE_ARRAYLIST2.items, j);
						if (sTART_END_PAIR2.start >= start && sTART_END_PAIR2.end <= end)
						{
							list6.Add(j);
						}
					}
					if (list6.Count > 0)
					{
						list6.Sort(_003C_003Ec._003C_003E9__39_3 ?? (_003C_003Ec._003C_003E9__39_3 = new Comparison<int>(_003C_003Ec._003C_003E9.c)));
						for (int m = 0; m < list6.Count; m++)
						{
							nOTE_ARRAYLIST2.items.RemoveAt(Enumerable.ElementAt(list6, m));
						}
						if (nOTE_ARRAYLIST2.items.Count == 0)
						{
							list5.Add(i);
						}
					}
				}
				if (list5.Count > 0)
				{
					list5.Sort(_003C_003Ec._003C_003E9__39_2 ?? (_003C_003Ec._003C_003E9__39_2 = new Comparison<int>(_003C_003Ec._003C_003E9.d)));
					for (int n = 0; n < list5.Count; n++)
					{
						a8.ExecuteScriptAsync("android.selection.removeNoteMarkByID(" + Enumerable.ElementAt(list4, Enumerable.ElementAt(list5, n)).top + ");");
						list4.RemoveAt(Enumerable.ElementAt(list5, n));
					}
				}
			}

			public void returnResultsOfModifyHighlights(string webviewName, int newCount, string rangesAndBoundingRect, bool inSearchMode)
			{
				if (inSearchMode)
				{
					return;
				}
				Console.WriteLine(webviewName);
				Console.WriteLine(newCount);
				Console.WriteLine(rangesAndBoundingRect);
				string selectText = "";
				if (!rangesAndBoundingRect.Equals(""))
				{
					selectText = rangesAndBoundingRect.Substring(rangesAndBoundingRect.IndexOf("{")).Replace("{", "").Replace("}", "");
				}
				if (bp)
				{
					if (webviewName == "LEFT_WEBVIEW")
					{
						switch (newCount)
						{
						case 1:
						{
							string[] array3 = rangesAndBoundingRect.Split(',');
							int num6 = int.Parse(array3[0]);
							int num7 = int.Parse(array3[1]);
							int.Parse(array3[2]);
							int num8 = int.Parse(array3[3]);
							int.Parse(array3[4]);
							int.Parse(array3[5]);
							List<NOTE_ARRAYLIST> list2 = leftNoteList;
							START_END_PAIR sTART_END_PAIR3 = new START_END_PAIR();
							sTART_END_PAIR3.start = num6;
							sTART_END_PAIR3.end = num7;
							sTART_END_PAIR3.selectText = selectText;
							bool flag2 = false;
							bool flag3 = false;
							for (int l = 0; l < list2.Count; l++)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST2 = Enumerable.ElementAt(list2, l);
								for (int m = 0; m < nOTE_ARRAYLIST2.items.Count; m++)
								{
									START_END_PAIR sTART_END_PAIR4 = Enumerable.ElementAt(nOTE_ARRAYLIST2.items, m);
									if (sTART_END_PAIR4.start == num6 || sTART_END_PAIR4.end == num7)
									{
										flag2 = true;
										if (!bj)
										{
											flag3 = ((Math.Abs(nOTE_ARRAYLIST2.top - num8) >= 30) ? true : false);
										}
									}
									if (flag2 && !flag3)
									{
										nOTE_ARRAYLIST2.items.RemoveAt(m);
										nOTE_ARRAYLIST2.items.Add(sTART_END_PAIR3);
										break;
									}
									if (flag2 && flag3)
									{
										nOTE_ARRAYLIST2.items.RemoveAt(m);
										break;
									}
								}
								if (flag2)
								{
									break;
								}
							}
							if (!flag2)
							{
								for (int l = 0; l < list2.Count; l++)
								{
									NOTE_ARRAYLIST nOTE_ARRAYLIST3 = Enumerable.ElementAt(list2, l);
									if (Math.Abs(nOTE_ARRAYLIST3.top - num8) <= 30)
									{
										nOTE_ARRAYLIST3.items.Add(sTART_END_PAIR3);
										flag2 = true;
										break;
									}
								}
								if (!flag2)
								{
									NOTE_ARRAYLIST item2 = default(NOTE_ARRAYLIST);
									item2.top = num8;
									item2.items = new List<START_END_PAIR>();
									item2.items.Add(sTART_END_PAIR3);
									list2.Add(item2);
									int num9 = 0;
									int num10 = num8;
									a7.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num9 + "," + num10 + "); ");
								}
							}
							else
							{
								if (!(flag2 && flag3))
								{
									break;
								}
								flag2 = false;
								for (int l = 0; l < list2.Count; l++)
								{
									NOTE_ARRAYLIST nOTE_ARRAYLIST4 = Enumerable.ElementAt(list2, l);
									if (Math.Abs(nOTE_ARRAYLIST4.top - num8) <= 30)
									{
										nOTE_ARRAYLIST4.items.Add(sTART_END_PAIR3);
										flag2 = true;
										break;
									}
								}
								if (!flag2)
								{
									NOTE_ARRAYLIST item3 = default(NOTE_ARRAYLIST);
									item3.top = num8;
									item3.items = new List<START_END_PAIR>();
									item3.items.Add(sTART_END_PAIR3);
									list2.Add(item3);
									int num11 = 0;
									int num12 = num8;
									a7.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num11 + "," + num12 + "); ");
								}
							}
							break;
						}
						case 2:
						{
							string[] array4 = rangesAndBoundingRect.Split(';');
							for (int n = 0; n < 2; n++)
							{
								string[] array5 = array4[n].Split(',');
								int num13 = int.Parse(array5[0]);
								int num14 = int.Parse(array5[1]);
								int.Parse(array5[2]);
								int num15 = int.Parse(array5[3]);
								int.Parse(array5[4]);
								int.Parse(array5[5]);
								List<NOTE_ARRAYLIST> list3 = leftNoteList;
								bool flag4 = false;
								for (int num16 = 0; num16 < list3.Count; num16++)
								{
									NOTE_ARRAYLIST nOTE_ARRAYLIST5 = Enumerable.ElementAt(list3, num16);
									for (int num17 = 0; num17 < nOTE_ARRAYLIST5.items.Count; num17++)
									{
										START_END_PAIR sTART_END_PAIR5 = Enumerable.ElementAt(nOTE_ARRAYLIST5.items, num17);
										switch (n)
										{
										case 0:
											if (sTART_END_PAIR5.start == num13)
											{
												sTART_END_PAIR5.end = num14;
												flag4 = true;
											}
											break;
										case 1:
											if (sTART_END_PAIR5.end == num14)
											{
												sTART_END_PAIR5.start = num13;
												flag4 = true;
											}
											break;
										}
										if (flag4)
										{
											nOTE_ARRAYLIST5.items.RemoveAt(num17);
											nOTE_ARRAYLIST5.items.Add(sTART_END_PAIR5);
											break;
										}
									}
									if (flag4)
									{
										break;
									}
								}
								if (flag4)
								{
									continue;
								}
								START_END_PAIR sTART_END_PAIR6 = new START_END_PAIR();
								sTART_END_PAIR6.start = num13;
								sTART_END_PAIR6.end = num14;
								sTART_END_PAIR6.selectText = selectText;
								foreach (NOTE_ARRAYLIST item17 in list3)
								{
									if (Math.Abs(item17.top - num15) <= 30)
									{
										item17.items.Add(sTART_END_PAIR6);
										flag4 = true;
										break;
									}
								}
								if (!flag4)
								{
									NOTE_ARRAYLIST item4 = default(NOTE_ARRAYLIST);
									item4.top = num15;
									item4.items = new List<START_END_PAIR>();
									item4.items.Add(sTART_END_PAIR6);
									list3.Add(item4);
									int num18 = 0;
									int num19 = num15;
									a7.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num18 + "," + num19 + "); ");
								}
							}
							break;
						}
						case 3:
						{
							string[] array = rangesAndBoundingRect.Split(';');
							for (int i = 0; i < 3; i++)
							{
								string[] array2 = array[i].Split(',');
								int num = int.Parse(array2[0]);
								int num2 = int.Parse(array2[1]);
								int.Parse(array2[2]);
								int num3 = int.Parse(array2[3]);
								int.Parse(array2[4]);
								int.Parse(array2[5]);
								List<NOTE_ARRAYLIST> list = leftNoteList;
								bool flag = false;
								for (int j = 0; j < list.Count; j++)
								{
									NOTE_ARRAYLIST nOTE_ARRAYLIST = Enumerable.ElementAt(list, j);
									for (int k = 0; k < nOTE_ARRAYLIST.items.Count; k++)
									{
										START_END_PAIR sTART_END_PAIR = Enumerable.ElementAt(nOTE_ARRAYLIST.items, k);
										switch (i)
										{
										case 0:
											if (sTART_END_PAIR.start == num)
											{
												sTART_END_PAIR.end = num2;
												flag = true;
											}
											break;
										case 2:
											if (sTART_END_PAIR.end == num2)
											{
												sTART_END_PAIR.start = num;
												flag = true;
											}
											break;
										}
										if (flag)
										{
											nOTE_ARRAYLIST.items.RemoveAt(k);
											nOTE_ARRAYLIST.items.Add(sTART_END_PAIR);
											break;
										}
									}
									if (flag)
									{
										break;
									}
								}
								if (flag)
								{
									continue;
								}
								START_END_PAIR sTART_END_PAIR2 = new START_END_PAIR();
								sTART_END_PAIR2.start = num;
								sTART_END_PAIR2.end = num2;
								sTART_END_PAIR2.selectText = selectText;
								foreach (NOTE_ARRAYLIST item18 in list)
								{
									if (Math.Abs(item18.top - num3) <= 30)
									{
										item18.items.Add(sTART_END_PAIR2);
										flag = true;
										break;
									}
								}
								if (!flag)
								{
									NOTE_ARRAYLIST item = default(NOTE_ARRAYLIST);
									item.top = num3;
									item.items = new List<START_END_PAIR>();
									item.items.Add(sTART_END_PAIR2);
									list.Add(item);
									int num4 = 0;
									int num5 = num3;
									a7.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num4 + "," + num5 + "); ");
								}
							}
							break;
						}
						}
						return;
					}
					switch (newCount)
					{
					case 1:
					{
						string[] array8 = rangesAndBoundingRect.Split(',');
						int num28 = int.Parse(array8[0]);
						int num29 = int.Parse(array8[1]);
						int.Parse(array8[2]);
						int num30 = int.Parse(array8[3]);
						int.Parse(array8[4]);
						int.Parse(array8[5]);
						List<NOTE_ARRAYLIST> list5 = rightNoteList;
						START_END_PAIR sTART_END_PAIR9 = new START_END_PAIR();
						sTART_END_PAIR9.start = num28;
						sTART_END_PAIR9.end = num29;
						sTART_END_PAIR9.selectText = selectText;
						bool flag6 = false;
						bool flag7 = false;
						for (int num31 = 0; num31 < list5.Count; num31++)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST7 = Enumerable.ElementAt(list5, num31);
							for (int num32 = 0; num32 < nOTE_ARRAYLIST7.items.Count; num32++)
							{
								START_END_PAIR sTART_END_PAIR10 = Enumerable.ElementAt(nOTE_ARRAYLIST7.items, num32);
								if (sTART_END_PAIR10.start == num28 || sTART_END_PAIR10.end == num29)
								{
									flag6 = true;
									if (!bj)
									{
										flag7 = ((Math.Abs(nOTE_ARRAYLIST7.top - num30) >= 30) ? true : false);
									}
								}
								if (flag6 && !flag7)
								{
									nOTE_ARRAYLIST7.items.RemoveAt(num32);
									nOTE_ARRAYLIST7.items.Add(sTART_END_PAIR9);
									break;
								}
								if (flag6 && flag7)
								{
									nOTE_ARRAYLIST7.items.RemoveAt(num32);
									break;
								}
							}
							if (flag6)
							{
								break;
							}
						}
						if (!flag6)
						{
							for (int num31 = 0; num31 < list5.Count; num31++)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST8 = Enumerable.ElementAt(list5, num31);
								if (Math.Abs(nOTE_ARRAYLIST8.top - num30) <= 30)
								{
									nOTE_ARRAYLIST8.items.Add(sTART_END_PAIR9);
									flag6 = true;
									break;
								}
							}
							if (!flag6)
							{
								NOTE_ARRAYLIST item6 = default(NOTE_ARRAYLIST);
								item6.top = num30;
								item6.items = new List<START_END_PAIR>();
								item6.items.Add(sTART_END_PAIR9);
								list5.Add(item6);
								int width = a8.Width;
								int num33 = num30;
								a8.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + width + "," + num33 + "); ");
							}
						}
						else
						{
							if (!(flag6 && flag7))
							{
								break;
							}
							flag6 = false;
							for (int num31 = 0; num31 < list5.Count; num31++)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST9 = Enumerable.ElementAt(list5, num31);
								if (Math.Abs(nOTE_ARRAYLIST9.top - num30) <= 30)
								{
									nOTE_ARRAYLIST9.items.Add(sTART_END_PAIR9);
									flag6 = true;
									break;
								}
							}
							if (!flag6)
							{
								NOTE_ARRAYLIST item7 = default(NOTE_ARRAYLIST);
								item7.top = num30;
								item7.items = new List<START_END_PAIR>();
								item7.items.Add(sTART_END_PAIR9);
								list5.Add(item7);
								int width2 = a8.Width;
								int num34 = num30;
								a8.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + width2 + "," + num34 + "); ");
							}
						}
						break;
					}
					case 2:
					{
						string[] array9 = rangesAndBoundingRect.Split(';');
						for (int num35 = 0; num35 < 2; num35++)
						{
							string[] array10 = array9[num35].Split(',');
							int num36 = int.Parse(array10[0]);
							int num37 = int.Parse(array10[1]);
							int.Parse(array10[2]);
							int num38 = int.Parse(array10[3]);
							int.Parse(array10[4]);
							int.Parse(array10[5]);
							List<NOTE_ARRAYLIST> list6 = rightNoteList;
							bool flag8 = false;
							for (int num39 = 0; num39 < list6.Count; num39++)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST10 = Enumerable.ElementAt(list6, num39);
								for (int num40 = 0; num40 < nOTE_ARRAYLIST10.items.Count; num40++)
								{
									START_END_PAIR sTART_END_PAIR11 = Enumerable.ElementAt(nOTE_ARRAYLIST10.items, num40);
									switch (num35)
									{
									case 0:
										if (sTART_END_PAIR11.start == num36)
										{
											sTART_END_PAIR11.end = num37;
											flag8 = true;
										}
										break;
									case 1:
										if (sTART_END_PAIR11.end == num37)
										{
											sTART_END_PAIR11.start = num36;
											flag8 = true;
										}
										break;
									}
									if (flag8)
									{
										nOTE_ARRAYLIST10.items.RemoveAt(num40);
										nOTE_ARRAYLIST10.items.Add(sTART_END_PAIR11);
										break;
									}
								}
								if (flag8)
								{
									break;
								}
							}
							if (flag8)
							{
								continue;
							}
							START_END_PAIR sTART_END_PAIR12 = new START_END_PAIR();
							sTART_END_PAIR12.start = num36;
							sTART_END_PAIR12.end = num37;
							sTART_END_PAIR12.selectText = selectText;
							foreach (NOTE_ARRAYLIST item19 in list6)
							{
								if (Math.Abs(item19.top - num38) <= 30)
								{
									item19.items.Add(sTART_END_PAIR12);
									flag8 = true;
									break;
								}
							}
							if (!flag8)
							{
								NOTE_ARRAYLIST item8 = default(NOTE_ARRAYLIST);
								item8.top = num38;
								item8.items = new List<START_END_PAIR>();
								item8.items.Add(sTART_END_PAIR12);
								list6.Add(item8);
								int num41 = 0;
								int num42 = num38;
								a8.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num41 + "," + num42 + "); ");
							}
						}
						break;
					}
					case 3:
					{
						string[] array6 = rangesAndBoundingRect.Split(';');
						for (int num20 = 0; num20 < 3; num20++)
						{
							string[] array7 = array6[num20].Split(',');
							int num21 = int.Parse(array7[0]);
							int num22 = int.Parse(array7[1]);
							int.Parse(array7[2]);
							int num23 = int.Parse(array7[3]);
							int.Parse(array7[4]);
							int.Parse(array7[5]);
							List<NOTE_ARRAYLIST> list4 = rightNoteList;
							bool flag5 = false;
							for (int num24 = 0; num24 < list4.Count; num24++)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST6 = Enumerable.ElementAt(list4, num24);
								for (int num25 = 0; num25 < nOTE_ARRAYLIST6.items.Count; num25++)
								{
									START_END_PAIR sTART_END_PAIR7 = Enumerable.ElementAt(nOTE_ARRAYLIST6.items, num25);
									switch (num20)
									{
									case 0:
										if (sTART_END_PAIR7.start == num21)
										{
											sTART_END_PAIR7.end = num22;
											flag5 = true;
										}
										break;
									case 2:
										if (sTART_END_PAIR7.end == num22)
										{
											sTART_END_PAIR7.start = num21;
											flag5 = true;
										}
										break;
									}
									if (flag5)
									{
										nOTE_ARRAYLIST6.items.RemoveAt(num25);
										nOTE_ARRAYLIST6.items.Add(sTART_END_PAIR7);
										break;
									}
								}
								if (flag5)
								{
									break;
								}
							}
							if (flag5)
							{
								continue;
							}
							START_END_PAIR sTART_END_PAIR8 = new START_END_PAIR();
							sTART_END_PAIR8.start = num21;
							sTART_END_PAIR8.end = num22;
							sTART_END_PAIR8.selectText = selectText;
							foreach (NOTE_ARRAYLIST item20 in list4)
							{
								if (Math.Abs(item20.top - num23) <= 30)
								{
									item20.items.Add(sTART_END_PAIR8);
									flag5 = true;
									break;
								}
							}
							if (!flag5)
							{
								NOTE_ARRAYLIST item5 = default(NOTE_ARRAYLIST);
								item5.top = num23;
								item5.items = new List<START_END_PAIR>();
								item5.items.Add(sTART_END_PAIR8);
								list4.Add(item5);
								int num26 = 0;
								int num27 = num23;
								a8.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num26 + "," + num27 + "); ");
							}
						}
						break;
					}
					}
					return;
				}
				if (webviewName == "LEFT_WEBVIEW")
				{
					switch (newCount)
					{
					case 1:
					{
						string[] array27 = rangesAndBoundingRect.Split(',');
						int num75 = int.Parse(array27[0]);
						int num76 = int.Parse(array27[1]);
						int num77 = int.Parse(array27[2]);
						int num78 = int.Parse(array27[3]);
						int num79 = int.Parse(array27[4]);
						int.Parse(array27[5]);
						int num80 = 0;
						int num81 = 0;
						int num82 = 0;
						int num83 = 0;
						if (!bj && bk)
						{
							num80 = (num77 + form.jsObj1.CurLeft) % ((form.actual_webkit_column_width + 50 + 50) * bi);
							num81 = (num77 + form.jsObj1.CurLeft) / ((form.actual_webkit_column_width + 50 + 50) * bi);
							if (num80 > form.actual_webkit_column_width + 50 + 50)
							{
								num82 = (num81 + 1) * ((form.actual_webkit_column_width + 50 + 50) * bi);
								num82 -= 50;
							}
							else
							{
								num82 = num81 * ((form.actual_webkit_column_width + 50 + 50) * bi);
								num82 += 20;
							}
						}
						else if (bj && !bk)
						{
							num81 = (num78 + form.jsObj1.CurTop) / (form.actual_webkit_column_height + 50 + 50);
							num83 = num81 * (form.actual_webkit_column_height + 50 + 50);
							num83 += 20;
						}
						List<NOTE_ARRAYLIST> list15 = leftNoteList;
						START_END_PAIR sTART_END_PAIR18 = new START_END_PAIR();
						sTART_END_PAIR18.start = num75;
						sTART_END_PAIR18.end = num76;
						sTART_END_PAIR18.selectText = selectText;
						bool flag13 = false;
						string text6 = "";
						List<int> list16 = new List<int>();
						for (int num84 = 0; num84 < list15.Count; num84++)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST25 = Enumerable.ElementAt(list15, num84);
							List<int> list17 = new List<int>();
							for (int num85 = 0; num85 < nOTE_ARRAYLIST25.items.Count; num85++)
							{
								START_END_PAIR sTART_END_PAIR19 = Enumerable.ElementAt(nOTE_ARRAYLIST25.items, num85);
								if (sTART_END_PAIR19.start >= num75 && sTART_END_PAIR19.end <= num76)
								{
									list17.Add(num85);
									text6 += sTART_END_PAIR19.noteText;
								}
							}
							for (int num85 = list17.Count - 1; num85 >= 0; num85--)
							{
								nOTE_ARRAYLIST25.items.RemoveAt(Enumerable.ElementAt(list17, num85));
							}
							if (nOTE_ARRAYLIST25.items.Count == 0)
							{
								list16.Add(num84);
							}
						}
						for (int num84 = list16.Count - 1; num84 >= 0; num84--)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST26 = Enumerable.ElementAt(list15, Enumerable.ElementAt(list16, num84));
							a7.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST26.left + "," + nOTE_ARRAYLIST26.top + "); ");
							list15.RemoveAt(Enumerable.ElementAt(list16, num84));
						}
						sTART_END_PAIR18.noteText = "";
						sTART_END_PAIR18.noteText += text6;
						for (int num84 = 0; num84 < list15.Count; num84++)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST27 = Enumerable.ElementAt(list15, num84);
							if (!bj && bk)
							{
								if (nOTE_ARRAYLIST27.left == num82 && Math.Abs(nOTE_ARRAYLIST27.top - num78) <= 30)
								{
									nOTE_ARRAYLIST27.items.Add(sTART_END_PAIR18);
									flag13 = true;
									break;
								}
							}
							else if (bj && !bk && nOTE_ARRAYLIST27.top == num83 && Math.Abs(nOTE_ARRAYLIST27.left + 30 - num79) <= 30)
							{
								nOTE_ARRAYLIST27.items.Add(sTART_END_PAIR18);
								flag13 = true;
								break;
							}
						}
						if (!flag13)
						{
							NOTE_ARRAYLIST item12 = default(NOTE_ARRAYLIST);
							if (!bj && bk)
							{
								item12.top = num78;
								item12.left = num82;
							}
							else if (bj && !bk)
							{
								item12.top = num83;
								item12.left = num79 - 30;
							}
							item12.items = new List<START_END_PAIR>();
							item12.items.Add(sTART_END_PAIR18);
							list15.Add(item12);
							if (!bj && bk)
							{
								int num86 = num82;
								int num87 = num78;
								a7.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num86 + "," + num87 + "); ");
							}
							else if (bj && !bk)
							{
								int num88 = num79 - 30;
								int num89 = num83;
								a7.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num88 + "," + num89 + "); ");
							}
						}
						break;
					}
					case 2:
					{
						string[] array19 = rangesAndBoundingRect.Split(';');
						int[] array20 = new int[2];
						int[] array21 = new int[2];
						int[] array22 = new int[2];
						int[] array23 = new int[2];
						int[] array24 = new int[2];
						int[] array25 = new int[2];
						int num55 = -1;
						for (int num56 = 0; num56 < 2; num56++)
						{
							string[] array26 = array19[num56].Split(',');
							array20[num56] = int.Parse(array26[0]);
							array21[num56] = int.Parse(array26[1]);
							array22[num56] = int.Parse(array26[2]);
							array23[num56] = int.Parse(array26[3]);
							array24[num56] = int.Parse(array26[4]);
							array25[num56] = int.Parse(array26[5]);
						}
						List<NOTE_ARRAYLIST> list10 = leftNoteList;
						bool flag10 = false;
						for (int num56 = 0; num56 < list10.Count; num56++)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST16 = Enumerable.ElementAt(list10, num56);
							for (int num57 = 0; num57 < nOTE_ARRAYLIST16.items.Count; num57++)
							{
								START_END_PAIR sTART_END_PAIR15 = Enumerable.ElementAt(nOTE_ARRAYLIST16.items, num57);
								if (sTART_END_PAIR15.start == array20[0] && sTART_END_PAIR15.end > array21[0])
								{
									sTART_END_PAIR15.end = array21[0];
									flag10 = true;
									nOTE_ARRAYLIST16.items.RemoveAt(num57);
									nOTE_ARRAYLIST16.items.Add(sTART_END_PAIR15);
									num55 = 0;
									break;
								}
								if (sTART_END_PAIR15.end == array21[1] && sTART_END_PAIR15.start < array20[1])
								{
									sTART_END_PAIR15.start = array20[1];
									flag10 = true;
									nOTE_ARRAYLIST16.items.RemoveAt(num57);
									num55 = 1;
									break;
								}
							}
							if (flag10)
							{
								break;
							}
						}
						if (flag10 && num55 == 0)
						{
							List<int> list11 = new List<int>();
							for (int num56 = 0; num56 < list10.Count; num56++)
							{
								if (Enumerable.ElementAt(list10, num56).items.Count == 0)
								{
									list11.Add(num56);
								}
							}
							for (int num56 = list11.Count - 1; num56 >= 0; num56--)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST17 = Enumerable.ElementAt(list10, Enumerable.ElementAt(list11, num56));
								a7.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST17.left + "," + nOTE_ARRAYLIST17.top + "); ");
								list10.RemoveAt(Enumerable.ElementAt(list11, num56));
							}
							int num58 = 0;
							int num59 = 0;
							int num60 = 0;
							int num61 = 0;
							if (!bj && bk)
							{
								num58 = (array22[1] + form.jsObj1.CurLeft) % ((form.actual_webkit_column_width + 50 + 50) * bi);
								num59 = (array22[1] + form.jsObj1.CurLeft) / ((form.actual_webkit_column_width + 50 + 50) * bi);
								if (num58 > form.actual_webkit_column_width + 50 + 50)
								{
									num60 = (num59 + 1) * ((form.actual_webkit_column_width + 50 + 50) * bi);
									num60 -= 50;
								}
								else
								{
									num60 = num59 * ((form.actual_webkit_column_width + 50 + 50) * bi);
									num60 += 20;
								}
							}
							else if (bj && !bk)
							{
								int num137 = array23[1];
								num59 = (array23[1] + form.jsObj1.CurTop) / (form.actual_webkit_column_height + 50 + 50);
								num61 = num59 * (form.actual_webkit_column_height + 50 + 50);
								num61 += 20;
							}
							START_END_PAIR sTART_END_PAIR15 = new START_END_PAIR();
							sTART_END_PAIR15.start = array20[1];
							sTART_END_PAIR15.end = array21[1];
							string text3 = "";
							string text4 = "";
							for (int num56 = 0; num56 < list10.Count; num56++)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST18 = Enumerable.ElementAt(list10, num56);
								List<int> list12 = new List<int>();
								for (int num57 = 0; num57 < nOTE_ARRAYLIST18.items.Count; num57++)
								{
									START_END_PAIR sTART_END_PAIR16 = Enumerable.ElementAt(nOTE_ARRAYLIST18.items, num57);
									if (sTART_END_PAIR16.start >= array20[1] && sTART_END_PAIR16.end <= array21[1])
									{
										list12.Add(num57);
										text3 += sTART_END_PAIR16.noteText;
										text4 += sTART_END_PAIR16.selectText;
									}
								}
								for (int num57 = list12.Count - 1; num57 >= 0; num57--)
								{
									nOTE_ARRAYLIST18.items.RemoveAt(Enumerable.ElementAt(list12, num57));
								}
								if (nOTE_ARRAYLIST18.items.Count == 0)
								{
									list11.Add(num56);
								}
							}
							for (int num56 = list11.Count - 1; num56 >= 0; num56--)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST19 = Enumerable.ElementAt(list10, Enumerable.ElementAt(list11, num56));
								a7.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST19.left + "," + nOTE_ARRAYLIST19.top + "); ");
								list10.RemoveAt(Enumerable.ElementAt(list11, num56));
							}
							sTART_END_PAIR15.noteText = "";
							sTART_END_PAIR15.noteText += text3;
							sTART_END_PAIR15.selectText = text4;
							bool flag11 = false;
							for (int num56 = 0; num56 < list10.Count; num56++)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST20 = Enumerable.ElementAt(list10, num56);
								if (!bj && bk)
								{
									if (nOTE_ARRAYLIST20.left == num60 && Math.Abs(nOTE_ARRAYLIST20.top - array23[1]) <= 30)
									{
										nOTE_ARRAYLIST20.items.Add(sTART_END_PAIR15);
										flag11 = true;
										break;
									}
								}
								else if (bj && !bk && nOTE_ARRAYLIST20.top == num61 && Math.Abs(nOTE_ARRAYLIST20.left + 30 - array24[1]) <= 30)
								{
									nOTE_ARRAYLIST20.items.Add(sTART_END_PAIR15);
									flag11 = true;
									break;
								}
							}
							if (!flag11)
							{
								NOTE_ARRAYLIST item10 = default(NOTE_ARRAYLIST);
								if (!bj && bk)
								{
									item10.top = array23[1];
									item10.left = num60;
								}
								else if (bj && !bk)
								{
									item10.top = num61;
									item10.left = array24[1] - 30;
								}
								item10.items = new List<START_END_PAIR>();
								item10.items.Add(sTART_END_PAIR15);
								list10.Add(item10);
								if (!bj && bk)
								{
									int num62 = num60;
									int num63 = array23[1];
									a7.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num62 + "," + num63 + "); ");
								}
								else if (bj && !bk)
								{
									int num64 = array24[1] - 30;
									int num65 = num61;
									a7.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num64 + "," + num65 + "); ");
								}
							}
						}
						else
						{
							if (!flag10 || num55 != 1)
							{
								break;
							}
							List<int> list13 = new List<int>();
							for (int num56 = 0; num56 < list10.Count; num56++)
							{
								if (Enumerable.ElementAt(list10, num56).items.Count == 0)
								{
									list13.Add(num56);
								}
							}
							for (int num56 = list13.Count - 1; num56 >= 0; num56--)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST21 = Enumerable.ElementAt(list10, Enumerable.ElementAt(list13, num56));
								a7.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST21.left + "," + nOTE_ARRAYLIST21.top + "); ");
								list10.RemoveAt(Enumerable.ElementAt(list13, num56));
							}
							for (int num66 = 0; num66 < 2; num66++)
							{
								int num67 = 0;
								int num68 = 0;
								int num69 = 0;
								int num70 = 0;
								if (!bj && bk)
								{
									num67 = (array22[num66] + form.jsObj1.CurLeft) % ((form.actual_webkit_column_width + 50 + 50) * bi);
									num68 = (array22[num66] + form.jsObj1.CurLeft) / ((form.actual_webkit_column_width + 50 + 50) * bi);
									if (num67 > form.actual_webkit_column_width + 50 + 50)
									{
										num69 = (num68 + 1) * ((form.actual_webkit_column_width + 50 + 50) * bi);
										num69 -= 50;
									}
									else
									{
										num69 = num68 * ((form.actual_webkit_column_width + 50 + 50) * bi);
										num69 += 20;
									}
								}
								else if (bj && !bk)
								{
									int num138 = array23[num66];
									num68 = (array23[num66] + form.jsObj1.CurTop) / (form.actual_webkit_column_height + 50 + 50);
									num70 = num68 * (form.actual_webkit_column_height + 50 + 50);
									num70 += 20;
								}
								START_END_PAIR sTART_END_PAIR15 = new START_END_PAIR();
								sTART_END_PAIR15.start = array20[num66];
								sTART_END_PAIR15.end = array21[num66];
								string text5 = "";
								string str = "";
								if (num66 == 0)
								{
									list13.Clear();
									for (int num56 = 0; num56 < list10.Count; num56++)
									{
										NOTE_ARRAYLIST nOTE_ARRAYLIST22 = Enumerable.ElementAt(list10, num56);
										List<int> list14 = new List<int>();
										for (int num57 = 0; num57 < nOTE_ARRAYLIST22.items.Count; num57++)
										{
											START_END_PAIR sTART_END_PAIR17 = Enumerable.ElementAt(nOTE_ARRAYLIST22.items, num57);
											if (sTART_END_PAIR17.start >= array20[num66] && sTART_END_PAIR17.end <= array21[num66])
											{
												list14.Add(num57);
												text5 += sTART_END_PAIR17.noteText;
												str += sTART_END_PAIR17.selectText;
											}
										}
										for (int num57 = list14.Count - 1; num57 >= 0; num57--)
										{
											nOTE_ARRAYLIST22.items.RemoveAt(Enumerable.ElementAt(list14, num57));
										}
										if (nOTE_ARRAYLIST22.items.Count == 0)
										{
											list13.Add(num56);
										}
									}
									for (int num56 = list13.Count - 1; num56 >= 0; num56--)
									{
										NOTE_ARRAYLIST nOTE_ARRAYLIST23 = Enumerable.ElementAt(list10, Enumerable.ElementAt(list13, num56));
										a7.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST23.left + "," + nOTE_ARRAYLIST23.top + "); ");
										list10.RemoveAt(Enumerable.ElementAt(list13, num56));
									}
								}
								sTART_END_PAIR15.noteText = "";
								sTART_END_PAIR15.noteText += text5;
								sTART_END_PAIR15.selectText = selectText;
								bool flag12 = false;
								for (int num56 = 0; num56 < list10.Count; num56++)
								{
									NOTE_ARRAYLIST nOTE_ARRAYLIST24 = Enumerable.ElementAt(list10, num56);
									if (!bj && bk)
									{
										if (nOTE_ARRAYLIST24.left == num69 && Math.Abs(nOTE_ARRAYLIST24.top - array23[num66]) <= 30)
										{
											nOTE_ARRAYLIST24.items.Add(sTART_END_PAIR15);
											flag12 = true;
											break;
										}
									}
									else if (bj && !bk && nOTE_ARRAYLIST24.top == num70 && Math.Abs(nOTE_ARRAYLIST24.left + 30 - array24[num66]) <= 30)
									{
										nOTE_ARRAYLIST24.items.Add(sTART_END_PAIR15);
										flag12 = true;
										break;
									}
								}
								if (!flag12)
								{
									NOTE_ARRAYLIST item11 = default(NOTE_ARRAYLIST);
									if (!bj && bk)
									{
										item11.top = array23[num66];
										item11.left = num69;
									}
									else if (bj && !bk)
									{
										item11.top = num70;
										item11.left = array24[num66] - 30;
									}
									item11.items = new List<START_END_PAIR>();
									item11.items.Add(sTART_END_PAIR15);
									list10.Add(item11);
									if (!bj && bk)
									{
										int num71 = num69;
										int num72 = array23[num66];
										a7.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num71 + "," + num72 + "); ");
									}
									else if (bj && !bk)
									{
										int num73 = array24[num66] - 30;
										int num74 = num70;
										a7.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num73 + "," + num74 + "); ");
									}
								}
							}
						}
						break;
					}
					case 3:
					{
						string[] array11 = rangesAndBoundingRect.Split(';');
						int[] array12 = new int[3];
						int[] array13 = new int[3];
						int[] array14 = new int[3];
						int[] array15 = new int[3];
						int[] array16 = new int[3];
						int[] array17 = new int[3];
						for (int num43 = 0; num43 < 3; num43++)
						{
							string[] array18 = array11[num43].Split(',');
							array12[num43] = int.Parse(array18[0]);
							array13[num43] = int.Parse(array18[1]);
							array14[num43] = int.Parse(array18[2]);
							array15[num43] = int.Parse(array18[3]);
							array16[num43] = int.Parse(array18[4]);
							array17[num43] = int.Parse(array18[5]);
						}
						List<NOTE_ARRAYLIST> list7 = leftNoteList;
						int num44 = 0;
						for (int num43 = 0; num43 < list7.Count; num43++)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST11 = Enumerable.ElementAt(list7, num43);
							for (int num45 = 0; num45 < nOTE_ARRAYLIST11.items.Count; num45++)
							{
								START_END_PAIR sTART_END_PAIR13 = Enumerable.ElementAt(nOTE_ARRAYLIST11.items, num45);
								if (sTART_END_PAIR13.start == array12[0] && sTART_END_PAIR13.end > array13[0])
								{
									sTART_END_PAIR13.end = array13[0];
									nOTE_ARRAYLIST11.items.RemoveAt(num45);
									nOTE_ARRAYLIST11.items.Add(sTART_END_PAIR13);
									num44++;
									if (num44 == 2)
									{
										break;
									}
								}
								else if (sTART_END_PAIR13.end == array13[2] && sTART_END_PAIR13.start < array12[2])
								{
									nOTE_ARRAYLIST11.items.RemoveAt(num45);
									num44++;
									if (num44 == 2)
									{
										break;
									}
								}
							}
							if (num44 == 2)
							{
								break;
							}
						}
						if (num44 != 2 && num44 != 1)
						{
							break;
						}
						List<int> list8 = new List<int>();
						for (int num43 = 0; num43 < list7.Count; num43++)
						{
							if (Enumerable.ElementAt(list7, num43).items.Count == 0)
							{
								list8.Add(num43);
							}
						}
						for (int num43 = list8.Count - 1; num43 >= 0; num43--)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST12 = Enumerable.ElementAt(list7, Enumerable.ElementAt(list8, num43));
							a7.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST12.left + "," + nOTE_ARRAYLIST12.top + "); ");
							list7.RemoveAt(Enumerable.ElementAt(list8, num43));
						}
						for (int num46 = 1; num46 < 3; num46++)
						{
							int num47 = 0;
							int num48 = 0;
							int num49 = 0;
							int num50 = 0;
							if (!bj && bk)
							{
								num47 = (array14[num46] + form.jsObj1.CurLeft) % ((form.actual_webkit_column_width + 50 + 50) * bi);
								num48 = (array14[num46] + form.jsObj1.CurLeft) / ((form.actual_webkit_column_width + 50 + 50) * bi);
								if (num47 > form.actual_webkit_column_width + 50 + 50)
								{
									num49 = (num48 + 1) * ((form.actual_webkit_column_width + 50 + 50) * bi);
									num49 -= 50;
								}
								else
								{
									num49 = num48 * ((form.actual_webkit_column_width + 50 + 50) * bi);
									num49 += 20;
								}
							}
							else if (bj && !bk)
							{
								int num139 = array15[num46];
								num48 = (array15[num46] + form.jsObj1.CurTop) / (form.actual_webkit_column_height + 50 + 50);
								num50 = num48 * (form.actual_webkit_column_height + 50 + 50);
								num50 += 20;
							}
							START_END_PAIR sTART_END_PAIR13 = new START_END_PAIR();
							sTART_END_PAIR13.start = array12[num46];
							sTART_END_PAIR13.end = array13[num46];
							string text = "";
							string text2 = "";
							if (num46 == 1)
							{
								list8.Clear();
								for (int num43 = 0; num43 < list7.Count; num43++)
								{
									NOTE_ARRAYLIST nOTE_ARRAYLIST13 = Enumerable.ElementAt(list7, num43);
									List<int> list9 = new List<int>();
									for (int num45 = 0; num45 < nOTE_ARRAYLIST13.items.Count; num45++)
									{
										START_END_PAIR sTART_END_PAIR14 = Enumerable.ElementAt(nOTE_ARRAYLIST13.items, num45);
										if (sTART_END_PAIR14.start >= array12[num46] && sTART_END_PAIR14.end <= array13[num46])
										{
											list9.Add(num45);
											text += sTART_END_PAIR14.noteText;
											text2 += sTART_END_PAIR14.selectText;
										}
									}
									for (int num45 = list9.Count - 1; num45 >= 0; num45--)
									{
										nOTE_ARRAYLIST13.items.RemoveAt(Enumerable.ElementAt(list9, num45));
									}
									if (nOTE_ARRAYLIST13.items.Count == 0)
									{
										list8.Add(num43);
									}
								}
								for (int num43 = list8.Count - 1; num43 >= 0; num43--)
								{
									NOTE_ARRAYLIST nOTE_ARRAYLIST14 = Enumerable.ElementAt(list7, Enumerable.ElementAt(list8, num43));
									a7.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST14.left + "," + nOTE_ARRAYLIST14.top + "); ");
									list7.RemoveAt(Enumerable.ElementAt(list8, num43));
								}
							}
							sTART_END_PAIR13.noteText = "";
							sTART_END_PAIR13.noteText += text;
							sTART_END_PAIR13.selectText = text2;
							bool flag9 = false;
							for (int num43 = 0; num43 < list7.Count; num43++)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST15 = Enumerable.ElementAt(list7, num43);
								if (!bj && bk)
								{
									if (nOTE_ARRAYLIST15.left == num49 && Math.Abs(nOTE_ARRAYLIST15.top - array15[num46]) <= 30)
									{
										nOTE_ARRAYLIST15.items.Add(sTART_END_PAIR13);
										flag9 = true;
										break;
									}
								}
								else if (bj && !bk && nOTE_ARRAYLIST15.top == num50 && Math.Abs(nOTE_ARRAYLIST15.left + 30 - array16[num46]) <= 30)
								{
									nOTE_ARRAYLIST15.items.Add(sTART_END_PAIR13);
									flag9 = true;
									break;
								}
							}
							if (!flag9)
							{
								NOTE_ARRAYLIST item9 = default(NOTE_ARRAYLIST);
								if (!bj && bk)
								{
									item9.top = array15[num46];
									item9.left = num49;
								}
								else if (bj && !bk)
								{
									item9.top = num50;
									item9.left = array16[num46] - 30;
								}
								item9.items = new List<START_END_PAIR>();
								item9.items.Add(sTART_END_PAIR13);
								list7.Add(item9);
								if (!bj && bk)
								{
									int num51 = num49;
									int num52 = array15[num46];
									a7.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num51 + "," + num52 + "); ");
								}
								else if (bj && !bk)
								{
									int num53 = array16[num46] - 30;
									int num54 = num50;
									a7.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num53 + "," + num54 + "); ");
								}
							}
						}
						break;
					}
					}
					return;
				}
				switch (newCount)
				{
				case 1:
				{
					string[] array44 = rangesAndBoundingRect.Split(',');
					int num122 = int.Parse(array44[0]);
					int num123 = int.Parse(array44[1]);
					int num124 = int.Parse(array44[2]);
					int num125 = int.Parse(array44[3]);
					int num126 = int.Parse(array44[4]);
					int.Parse(array44[5]);
					int num127 = 0;
					int num128 = 0;
					int num129 = 0;
					int num130 = 0;
					if (!bj && bk)
					{
						num127 = (num124 + form.jsObj2.CurLeft) % ((form.actual_webkit_column_width + 50 + 50) * bi);
						num128 = (num124 + form.jsObj2.CurLeft) / ((form.actual_webkit_column_width + 50 + 50) * bi);
						if (num127 > form.actual_webkit_column_width + 50 + 50)
						{
							num129 = (num128 + 1) * ((form.actual_webkit_column_width + 50 + 50) * bi);
							num129 -= 50;
						}
						else
						{
							num129 = num128 * ((form.actual_webkit_column_width + 50 + 50) * bi);
							num129 += 20;
						}
					}
					else if (bj && !bk)
					{
						num128 = (num125 + form.jsObj2.CurTop) / (form.actual_webkit_column_height + 50 + 50);
						num130 = num128 * (form.actual_webkit_column_height + 50 + 50);
						num130 += 20;
					}
					List<NOTE_ARRAYLIST> list26 = rightNoteList;
					START_END_PAIR sTART_END_PAIR25 = new START_END_PAIR();
					sTART_END_PAIR25.start = num122;
					sTART_END_PAIR25.end = num123;
					sTART_END_PAIR25.selectText = selectText;
					bool flag18 = false;
					string text13 = "";
					List<int> list27 = new List<int>();
					for (int num131 = 0; num131 < list26.Count; num131++)
					{
						NOTE_ARRAYLIST nOTE_ARRAYLIST42 = Enumerable.ElementAt(list26, num131);
						List<int> list28 = new List<int>();
						for (int num132 = 0; num132 < nOTE_ARRAYLIST42.items.Count; num132++)
						{
							START_END_PAIR sTART_END_PAIR26 = Enumerable.ElementAt(nOTE_ARRAYLIST42.items, num132);
							if (sTART_END_PAIR26.start >= num122 && sTART_END_PAIR26.end <= num123)
							{
								list28.Add(num132);
								text13 += sTART_END_PAIR26.noteText;
							}
						}
						for (int num132 = list28.Count - 1; num132 >= 0; num132--)
						{
							nOTE_ARRAYLIST42.items.RemoveAt(Enumerable.ElementAt(list28, num132));
						}
						if (nOTE_ARRAYLIST42.items.Count == 0)
						{
							list27.Add(num131);
						}
					}
					for (int num131 = list27.Count - 1; num131 >= 0; num131--)
					{
						NOTE_ARRAYLIST nOTE_ARRAYLIST43 = Enumerable.ElementAt(list26, Enumerable.ElementAt(list27, num131));
						a8.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST43.left + "," + nOTE_ARRAYLIST43.top + "); ");
						list26.RemoveAt(Enumerable.ElementAt(list27, num131));
					}
					sTART_END_PAIR25.noteText = "";
					sTART_END_PAIR25.noteText += text13;
					for (int num131 = 0; num131 < list26.Count; num131++)
					{
						NOTE_ARRAYLIST nOTE_ARRAYLIST44 = Enumerable.ElementAt(list26, num131);
						if (!bj && bk)
						{
							if (nOTE_ARRAYLIST44.left == num129 && Math.Abs(nOTE_ARRAYLIST44.top - num125) <= 30)
							{
								nOTE_ARRAYLIST44.items.Add(sTART_END_PAIR25);
								flag18 = true;
								break;
							}
						}
						else if (bj && !bk && nOTE_ARRAYLIST44.top == num130 && Math.Abs(nOTE_ARRAYLIST44.left + 30 - num126) <= 30)
						{
							nOTE_ARRAYLIST44.items.Add(sTART_END_PAIR25);
							flag18 = true;
							break;
						}
					}
					if (!flag18)
					{
						NOTE_ARRAYLIST item16 = default(NOTE_ARRAYLIST);
						if (!bj && bk)
						{
							item16.top = num125;
							item16.left = num129;
						}
						else if (bj && !bk)
						{
							item16.top = num130;
							item16.left = num126 - 30;
						}
						item16.items = new List<START_END_PAIR>();
						item16.items.Add(sTART_END_PAIR25);
						list26.Add(item16);
						if (!bj && bk)
						{
							int num133 = num129;
							int num134 = num125;
							a8.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num133 + "," + num134 + "); ");
						}
						else if (bj && !bk)
						{
							int num135 = num126 - 30;
							int num136 = num130;
							a8.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num135 + "," + num136 + "); ");
						}
					}
					break;
				}
				case 2:
				{
					string[] array36 = rangesAndBoundingRect.Split(';');
					int[] array37 = new int[2];
					int[] array38 = new int[2];
					int[] array39 = new int[2];
					int[] array40 = new int[2];
					int[] array41 = new int[2];
					int[] array42 = new int[2];
					int num102 = -1;
					for (int num103 = 0; num103 < 2; num103++)
					{
						string[] array43 = array36[num103].Split(',');
						array37[num103] = int.Parse(array43[0]);
						array38[num103] = int.Parse(array43[1]);
						array39[num103] = int.Parse(array43[2]);
						array40[num103] = int.Parse(array43[3]);
						array41[num103] = int.Parse(array43[4]);
						array42[num103] = int.Parse(array43[5]);
					}
					List<NOTE_ARRAYLIST> list21 = rightNoteList;
					bool flag15 = false;
					for (int num103 = 0; num103 < list21.Count; num103++)
					{
						NOTE_ARRAYLIST nOTE_ARRAYLIST33 = Enumerable.ElementAt(list21, num103);
						for (int num104 = 0; num104 < nOTE_ARRAYLIST33.items.Count; num104++)
						{
							START_END_PAIR sTART_END_PAIR22 = Enumerable.ElementAt(nOTE_ARRAYLIST33.items, num104);
							if (sTART_END_PAIR22.start == array37[0] && sTART_END_PAIR22.end > array38[0])
							{
								sTART_END_PAIR22.end = array38[0];
								flag15 = true;
								nOTE_ARRAYLIST33.items.RemoveAt(num104);
								nOTE_ARRAYLIST33.items.Add(sTART_END_PAIR22);
								num102 = 0;
								break;
							}
							if (sTART_END_PAIR22.end == array38[1] && sTART_END_PAIR22.start < array37[1])
							{
								sTART_END_PAIR22.start = array37[1];
								flag15 = true;
								nOTE_ARRAYLIST33.items.RemoveAt(num104);
								num102 = 1;
								break;
							}
						}
						if (flag15)
						{
							break;
						}
					}
					if (flag15 && num102 == 0)
					{
						List<int> list22 = new List<int>();
						for (int num103 = 0; num103 < list21.Count; num103++)
						{
							if (Enumerable.ElementAt(list21, num103).items.Count == 0)
							{
								list22.Add(num103);
							}
						}
						for (int num103 = list22.Count - 1; num103 >= 0; num103--)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST34 = Enumerable.ElementAt(list21, Enumerable.ElementAt(list22, num103));
							a8.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST34.left + "," + nOTE_ARRAYLIST34.top + "); ");
							list21.RemoveAt(Enumerable.ElementAt(list22, num103));
						}
						int num105 = 0;
						int num106 = 0;
						int num107 = 0;
						int num108 = 0;
						if (!bj && bk)
						{
							num105 = (array39[1] + form.jsObj2.CurLeft) % ((form.actual_webkit_column_width + 50 + 50) * bi);
							num106 = (array39[1] + form.jsObj2.CurLeft) / ((form.actual_webkit_column_width + 50 + 50) * bi);
							if (num105 > form.actual_webkit_column_width + 50 + 50)
							{
								num107 = (num106 + 1) * ((form.actual_webkit_column_width + 50 + 50) * bi);
								num107 -= 50;
							}
							else
							{
								num107 = num106 * ((form.actual_webkit_column_width + 50 + 50) * bi);
								num107 += 20;
							}
						}
						else if (bj && !bk)
						{
							int num140 = array40[1];
							num106 = (array40[1] + form.jsObj2.CurTop) / (form.actual_webkit_column_height + 50 + 50);
							num108 = num106 * (form.actual_webkit_column_height + 50 + 50);
							num108 += 20;
						}
						START_END_PAIR sTART_END_PAIR22 = new START_END_PAIR();
						sTART_END_PAIR22.start = array37[1];
						sTART_END_PAIR22.end = array38[1];
						string text9 = "";
						string text10 = "";
						for (int num103 = 0; num103 < list21.Count; num103++)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST35 = Enumerable.ElementAt(list21, num103);
							List<int> list23 = new List<int>();
							for (int num104 = 0; num104 < nOTE_ARRAYLIST35.items.Count; num104++)
							{
								START_END_PAIR sTART_END_PAIR23 = Enumerable.ElementAt(nOTE_ARRAYLIST35.items, num104);
								if (sTART_END_PAIR23.start >= array37[1] && sTART_END_PAIR23.end <= array38[1])
								{
									list23.Add(num104);
									text9 += sTART_END_PAIR23.noteText;
									text10 += sTART_END_PAIR23.selectText;
								}
							}
							for (int num104 = list23.Count - 1; num104 >= 0; num104--)
							{
								nOTE_ARRAYLIST35.items.RemoveAt(Enumerable.ElementAt(list23, num104));
							}
							if (nOTE_ARRAYLIST35.items.Count == 0)
							{
								list22.Add(num103);
							}
						}
						for (int num103 = list22.Count - 1; num103 >= 0; num103--)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST36 = Enumerable.ElementAt(list21, Enumerable.ElementAt(list22, num103));
							a8.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST36.left + "," + nOTE_ARRAYLIST36.top + "); ");
							list21.RemoveAt(Enumerable.ElementAt(list22, num103));
						}
						sTART_END_PAIR22.noteText = "";
						sTART_END_PAIR22.noteText += text9;
						sTART_END_PAIR22.selectText = text10;
						bool flag16 = false;
						for (int num103 = 0; num103 < list21.Count; num103++)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST37 = Enumerable.ElementAt(list21, num103);
							if (!bj && bk)
							{
								if (nOTE_ARRAYLIST37.left == num107 && Math.Abs(nOTE_ARRAYLIST37.top - array40[1]) <= 30)
								{
									nOTE_ARRAYLIST37.items.Add(sTART_END_PAIR22);
									flag16 = true;
									break;
								}
							}
							else if (bj && !bk && nOTE_ARRAYLIST37.top == num108 && Math.Abs(nOTE_ARRAYLIST37.left + 30 - array41[1]) <= 30)
							{
								nOTE_ARRAYLIST37.items.Add(sTART_END_PAIR22);
								flag16 = true;
								break;
							}
						}
						if (!flag16)
						{
							NOTE_ARRAYLIST item14 = default(NOTE_ARRAYLIST);
							if (!bj && bk)
							{
								item14.top = array40[1];
								item14.left = num107;
							}
							else if (bj && !bk)
							{
								item14.top = num108;
								item14.left = array41[1] - 30;
							}
							item14.items = new List<START_END_PAIR>();
							item14.items.Add(sTART_END_PAIR22);
							list21.Add(item14);
							if (!bj && bk)
							{
								int num109 = num107;
								int num110 = array40[1];
								a8.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num109 + "," + num110 + "); ");
							}
							else if (bj && !bk)
							{
								int num111 = array41[1] - 30;
								int num112 = num108;
								a8.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num111 + "," + num112 + "); ");
							}
						}
					}
					else
					{
						if (!flag15 || num102 != 1)
						{
							break;
						}
						List<int> list24 = new List<int>();
						for (int num103 = 0; num103 < list21.Count; num103++)
						{
							if (Enumerable.ElementAt(list21, num103).items.Count == 0)
							{
								list24.Add(num103);
							}
						}
						for (int num103 = list24.Count - 1; num103 >= 0; num103--)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST38 = Enumerable.ElementAt(list21, Enumerable.ElementAt(list24, num103));
							a8.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST38.left + "," + nOTE_ARRAYLIST38.top + "); ");
							list21.RemoveAt(Enumerable.ElementAt(list24, num103));
						}
						for (int num113 = 0; num113 < 2; num113++)
						{
							int num114 = 0;
							int num115 = 0;
							int num116 = 0;
							int num117 = 0;
							if (!bj && bk)
							{
								num114 = (array39[num113] + form.jsObj2.CurLeft) % ((form.actual_webkit_column_width + 50 + 50) * bi);
								num115 = (array39[num113] + form.jsObj2.CurLeft) / ((form.actual_webkit_column_width + 50 + 50) * bi);
								if (num114 > form.actual_webkit_column_width + 50 + 50)
								{
									num116 = (num115 + 1) * ((form.actual_webkit_column_width + 50 + 50) * bi);
									num116 -= 50;
								}
								else
								{
									num116 = num115 * ((form.actual_webkit_column_width + 50 + 50) * bi);
									num116 += 20;
								}
							}
							else if (bj && !bk)
							{
								int num141 = array40[num113];
								num115 = (array40[num113] + form.jsObj2.CurTop) / (form.actual_webkit_column_height + 50 + 50);
								num117 = num115 * (form.actual_webkit_column_height + 50 + 50);
								num117 += 20;
							}
							START_END_PAIR sTART_END_PAIR22 = new START_END_PAIR();
							sTART_END_PAIR22.start = array37[num113];
							sTART_END_PAIR22.end = array38[num113];
							string text11 = "";
							string text12 = "";
							if (num113 == 0)
							{
								list24.Clear();
								for (int num103 = 0; num103 < list21.Count; num103++)
								{
									NOTE_ARRAYLIST nOTE_ARRAYLIST39 = Enumerable.ElementAt(list21, num103);
									List<int> list25 = new List<int>();
									for (int num104 = 0; num104 < nOTE_ARRAYLIST39.items.Count; num104++)
									{
										START_END_PAIR sTART_END_PAIR24 = Enumerable.ElementAt(nOTE_ARRAYLIST39.items, num104);
										if (sTART_END_PAIR24.start >= array37[num113] && sTART_END_PAIR24.end <= array38[num113])
										{
											list25.Add(num104);
											text11 += sTART_END_PAIR24.noteText;
											text12 += sTART_END_PAIR24.selectText;
										}
									}
									for (int num104 = list25.Count - 1; num104 >= 0; num104--)
									{
										nOTE_ARRAYLIST39.items.RemoveAt(Enumerable.ElementAt(list25, num104));
									}
									if (nOTE_ARRAYLIST39.items.Count == 0)
									{
										list24.Add(num103);
									}
								}
								for (int num103 = list24.Count - 1; num103 >= 0; num103--)
								{
									NOTE_ARRAYLIST nOTE_ARRAYLIST40 = Enumerable.ElementAt(list21, Enumerable.ElementAt(list24, num103));
									a8.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST40.left + "," + nOTE_ARRAYLIST40.top + "); ");
									list21.RemoveAt(Enumerable.ElementAt(list24, num103));
								}
							}
							sTART_END_PAIR22.noteText = "";
							sTART_END_PAIR22.noteText += text11;
							sTART_END_PAIR22.selectText = text12;
							bool flag17 = false;
							for (int num103 = 0; num103 < list21.Count; num103++)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST41 = Enumerable.ElementAt(list21, num103);
								if (!bj && bk)
								{
									if (nOTE_ARRAYLIST41.left == num116 && Math.Abs(nOTE_ARRAYLIST41.top - array40[num113]) <= 30)
									{
										nOTE_ARRAYLIST41.items.Add(sTART_END_PAIR22);
										flag17 = true;
										break;
									}
								}
								else if (bj && !bk && nOTE_ARRAYLIST41.top == num117 && Math.Abs(nOTE_ARRAYLIST41.left + 30 - array41[num113]) <= 30)
								{
									nOTE_ARRAYLIST41.items.Add(sTART_END_PAIR22);
									flag17 = true;
									break;
								}
							}
							if (!flag17)
							{
								NOTE_ARRAYLIST item15 = default(NOTE_ARRAYLIST);
								if (!bj && bk)
								{
									item15.top = array40[num113];
									item15.left = num116;
								}
								else if (bj && !bk)
								{
									item15.top = num117;
									item15.left = array41[num113] - 30;
								}
								item15.items = new List<START_END_PAIR>();
								item15.items.Add(sTART_END_PAIR22);
								list21.Add(item15);
								if (!bj && bk)
								{
									int num118 = num116;
									int num119 = array40[num113];
									a8.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num118 + "," + num119 + "); ");
								}
								else if (bj && !bk)
								{
									int num120 = array41[num113] - 30;
									int num121 = num117;
									a8.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num120 + "," + num121 + "); ");
								}
							}
						}
					}
					break;
				}
				case 3:
				{
					string[] array28 = rangesAndBoundingRect.Split(';');
					int[] array29 = new int[3];
					int[] array30 = new int[3];
					int[] array31 = new int[3];
					int[] array32 = new int[3];
					int[] array33 = new int[3];
					int[] array34 = new int[3];
					for (int num90 = 0; num90 < 3; num90++)
					{
						string[] array35 = array28[num90].Split(',');
						array29[num90] = int.Parse(array35[0]);
						array30[num90] = int.Parse(array35[1]);
						array31[num90] = int.Parse(array35[2]);
						array32[num90] = int.Parse(array35[3]);
						array33[num90] = int.Parse(array35[4]);
						array34[num90] = int.Parse(array35[5]);
					}
					List<NOTE_ARRAYLIST> list18 = rightNoteList;
					int num91 = 0;
					for (int num90 = 0; num90 < list18.Count; num90++)
					{
						NOTE_ARRAYLIST nOTE_ARRAYLIST28 = Enumerable.ElementAt(list18, num90);
						for (int num92 = 0; num92 < nOTE_ARRAYLIST28.items.Count; num92++)
						{
							START_END_PAIR sTART_END_PAIR20 = Enumerable.ElementAt(nOTE_ARRAYLIST28.items, num92);
							if (sTART_END_PAIR20.start == array29[0] && sTART_END_PAIR20.end > array30[0])
							{
								sTART_END_PAIR20.end = array30[0];
								nOTE_ARRAYLIST28.items.RemoveAt(num92);
								nOTE_ARRAYLIST28.items.Add(sTART_END_PAIR20);
								num91++;
								if (num91 == 2)
								{
									break;
								}
							}
							else if (sTART_END_PAIR20.end == array30[2] && sTART_END_PAIR20.start < array29[2])
							{
								nOTE_ARRAYLIST28.items.RemoveAt(num92);
								num91++;
								if (num91 == 2)
								{
									break;
								}
							}
						}
						if (num91 == 2)
						{
							break;
						}
					}
					if (num91 != 2 && num91 != 1)
					{
						break;
					}
					List<int> list19 = new List<int>();
					for (int num90 = 0; num90 < list18.Count; num90++)
					{
						if (Enumerable.ElementAt(list18, num90).items.Count == 0)
						{
							list19.Add(num90);
						}
					}
					for (int num90 = list19.Count - 1; num90 >= 0; num90--)
					{
						NOTE_ARRAYLIST nOTE_ARRAYLIST29 = Enumerable.ElementAt(list18, Enumerable.ElementAt(list19, num90));
						a8.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST29.left + "," + nOTE_ARRAYLIST29.top + "); ");
						list18.RemoveAt(Enumerable.ElementAt(list19, num90));
					}
					for (int num93 = 1; num93 < 3; num93++)
					{
						int num94 = 0;
						int num95 = 0;
						int num96 = 0;
						int num97 = 0;
						if (!bj && bk)
						{
							num94 = (array31[num93] + form.jsObj2.CurLeft) % ((form.actual_webkit_column_width + 50 + 50) * bi);
							num95 = (array31[num93] + form.jsObj2.CurLeft) / ((form.actual_webkit_column_width + 50 + 50) * bi);
							if (num94 > form.actual_webkit_column_width + 50 + 50)
							{
								num96 = (num95 + 1) * ((form.actual_webkit_column_width + 50 + 50) * bi);
								num96 -= 50;
							}
							else
							{
								num96 = num95 * ((form.actual_webkit_column_width + 50 + 50) * bi);
								num96 += 20;
							}
						}
						else if (bj && !bk)
						{
							int num142 = array32[num93];
							num95 = (array32[num93] + form.jsObj2.CurTop) / (form.actual_webkit_column_height + 50 + 50);
							num97 = num95 * (form.actual_webkit_column_height + 50 + 50);
							num97 += 20;
						}
						START_END_PAIR sTART_END_PAIR20 = new START_END_PAIR();
						sTART_END_PAIR20.start = array29[num93];
						sTART_END_PAIR20.end = array30[num93];
						string text7 = "";
						string text8 = "";
						if (num93 == 1)
						{
							list19.Clear();
							for (int num90 = 0; num90 < list18.Count; num90++)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST30 = Enumerable.ElementAt(list18, num90);
								List<int> list20 = new List<int>();
								for (int num92 = 0; num92 < nOTE_ARRAYLIST30.items.Count; num92++)
								{
									START_END_PAIR sTART_END_PAIR21 = Enumerable.ElementAt(nOTE_ARRAYLIST30.items, num92);
									if (sTART_END_PAIR21.start >= array29[num93] && sTART_END_PAIR21.end <= array30[num93])
									{
										list20.Add(num92);
										text7 += sTART_END_PAIR21.noteText;
										text8 += sTART_END_PAIR21.selectText;
									}
								}
								for (int num92 = list20.Count - 1; num92 >= 0; num92--)
								{
									nOTE_ARRAYLIST30.items.RemoveAt(Enumerable.ElementAt(list20, num92));
								}
								if (nOTE_ARRAYLIST30.items.Count == 0)
								{
									list19.Add(num90);
								}
							}
							for (int num90 = list19.Count - 1; num90 >= 0; num90--)
							{
								NOTE_ARRAYLIST nOTE_ARRAYLIST31 = Enumerable.ElementAt(list18, Enumerable.ElementAt(list19, num90));
								a8.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST31.left + "," + nOTE_ARRAYLIST31.top + "); ");
								list18.RemoveAt(Enumerable.ElementAt(list19, num90));
							}
						}
						sTART_END_PAIR20.noteText = "";
						sTART_END_PAIR20.noteText += text7;
						sTART_END_PAIR20.selectText = text8;
						bool flag14 = false;
						for (int num90 = 0; num90 < list18.Count; num90++)
						{
							NOTE_ARRAYLIST nOTE_ARRAYLIST32 = Enumerable.ElementAt(list18, num90);
							if (!bj && bk)
							{
								if (nOTE_ARRAYLIST32.left == num96 && Math.Abs(nOTE_ARRAYLIST32.top - array32[num93]) <= 30)
								{
									nOTE_ARRAYLIST32.items.Add(sTART_END_PAIR20);
									flag14 = true;
									break;
								}
							}
							else if (bj && !bk && nOTE_ARRAYLIST32.top == num97 && Math.Abs(nOTE_ARRAYLIST32.left + 30 - array33[num93]) <= 30)
							{
								nOTE_ARRAYLIST32.items.Add(sTART_END_PAIR20);
								flag14 = true;
								break;
							}
						}
						if (!flag14)
						{
							NOTE_ARRAYLIST item13 = default(NOTE_ARRAYLIST);
							if (!bj && bk)
							{
								item13.top = array32[num93];
								item13.left = num96;
							}
							else if (bj && !bk)
							{
								item13.top = num97;
								item13.left = array33[num93] - 30;
							}
							item13.items = new List<START_END_PAIR>();
							item13.items.Add(sTART_END_PAIR20);
							list18.Add(item13);
							if (!bj && bk)
							{
								int num98 = num96;
								int num99 = array32[num93];
								a8.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num98 + "," + num99 + "); ");
							}
							else if (bj && !bk)
							{
								int num100 = array33[num93] - 30;
								int num101 = num97;
								a8.ExecuteScriptAsync("android.selection.addNoteMark(" + 0 + "," + 0 + "," + num100 + "," + num101 + "); ");
							}
						}
					}
					break;
				}
				}
			}

			public void keyup(int keyCode)
			{
				form.c(Convert.ToString(keyCode));
			}

			public void setContentsWidthAndHeight(int w, int h)
			{
				ContentsWidth = w;
				ContentsHeight = h;
			}

			public void onMouseDown(string pos, string str)
			{
				Console.WriteLine("MouseDown(" + pos + ") in " + str);
				isMouseDown = true;
				if (!bj && bk)
				{
					if (bi == 2)
					{
						if (str == "LEFT_WEBVIEW")
						{
							a7.ExecuteScriptAsync("$(document).on('selectionchange', function(event){ android.selection.OnSelectionChange(event);} );");
							a8.ExecuteScriptAsync("android.selection.isMouseDown = true;");
							isMouseDown = true;
						}
						else
						{
							a8.ExecuteScriptAsync("$(document).on('selectionchange', function(event){ android.selection.OnSelectionChange(event);} );");
							a7.ExecuteScriptAsync("android.selection.isMouseDown = true;");
							isMouseDown = true;
						}
					}
				}
				else if (bi == 2)
				{
					if (str == "LEFT_WEBVIEW")
					{
						a7.ExecuteScriptAsync("$(document).on('mousemove', function(e){ android.selection.OnMouseMove(e); } );");
						a8.ExecuteScriptAsync("android.selection.isMouseDown = true;");
						isMouseDown = true;
					}
					else
					{
						a8.ExecuteScriptAsync("$(document).on('mousemove', function(e){ android.selection.OnMouseMove(e); } );");
						a7.ExecuteScriptAsync("android.selection.isMouseDown = true;");
						isMouseDown = true;
					}
				}
			}

			public void onMouseMove(string pos, string text, string str)
			{
				Console.WriteLine("MouseMove(" + pos + ") in {" + text + "} of " + str);
				if ((bj || !bk) && isMouseDown && bi == 2)
				{
					if (str == "LEFT_WEBVIEW")
					{
						a7.ExecuteScriptAsync("$(document).on('selectionchange', function(){ android.selection.OnSelectionChange();} );");
					}
					else
					{
						a8.ExecuteScriptAsync("$(document).on('selectionchange', function(){ android.selection.OnSelectionChange();} );");
					}
				}
			}

			public string getCaretRangeFromPointInTheOtherWebview(string pos, string webviewName)
			{
				Console.WriteLine(pos + " from " + webviewName);
				string[] array = pos.Split(',');
				int num = Convert.ToInt32(array[0]);
				int num2 = Convert.ToInt32(array[1]);
				Task<JavascriptResponse> task = null;
				if (webviewName == "RIGHT_WEBVIEW")
				{
					task = a7.EvaluateScriptAsync("(function(){ var range = document.caretRangeFromPoint(" + num + "," + num2 + "); var xpath = android.selection.makeXPath(range.startContainer) + '|' + range.startOffset; return xpath; })();");
					task.ContinueWith(_003C_003Ec._003C_003E9__46_0 ?? (_003C_003Ec._003C_003E9__46_0 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.a)), TaskScheduler.Default);
					Console.WriteLine("task.Result.Result = " + task.Result.Result);
					if (task.Result.Result == null)
					{
						return "";
					}
					return task.Result.Result.ToString();
				}
				task = a8.EvaluateScriptAsync("(function(){ var range = document.caretRangeFromPoint(" + num + "," + num2 + "); var xpath = android.selection.makeXPath(range.startContainer) + '|' + range.startOffset; return xpath; })();");
				task.ContinueWith(_003C_003Ec._003C_003E9__46_1 ?? (_003C_003Ec._003C_003E9__46_1 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.b)), TaskScheduler.Default);
				Console.WriteLine("task.Result.Result = " + task.Result.Result);
				if (task.Result.Result == null)
				{
					return "";
				}
				return task.Result.Result.ToString();
			}

			public void notifyToAttachOnSelectionChangeHandler(string str, bool flag)
			{
				Console.WriteLine("notify:by " + str);
				isMouseDown = false;
				if (!bj && bk)
				{
					if (bi == 2)
					{
						if (str == "LEFT_WEBVIEW")
						{
							a7.ExecuteScriptAsync("$(document).off('selectionchange', function(event){ android.selection.OnSelectionChange(event);} );");
							a8.ExecuteScriptAsync("android.selection.clearSelection();");
						}
						else
						{
							a8.ExecuteScriptAsync("$(document).off('selectionchange', function(event){ android.selection.OnSelectionChange(event);} );");
							a7.ExecuteScriptAsync("android.selection.clearSelection();");
						}
					}
				}
				else if (bi == 2)
				{
					if (str == "LEFT_WEBVIEW")
					{
						a8.ExecuteScriptAsync("window.getSelection().empty();");
					}
					else
					{
						a7.ExecuteScriptAsync("window.getSelection().empty();");
					}
				}
			}

			public void onMouseUp(string pos, string str)
			{
				form.a0 = true;
				isMouseDown = false;
				Console.Write("MouseUp( " + pos + " )in " + str);
				if (!bj && bk)
				{
					if (bi == 2)
					{
						if (str == "LEFT_WEBVIEW")
						{
							a7.ExecuteScriptAsync("android.selection.isMouseDown = false;");
							a8.ExecuteScriptAsync("android.selection.isMouseDown = false;");
							isMouseDown = false;
						}
						else
						{
							a8.ExecuteScriptAsync("android.selection.isMouseDown = false;");
							a7.ExecuteScriptAsync("android.selection.isMouseDown = false;");
							isMouseDown = false;
						}
					}
				}
				else if (bi == 2)
				{
					if (str == "LEFT_WEBVIEW")
					{
						a7.ExecuteScriptAsync("android.selection.isMouseDown = false;");
						a7.ExecuteScriptAsync("android.selection.lastTouchRange = null;");
						a8.ExecuteScriptAsync("android.selection.clearSelection();");
						a8.ExecuteScriptAsync("android.selection.isMouseDown = false;");
						isMouseDown = false;
					}
					else
					{
						a8.ExecuteScriptAsync("android.selection.isMouseDown = false;");
						a8.ExecuteScriptAsync("android.selection.lastTouchRange = null;");
						a7.ExecuteScriptAsync("android.selection.clearSelection();");
						a7.ExecuteScriptAsync("android.selection.isMouseDown = false;");
						isMouseDown = false;
					}
				}
				form.closeFormMenu();
			}

			public void getMouseStatus(string obj)
			{
			}

			public void getHandleBounds(string str)
			{
			}

			public void getMenuBounds(string str)
			{
				System.Windows.Forms.MessageBox.Show(str);
			}

			public void onSelectionChange(string path, string webviewName, bool flag_clear)
			{
				Console.WriteLine("onSelectionChange:" + path + " in " + webviewName);
				if (!bj && bk)
				{
					if (bi != 2)
					{
						return;
					}
					if (webviewName == "LEFT_WEBVIEW")
					{
						a8.ExecuteScriptAsync("$(document).off('selectionchange');");
						if (isMouseDown)
						{
							a8.ExecuteScriptAsync("android.selection.showSelectionFromTheOtherWebview('" + path + "');");
						}
						else
						{
							a8.ExecuteScriptAsync("window.getSelection().empty();");
						}
					}
					else
					{
						a7.ExecuteScriptAsync("$(document).off('selectionchange');");
						if (isMouseDown)
						{
							a7.ExecuteScriptAsync("android.selection.showSelectionFromTheOtherWebview('" + path + "');");
						}
						else
						{
							a7.ExecuteScriptAsync("window.getSelection().empty();");
						}
					}
				}
				else
				{
					if (bi != 2)
					{
						return;
					}
					if (webviewName == "LEFT_WEBVIEW")
					{
						a8.ExecuteScriptAsync("$(document).off('selectionchange');");
						a8.ExecuteScriptAsync("android.selection.showSelectionFromTheOtherWebview('" + path + "');");
						if (flag_clear)
						{
							a8.ExecuteScriptAsync("window.getSelection().empty();");
						}
					}
					else
					{
						a7.ExecuteScriptAsync("$(document).off('selectionchange');");
						a7.ExecuteScriptAsync("android.selection.showSelectionFromTheOtherWebview('" + path + "');");
						if (flag_clear)
						{
							a7.ExecuteScriptAsync("window.getSelection().empty();");
						}
					}
				}
			}

			public void selectionChanged(string rangyRange, string text, string handleBounds, string menuBounds, string x, string y)
			{
				string text2 = @as[0];
				if (web_view.Name == "LEFT_WEBVIEW")
				{
					a7.ExecuteScriptAsync("android.selection.elementRectsByIdentifier('" + rangyRange + "', 0, '" + @as[0] + "', 0 );");
				}
				else
				{
					a8.ExecuteScriptAsync("android.selection.elementRectsByIdentifier('" + rangyRange + "', 0, '" + @as[0] + "', 0 );");
				}
				form.a(rangyRange, text.Trim(), handleBounds, menuBounds, Convert.ToInt32(x), Convert.ToInt32(y), web_view.Name);
			}

			public void returnSearchResult(string results, string displayResult)
			{
			}

			public void fxl_returnSearchResult(string webviewName, string startAndEnd, string displayResult)
			{
				Console.WriteLine(webviewName);
				Console.WriteLine(displayResult);
				Console.WriteLine(startAndEnd);
				if (startAndEnd == "")
				{
					return;
				}
				string[] array;
				if (webviewName == "LEFT_WEBVIEW")
				{
					if (!leftStartAndEnd.Equals(string.Empty))
					{
						array = leftStartAndEnd.Split(';');
						for (int i = 0; i < array.Length; i++)
						{
							string[] array2 = array[i].Split(',');
							int num = int.Parse(array2[0]);
							int num2 = int.Parse(array2[1]);
							a7.ExecuteScriptAsync("highlighter.removeHighlightsByStartAndEnd(" + num + "," + num2 + "); ");
						}
					}
					leftStartAndEnd = startAndEnd;
				}
				else
				{
					if (!rightStartAndEnd.Equals(string.Empty))
					{
						array = rightStartAndEnd.Split(';');
						for (int i = 0; i < array.Length; i++)
						{
							string[] array3 = array[i].Split(',');
							int num3 = int.Parse(array3[0]);
							int num4 = int.Parse(array3[1]);
							a8.ExecuteScriptAsync("highlighter.removeHighlightsByStartAndEnd(" + num3 + "," + num4 + "); ");
						}
					}
					rightStartAndEnd = startAndEnd;
				}
				string text = "highlight_yellow";
				array = startAndEnd.Split(';');
				for (int i = 0; i < array.Length; i++)
				{
					string[] array4 = array[i].Split(',');
					int num5 = int.Parse(array4[0]);
					int num6 = int.Parse(array4[1]);
					if (webviewName == "LEFT_WEBVIEW")
					{
						a7.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + num5 + "," + num6 + ",'" + text + "', 'true'); ");
					}
					else
					{
						a8.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + num5 + "," + num6 + ",'" + text + "', 'true'); ");
					}
				}
				form.a(displayResult, displayResult);
			}

			public void setTotalPages(int p)
			{
				TotalPages = p;
				form.modifyTotalPageTextBox(TotalPages);
			}

			public void notifyColumnized(bool flagIsColumnized)
			{
				if (flagIsColumnized)
				{
					columnizedCount++;
					if (columnizedCount == bi)
					{
						form.showWebview();
					}
				}
			}

			public void getWindowJSON(string obj)
			{
			}

			public void onAudioEnded(string webviewName, bool flag)
			{
				form.cz = false;
				if (bi == 2)
				{
					if (webviewName == "LEFT_WEBVIEW")
					{
						a7.ExecuteScriptAsync("android.selection.pauseAudio();");
						form.mediaOverlayPlay("RIGHT_WEBVIEW", form.m_ac);
						return;
					}
					a8.ExecuteScriptAsync("android.selection.pauseAudio();");
					epubReadPage.m_aa = 0;
					form.mediaOverLayAutoPlayFlag = true;
					form.r();
				}
				else if (form.m_p < form.m_v)
				{
					a7.ExecuteScriptAsync("android.selection.pauseAudio();");
					epubReadPage.m_aa = 0;
					form.mediaOverLayAutoPlayFlag = true;
					form.r();
				}
				else
				{
					form.mediaOverLayAutoPlayFlag = false;
				}
			}

			public void onAudioCanPlay(string webviewName, bool flag)
			{
				if (bp)
				{
					if (webviewName == "LEFT_WEBVIEW")
					{
						if (form.leftSmil == null)
						{
							return;
						}
						a7.ExecuteScriptAsync("android.selection.setHtml5AudioDurationCount(" + form.leftSmil.parList.Count + ");");
						for (int i = 0; i < form.leftSmil.parList.Count; i++)
						{
							if (i == 0)
							{
								form.m_ab = form.leftSmil.parList[i].clipBegin;
							}
							string text = form.leftSmil.parList[i].textSrc.Substring(form.leftSmil.parList[i].textSrc.IndexOf("#") + 1);
							a7.ExecuteScriptAsync("android.selection.addDurationAndIdToAudioMap(" + form.leftSmil.parList[i].clipBegin + ", " + form.leftSmil.parList[i].clipEnd + ", '" + text + "');");
						}
					}
					else
					{
						if (form.rightSmil == null)
						{
							return;
						}
						a8.ExecuteScriptAsync("android.selection.setHtml5AudioDurationCount(" + form.rightSmil.parList.Count + ");");
						for (int j = 0; j < form.rightSmil.parList.Count; j++)
						{
							if (j == 0)
							{
								form.m_ac = form.rightSmil.parList[j].clipBegin;
							}
							string text2 = form.rightSmil.parList[j].textSrc.Substring(form.rightSmil.parList[j].textSrc.IndexOf("#") + 1);
							a8.ExecuteScriptAsync("android.selection.addDurationAndIdToAudioMap(" + form.rightSmil.parList[j].clipBegin + ", " + form.rightSmil.parList[j].clipEnd + ", '" + text2 + "');");
						}
					}
					return;
				}
				for (int k = 0; k < form.leftSmil.parList.Count; k++)
				{
					if (k == 0)
					{
						form.m_ab = form.leftSmil.parList[k].clipBegin;
					}
					string text3 = form.leftSmil.parList[k].textSrc.Substring(form.leftSmil.parList[k].textSrc.IndexOf("#") + 1);
					a7.ExecuteScriptAsync("android.selection.addDurationAndIdToAudioMap(" + form.leftSmil.parList[k].clipBegin + ", " + form.leftSmil.parList[k].clipEnd + ", '" + text3 + "');");
				}
				form.audioCanPlay = true;
			}

			public void notifyToAutoPlay(string name, bool flag)
			{
				epubReadPage.m_aa++;
				if (name == "LEFT_WEBVIEW")
				{
					form.leftAudioCanPlay = true;
				}
				else
				{
					form.rightAudioCanPlay = true;
				}
				if (epubReadPage.m_aa == bi && form.mediaOverLayAutoPlayFlag)
				{
					form.mediaOverlayPlay("LEFT_WEBVIEW", form.m_ab);
				}
			}

			public void jumpToSpecificPage(string name, int page)
			{
				if (name == "LEFT_WEBVIEW")
				{
					form.b(page);
				}
			}

			public void modifyCssInOtherWebviews(string name, string id, string cssClassName, bool flag)
			{
				if (bi == 2 && name == "LEFT_WEBVIEW")
				{
					a8.ExecuteScriptAsync("document.getElementById('" + id + "').className = '" + cssClassName + "';");
				}
			}

			public void notifyDurationOutOfRange(string name, bool flag)
			{
				form.cz = false;
				if (bi == 2)
				{
					if (name == "LEFT_WEBVIEW")
					{
						a7.ExecuteScriptAsync("android.selection.pauseAudio();");
						form.mediaOverlayPlay("RIGHT_WEBVIEW", form.m_ac);
						return;
					}
					a8.ExecuteScriptAsync("android.selection.pauseAudio();");
					epubReadPage.m_aa = 0;
					form.mediaOverLayAutoPlayFlag = true;
					form.r();
				}
				else if (form.m_p < form.m_v)
				{
					a7.ExecuteScriptAsync("android.selection.pauseAudio();");
					epubReadPage.m_aa = 0;
					form.mediaOverLayAutoPlayFlag = true;
					form.r();
				}
				else
				{
					form.mediaOverLayAutoPlayFlag = false;
				}
			}

			public void aClicked(string name, string s)
			{
				form.b(name, s);
			}
		}

		public delegate void delCloseFormMenu();

		public delegate void delresetAnnotationDataRects(int anntSno, string rects);

		private delegate void a(string A_0, string A_1, string A_2, string A_3, int A_4, int A_5, string A_6);

		public delegate void delModifyLeftPageTextBox(int left_page);

		public delegate void delModifyRightPageTextBox(int right_page);

		public delegate void delModifyTotalPageTextBox(int pages);

		public delegate void delSetPageLabel();

		public delegate void delShowWebview();

		public delegate void delOnIsLoadingChanged(object sender, IsLoadingChangedEventArgs e);

		public delegate void dellaunchBook();

		public delegate void delloadHtmlDoc();

		public delegate void deljumpToHyperLinkPage(string name, string s);

		public delegate void delreflashDocument();

		public delegate void deltoc_panel_Control(int CloseOpenNo, int tvwIdx);

		private delegate void b(string A_0, string A_1);

		private delegate void c(string A_0);

		public delegate void delformShowNote(List<START_END_PAIR> ModifyNoteList, string webviewName, string id);

		private delegate void d();

		private delegate void e(int A_0);

		public delegate void delScrollToPosition(bool flag_HorizontalOrVertical, int pos, string webviewName);

		public delegate void delprocessStartAndEnd(string name, int start, int end, int x, int y, string hBounds, string textContent);

		public delegate void delformclickHighlight(string webviewName, int x, int y, int start, int end, string className);

		[CompilerGenerated]
		private sealed class f
		{
			public System.Timers.Timer a;

			public Action b;

			internal void c(object A_0, ElapsedEventArgs A_1)
			{
				a.Enabled = false;
				b();
			}
		}

		[Serializable]
		[CompilerGenerated]
		private sealed class _003C_003Ec
		{
			public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

			public static Func<string, IEnumerable<string>> _003C_003E9__143_0;

			public static Func<string, string, global::b<string, string>> _003C_003E9__143_1;

			public static Func<global::b<string, string>, bool> _003C_003E9__143_2;

			public static Func<global::b<string, string>, global::c<string, string>> _003C_003E9__143_3;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_0;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_1;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_2;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_3;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_4;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_5;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_6;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_7;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_8;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_9;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_10;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_11;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_12;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_13;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_14;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_15;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_16;

			public static Action<Task<JavascriptResponse>> _003C_003E9__161_17;

			public static Comparison<AnnotationData> _003C_003E9__275_0;

			public static Action<Task<JavascriptResponse>> _003C_003E9__301_0;

			public static Action<Task<JavascriptResponse>> _003C_003E9__301_1;

			internal IEnumerable<string> a(string A_0)
			{
				return File.ReadLines(A_0);
			}

			internal global::b<string, string> a(string A_0, string A_1)
			{
				return new global::b<string, string>(A_0, A_1);
			}

			internal bool a(global::b<string, string> A_0)
			{
				return A_0.line.Contains("Microsoft");
			}

			internal global::c<string, string> b(global::b<string, string> A_0)
			{
				return new global::c<string, string>(A_0.file, A_0.line);
			}

			internal void a(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void b(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void c(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void d(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void e(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void f(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void g(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void h(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void i(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void j(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void k(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void l(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void m(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void n(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void o(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void p(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void q(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void r(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal int a(AnnotationData A_0, AnnotationData A_1)
			{
				return A_0.itemIndex.CompareTo(A_1.itemIndex);
			}

			internal void s(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}

			internal void t(Task<JavascriptResponse> A_0)
			{
				if (!A_0.IsFaulted)
				{
					JavascriptResponse result = A_0.Result;
					if (!result.Success)
					{
						string message = result.Message;
					}
					else
					{
						object result2 = result.Result;
					}
				}
			}
		}

		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct g : IAsyncStateMachine
		{
			public int a;

			public AsyncTaskMethodBuilder b;

			public epubReadPage c;

			private string m_d;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter e;

			private void d()
			{
				int num = a;
				epubReadPage epubReadPage = c;
				try
				{
					Microsoft.Runtime.CompilerServices.TaskAwaiter awaiter;
					if (num != 0)
					{
						string str = epubReadPage.m_i.Substring(epubReadPage.m_i.LastIndexOf("\\") + 1);
						this.m_d = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) + "\\hyread\\" + str;
						awaiter = AwaitExtensions.GetAwaiter(epubReadPage.c(epubReadPage.m_i, this.m_d));
						if (!awaiter.IsCompleted)
						{
							num = (a = 0);
							e = awaiter;
							b.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = e;
						e = default(Microsoft.Runtime.CompilerServices.TaskAwaiter);
						num = (a = -1);
					}
					awaiter.GetResult();
					epubReadPage.m_i = this.m_d;
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult();
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in d
				this.d();
			}

			[DebuggerHidden]
			private void d(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in d
				this.d(A_0);
			}
		}

		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct h : IAsyncStateMachine
		{
			public int a;

			public AsyncTaskMethodBuilder b;

			public string c;

			public string d;

			public epubReadPage e;

			private DirectoryInfo[] m_f;

			private int g;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter h;

			private void f()
			{
				int num = a;
				epubReadPage epubReadPage = e;
				try
				{
					if (num != 0)
					{
						if (!Directory.Exists(c))
						{
							Directory.CreateDirectory(c);
						}
						DirectoryInfo directoryInfo = new DirectoryInfo(d);
						FileInfo[] files = directoryInfo.GetFiles();
						foreach (FileInfo fileInfo in files)
						{
							fileInfo.CopyTo(Path.Combine(c, fileInfo.Name), true);
						}
						DirectoryInfo[] array = this.m_f = directoryInfo.GetDirectories();
						g = 0;
						goto IL_012c;
					}
					Microsoft.Runtime.CompilerServices.TaskAwaiter awaiter = h;
					h = default(Microsoft.Runtime.CompilerServices.TaskAwaiter);
					num = (a = -1);
					goto IL_0117;
					IL_0117:
					awaiter.GetResult();
					g++;
					goto IL_012c;
					IL_012c:
					if (g < this.m_f.Length)
					{
						DirectoryInfo directoryInfo2 = this.m_f[g];
						awaiter = AwaitExtensions.GetAwaiter(epubReadPage.c(Path.Combine(d, directoryInfo2.Name), Path.Combine(c, directoryInfo2.Name)));
						if (!awaiter.IsCompleted)
						{
							num = (a = 0);
							h = awaiter;
							b.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
						goto IL_0117;
					}
					this.m_f = null;
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult();
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in f
				this.f();
			}

			[DebuggerHidden]
			private void f(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in f
				this.f(A_0);
			}
		}

		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct i : IAsyncStateMachine
		{
			public int a;

			public AsyncVoidMethodBuilder b;

			public epubReadPage c;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter m_d;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter<int> e;

			private void d()
			{
				int num = a;
				epubReadPage epubReadPage = c;
				try
				{
					Microsoft.Runtime.CompilerServices.TaskAwaiter awaiter;
					if (num == 0)
					{
						awaiter = this.m_d;
						this.m_d = default(Microsoft.Runtime.CompilerServices.TaskAwaiter);
						num = (a = -1);
						goto IL_009e;
					}
					Microsoft.Runtime.CompilerServices.TaskAwaiter<int> awaiter2;
					if (num == 1)
					{
						awaiter2 = e;
						e = default(Microsoft.Runtime.CompilerServices.TaskAwaiter<int>);
						num = (a = -1);
						goto IL_0155;
					}
					if (!epubReadPage.InvokeRequired)
					{
						if (isChinese(epubReadPage.m_i))
						{
							awaiter = AwaitExtensions.GetAwaiter(epubReadPage.z());
							if (!awaiter.IsCompleted)
							{
								num = (a = 0);
								this.m_d = awaiter;
								b.AwaitUnsafeOnCompleted(ref awaiter, ref this);
								return;
							}
							goto IL_009e;
						}
						goto IL_00a5;
					}
					dellaunchBook method = new dellaunchBook(epubReadPage.y);
					epubReadPage.Invoke(method);
					goto end_IL_000e;
					IL_009e:
					awaiter.GetResult();
					goto IL_00a5;
					IL_0155:
					awaiter2.GetResult();
					epubReadPage.Text = epubReadPage.m_c.title;
					epubReadPage.c7.Text = "";
					epubReadPage.a6 = ((!epubReadPage.m_k.StartsWith("螺旋英語")) ? true : false);
					epubReadPage.d9.Visible = epubReadPage.a6;
					epubReadPage.m_l = epubReadPage.m_c.bookDataPath;
					bj = ((!epubReadPage.m_c.writingMode.Equals("horizontal")) ? true : false);
					epubReadPage.bo = !bj;
					bp = epubReadPage.m_c.isFixedlayout;
					bq = epubReadPage.m_c.hasMediaOverlay;
					bi = epubReadPage.m_c.landscapeGroupCount;
					bk = !bj;
					if (bp)
					{
						epubReadPage.c5.Visible = false;
						epubReadPage.c6.Visible = false;
						epubReadPage.dn.Visible = false;
					}
					else
					{
						bk = !bj;
					}
					epubReadPage.m_v = Enumerable.Count(epubReadPage.m_c.spineDictionary);
					epubReadPage.m_w = epubReadPage.m_c.getTocListItem();
					epubReadPage.m_z = epubReadPage.m_c.getSmilListItem();
					if (epubReadPage.m_w.Count > 0)
					{
						epubReadPage.v();
						epubReadPage.u();
						epubReadPage.dh.ExpandAll();
					}
					else
					{
						epubReadPage.df.Visible = false;
					}
					epubReadPage.cc = new int[epubReadPage.m_v];
					epubReadPage.ac();
					epubReadPage.perFontFize = Convert.ToInt32(epubReadPage.configMng.saveEpubFontSize);
					epubReadPage.m_aj = Global.bookManager.getUserBookSno(epubReadPage.m_d, epubReadPage.m_e, epubReadPage.m_f, epubReadPage.m_h);
					string text = "Y";
					string sqlCommand = "SELECT epubLastNode, epubLastPageRate, allowGBConvert from userbook_metadata where sno= " + epubReadPage.m_aj;
					QueryResult queryResult = Global.bookManager.sqlCommandQuery(sqlCommand);
					if (queryResult.fetchRow())
					{
						epubReadPage.m_p = queryResult.getInt("epubLastNode");
						epubReadPage.m_a = queryResult.getFloat("epubLastPageRate");
						text = queryResult.getString("allowGBConvert");
					}
					if (epubReadPage.m_c.spineDictionary.Count == 0)
					{
						System.Windows.Forms.MessageBox.Show("無法開啟電子書");
						epubReadPage.Close();
					}
					else
					{
						if (text.Equals("N"))
						{
							epubReadPage.db.Visible = false;
							epubReadPage.da.Visible = false;
						}
						if (bq)
						{
							epubReadPage.m_x = epubReadPage.m_c.mediaOverlayActiveClassName;
						}
						epubReadPage.ae();
						epubReadPage.d7.Visible = true;
						epubReadPage.x();
					}
					goto end_IL_000e;
					IL_00a5:
					JSBindingObject.annotList.Clear();
					columnizedCount = 0;
					epubReadPage.m_ag = epubReadPage.t();
					for (int i = 0; i < epubReadPage.m_ag.Length; i++)
					{
					}
					epubReadPage.m_c = new DBDataEPUBWin7(epubReadPage.m_i, epubReadPage.m_ag);
					awaiter2 = AwaitExtensions.GetAwaiter(epubReadPage.m_c.initByBookPath("container.xml"));
					if (!awaiter2.IsCompleted)
					{
						num = (a = 1);
						e = awaiter2;
						b.AwaitUnsafeOnCompleted(ref awaiter2, ref this);
						return;
					}
					goto IL_0155;
					end_IL_000e:;
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult();
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in d
				this.d();
			}

			[DebuggerHidden]
			private void d(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in d
				this.d(A_0);
			}
		}

		private float m_a;

		public ConfigurationManager configMng = new ConfigurationManager(Global.bookManager);

		private System.Drawing.Size m_b = SystemInformation.PrimaryMonitorSize;

		private DBDataEPUBWin7 m_c;

		private string m_d = "";

		private string m_e = "";

		private string m_f = "";

		private string m_g = "";

		private string m_h = "";

		private string m_i = "";

		private string m_j = "";

		private string m_k = "";

		private string m_l = "";

		private int m_m;

		private int m_n;

		private int m_o;

		private int m_p;

		private int m_q;

		private string m_r = "";

		private string m_s = "";

		private string m_t = "";

		private string m_u = "";

		private int m_v;

		private List<SimpleListItem> m_w = new List<SimpleListItem>();

		private string m_x;

		private string m_y;

		public SimpleSmil leftSmil = new SimpleSmil();

		public SimpleSmil rightSmil = new SimpleSmil();

		private List<SimpleSmil> m_z = new List<SimpleSmil>();

		public bool audioCanPlay;

		public bool leftAudioCanPlay;

		public bool rightAudioCanPlay;

		private static int m_aa = 0;

		public bool mediaOverLayAutoPlayFlag;

		public bool FXL_CanHighlight = true;

		private double m_ab;

		private double m_ac;

		private Dictionary<string, string> m_ad = new Dictionary<string, string>();

		private Dictionary<string, string> m_ae = new Dictionary<string, string>();

		private CACodecTools m_af = new CACodecTools();

		private byte[] m_ag;

		private bool m_ah;

		private int m_ai;

		private int m_aj;

		private int m_ak;

		public List<AnnotationData> bookAnnotation = new List<AnnotationData>();

		public List<SearchListData> searchListData = new List<SearchListData>();

		private string m_al = "";

		private string m_am = "";

		private string m_an = "";

		private string m_ao = "";

		private int m_ap;

		private int m_aq;

		private string ar = "";

		private static string[] @as = new string[4]
		{
			"128, 128, 128, 128",
			"241, 191, 206, 128",
			"194, 223, 241, 128",
			"181, 221, 183, 128"
		};

		private static string[] at = new string[4]
		{
			"#f2b5ce",
			"#b5ddb7",
			"#c1ddf2",
			"#fff200"
		};

		private static string[] au = new string[4]
		{
			"highlight_pink",
			"highlight_green",
			"highlight_blue",
			"highlight_yellow"
		};

		private int av;

		private int aw;

		private object ax = new object();

		private int ay;

		private bool az;

		private bool a0;

		private double a1 = 1.0;

		private bool a2 = true;

		private bool a3;

		private bool a4;

		private bool a5;

		private bool a6 = true;

		private static ChromiumWebBrowser a7 = null;

		private static ChromiumWebBrowser a8 = null;

		private const bool a9 = false;

		private const bool ba = true;

		private const int bb = 400;

		private int bc = 400;

		public int actual_webkit_column_width;

		private int bd = 400;

		public int actual_webkit_column_height;

		private const int be = 50;

		private const int bf = 50;

		private const int bg = 50;

		private const int bh = 50;

		private static int bi = 1;

		private static bool bj = false;

		private static bool bk = true;

		private double bl;

		private const int bm = 96;

		private const double bn = 2.0;

		private bool bo = true;

		private static bool bp = true;

		private static bool bq = true;

		private bool br;

		private string bs;

		private string bt;

		private string bu;

		private string bv;

		private string bw;

		private string bx;

		private string by;

		private string bz;

		private string b0;

		private string b1;

		private string b2;

		private string b3;

		private string b4;

		private string b5;

		private string b6;

		private string b7;

		private string b8;

		private string b9;

		private string ca;

		private int cb;

		private int[] cc;

		public static string pathToBookOEBPS = null;

		public int fontSize = 20;

		public int perFontFize = 100;

		public static int columnizedCount;

		public JSBindingObject jsObj1;

		public JSBindingObject jsObj2;

		private string cd = "";

		private System.Windows.Forms.Timer ce = new System.Windows.Forms.Timer();

		private string cf = "";

		private List<START_END_PAIR> cg = new List<START_END_PAIR>();

		private bool ch;

		private string ci = "";

		private double cj = 1.0;

		private string ck = "";

		public int lavel;

		private int cl = -1;

		private int cm = 10;

		private string cn = "";

		private List<START_END_PAIR> co = new List<START_END_PAIR>();

		private int cp;

		private bool cq = true;

		private int cr;

		private string cs = "";

		private string ct = "";

		private int cu = -1;

		private bool cv;

		private int cw;

		private int cx;

		private string cy = "";

		private bool cz;

		private Bitmap c0;

		private IContainer c1;

		private Panel c2;

		private Panel c3;

		private ToolStrip c4;

		private ToolStripButton c5;

		private ToolStripButton c6;

		private ToolStripLabel c7;

		private ToolStripLabel c8;

		private ToolStripLabel c9;

		private ToolStripButton da;

		private ToolStripButton db;

		private ToolStripTextBox dc;

		private ToolStripButton dd;

		private ToolStripLabel de;

		private ToolStripButton df;

		private Panel dg;

		private TreeView dh;

		private ToolStrip di;

		private ToolStripButton dj;

		private ToolStripButton dk;

		private ToolStripButton dl;

		private ToolStripButton dm;

		private ToolStripButton dn;

		private Panel @do;

		private Button dp;

		private Button dq;

		private TreeView dr;

		private Button ds;

		private Button dt;

		private Button du;

		private ToolStripButton dv;

		private TreeView dw;

		private ToolStripButton dx;

		private ImageList dy;

		private Panel dz;

		private TextBox d0;

		private TextBox d1;

		private Button d2;

		private Button d3;

		private ToolStripButton d4;

		private ToolStripButton d5;

		private PictureBox d6;

		private Panel d7;

		private ToolStrip d8;

		private ToolStripButton d9;

		private ToolStripButton ea;

		private ToolStripButton eb;

		private ToolStripDropDownButton ec;

		private ToolStripMenuItem ed;

		private ToolStripMenuItem ee;

		private ToolStripMenuItem ef;

		private ToolStripMenuItem eg;

		private ToolStripButton eh;

		private ToolStripButton ei;

		private ToolStripButton ej;

		private ToolStripButton ek;

		public void closeFormMenu()
		{
			if (base.InvokeRequired)
			{
				delCloseFormMenu method = new delCloseFormMenu(closeFormMenu);
				Invoke(method);
			}
			else
			{
				a(0, 0);
				d8.Hide();
				di.Hide();
			}
		}

		private void a(object A_0, MouseEventArgs A_1)
		{
			Console.WriteLine("web_view1_MouseDown");
			new System.Drawing.Point(A_1.X, A_1.Y);
			switch (A_1.Button)
			{
			case MouseButtons.Left:
				Console.WriteLine("L");
				break;
			case MouseButtons.Right:
				Console.WriteLine("R");
				break;
			case MouseButtons.Middle:
				Console.WriteLine("M");
				break;
			}
			c2.Focus();
			c2.Invalidate();
		}

		public static KeyValuePair<string, string>[] GetLinkMetaDataKeyValue(string htmlSource)
		{
			IDictionary<string, string> dictionary = new Dictionary<string, string>();
			foreach (Match item in new Regex("<meta[\\s]+[^>]*?name[\\s]?=[\\s\"']+(?<KEY>.*?)[\\s\"']+content[\\s]?=[\\s\"']+(?<VALUE>.*?)[\"']+.*?>", RegexOptions.IgnoreCase).Matches(htmlSource))
			{
				string value = "";
				if (!dictionary.TryGetValue(item.Groups["KEY"].Value, out value))
				{
					dictionary.Add(new KeyValuePair<string, string>(item.Groups["KEY"].Value, item.Groups["VALUE"].Value));
					continue;
				}
				IDictionary<string, string> dictionary2 = dictionary;
				string value2 = item.Groups["KEY"].Value;
				dictionary2[value2] = dictionary2[value2] + "," + item.Groups["VALUE"].Value;
			}
			return Enumerable.ToArray(dictionary);
		}

		public void resetAnnotationDataRects(int anntSno, string rects)
		{
			for (int i = 0; i < bookAnnotation.Count; i++)
			{
				if (bookAnnotation[i].sno == anntSno)
				{
					string[] array = rects.Split(',');
					string handleBounds = Convert.ToString(Convert.ToInt32(array[0]) + ay) + "," + array[1] + "," + Convert.ToString(Convert.ToInt32(array[2]) + ay) + "," + array[3];
					bookAnnotation[i].handleBounds = handleBounds;
				}
			}
		}

		private void a(string A_0, string A_1, string A_2, string A_3, int A_4, int A_5, string A_6)
		{
			if (base.InvokeRequired)
			{
				a method = new a(a);
				Invoke(method, A_0, A_1, A_2, A_3, A_4, A_5, A_6);
				return;
			}
			closeFormMenu();
			this.m_al = A_0;
			this.m_am = A_2;
			this.m_an = A_3;
			this.m_ao = A_1.Trim().Replace("wesleywesley", "");
			this.m_ap = A_4;
			this.m_aq = A_5;
			ar = A_6;
			if (this.m_ao.Length > 0)
			{
				cn = "add";
				if (cd == A_1)
				{
					cd = "";
					d8.Hide();
					return;
				}
				cd = A_1;
				this.m_ak = 0;
				d8.Location = d(A_2, A_6);
				d8.Show();
				return;
			}
			cn = "update";
			o(A_2);
			foreach (AnnotationData item in bookAnnotation)
			{
				if (item.itemIndex == this.m_p && e(item.rangyRange, A_0))
				{
					this.m_ak = item.sno;
					this.m_al = item.rangyRange;
					this.m_am = item.handleBounds;
					this.m_an = item.menuBounds;
					this.m_ao = item.htmlContent;
					d0.Text = item.noteText;
					d1.Text = item.htmlContent;
					this.m_ap = A_4;
					this.m_aq = A_5;
					if (item.annoType == 0)
					{
						di.Location = d(A_2, A_6);
						di.Visible = true;
					}
					else
					{
						@do.Visible = true;
					}
					break;
				}
			}
		}

		private bool e(string A_0, string A_1)
		{
			string[] array = A_0.Split('/', ',', ':');
			string[] array2 = A_1.Split('/', ',', ':');
			for (int i = 0; i < array2.Length; i++)
			{
				int num4 = 4;
				int num = (i < 4) ? Convert.ToInt16(array[i]) : Convert.ToInt16(array[i - 4]);
				int num2 = (i < 4) ? Convert.ToInt16(array[i + 4]) : Convert.ToInt16(array[i]);
				int num3 = Convert.ToInt16(array2[i]);
				if (num3 < num || num3 > num2)
				{
					return false;
				}
			}
			return true;
		}

		private System.Drawing.Point d(string A_0, string A_1)
		{
			string[] array = p(A_0);
			int num = (int)Convert.ToDouble(array[0]);
			int num2 = (int)Convert.ToDouble(array[1]);
			if (A_1 == "RIGHT_WEBVIEW")
			{
				num += this.m_b.Width / 2;
			}
			num = ((num > this.m_b.Width - (d8.Width + 50)) ? (this.m_b.Width - (d8.Width + 50)) : num);
			return new System.Drawing.Point(num, num2);
		}

		private System.Drawing.Point q(string A_0)
		{
			string[] array = p(A_0);
			int num = (int)Convert.ToDouble(array[0]);
			int num2 = (int)Convert.ToDouble(array[1]);
			num -= 50;
			num2 -= 50;
			return new System.Drawing.Point(num + 10, num2 - 10);
		}

		private string[] p(string A_0)
		{
			A_0 = A_0.Replace("'left':", "");
			A_0 = A_0.Replace("'top':", "");
			A_0 = A_0.Replace("'right':", "");
			A_0 = A_0.Replace("'bottom':", "");
			A_0 = A_0.Replace("{", "");
			A_0 = A_0.Replace("}", "");
			return A_0.Split(',');
		}

		private handleCoordinate o(string A_0)
		{
			handleCoordinate handleCoordinate = new handleCoordinate();
			A_0 = A_0.Replace("'left':", "");
			A_0 = A_0.Replace("'top':", "");
			A_0 = A_0.Replace("'right':", "");
			A_0 = A_0.Replace("'bottom':", "");
			A_0 = A_0.Replace("{", "");
			A_0 = A_0.Replace("}", "");
			string[] array = A_0.Split(',');
			handleCoordinate.left = (int)Convert.ToDouble(array[0]);
			handleCoordinate.top = (int)Convert.ToDouble(array[1]);
			handleCoordinate.right = (int)Convert.ToDouble(array[2]);
			handleCoordinate.buttom = (int)Convert.ToDouble(array[3]);
			handleCoordinate.left = ((handleCoordinate.left < 0) ? (handleCoordinate.left + ay) : handleCoordinate.left);
			handleCoordinate.right = ((handleCoordinate.right < 0) ? (handleCoordinate.right + ay) : handleCoordinate.right);
			return handleCoordinate;
		}

		private List<handleCoordinate> n(string A_0)
		{
			List<handleCoordinate> list = new List<handleCoordinate>();
			if (A_0.Contains("left"))
			{
				list.Add(o(A_0));
			}
			else
			{
				string[] array = A_0.Split(';');
				for (int i = 0; i < array.Length; i++)
				{
					string[] array2 = array[i].Split(',');
					handleCoordinate handleCoordinate = new handleCoordinate();
					if (array2.Length > 3)
					{
						handleCoordinate.left = (int)Convert.ToDouble(array2[0]);
						handleCoordinate.top = (int)Convert.ToDouble(array2[1]);
						handleCoordinate.right = (int)Convert.ToDouble(array2[2]);
						handleCoordinate.buttom = (int)Convert.ToDouble(array2[3]);
						handleCoordinate.left = ((handleCoordinate.left < 0) ? (handleCoordinate.left + ay) : handleCoordinate.left);
						handleCoordinate.right = ((handleCoordinate.right < 0) ? (handleCoordinate.right + ay) : handleCoordinate.right);
						list.Add(handleCoordinate);
					}
				}
			}
			return list;
		}

		public epubReadPage(string vendorId, string colibId, string userId, string password, string bookId, string bookPath, string publisher, int tryReadPages = 0)
		{
			a();
			c2.Size = new System.Drawing.Size(2560, 1440);
			c3.Size = c2.Size;
			this.m_d = vendorId;
			this.m_e = colibId;
			this.m_f = userId;
			this.m_g = password;
			this.m_h = bookId;
			this.m_i = bookPath;
			this.m_j = bookPath;
			this.m_k = publisher;
			cb = ((tryReadPages != 0) ? (tryReadPages + 2) : 0);
			JSBindingObject.annotList = new ArrayList();
			JSBindingObject.leftNoteList = new List<NOTE_ARRAYLIST>();
			JSBindingObject.rightNoteList = new List<NOTE_ARRAYLIST>();
			JSBindingObject.setForm(this);
			a7 = new ChromiumWebBrowser("");
			a7.Name = "LEFT_WEBVIEW";
			a7.Dock = DockStyle.Fill;
			a8 = new ChromiumWebBrowser("");
			a8.Name = "RIGHT_WEBVIEW";
			a8.Dock = DockStyle.Fill;
			using (Graphics graphics = CreateGraphics())
			{
				bl = graphics.DpiX;
			}
			BrowserSettings browserSettings = new BrowserSettings();
			browserSettings.ApplicationCacheDisabled = true;
			browserSettings.JavascriptDisabled = false;
			browserSettings.JavaDisabled = true;
			browserSettings.JavascriptDomPasteDisabled = true;
			browserSettings.JavaScriptOpenWindowsDisabled = true;
			browserSettings.CaretBrowsingEnabled = false;
			browserSettings.UniversalAccessFromFileUrlsAllowed = true;
			browserSettings.ImageLoadingDisabled = false;
			browserSettings.FileAccessFromFileUrlsAllowed = true;
			a7.DragHandler = new global::d();
			a7.MenuHandler = new global::e();
			a7.DownloadHandler = new global::f();
			a7.RequestHandler = new global::g();
			a7.IsLoadingChanged += new EventHandler<IsLoadingChangedEventArgs>(c);
			a7.ShowDevTools();
			a8.DragHandler = new global::d();
			a8.MenuHandler = new global::e();
			a8.DownloadHandler = new global::f();
			a8.RequestHandler = new global::g();
			a8.IsLoadingChanged += new EventHandler<IsLoadingChangedEventArgs>(c);
			a7.IsLoadingChanged += new EventHandler<IsLoadingChangedEventArgs>(b);
			a8.IsLoadingChanged += new EventHandler<IsLoadingChangedEventArgs>(a);
			c2.Controls.Add(a7);
			c3.Controls.Add(a8);
			jsObj1 = new JSBindingObject();
			jsObj1.setWebview(a7);
			a7.RegisterJsObject("FORM", jsObj1);
			jsObj2 = new JSBindingObject();
			jsObj2.setWebview(a8);
			a8.RegisterJsObject("FORM", jsObj2);
			c2.HorizontalScroll.Enabled = false;
			c3.HorizontalScroll.Enabled = false;
			c2.VerticalScroll.Enabled = false;
			c3.VerticalScroll.Enabled = false;
		}

		public static void SetTimeout(double interval, Action action)
		{
			f f = new f();
			f.b = action;
			f.a = new System.Timers.Timer(interval);
			f.a.Elapsed += new ElapsedEventHandler(f.c);
			f.a.Enabled = true;
		}

		private void aq(object A_0, EventArgs A_1)
		{
			bp = false;
			ac();
			d7.BringToFront();
			@do.BringToFront();
			di.BringToFront();
			d8.BringToFront();
			ce.Interval = 1000;
			ce.Tick += new EventHandler(ap);
			ce.Start();
			af();
		}

		private void af()
		{
			bool visible = false;
			string sqlCommand = "SELECT bookRightsDRM FROM userbook_metadata  WHERE userbook_metadata.vendorid = '" + this.m_d + "'  and userbook_metadata.colibid = '" + this.m_e + "'  and userbook_metadata.account = '" + this.m_f + "'  and userbook_metadata.bookid = '" + this.m_h + "' ";
			try
			{
				QueryResult queryResult = Global.bookManager.sqlCommandQuery(sqlCommand);
				if (queryResult.fetchRow())
				{
					new XMLTool();
					CACodecTools cACodecTools = new CACodecTools();
					string @string = queryResult.getString("bookRightsDRM");
					if (@string != null && @string != "")
					{
						XmlDocument xmlDocument = new XmlDocument();
						string xml = cACodecTools.stringDecode(@string, true);
						xmlDocument.LoadXml(xml);
						foreach (XmlNode item in xmlDocument.SelectNodes("/drm/functions"))
						{
							if (item.InnerText.Contains("canPrint"))
							{
								visible = true;
								break;
							}
						}
					}
				}
			}
			catch
			{
			}
			ek.Visible = visible;
		}

		private void ap(object A_0, EventArgs A_1)
		{
			ce.Stop();
			ce.Tick -= new EventHandler(ap);
			y();
		}

		private void ae()
		{
			bv = File.ReadAllText("./rangy-1.3.0/lib/jquery-2.1.4.min.js");
			bw = File.ReadAllText("./rangy-1.3.0/lib/rangy-core.js");
			bx = File.ReadAllText("./rangy-1.3.0/lib/rangy-classapplier.js");
			by = File.ReadAllText("./rangy-1.3.0/lib/rangy-serializer.js");
			bz = File.ReadAllText("./rangy-1.3.0/lib/rangy-textrange.js");
			b1 = File.ReadAllText("./rangy-1.3.0/lib/CustomSearch-backend.js");
			ca = File.ReadAllText("./rangy-1.3.0/lib/rangy-highlighter-backend.js");
			b6 = File.ReadAllText("./TongWen/tongwen_core.js");
			b7 = File.ReadAllText("./TongWen/tongwen_table_s2t.js");
			b8 = File.ReadAllText("./TongWen/tongwen_table_t2s.js");
			if (bp)
			{
				b0 = File.ReadAllText("./rangy-1.3.0/lib/wesley.android.selection.fxl.js");
				b0 += "android.selection.webviewName = 'LEFT_WEBVIEW';";
				b0 = b0 + "android.selection.leftToRight = " + (bk ? "true" : "false") + ";";
				b0 = b0 + "android.selection.verticalWritingMode = " + (bj ? "true" : "false") + ";";
				b4 = File.ReadAllText("./rangy-1.3.0/lib/wesley_2.fxl.js");
				b9 = File.ReadAllText("./rangy-1.3.0/lib/fxl.css");
				return;
			}
			cf = File.ReadAllText("./rangy-1.3.0/lib/wesley.android.selection_3.js");
			b2 = File.ReadAllText("./rangy-1.3.0/lib/backcanvas.js");
			b4 = File.ReadAllText("./rangy-1.3.0/lib/wesley_3.js");
			b5 = File.ReadAllText("./rangy-1.3.0/lib/multicolumn.js");
			if (!bj)
			{
				b3 = "$(document).ready(function(){\r\n                            $(document).keyup(function(e){  window.FORM.keyup(e.keyCode);   });                  \r\n                            $(document).mouseup(function(e){ if(e.which==1) { android.selection.longTouch(e); } }); \r\n                            $('a').click(function(){  android.selection.aClicked($(this).attr('href')); });\r\n                        })";
			}
			else
			{
				b3 = "$(document).ready(function(){\r\n                            $(document).keyup(function(e){  window.FORM.keyup(e.keyCode);   });\r\n                            $(document).mouseup(function(e){ if(e.which==1) { android.selection.longTouch(e); } });\r\n                             $('a').click(function(){  android.selection.aClicked($(this).attr('href')); });\r\n                        })";
			}
		}

		private bool ad()
		{
			foreach (global::c<string, string> item in Enumerable.Select(Enumerable.Where(Enumerable.SelectMany(Directory.EnumerateFiles(this.m_i, "*.js", SearchOption.AllDirectories), _003C_003Ec._003C_003E9__143_0 ?? (_003C_003Ec._003C_003E9__143_0 = new Func<string, IEnumerable<string>>(_003C_003Ec._003C_003E9.a)), _003C_003Ec._003C_003E9__143_1 ?? (_003C_003Ec._003C_003E9__143_1 = new Func<string, string, global::b<string, string>>(_003C_003Ec._003C_003E9.a))), _003C_003Ec._003C_003E9__143_2 ?? (_003C_003Ec._003C_003E9__143_2 = new Func<global::b<string, string>, bool>(_003C_003Ec._003C_003E9.a))), _003C_003Ec._003C_003E9__143_3 ?? (_003C_003Ec._003C_003E9__143_3 = new Func<global::b<string, string>, global::c<string, string>>(_003C_003Ec._003C_003E9.b))))
			{
				if (item.File.Contains("jquery"))
				{
					return true;
				}
			}
			return false;
		}

		private void ac()
		{
			if (this.m_d.Equals("tryread"))
			{
				df.Visible = false;
				dv.Visible = false;
				dc.Visible = false;
				dd.Visible = false;
				dn.Visible = false;
				c5.Visible = false;
				c6.Visible = false;
			}
			a1 = bl / 96.0;
			d6.Location = new System.Drawing.Point((this.m_b.Width - d6.Width) / 2, (this.m_b.Height - d6.Width) / 2);
			if (bi == 2)
			{
				bc = Convert.ToInt32((double)this.m_b.Width / a1 / 2.0 - 100.0);
				bd = Convert.ToInt32((double)this.m_b.Height / a1) - 100;
				bc -= (int)((double)dt.Width / a1);
			}
			else
			{
				bc = Convert.ToInt32((double)this.m_b.Width / a1) - 100;
				bd = Convert.ToInt32((double)this.m_b.Height / a1) - 100;
				bc -= dt.Width * 2;
			}
			bd -= (int)((double)c4.Height / a1);
			c2.Location = new System.Drawing.Point(dt.Right, c4.Bottom);
			c3.Top = c2.Top;
			dz.Width = this.m_b.Width / 2;
			dz.Height = this.m_b.Height - c4.Height;
			dz.Location = new System.Drawing.Point(c2.Right + 50, c2.Top);
			dg.Height = this.m_b.Height - (c4.Height - 15);
			dg.Width = Convert.ToInt32((double)this.m_b.Width * 0.25);
			dg.Location = new System.Drawing.Point(dt.Width, c4.Height);
			dh.Height = dg.Height - 3;
			dh.Width = dg.Width - 3;
			dr.Size = dh.Size;
			dw.Size = dh.Size;
			@do.Location = new System.Drawing.Point((this.m_b.Width - @do.Width) / 2, (this.m_b.Height - @do.Height - c4.Bottom) / 2);
			d7.Top = c2.Top;
			d7.Left = 0;
			d7.Width = this.m_b.Width;
			d7.Height = this.m_b.Height - c4.Height;
			dt.Location = new System.Drawing.Point(0, c4.Height);
			ds.Location = new System.Drawing.Point(this.m_b.Width - ds.Width, c4.Height);
			dt.Height = this.m_b.Height;
			ds.Height = this.m_b.Height;
		}

		public void modifyLeftPageTextBox(int left_page)
		{
			if (base.InvokeRequired)
			{
				delModifyLeftPageTextBox method = new delModifyLeftPageTextBox(modifyLeftPageTextBox);
				Invoke(method, left_page);
			}
			else
			{
				if (left_page <= 0)
				{
					return;
				}
				lock (ax)
				{
					this.m_n = left_page;
					if (dc.Text != string.Empty)
					{
						a7.ExecuteScriptAsync("custom_HighlightAllOccurencesOfString('" + dc.Text + "');");
					}
				}
			}
		}

		public void modifyRightPageTextBox(int right_page)
		{
			if (base.InvokeRequired)
			{
				delModifyRightPageTextBox method = new delModifyRightPageTextBox(modifyRightPageTextBox);
				Invoke(method, right_page);
			}
			else
			{
				if (right_page <= 0)
				{
					return;
				}
				lock (ax)
				{
					this.m_o = right_page;
					if (dc.Text != string.Empty)
					{
						a8.ExecuteScriptAsync("custom_HighlightAllOccurencesOfString('" + dc.Text + "');");
					}
				}
			}
		}

		public void modifyTotalPageTextBox(int pages)
		{
			if (base.InvokeRequired)
			{
				delModifyTotalPageTextBox method = new delModifyTotalPageTextBox(modifyTotalPageTextBox);
				Invoke(method, pages);
			}
			else
			{
				lock (ax)
				{
					this.m_m = pages;
				}
			}
		}

		public void setPageLabel()
		{
			if (base.InvokeRequired)
			{
				delSetPageLabel method = new delSetPageLabel(setPageLabel);
				Invoke(method);
			}
			else if (bp)
			{
				string text = Convert.ToString((this.m_p + 1 > this.m_v) ? this.m_v : (this.m_p + 1));
				string text2 = Convert.ToString((this.m_p + 2 > this.m_v) ? this.m_v : (this.m_p + 2));
				if (bi > 1)
				{
					if (bj)
					{
						if (text.Equals(text2) || this.m_p == 0)
						{
							c7.Text = text + " (" + this.m_v + ")";
						}
						else
						{
							c7.Text = text2 + "-" + text + " (" + this.m_v + ")";
						}
					}
					else if (text.Equals(text2) || this.m_p == 0)
					{
						c7.Text = text + " (" + this.m_v + ")";
					}
					else
					{
						c7.Text = text + "-" + text2 + " (" + this.m_v + ")";
					}
				}
				else
				{
					c7.Text = text + " (" + this.m_v + ")";
				}
			}
			else
			{
				this.m_o = ((this.m_o > this.m_m) ? this.m_m : this.m_o);
				if (this.m_p == 0 && this.m_v != 1)
				{
					c7.Text = "";
					return;
				}
				c7.Text = this.m_n + "-" + this.m_o + "(" + this.m_m + ")";
			}
		}

		private void ab()
		{
			dt.Visible = true;
			ds.Visible = true;
			if (bp)
			{
				if (this.m_p == 0)
				{
					dt.Visible = false;
				}
				else if (this.m_p >= this.m_v - bi)
				{
					ds.Visible = false;
				}
				return;
			}
			if (this.m_c.coverPath != null && this.m_c.coverPath.EndsWith(this.m_s))
			{
				bk = !bk;
			}
			if (bk)
			{
				if (this.m_v == 1)
				{
					if (this.m_n == 1)
					{
						dt.Visible = false;
					}
					if (this.m_o == this.m_v)
					{
						ds.Visible = false;
					}
				}
				else if (this.m_p == 0)
				{
					dt.Visible = false;
				}
				else if (this.m_p == this.m_v - 1 && this.m_o == this.m_m)
				{
					ds.Visible = false;
				}
			}
			else if (this.m_v == 1)
			{
				if (this.m_o == 1)
				{
					dt.Visible = false;
				}
				if (this.m_n == this.m_v)
				{
					ds.Visible = false;
				}
			}
			else if (this.m_p == 0)
			{
				ds.Visible = false;
			}
			else if (this.m_p == this.m_v - 1 && this.m_n == this.m_m)
			{
				dt.Visible = false;
			}
		}

		public void showWebview()
		{
			if (base.InvokeRequired)
			{
				delShowWebview method = new delShowWebview(showWebview);
				Invoke(method);
				return;
			}
			if (!this.m_ah && this.m_a == 0f)
			{
				columnizedCount = 0;
				c2.Visible = true;
				c3.Visible = true;
			}
			if (jsObj1.CurPage > 0)
			{
				this.m_n = jsObj1.CurPage;
			}
			if (jsObj2.CurPage > 0)
			{
				this.m_o = jsObj2.CurPage;
			}
			if (this.m_a > 0f)
			{
				this.m_ai = Convert.ToInt32((float)this.m_m / this.m_a);
				this.m_ai = ((this.m_ai < 1) ? 1 : this.m_ai);
				this.m_ai = ((this.m_ai > this.m_m) ? this.m_m : this.m_ai);
				this.m_a = 0f;
				b(this.m_ai);
			}
			else if (cu >= 0)
			{
				aa();
			}
			setPageLabel();
			ab();
			if (cc != null)
			{
				cc[this.m_p] = this.m_m;
			}
			c2.Visible = true;
			c3.Visible = true;
			if (a2)
			{
				a7.ExecuteScriptAsync("TongWen.trans2Trad(document);");
				if (bi == 2)
				{
					a8.ExecuteScriptAsync("TongWen.trans2Trad(document);");
				}
			}
			else
			{
				a7.ExecuteScriptAsync("TongWen.trans2Simp(document);");
				if (bi == 2)
				{
					a8.ExecuteScriptAsync("TongWen.trans2Simp(document);");
				}
			}
		}

		private void aa()
		{
			do
			{
				try
				{
					lock (ax)
					{
						int pos = bookAnnotation[cu].locationX + jsObj1.CurLeft;
						scrollToPosition(bj, pos, a7.Name);
						cu = -1;
					}
					return;
				}
				catch
				{
				}
				Thread.Sleep(300);
			}
			while (cu >= 0);
		}

		private string m(string A_0)
		{
			if (A_0.EndsWith(".mp4") || A_0.EndsWith(".m4a"))
			{
				return "audio/mp4";
			}
			if (A_0.EndsWith(".aac"))
			{
				return "audio/aac";
			}
			if (A_0.EndsWith(".mp1") || A_0.EndsWith(".mp1") || A_0.EndsWith(".mp2") || A_0.EndsWith(".mp3") || A_0.EndsWith(".mpg") || A_0.EndsWith(".mpeg"))
			{
				return "audio/mpeg";
			}
			if (A_0.EndsWith(".oga") || A_0.EndsWith(".ogg"))
			{
				return "audio/ogg";
			}
			if (A_0.EndsWith(".wav"))
			{
				return "audio/wav";
			}
			if (A_0.EndsWith(".webm"))
			{
				return "audio/webm";
			}
			return "";
		}

		private void a(int A_0, int A_1, string A_2)
		{
			START_END_PAIR sTART_END_PAIR = new START_END_PAIR();
			sTART_END_PAIR.start = A_0;
			sTART_END_PAIR.end = A_1;
			sTART_END_PAIR.rangy = A_2;
			START_END_PAIR item = sTART_END_PAIR;
			cg.Add(item);
		}

		private void c(object A_0, IsLoadingChangedEventArgs A_1)
		{
			if (base.InvokeRequired)
			{
				delOnIsLoadingChanged method = new delOnIsLoadingChanged(c);
				Invoke(method, A_0, A_1);
				return;
			}
			ChromiumWebBrowser chromiumWebBrowser = (ChromiumWebBrowser)A_0;
			string name = chromiumWebBrowser.Name;
			if (A_1.IsLoading)
			{
				int num28 = 1;
				return;
			}
			System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
			timer.Interval = 500;
			timer.Tick += new EventHandler(ao);
			Task<JavascriptResponse> task = null;
			ch = false;
			c7.Visible = true;
			if (bp)
			{
				d4.Visible = false;
				if (bi == 1)
				{
					if (bq && leftSmil != null && leftSmil.parList.Count > 0)
					{
						string text = leftSmil.parList[0].audioSrc.Replace(this.m_l, "").Replace("\\", "/");
						string text2 = m(text);
						chromiumWebBrowser.ExecuteScriptAsync("addCSSRule('." + this.m_x + "','" + this.m_y + "');");
						chromiumWebBrowser.ExecuteScriptAsync("android.selection.addHtml5Audio('" + text + "','" + this.m_x + "', '" + text2 + "');");
						d4.Visible = !d5.Visible;
					}
					foreach (AnnotationData item in bookAnnotation)
					{
						if (item.itemIndex == this.m_p)
						{
							task = a7.EvaluateScriptAsync("(function(){ var range = highlighter.converterOldSerialIdToStartAndEnd('" + item.rangyRange + "'); return range; })();");
							task.ContinueWith(_003C_003Ec._003C_003E9__161_0 ?? (_003C_003Ec._003C_003E9__161_0 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.a)), TaskScheduler.Default);
							Console.WriteLine("task.Result.Result = " + task.Result.Result);
							string text3 = (string)task.Result.Result;
							if (text3 != null)
							{
								string[] array = text3.Split(',');
								int num = int.Parse(array[0]);
								int num2 = int.Parse(array[1]);
								task = a7.EvaluateScriptAsync("(function(){ var rect = highlighter.getBoundingRectByStartAndEnd(" + num + "," + num2 + "); return rect; })();");
								task.ContinueWith(_003C_003Ec._003C_003E9__161_1 ?? (_003C_003Ec._003C_003E9__161_1 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.b)), TaskScheduler.Default);
								Console.WriteLine("task.Result.Result = " + task.Result.Result);
								int num3 = l(item.colorRGBA);
								a7.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + num + "," + num2 + ",'" + au[num3] + "'); ");
								a(num, num2, item.rangyRange);
							}
						}
					}
				}
				else if (name == "LEFT_WEBVIEW")
				{
					if (bq && leftSmil != null && leftSmil.parList.Count > 0)
					{
						string text4 = leftSmil.parList[0].audioSrc.Replace(this.m_l, "").Replace("\\", "/");
						string text5 = m(text4);
						chromiumWebBrowser.ExecuteScriptAsync("addCSSRule('." + this.m_x + "','" + this.m_y + "');");
						chromiumWebBrowser.ExecuteScriptAsync("android.selection.addHtml5Audio('" + text4 + "','" + this.m_x + "', '" + text5 + "');");
						d4.Visible = !d5.Visible;
					}
					foreach (AnnotationData item2 in bookAnnotation)
					{
						if (item2.itemIndex == this.m_p)
						{
							task = a7.EvaluateScriptAsync("(function(){ var range = highlighter.converterOldSerialIdToStartAndEnd('" + item2.rangyRange + "'); return range; })();");
							task.ContinueWith(_003C_003Ec._003C_003E9__161_2 ?? (_003C_003Ec._003C_003E9__161_2 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.c)), TaskScheduler.Default);
							Console.WriteLine("task.Result.Result = " + task.Result.Result);
							string text6 = (string)task.Result.Result;
							if (text6 != null)
							{
								string[] array2 = text6.Split(',');
								int num4 = int.Parse(array2[0]);
								int num5 = int.Parse(array2[1]);
								task = a7.EvaluateScriptAsync("(function(){ var rect = highlighter.getBoundingRectByStartAndEnd(" + num4 + "," + num5 + "); return rect; })();");
								task.ContinueWith(_003C_003Ec._003C_003E9__161_3 ?? (_003C_003Ec._003C_003E9__161_3 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.d)), TaskScheduler.Default);
								Console.WriteLine("task.Result.Result = " + task.Result.Result);
								int num6 = l(item2.colorRGBA);
								a7.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + num4 + "," + num5 + ",'" + au[num6] + "'); ");
								a(num4, num5, item2.rangyRange);
							}
						}
					}
				}
				else
				{
					if (bq && rightSmil != null && rightSmil.parList.Count > 0)
					{
						string text7 = rightSmil.parList[0].audioSrc.Replace(this.m_l, "").Replace("\\", "/");
						string text8 = m(text7);
						chromiumWebBrowser.ExecuteScriptAsync("addCSSRule('." + this.m_x + "','" + this.m_y + "');");
						chromiumWebBrowser.ExecuteScriptAsync("android.selection.addHtml5Audio('" + text7 + "','" + this.m_x + "', '" + text8 + "');");
						d4.Visible = !d5.Visible;
					}
					foreach (AnnotationData item3 in bookAnnotation)
					{
						if (item3.itemIndex == this.m_p + 1)
						{
							task = a8.EvaluateScriptAsync("(function(){ var range = highlighter.converterOldSerialIdToStartAndEnd('" + item3.rangyRange + "'); return range; })();");
							task.ContinueWith(_003C_003Ec._003C_003E9__161_4 ?? (_003C_003Ec._003C_003E9__161_4 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.e)), TaskScheduler.Default);
							Console.WriteLine("task.Result.Result = " + task.Result.Result);
							string text9 = (string)task.Result.Result;
							if (text9 != null)
							{
								string[] array3 = text9.Split(',');
								int num7 = int.Parse(array3[0]);
								int num8 = int.Parse(array3[1]);
								task = a8.EvaluateScriptAsync("(function(){ var rect = highlighter.getBoundingRectByStartAndEnd(" + num7 + "," + num8 + "); return rect; })();");
								task.ContinueWith(_003C_003Ec._003C_003E9__161_5 ?? (_003C_003Ec._003C_003E9__161_5 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.f)), TaskScheduler.Default);
								Console.WriteLine("task.Result.Result = " + task.Result.Result);
								int num9 = l(item3.colorRGBA);
								a8.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + num7 + "," + num8 + ",'" + au[num9] + "'); ");
								a(num7, num8, item3.rangyRange);
							}
						}
					}
				}
				setPageLabel();
				chromiumWebBrowser.ExecuteScriptAsync("android.selection.modifyAtags();");
				timer.Start();
				return;
			}
			if (!bj && bk)
			{
				if (bi == 1)
				{
					chromiumWebBrowser.ExecuteScriptAsync("android.selection.webviewName ='LEFT_WEBVIEW';");
					chromiumWebBrowser.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
					chromiumWebBrowser.ExecuteScriptAsync("$(window).unbind('scroll');");
					chromiumWebBrowser.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					if (bq && leftSmil != null && leftSmil.parList.Count > 0)
					{
						string text10 = leftSmil.parList[0].audioSrc.Replace(this.m_l, "").Replace("\\", "/");
						string text11 = m(text10);
						chromiumWebBrowser.ExecuteScriptAsync("addCSSRule('." + this.m_x + "','" + this.m_y + "');");
						chromiumWebBrowser.ExecuteScriptAsync("android.selection.addHtml5Audio('" + text10 + "','" + this.m_x + "', '" + text11 + "');");
					}
					foreach (AnnotationData item4 in bookAnnotation)
					{
						if (item4.itemIndex == this.m_p)
						{
							task = chromiumWebBrowser.EvaluateScriptAsync("(function(){ var range = highlighter.converterOldSerialIdToStartAndEnd('" + item4.rangyRange + "'); return range; })();");
							task.ContinueWith(_003C_003Ec._003C_003E9__161_6 ?? (_003C_003Ec._003C_003E9__161_6 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.g)), TaskScheduler.Default);
							Console.WriteLine("task.Result.Result = " + task.Result.Result);
							string text12 = (string)task.Result.Result;
							if (text12 != null)
							{
								string[] array4 = text12.Split(',');
								int num10 = int.Parse(array4[0]);
								int num11 = int.Parse(array4[1]);
								task = chromiumWebBrowser.EvaluateScriptAsync("(function(){ var rect = highlighter.getBoundingRectByStartAndEnd(" + num10 + "," + num11 + "); return rect; })();");
								task.ContinueWith(_003C_003Ec._003C_003E9__161_7 ?? (_003C_003Ec._003C_003E9__161_7 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.h)), TaskScheduler.Default);
								Console.WriteLine("task.Result.Result = " + task.Result.Result);
								int num12 = l(item4.colorRGBA);
								chromiumWebBrowser.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + num10 + "," + num11 + ",'" + au[num12] + "'); ");
								a(num10, num11, item4.rangyRange);
							}
						}
					}
					columnizedCount++;
					if (columnizedCount == bi)
					{
						showWebview();
					}
				}
				else if (bi == 2)
				{
					if (chromiumWebBrowser.Name == "LEFT_WEBVIEW")
					{
						chromiumWebBrowser.ExecuteScriptAsync("android.selection.webviewName ='LEFT_WEBVIEW';");
						chromiumWebBrowser.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
						chromiumWebBrowser.ExecuteScriptAsync("$(window).unbind('scroll');");
						chromiumWebBrowser.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						if (bq && leftSmil != null && leftSmil.parList.Count > 0)
						{
							string text13 = leftSmil.parList[0].audioSrc.Replace(this.m_l, "").Replace("\\", "/");
							string text14 = m(text13);
							chromiumWebBrowser.ExecuteScriptAsync("addCSSRule('." + this.m_x + "','" + this.m_y + "');");
							chromiumWebBrowser.ExecuteScriptAsync("android.selection.addHtml5Audio('" + text13 + "','" + this.m_x + "', '" + text14 + "');");
						}
						foreach (AnnotationData item5 in bookAnnotation)
						{
							if (item5.itemIndex == this.m_p)
							{
								task = chromiumWebBrowser.EvaluateScriptAsync("(function(){ var range = highlighter.converterOldSerialIdToStartAndEnd('" + item5.rangyRange + "'); return range; })();");
								task.ContinueWith(_003C_003Ec._003C_003E9__161_8 ?? (_003C_003Ec._003C_003E9__161_8 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.i)), TaskScheduler.Default);
								Console.WriteLine("task.Result.Result = " + task.Result.Result);
								string text15 = (string)task.Result.Result;
								if (text15 != null)
								{
									string[] array5 = text15.Split(',');
									int num13 = int.Parse(array5[0]);
									int num14 = int.Parse(array5[1]);
									task = chromiumWebBrowser.EvaluateScriptAsync("(function(){ var rect = highlighter.getBoundingRectByStartAndEnd(" + num13 + "," + num14 + "); return rect; })();");
									task.ContinueWith(_003C_003Ec._003C_003E9__161_9 ?? (_003C_003Ec._003C_003E9__161_9 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.j)), TaskScheduler.Default);
									Console.WriteLine("task.Result.Result = " + task.Result.Result);
									int num15 = l(item5.colorRGBA);
									chromiumWebBrowser.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + num13 + "," + num14 + ",'" + au[num15] + "'); ");
									a(num13, num14, item5.rangyRange);
								}
							}
						}
						columnizedCount++;
						if (columnizedCount == bi)
						{
							Console.WriteLine("this.showWebview");
							showWebview();
						}
					}
					else
					{
						chromiumWebBrowser.ExecuteScriptAsync("android.selection.webviewName ='RIGHT_WEBVIEW';");
						chromiumWebBrowser.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
						chromiumWebBrowser.ExecuteScriptAsync("$(window).unbind('scroll');");
						chromiumWebBrowser.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						if (bq && rightSmil != null && rightSmil.parList.Count > 0)
						{
							string text16 = rightSmil.parList[0].audioSrc.Replace(this.m_l, "").Replace("\\", "/");
							string text17 = m(text16);
							chromiumWebBrowser.ExecuteScriptAsync("addCSSRule('." + this.m_x + "','" + this.m_y + "');");
							chromiumWebBrowser.ExecuteScriptAsync("android.selection.addHtml5Audio('" + text16 + "','" + this.m_x + "', '" + text17 + "');");
						}
						foreach (AnnotationData item6 in bookAnnotation)
						{
							if (item6.itemIndex == this.m_p)
							{
								task = chromiumWebBrowser.EvaluateScriptAsync("(function(){ var range = highlighter.converterOldSerialIdToStartAndEnd('" + item6.rangyRange + "'); return range; })();");
								task.ContinueWith(_003C_003Ec._003C_003E9__161_10 ?? (_003C_003Ec._003C_003E9__161_10 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.k)), TaskScheduler.Default);
								Console.WriteLine("task.Result.Result = " + task.Result.Result);
								string text18 = (string)task.Result.Result;
								if (text18 != null)
								{
									string[] array6 = text18.Split(',');
									int num16 = int.Parse(array6[0]);
									int num17 = int.Parse(array6[1]);
									task = chromiumWebBrowser.EvaluateScriptAsync("(function(){ var rect = highlighter.getBoundingRectByStartAndEnd(" + num16 + "," + num17 + "); return rect; })();");
									task.ContinueWith(_003C_003Ec._003C_003E9__161_11 ?? (_003C_003Ec._003C_003E9__161_11 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.l)), TaskScheduler.Default);
									Console.WriteLine("task.Result.Result = " + task.Result.Result);
									int num18 = l(item6.colorRGBA);
									chromiumWebBrowser.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + num16 + "," + num17 + ",'" + au[num18] + "'); ");
									a(num16, num17, item6.rangyRange);
								}
							}
						}
						modifyLeftPageTextBox(1);
						modifyRightPageTextBox(2);
						columnizedCount++;
						if (columnizedCount == bi)
						{
							Console.WriteLine("this.showWebview");
							showWebview();
						}
					}
				}
			}
			else if (bi == 1)
			{
				chromiumWebBrowser.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
				chromiumWebBrowser.ExecuteScriptAsync("$(window).unbind('scroll');");
				chromiumWebBrowser.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				if (bq && leftSmil != null && leftSmil.parList.Count > 0)
				{
					string text19 = leftSmil.parList[0].audioSrc.Replace(this.m_l, "").Replace("\\", "/");
					string text20 = m(text19);
					chromiumWebBrowser.ExecuteScriptAsync("addCSSRule('." + this.m_x + "','" + this.m_y + "');");
					chromiumWebBrowser.ExecuteScriptAsync("android.selection.addHtml5Audio('" + text19 + "','" + this.m_x + "', '" + text20 + "');");
				}
				foreach (AnnotationData item7 in bookAnnotation)
				{
					if (item7.itemIndex == this.m_p)
					{
						task = chromiumWebBrowser.EvaluateScriptAsync("(function(){ var range = highlighter.converterOldSerialIdToStartAndEnd('" + item7.rangyRange + "'); return range; })();");
						task.ContinueWith(_003C_003Ec._003C_003E9__161_12 ?? (_003C_003Ec._003C_003E9__161_12 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.m)), TaskScheduler.Default);
						Console.WriteLine("task.Result.Result = " + task.Result.Result);
						string text21 = (string)task.Result.Result;
						if (text21 != null)
						{
							string[] array7 = text21.Split(',');
							int num19 = int.Parse(array7[0]);
							int num20 = int.Parse(array7[1]);
							task = chromiumWebBrowser.EvaluateScriptAsync("(function(){ var rect = highlighter.getBoundingRectByStartAndEnd(" + num19 + "," + num20 + "); return rect; })();");
							task.ContinueWith(_003C_003Ec._003C_003E9__161_13 ?? (_003C_003Ec._003C_003E9__161_13 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.n)), TaskScheduler.Default);
							Console.WriteLine("task.Result.Result = " + task.Result.Result);
							int num21 = l(item7.colorRGBA);
							chromiumWebBrowser.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + num19 + "," + num20 + ",'" + au[num21] + "'); ");
							a(num19, num20, item7.rangyRange);
						}
					}
				}
				modifyLeftPageTextBox(1);
				columnizedCount++;
				if (columnizedCount == bi)
				{
					showWebview();
				}
			}
			else if (bi == 2)
			{
				if (chromiumWebBrowser.Name == "LEFT_WEBVIEW")
				{
					chromiumWebBrowser.ExecuteScriptAsync("android.selection.rightPadding =" + 50 + ";");
					chromiumWebBrowser.ExecuteScriptAsync("android.selection.leftPadding =" + 50 + ";");
					chromiumWebBrowser.ExecuteScriptAsync("$(window).unbind('scroll');");
					chromiumWebBrowser.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					if (bq && leftSmil != null && leftSmil.parList.Count > 0)
					{
						string text22 = leftSmil.parList[0].audioSrc.Replace(this.m_l, "").Replace("\\", "/");
						string text23 = m(text22);
						chromiumWebBrowser.ExecuteScriptAsync("addCSSRule('." + this.m_x + "','" + this.m_y + "');");
						chromiumWebBrowser.ExecuteScriptAsync("android.selection.addHtml5Audio('" + text22 + "','" + this.m_x + "', '" + text23 + "');");
					}
					foreach (AnnotationData item8 in bookAnnotation)
					{
						if (item8.itemIndex == this.m_p)
						{
							task = chromiumWebBrowser.EvaluateScriptAsync("(function(){ var range = highlighter.converterOldSerialIdToStartAndEnd('" + item8.rangyRange + "'); return range; })();");
							task.ContinueWith(_003C_003Ec._003C_003E9__161_14 ?? (_003C_003Ec._003C_003E9__161_14 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.o)), TaskScheduler.Default);
							Console.WriteLine("task.Result.Result = " + task.Result.Result);
							string text24 = (string)task.Result.Result;
							if (text24 != null)
							{
								string[] array8 = text24.Split(',');
								int num22 = int.Parse(array8[0]);
								int num23 = int.Parse(array8[1]);
								task = chromiumWebBrowser.EvaluateScriptAsync("(function(){ var rect = highlighter.getBoundingRectByStartAndEnd(" + num22 + "," + num23 + "); return rect; })();");
								task.ContinueWith(_003C_003Ec._003C_003E9__161_15 ?? (_003C_003Ec._003C_003E9__161_15 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.p)), TaskScheduler.Default);
								Console.WriteLine("task.Result.Result = " + task.Result.Result);
								int num24 = l(item8.colorRGBA);
								chromiumWebBrowser.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + num22 + "," + num23 + ",'" + au[num24] + "'); ");
								a(num22, num23, item8.rangyRange);
							}
						}
					}
					columnizedCount++;
					if (columnizedCount == bi)
					{
						showWebview();
					}
				}
				else
				{
					chromiumWebBrowser.ExecuteScriptAsync("$(document).on('selectionchange');");
					chromiumWebBrowser.ExecuteScriptAsync("android.selection.rightPadding =" + 50 + ";");
					chromiumWebBrowser.ExecuteScriptAsync("android.selection.leftPadding =" + 50 + ";");
					chromiumWebBrowser.ExecuteScriptAsync("$(window).unbind('scroll');");
					chromiumWebBrowser.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					modifyLeftPageTextBox(2);
					modifyRightPageTextBox(1);
					if (bq && rightSmil != null && rightSmil.parList.Count > 0)
					{
						string text25 = rightSmil.parList[0].audioSrc.Replace(this.m_l, "").Replace("\\", "/");
						string text26 = m(text25);
						chromiumWebBrowser.ExecuteScriptAsync("addCSSRule('." + this.m_x + "','" + this.m_y + "');");
						chromiumWebBrowser.ExecuteScriptAsync("android.selection.addHtml5Audio('" + text25 + "','" + this.m_x + "', '" + text26 + "');");
					}
					foreach (AnnotationData item9 in bookAnnotation)
					{
						if (item9.itemIndex == this.m_p)
						{
							task = chromiumWebBrowser.EvaluateScriptAsync("(function(){ var range = highlighter.converterOldSerialIdToStartAndEnd('" + item9.rangyRange + "'); return range; })();");
							task.ContinueWith(_003C_003Ec._003C_003E9__161_16 ?? (_003C_003Ec._003C_003E9__161_16 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.q)), TaskScheduler.Default);
							Console.WriteLine("task.Result.Result = " + task.Result.Result);
							string text27 = (string)task.Result.Result;
							if (text27 != null)
							{
								string[] array9 = text27.Split(',');
								int num25 = int.Parse(array9[0]);
								int num26 = int.Parse(array9[1]);
								task = chromiumWebBrowser.EvaluateScriptAsync("(function(){ var rect = highlighter.getBoundingRectByStartAndEnd(" + num25 + "," + num26 + "); return rect; })();");
								task.ContinueWith(_003C_003Ec._003C_003E9__161_17 ?? (_003C_003Ec._003C_003E9__161_17 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.r)), TaskScheduler.Default);
								Console.WriteLine("task.Result.Result = " + task.Result.Result);
								int num27 = l(item9.colorRGBA);
								chromiumWebBrowser.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + num25 + "," + num26 + ",'" + au[num27] + "'); ");
								a(num25, num26, item9.rangyRange);
							}
						}
					}
					columnizedCount++;
					if (columnizedCount == bi)
					{
						showWebview();
					}
				}
			}
			chromiumWebBrowser.ExecuteScriptAsync("$('a').click(function() { return false; });");
			timer.Start();
		}

		private void ao(object A_0, EventArgs A_1)
		{
			(A_0 as System.Windows.Forms.Timer).Stop();
			a7.Visible = true;
			a8.Visible = true;
			d7.Visible = false;
		}

		private int l(string A_0)
		{
			for (int i = 0; i < at.Length; i++)
			{
				if (at[i].ToLower() == A_0.ToLower())
				{
					return i;
				}
			}
			return 0;
		}

		private void b(object A_0, IsLoadingChangedEventArgs A_1)
		{
			a3 = A_1.IsLoading;
			if (a5 && !a3 && !a4)
			{
				a5 = false;
				b((this.m_ai == 0) ? this.m_m : this.m_ai);
				setPageLabel();
			}
		}

		private void a(object A_0, IsLoadingChangedEventArgs A_1)
		{
			a4 = A_1.IsLoading;
			if (a5 && !a3 && !a4)
			{
				a5 = false;
				b((this.m_ai == 0) ? this.m_m : this.m_ai);
				setPageLabel();
			}
		}

		[AsyncStateMachine(typeof(g))]
		private Task z()
		{
			g stateMachine = default(g);
			stateMachine.c = this;
			stateMachine.b = AsyncTaskMethodBuilder.Create();
			stateMachine.a = -1;
			AsyncTaskMethodBuilder asyncTaskMethodBuilder = stateMachine.b;
			asyncTaskMethodBuilder.Start(ref stateMachine);
			return stateMachine.b.Task;
		}

		[AsyncStateMachine(typeof(h))]
		private Task c(string A_0, string A_1)
		{
			h stateMachine = default(h);
			stateMachine.e = this;
			stateMachine.d = A_0;
			stateMachine.c = A_1;
			stateMachine.b = AsyncTaskMethodBuilder.Create();
			stateMachine.a = -1;
			AsyncTaskMethodBuilder asyncTaskMethodBuilder = stateMachine.b;
			asyncTaskMethodBuilder.Start(ref stateMachine);
			return stateMachine.b.Task;
		}

		public static bool isChinese(string strChinese)
		{
			bool result = true;
			int num = 0;
			int num2 = Convert.ToInt32("9fff", 16);
			int num3 = Convert.ToInt32("4e00", 16);
			for (int i = 0; i < strChinese.Length; i++)
			{
				num = Convert.ToInt32(Convert.ToChar(strChinese.Substring(i, 1)));
				if (num >= num3 && num < num2)
				{
					result = true;
					break;
				}
				result = false;
			}
			return result;
		}

		[AsyncStateMachine(typeof(i))]
		private void y()
		{
			i stateMachine = default(i);
			stateMachine.c = this;
			stateMachine.b = AsyncVoidMethodBuilder.Create();
			stateMachine.a = -1;
			AsyncVoidMethodBuilder asyncVoidMethodBuilder = stateMachine.b;
			asyncVoidMethodBuilder.Start(ref stateMachine);
		}

		public string getMediaOverlayRule(string htmlDoc)
		{
			foreach (XElement item in XDocument.Parse(htmlDoc, LoadOptions.None).Root.Elements())
			{
				if (!item.Name.LocalName.Equals("head"))
				{
					continue;
				}
				foreach (XElement item2 in item.Elements())
				{
					if (!item2.Name.LocalName.Equals("link"))
					{
						continue;
					}
					foreach (XAttribute item3 in item2.Attributes())
					{
						if (item3.Value.EndsWith(".css"))
						{
							string text = k(item3.Value);
							if (!text.Equals(""))
							{
								return text;
							}
						}
					}
				}
			}
			return "";
		}

		private string k(string A_0)
		{
			string result = "";
			if (!File.Exists(this.m_l + A_0))
			{
				return result;
			}
			string text = File.ReadAllText(this.m_l + A_0);
			Regex regex = new Regex("(?<selector>(?:(?:[^,{]+),?)*?)\\{(?:(?<name>[^}:]+):?(?<value>[^};]+);?)*?\\}", RegexOptions.IgnoreCase | RegexOptions.Compiled);
			if (!string.IsNullOrEmpty(text))
			{
				foreach (Match item in regex.Matches(Regex.Replace(text, "(?<!\")\\/\\*.+?\\*\\/(?!\")", string.Empty)))
				{
					string text2 = item.ToString().TrimStart().Replace("\n", " ");
					if (text2 != null && text2.StartsWith("." + this.m_x))
					{
						int num = text2.IndexOf("{") + 1;
						int num2 = text2.IndexOf("}");
						if (num2 > num)
						{
							return text2.Substring(num, num2 - num);
						}
						return result;
					}
				}
				return result;
			}
			return result;
		}

		private string d(int A_0)
		{
			string result = "";
			if (A_0 < 0)
			{
				return result;
			}
			string key = Enumerable.ElementAt(this.m_c.spineDictionary.Keys, A_0);
			this.m_s = this.m_c.manifestDictionary[key].href.Replace("/", "\\");
			int num = this.m_s.LastIndexOf('\\');
			if (num > 0)
			{
				return this.m_s.Substring(num + 1, this.m_s.Length - (num + 1));
			}
			return this.m_s;
		}

		private string c(int A_0)
		{
			if (A_0 < 0)
			{
				return "";
			}
			string key = Enumerable.ElementAt(this.m_c.spineDictionary.Keys, A_0);
			return this.m_c.manifestDictionary[key].id;
		}

		private void x()
		{
			if (base.InvokeRequired)
			{
				delloadHtmlDoc method = new delloadHtmlDoc(x);
				Invoke(method);
				return;
			}
			if (!bp)
			{
				c2.Visible = false;
				c3.Visible = false;
				d7.Visible = true;
			}
			columnizedCount = 0;
			leftSmil = new SimpleSmil();
			rightSmil = new SimpleSmil();
			a0 = false;
			c7.Visible = false;
			c7.Text = "";
			if (az)
			{
				b();
			}
			this.m_q = this.m_p;
			this.m_t = d(this.m_p);
			this.m_u = c(this.m_p);
			this.m_r = this.m_u;
			de.Text = (this.m_ad.ContainsKey(this.m_s) ? this.m_ad[this.m_s] : "");
			int left = (c4.Width - (de.Width + 900)) / 2;
			de.Margin = new Padding(left, 0, 0, 0);
			if (!this.m_ae.ContainsKey(this.m_s))
			{
				this.m_ae.Add(this.m_s, "");
			}
			leftSmil = getSmilData(this.m_s);
			if (bp)
			{
				pathToBookOEBPS = this.m_l;
				bt = ((this.m_ae[this.m_s] == "") ? a(this.m_s, this.m_ag) : this.m_ae[this.m_s]);
				this.m_ae[this.m_s] = ((this.m_ae[this.m_s] == "") ? bt : "");
				if (this.m_p == 0)
				{
					bu = "";
				}
				else if (this.m_p + 1 < this.m_v)
				{
					string key = Enumerable.ElementAt(this.m_c.spineDictionary.Keys, this.m_p + 1);
					string href = this.m_c.manifestDictionary[key].href;
					if (!this.m_ae.ContainsKey(href))
					{
						this.m_ae.Add(href, "");
					}
					bu = ((this.m_ae[href] == "") ? a(href, this.m_ag) : this.m_ae[href]);
					this.m_ae[href] = ((this.m_ae[href] == "") ? bu : "");
					rightSmil = getSmilData(href);
				}
				else
				{
					bu = "";
				}
				if (bj && (this.m_c.coverPath == null || !this.m_c.coverPath.EndsWith(this.m_s)))
				{
					string text = bt;
					bt = bu;
					bu = text;
				}
				bk = !bj;
			}
			else
			{
				bs = ((this.m_ae[this.m_s] == "") ? a(this.m_s, this.m_ag) : this.m_ae[this.m_s]);
				this.m_ae[this.m_s] = ((this.m_ae[this.m_s] == "") ? bs : "");
				if (br)
				{
					bo = true;
					bj = true;
					bk = false;
				}
				br = d(bs);
				bj = ((!this.m_c.writingMode.Equals("horizontal")) ? true : false);
				bo = !bj;
				if (this.m_c.coverPath != null && this.m_c.coverPath.EndsWith(this.m_s))
				{
					bj = !bj;
					bo = true;
				}
				bk = !bj;
				if (br)
				{
					bo = false;
					bj = false;
					bk = true;
				}
			}
			if (leftSmil == null && rightSmil == null)
			{
				d5.Visible = false;
			}
			JSBindingObject.leftNoteList = new List<NOTE_ARRAYLIST>();
			JSBindingObject.rightNoteList = new List<NOTE_ARRAYLIST>();
			az = false;
			if (a6 && (!bp || FXL_CanHighlight))
			{
				loadAnnotationFromDB();
			}
			ch = true;
			w();
		}

		private void b(string A_0, string A_1)
		{
			if (base.InvokeRequired)
			{
				deljumpToHyperLinkPage method = new deljumpToHyperLinkPage(b);
				Invoke(method, A_0, A_1);
				return;
			}
			bool flag = false;
			A_1 = A_1.Substring(A_1.LastIndexOf("/") + 1);
			foreach (KeyValuePair<string, Manifest> item in this.m_c.manifestDictionary)
			{
				string text = A_1;
				if (A_1.IndexOf(".") > 0)
				{
					text = A_1.Substring(0, A_1.IndexOf("."));
				}
				if (item.Value.href == A_1)
				{
					A_1 = item.Value.id;
					break;
				}
				if (item.Key == text)
				{
					A_1 = item.Key;
					break;
				}
			}
			for (int i = 0; i < this.m_c.spineDictionary.Count; i++)
			{
				if (Enumerable.First(Enumerable.Skip(this.m_c.spineDictionary, i)).Key == A_1)
				{
					this.m_p = i;
					flag = true;
					break;
				}
			}
			if (flag)
			{
				x();
			}
		}

		public SimpleSmil getSmilData(string htmlSrc)
		{
			foreach (SimpleSmil item in this.m_z)
			{
				string text = item.id;
				if (text.IndexOf("#") > 0)
				{
					text = text.Substring(0, text.IndexOf("#"));
				}
				if (text.Equals(htmlSrc))
				{
					return item;
				}
			}
			return null;
		}

		private void w()
		{
			if (base.InvokeRequired)
			{
				delreflashDocument method = new delreflashDocument(w);
				Invoke(method);
				return;
			}
			a7.Visible = false;
			a8.Visible = false;
			JSBindingObject.annotList.Clear();
			fontSize = 20;
			pathToBookOEBPS = this.m_l;
			if (bp)
			{
				b0 = b0 + "android.selection.multiColumnCount = " + bi + ";";
				if ((double)(bc + 50 + 50) * (bl / 96.0) / (double)av < (double)(bd + 50 + 50 - c4.Height) * (bl / 96.0) / (double)aw)
				{
					actual_webkit_column_width = (int)((double)(bc + 50 + 50) * (bl / 96.0));
					actual_webkit_column_width = (int)Math.Floor((double)actual_webkit_column_width / (bl / 96.0));
					actual_webkit_column_height = (int)Math.Floor((double)actual_webkit_column_width / (double)av * (double)aw);
					double num = (double)actual_webkit_column_width / (double)av;
				}
				else
				{
					actual_webkit_column_height = (int)((double)(bd + 50 + 50 - c4.Height) * (bl / 96.0));
					actual_webkit_column_height = (int)Math.Ceiling((double)actual_webkit_column_height / (bl / 96.0));
					actual_webkit_column_width = (int)Math.Ceiling((double)(actual_webkit_column_height * av) / (double)aw);
					double num2 = (double)actual_webkit_column_height / (double)aw;
				}
				int width = this.m_b.Width;
				int height = this.m_b.Height;
				if (bi == 2)
				{
					c2.Size = new System.Drawing.Size((int)Math.Ceiling((double)actual_webkit_column_width * (bl / 96.0)), (int)Math.Ceiling((double)actual_webkit_column_height * (bl / 96.0)));
					c3.Size = new System.Drawing.Size((int)Math.Ceiling((double)actual_webkit_column_width * (bl / 96.0)), (int)Math.Ceiling((double)actual_webkit_column_height * (bl / 96.0)));
					c2.Left = width / 2 - c2.Width + 1;
					c2.Top = height / 2 - c2.Height / 2;
					c3.Left = width / 2;
					c3.Top = height / 2 - c2.Height / 2;
					if (this.m_p == 0 && !bj)
					{
						int left = c2.Left;
						c2.Left = c3.Left;
						c3.Left = left;
					}
					string text = b0 += "android.selection.webviewName = 'LEFT_WEBVIEW';";
					string html = "<script>" + bv + bw + bx + by + bz + ca + text + b3 + b1 + b4 + b6 + b7 + b8 + "</script><style>" + b9 + "</style>" + bt;
					text = (b0 += "android.selection.webviewName = 'RIGHT_WEBVIEW';");
					string html2 = "<script>" + bv + bw + bx + by + bz + ca + text + b3 + b1 + b4 + b6 + b7 + b8 + "</script><style>" + b9 + "</style>" + bu;
					a7.Load("");
					a7.LoadHtml(html, "file:///");
					a8.Load("");
					a8.LoadHtml(html2, "file:///");
				}
				else
				{
					c2.Size = new System.Drawing.Size((int)Math.Ceiling((double)actual_webkit_column_width * (bl / 96.0)), (int)Math.Ceiling((double)actual_webkit_column_height * (bl / 96.0)));
					c2.Left = width / 2 - c2.Width / 2;
					c2.Top = c4.Height;
					string html3 = "<script>" + bv + bw + bx + by + bz + ca + b0 + b3 + b1 + b4 + b6 + b7 + b8 + "</script><style>" + b9 + "</style>" + bt;
					a7.Load("");
					a7.LoadHtml(html3, "file:///");
				}
				dt.Visible = true;
				ds.Visible = true;
				if (bk)
				{
					if (this.m_p == 0)
					{
						dt.Visible = false;
					}
					else if (this.m_p >= this.m_v - bi)
					{
						ds.Visible = false;
					}
				}
				else if (this.m_p == 0)
				{
					ds.Visible = false;
				}
				else if (this.m_p >= this.m_v - bi)
				{
					dt.Visible = false;
				}
				c2.Visible = ((!bt.Equals("")) ? true : false);
				c3.Visible = ((!bu.Equals("") && bi != 1) ? true : false);
				f();
			}
			else
			{
				b0 = cf;
				b0 = b0 + "android.selection.verticalWritingMode = " + (bj ? "true" : "false") + ";";
				b0 = b0 + "android.selection.leftToRight = " + (bk ? "true" : "false") + ";";
				b0 = b0 + "android.selection.pageProgressionDirection = " + (bo ? "true" : "false") + ";";
				b0 = b0 + "android.selection.multiColumnCount = " + bi + ";";
				b0 = b0 + "android.selection.fontSize = " + Convert.ToInt32(fontSize * perFontFize / 100) + ";";
				b0 = b0 + "android.selection.lineHeight = " + 2.0 + ";";
				b0 = b0 + "_dotNetWindowWidth = " + bc + ";";
				b0 = b0 + "_dotNetWindowHeight = " + bd + ";";
				b0 = b0 + "_dotNetWindowColumnGap = " + 100 + ";";
				b0 = b0 + "_dotNetWindowPaddingTop = " + 50 + ";";
				b0 = b0 + "_dotNetWindowPaddingBottom = " + 50 + ";";
				b0 = b0 + "_dotNetWindowPaddingLeft = " + 50 + ";";
				b0 = b0 + "_dotNetWindowPaddingRight = " + 50 + ";";
				actual_webkit_column_width = bc;
				actual_webkit_column_height = bd;
				if (!bj)
				{
					c2.Size = new System.Drawing.Size((int)((double)(actual_webkit_column_width + 50 + 50) * (bl / 96.0)), (int)((double)(actual_webkit_column_height + 50 + 50) * (bl / 96.0)));
				}
				else
				{
					c2.Size = new System.Drawing.Size((int)((double)(actual_webkit_column_width + 50 + 50) * (bl / 96.0)), (int)((double)(actual_webkit_column_height + 50 + 50) * (bl / 96.0)));
				}
				c3.Size = c2.Size;
				c3.Left = c2.Right - 1;
				b0 += "android.selection.webviewName = 'LEFT_WEBVIEW';";
				if (this.m_ah)
				{
					b0 += "android.selection.jumpToLastPageAfterLoaded = true;";
					this.m_ah = false;
				}
				else
				{
					b0 += "android.selection.jumpToLastPageAfterLoaded = false;";
				}
				string html4 = "<script type=\"text/javascript\">" + bv + bw + bx + by + bz + ca + b0 + b3 + b1 + b4 + b2 + b5 + b6 + b7 + b8 + "</script>" + bs;
				a7.LoadHtml(html4, "file:///");
				if (bi == 2)
				{
					b0 += "android.selection.webviewName = 'RIGHT_WEBVIEW';";
					html4 = "<script type=\"text/javascript\">" + bv + bw + bx + by + bz + ca + b0 + b3 + b1 + b4 + b2 + b5 + b6 + b7 + b8 + "</script>" + bs;
					a8.LoadHtml(html4, "file:///");
				}
				f();
			}
		}

		private void v()
		{
			this.m_ad.Clear();
			this.m_ae.Clear();
			a(this.m_w);
		}

		private void a(List<SimpleListItem> A_0)
		{
			foreach (SimpleListItem item in A_0)
			{
				string text = item.href.Replace("/", "\\");
				if (text.Contains("#"))
				{
					text = text.Substring(0, text.IndexOf("#"));
				}
				if (!this.m_ad.ContainsKey(text))
				{
					this.m_ad.Add(text, item.itemText);
				}
				if (!this.m_ae.ContainsKey(text))
				{
					this.m_ae.Add(text, "");
				}
				a(item.subOrderList);
			}
		}

		private void u()
		{
			dh.Nodes.Clear();
			dh.Nodes.Add(new TreeNode("目錄"));
			TreeNode treeNode = new TreeNode();
			treeNode = dh.Nodes[0];
			int a_ = 0;
			a(this.m_w, treeNode, a_);
		}

		private void b(object A_0, KeyEventArgs A_1)
		{
		}

		private void a(List<SimpleListItem> A_0, TreeNode A_1, int A_2)
		{
			int num = 0;
			try
			{
				foreach (SimpleListItem item in A_0)
				{
					A_1.Nodes.Add(new TreeNode(item.itemText));
					string text = item.href;
					if (text.Contains("#"))
					{
						text = text.Substring(0, text.IndexOf("#"));
					}
					A_1.Nodes[num].Tag = text;
					TreeNode a_ = A_1.Nodes[num];
					a(item.subOrderList, a_, num);
					num++;
				}
			}
			catch (Exception)
			{
			}
		}

		private void c(object A_0, TreeNodeMouseClickEventArgs A_1)
		{
			if (A_1.Node.Tag == null)
			{
				return;
			}
			int num = this.m_p;
			string text = A_1.Node.Tag.ToString();
			if (text.Contains("#"))
			{
				text = text.Substring(0, text.IndexOf("#"));
			}
			for (int i = 0; i < this.m_c.epubObjects.Count; i++)
			{
				string value = this.m_c.epubObjects[i].htmlPath.Replace(this.m_l, "").Replace("\\", "/");
				if (value == text || text.EndsWith(value))
				{
					this.m_p = i;
					break;
				}
			}
			if (num != this.m_p)
			{
				if (bp && bi == 2 && this.m_p % 2 == 0)
				{
					this.m_p--;
				}
				dg.Visible = false;
				x();
			}
			else if (this.m_n != 1)
			{
				b(1);
			}
		}

		private byte[] t()
		{
			byte[] result = new byte[1];
			if (this.m_d.Equals("free"))
			{
				this.m_g = "free";
			}
			string text = this.m_i + "\\encryption.xml";
			string text2 = this.m_j.Substring(0, this.m_j.LastIndexOf('\\')) + "\\HyHDWL.ps2";
			if (File.Exists(text) && File.Exists(text2))
			{
				try
				{
					string cipherValue = this.m_af.getCipherValue(text);
					if (this.m_g == null)
					{
						this.m_g = "";
					}
					string str = this.m_af.CreateMD5Hash(this.m_g);
					str += ":";
					result = this.m_af.encryptStringDecode2ByteArray(cipherValue, text2, str, true);
					return result;
				}
				catch
				{
					return result;
				}
			}
			return result;
		}

		private string a(string A_0, byte[] A_1)
		{
			Stream stream = new CACodecTools().fileAESDecode(this.m_l + A_0, A_1, false);
			string text;
			using (StreamReader streamReader = new StreamReader(stream, Encoding.UTF8))
			{
				text = streamReader.ReadToEnd();
			}
			stream.Close();
			if (bq)
			{
				string mediaOverlayRule = getMediaOverlayRule(text);
				this.m_y = (mediaOverlayRule.Equals("") ? this.m_y : mediaOverlayRule);
			}
			return i(text);
		}

		public static string getXMLNodeAttribute(XmlNode node, string attributeName)
		{
			string result = null;
			try
			{
				for (int i = 0; i < node.Attributes.Count; i++)
				{
					if (node.Attributes[i].Name.ToString().Equals(attributeName))
					{
						result = node.Attributes[i].Value.ToString();
						return result;
					}
				}
				return result;
			}
			catch
			{
				return result;
			}
		}

		private void j(string A_0)
		{
			av = 1;
			aw = 1;
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.XmlResolver = null;
			try
			{
				xmlDocument.LoadXml(A_0.Replace("<?xml version=\"1.0\" ?>", ""));
				foreach (XmlNode childNode in xmlDocument.ChildNodes)
				{
					foreach (XmlNode childNode2 in childNode.ChildNodes)
					{
						foreach (XmlNode childNode3 in childNode2.ChildNodes)
						{
							if (childNode3.Name.ToString().Equals("meta") && childNode3.Attributes.Count > 1)
							{
								ci = getXMLNodeAttribute(childNode3, "content");
								if (ci.StartsWith("width"))
								{
									break;
								}
							}
						}
					}
				}
				if (ci != null && !ci.Equals(""))
				{
					string[] array = ci.Split(',');
					av = Convert.ToInt32(array[0].Replace("width=", ""));
					aw = Convert.ToInt32(array[1].Replace("height=", ""));
				}
			}
			catch (Exception)
			{
			}
			if ((double)(bc + 50 + 50) * (bl / 96.0) / (double)av < (double)(bd + 50 + 50) * (bl / 96.0) / (double)aw)
			{
				actual_webkit_column_width = (int)((double)(bc + 50 + 50) * (bl / 96.0));
				actual_webkit_column_width = (int)Math.Floor((double)actual_webkit_column_width / (bl / 96.0));
				actual_webkit_column_height = (int)Math.Floor((double)actual_webkit_column_width / (double)av * (double)aw);
				cj = (double)actual_webkit_column_width / (double)av;
			}
			else
			{
				actual_webkit_column_height = (int)((double)(bd + 50 + 50 - c4.Height) * (bl / 96.0));
				actual_webkit_column_height = (int)Math.Ceiling((double)actual_webkit_column_height / (bl / 96.0));
				actual_webkit_column_width = (int)Math.Ceiling((double)(actual_webkit_column_height * av) / (double)aw);
				cj = (double)actual_webkit_column_height / (double)aw;
			}
		}

		private string i(string A_0)
		{
			if (bp)
			{
				j(A_0);
			}
			else
			{
				string a_ = string.Format("width={0}, height={1}", bc, bd);
				A_0 = a(A_0, "html/head/meta", "viewport", "content", a_);
			}
			string text = "";
			StringReader stringReader = new StringReader(A_0);
			string empty = string.Empty;
			do
			{
				empty = stringReader.ReadLine();
				if (empty != null)
				{
					empty = empty.Replace("<title/>", "");
					if (empty.Contains("ibook.js"))
					{
						empty = "";
					}
					if (bp && empty.Contains("viewport"))
					{
						empty = empty.Replace(ci, ci + ", initial-scale=" + cj);
					}
					empty = empty.Replace("<a xlink:href=", "<a href=");
					empty = empty.Replace("<video ", "<video poster=\"playbutton.png\" onclick=\"mediaClicked(src);\" ");
					empty = empty.Replace("controls=\"controls\"", "");
					empty = empty.Replace("preload=\"true\"", "");
					empty = empty.Replace("jquery.js", "");
					if (!bp)
					{
						empty = h(empty);
					}
					if (Global.regPath.Equals("NCLReader") && empty.Contains(".mp3") && !empty.Contains("class="))
					{
						empty = empty.Replace(".mp3\"", ".mp3\" class=\"rMovArea\" ");
					}
					text += (bp ? empty : e(empty));
					text += "\n";
				}
			}
			while (empty != null);
			string str = "<style> video::-webkit-media-controls-fullscreen-button {  display: none; }   img { max-height: 100%;  max-width: 100%; } </style>";
			string text2 = "<base href=" + this.m_l + "\\>";
			if (bp)
			{
				return text.Replace("</head>", text2 + "</head>");
			}
			return text.Replace("</head>", str + text2 + "</head>");
		}

		private string a(string A_0, string A_1, string A_2, string A_3, string A_4)
		{
			HtmlAgilityPack.HtmlDocument htmlDocument = new HtmlAgilityPack.HtmlDocument();
			htmlDocument.LoadHtml(A_0);
			HtmlNodeCollection htmlNodeCollection = htmlDocument.DocumentNode.SelectNodes(A_1);
			if (htmlNodeCollection != null)
			{
				foreach (HtmlNode item in (IEnumerable<HtmlNode>)htmlNodeCollection)
				{
					if (item.OuterHtml.Contains(A_2))
					{
						item.SetAttributeValue(A_3, A_4);
					}
				}
			}
			return htmlDocument.DocumentNode.OuterHtml;
		}

		private string h(string A_0)
		{
			int num = A_0.IndexOf("<audio");
			int num2 = A_0.IndexOf("</audio>");
			if (num2 >= 0 && num >= 0 && num2 > num)
			{
				string text = A_0.Substring(num, num2 - num + 8);
				string str = f(text);
				A_0 = A_0.Replace(text, "<img src=\"audiobutton.png\" onclick=\"mediaClicked('" + str + "')\" />");
			}
			return A_0;
		}

		private string g(string A_0)
		{
			int num = A_0.IndexOf("<video");
			int num2 = A_0.IndexOf("</video>");
			if (num2 >= 0 && num >= 0 && num2 > num)
			{
				string text = A_0.Substring(num, num2 - num + 8);
				string str = f(text);
				A_0 = A_0.Replace(text, "<img src=\"playbutton.png\" onclick=\"window.open('" + str + "')\" />");
			}
			return A_0;
		}

		private string f(string A_0)
		{
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml(A_0);
			return getXMLNodeAttribute(xmlDocument.ChildNodes[0], "src");
		}

		private string e(string A_0)
		{
			string value = "<!--";
			string value2 = "-->";
			string text = A_0;
			while (text.Contains(value) && text.Contains(value2))
			{
				int num = text.IndexOf(value);
				int num2 = text.IndexOf(value2);
				try
				{
					string oldValue = text.Substring(num, num2 - num + 3);
					text = text.Replace(oldValue, "");
				}
				catch
				{
					return text;
				}
			}
			return text;
		}

		private bool d(string A_0)
		{
			HtmlAgilityPack.HtmlDocument htmlDocument = new HtmlAgilityPack.HtmlDocument();
			htmlDocument.LoadHtml(A_0);
			HtmlNodeCollection childNodes = htmlDocument.DocumentNode.ChildNodes;
			List<string> list = new List<string>();
			List<string> list2 = new List<string>();
			foreach (HtmlNode item in (IEnumerable<HtmlNode>)childNodes)
			{
				if (!item.Name.Equals("html"))
				{
					continue;
				}
				foreach (HtmlAttribute item2 in (IEnumerable<HtmlAttribute>)item.Attributes)
				{
					if (item2.Name.Equals("class"))
					{
						list.Add(item2.Value);
					}
				}
				HtmlNode htmlNode = item.SelectSingleNode("body");
				if (htmlNode == null)
				{
					return false;
				}
				foreach (HtmlAttribute item3 in (IEnumerable<HtmlAttribute>)htmlNode.Attributes)
				{
					if (item3.Name.Equals("class"))
					{
						list.Add(item3.Value);
					}
				}
				htmlNode = item.SelectSingleNode("head/link");
				if (htmlNode == null)
				{
					return false;
				}
				foreach (HtmlAttribute item4 in (IEnumerable<HtmlAttribute>)htmlNode.Attributes)
				{
					if (item4.Name.Equals("href"))
					{
						list2.Add(item4.Value);
					}
				}
			}
			List<string> list3 = new List<string>();
			try
			{
				foreach (string item5 in list2)
				{
					string[] array = File.ReadAllLines(this.m_l + item5.Replace("..", ""));
					item5.Replace("\\", "/");
					string str = item5.Substring(0, item5.LastIndexOf("/") + 1);
					string[] array2 = array;
					foreach (string text in array2)
					{
						if (text.Contains("@import"))
						{
							int num = text.IndexOf('"') + 1;
							int num2 = text.LastIndexOf('"');
							list3.Add(str + text.Substring(num, num2 - num));
						}
					}
				}
			}
			catch
			{
			}
			foreach (string item6 in list3)
			{
				list2.Add(item6);
			}
			foreach (string item7 in list2)
			{
				if (!File.Exists(this.m_l + item7.Replace("..", "")))
				{
					continue;
				}
				MatchCollection matchCollection = Regex.Matches(File.ReadAllText(this.m_l + item7.Replace("..", "")), "[^}]?([^{]*{[^}]*})", RegexOptions.Multiline);
				for (int j = 0; j < matchCollection.Count; j++)
				{
					string text2 = matchCollection[j].Captures[0].ToString().Replace("\n", "").Replace("\t", "");
					foreach (string item8 in list)
					{
						if (!text2.StartsWith("." + item8) && !text2.StartsWith(item8) && !text2.Contains(item8))
						{
							continue;
						}
						int num3 = text2.IndexOf("{") + 1;
						int num4 = text2.IndexOf("}");
						if (num4 <= num3)
						{
							continue;
						}
						string[] array2 = text2.Substring(num3, num4 - num3).Split(';');
						for (int i = 0; i < array2.Length; i++)
						{
							string[] array3 = array2[i].Split(':');
							if (array3.Length == 2 && array3[0].Contains("-epub-writing-mode"))
							{
								string text3 = array3[1];
								if (bj && text3.Contains("horizontal"))
								{
									return true;
								}
								if (!bj && text3.Contains("vertical"))
								{
									return true;
								}
							}
						}
					}
				}
			}
			return false;
		}

		private bool s()
		{
			int num = 0;
			for (int i = 0; i < this.m_p; i++)
			{
				num += cc[i];
			}
			if (num + this.m_n > cb)
			{
				dz.Visible = true;
				return true;
			}
			return false;
		}

		private void r()
		{
			dz.Visible = false;
			if (cb > 0 && s())
			{
				return;
			}
			this.m_ah = false;
			if (bp)
			{
				if (!ch && this.m_p < this.m_v - bi)
				{
					a7.ExecuteScriptAsync("android.selection.pauseAudio();");
					a8.ExecuteScriptAsync("android.selection.pauseAudio();");
					cz = false;
					epubReadPage.m_aa = 0;
					this.m_p = ((this.m_p == 0) ? (++this.m_p) : (this.m_p += bi));
					x();
				}
				return;
			}
			if (this.m_n >= this.m_m || this.m_o >= this.m_m)
			{
				if (ch)
				{
					return;
				}
				if (this.m_p < this.m_v - 1)
				{
					this.m_p++;
					x();
				}
			}
			else if (bo)
			{
				if (!bj && bk)
				{
					if (bi == 1)
					{
						if (jsObj1.CurPage + 1 <= jsObj1.TotalPages)
						{
							a7.ExecuteScriptAsync("$(window).bind('scroll');");
							a7.ExecuteScriptAsync("slideRight();");
							a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
							a7.ExecuteScriptAsync("$(window).unbind('scroll');");
							a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
							modifyLeftPageTextBox(jsObj1.CurPage + 1);
						}
					}
					else if (jsObj2.CurPage + 2 <= jsObj2.TotalPages)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideRight();slideRight();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						a8.ExecuteScriptAsync("$(window).bind('scroll');");
						a8.ExecuteScriptAsync("slideRight();slideRight();");
						a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
						a8.ExecuteScriptAsync("$(window).unbind('scroll');");
						a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						modifyLeftPageTextBox(jsObj1.CurPage + 2);
						modifyRightPageTextBox(jsObj2.CurPage + 2);
					}
				}
				else
				{
					Console.WriteLine("PAGE_PROGRESSION_DIRECTION + VERTICAL_WRITING_MODE && !LEFT_TO_RIGHT => Not implemented!");
				}
			}
			else if (!bj && bk)
			{
				if (bi == 1)
				{
					if (jsObj1.CurPage + 1 <= jsObj1.TotalPages)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideRight();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						modifyLeftPageTextBox(jsObj1.CurPage + 1);
					}
				}
				else if (jsObj1.CurPage + 2 <= jsObj1.TotalPages)
				{
					a7.ExecuteScriptAsync("$(window).bind('scroll');");
					a7.ExecuteScriptAsync("slideRight();slideRight();");
					a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
					a7.ExecuteScriptAsync("$(window).unbind('scroll');");
					a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					a8.ExecuteScriptAsync("$(window).bind('scroll');");
					a8.ExecuteScriptAsync("slideRight();slideRight();");
					a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
					a8.ExecuteScriptAsync("$(window).unbind('scroll');");
					a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					modifyLeftPageTextBox(jsObj1.CurPage + 2);
					modifyRightPageTextBox(jsObj2.CurPage + 2);
				}
			}
			else if (bi == 1)
			{
				if (jsObj1.CurPage + 1 <= jsObj1.TotalPages)
				{
					a7.ExecuteScriptAsync("$(window).bind('scroll');");
					a7.ExecuteScriptAsync("slideUp();");
					a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
					a7.ExecuteScriptAsync("$(window).unbind('scroll');");
					a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					modifyLeftPageTextBox(jsObj1.CurPage + 1);
				}
			}
			else if (jsObj1.CurPage + 2 <= jsObj1.TotalPages)
			{
				a7.ExecuteScriptAsync("$(window).bind('scroll');");
				a7.ExecuteScriptAsync("slideUp();slideUp();");
				a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
				a7.ExecuteScriptAsync("$(window).unbind('scroll');");
				a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				a8.ExecuteScriptAsync("$(window).bind('scroll');");
				a8.ExecuteScriptAsync("slideUp();slideUp();");
				a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj2.CurTop + "); android.selection.scrollLeft(0); return false;});");
				a8.ExecuteScriptAsync("$(window).unbind('scroll');");
				a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				modifyLeftPageTextBox(jsObj1.CurPage + 2);
				modifyRightPageTextBox(jsObj2.CurPage + 2);
			}
			if (this.m_v == 1)
			{
				ab();
			}
			setPageLabel();
		}

		private void q()
		{
			dz.Visible = false;
			if (cb > 0 && s())
			{
				return;
			}
			this.m_ah = false;
			if (bp)
			{
				if (!ch && this.m_p < this.m_v - bi)
				{
					a7.ExecuteScriptAsync("android.selection.pauseAudio();");
					a8.ExecuteScriptAsync("android.selection.pauseAudio();");
					cz = false;
					epubReadPage.m_aa = 0;
					this.m_p = ((this.m_p == 0) ? (++this.m_p) : (this.m_p += bi));
					x();
				}
				return;
			}
			if (this.m_n >= this.m_m || this.m_o >= this.m_m)
			{
				if (ch)
				{
					return;
				}
				if (this.m_p < this.m_v - 1)
				{
					this.m_p++;
					x();
				}
			}
			else if (!bj && bk)
			{
				if (bi == 1)
				{
					if (jsObj1.CurPage + 1 <= jsObj1.TotalPages)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideRight();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						modifyLeftPageTextBox(jsObj1.CurPage + 1);
					}
				}
				else if (jsObj2.CurPage + 2 <= jsObj2.TotalPages)
				{
					a7.ExecuteScriptAsync("$(window).bind('scroll');");
					a7.ExecuteScriptAsync("slideRight();slideRight();");
					a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
					a7.ExecuteScriptAsync("$(window).unbind('scroll');");
					a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					a8.ExecuteScriptAsync("$(window).bind('scroll');");
					a8.ExecuteScriptAsync("slideRight();slideRight();");
					a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
					a8.ExecuteScriptAsync("$(window).unbind('scroll');");
					a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					modifyLeftPageTextBox(jsObj1.CurPage + 2);
					modifyRightPageTextBox(jsObj2.CurPage + 2);
				}
			}
			else if (bi == 1)
			{
				if (jsObj1.CurPage + 1 <= jsObj1.TotalPages)
				{
					a7.ExecuteScriptAsync("$(window).bind('scroll');");
					a7.ExecuteScriptAsync("slideUp();");
					a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
					a7.ExecuteScriptAsync("$(window).unbind('scroll');");
					a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					modifyLeftPageTextBox(jsObj1.CurPage + 1);
				}
			}
			else if (jsObj1.CurPage + 2 <= jsObj1.TotalPages)
			{
				a7.ExecuteScriptAsync("$(window).bind('scroll');");
				a7.ExecuteScriptAsync("slideUp();slideUp();");
				a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
				a7.ExecuteScriptAsync("$(window).unbind('scroll');");
				a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				a8.ExecuteScriptAsync("$(window).bind('scroll');");
				a8.ExecuteScriptAsync("slideUp();slideUp();");
				a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj2.CurTop + "); android.selection.scrollLeft(0); return false;});");
				a8.ExecuteScriptAsync("$(window).unbind('scroll');");
				a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				modifyLeftPageTextBox(jsObj1.CurPage + 2);
				modifyRightPageTextBox(jsObj2.CurPage + 2);
			}
			if (this.m_v == 1)
			{
				ab();
			}
			setPageLabel();
		}

		private void p()
		{
			dz.Visible = false;
			if (bp)
			{
				if (!ch && this.m_p > 0)
				{
					a7.ExecuteScriptAsync("android.selection.pauseAudio();");
					a8.ExecuteScriptAsync("android.selection.pauseAudio();");
					cz = false;
					epubReadPage.m_aa = 0;
					this.m_p = ((this.m_p == 1) ? (--this.m_p) : (this.m_p -= bi));
					x();
				}
				return;
			}
			if (this.m_n == 1 || this.m_o == 1)
			{
				if (ch)
				{
					return;
				}
				if (this.m_p > 0)
				{
					this.m_p--;
					this.m_ah = true;
					this.m_ai = 0;
					x();
				}
			}
			else if (bo)
			{
				if (!bj && bk)
				{
					if (bi == 1)
					{
						if (jsObj1.CurPage > 1)
						{
							a7.ExecuteScriptAsync("$(window).bind('scroll');");
							a7.ExecuteScriptAsync("slideLeft();");
							a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
							a7.ExecuteScriptAsync("$(window).unbind('scroll');");
							a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
							modifyLeftPageTextBox(jsObj1.CurPage - 1);
						}
					}
					else if (jsObj1.CurPage > 2)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideLeft();slideLeft();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						a8.ExecuteScriptAsync("$(window).bind('scroll');");
						a8.ExecuteScriptAsync("slideLeft();slideLeft();");
						a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
						a8.ExecuteScriptAsync("$(window).unbind('scroll');");
						a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						modifyLeftPageTextBox(jsObj1.CurPage - 2);
						modifyRightPageTextBox(jsObj2.CurPage - 2);
					}
				}
				else
				{
					Console.WriteLine("PAGE_PROGRESSION_DIRECTION + VERTICAL_WRITING_MODE && !LEFT_TO_RIGHT => Not implemented!");
				}
			}
			else if (!bj && bk)
			{
				if (bi == 1)
				{
					if (jsObj1.CurPage > 1)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideLeft();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						modifyLeftPageTextBox(jsObj1.CurPage - 1);
					}
				}
				else if (jsObj2.CurPage > 2)
				{
					a7.ExecuteScriptAsync("$(window).bind('scroll');");
					a7.ExecuteScriptAsync("slideLeft();slideLeft();");
					a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
					a7.ExecuteScriptAsync("$(window).unbind('scroll');");
					a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					a8.ExecuteScriptAsync("$(window).bind('scroll');");
					a8.ExecuteScriptAsync("slideLeft();slideLeft();");
					a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
					a8.ExecuteScriptAsync("$(window).unbind('scroll');");
					a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					modifyLeftPageTextBox(jsObj1.CurPage - 2);
					modifyRightPageTextBox(jsObj2.CurPage - 2);
				}
			}
			else if (bi == 1)
			{
				if (jsObj1.CurPage > 1)
				{
					a7.ExecuteScriptAsync("$(window).bind('scroll');");
					a7.ExecuteScriptAsync("slideDown();");
					a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
					a7.ExecuteScriptAsync("$(window).unbind('scroll');");
					a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					modifyLeftPageTextBox(jsObj1.CurPage - 1);
				}
			}
			else if (jsObj2.CurPage > 2)
			{
				a7.ExecuteScriptAsync("$(window).bind('scroll');");
				a7.ExecuteScriptAsync("slideDown();slideDown();");
				a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
				a7.ExecuteScriptAsync("$(window).unbind('scroll');");
				a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				a8.ExecuteScriptAsync("$(window).bind('scroll');");
				a8.ExecuteScriptAsync("slideDown();slideDown();");
				a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj2.CurTop + "); android.selection.scrollLeft(0); return false;});");
				a8.ExecuteScriptAsync("$(window).unbind('scroll');");
				a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				modifyLeftPageTextBox(jsObj1.CurPage - 2);
				modifyRightPageTextBox(jsObj2.CurPage - 2);
			}
			if (this.m_v == 1)
			{
				ab();
			}
			setPageLabel();
		}

		private void o()
		{
			dz.Visible = false;
			if (bp)
			{
				if (!ch && this.m_p > 0)
				{
					a7.ExecuteScriptAsync("android.selection.pauseAudio();");
					a8.ExecuteScriptAsync("android.selection.pauseAudio();");
					cz = false;
					epubReadPage.m_aa = 0;
					this.m_p = ((this.m_p == 1) ? (--this.m_p) : (this.m_p -= bi));
					x();
				}
				return;
			}
			if (this.m_n == 1 || this.m_o == 1)
			{
				if (ch)
				{
					return;
				}
				if (this.m_p > 0)
				{
					this.m_p--;
					this.m_ah = true;
					this.m_ai = 0;
					x();
				}
			}
			else if (!bj && bk)
			{
				if (bi == 1)
				{
					if (jsObj1.CurPage > 1)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideLeft();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						modifyLeftPageTextBox(jsObj1.CurPage - 1);
					}
				}
				else if (jsObj1.CurPage > 2)
				{
					a7.ExecuteScriptAsync("$(window).bind('scroll');");
					a7.ExecuteScriptAsync("slideLeft();slideLeft();");
					a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
					a7.ExecuteScriptAsync("$(window).unbind('scroll');");
					a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					a8.ExecuteScriptAsync("$(window).bind('scroll');");
					a8.ExecuteScriptAsync("slideLeft();slideLeft();");
					a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
					a8.ExecuteScriptAsync("$(window).unbind('scroll');");
					a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					modifyLeftPageTextBox(jsObj1.CurPage - 2);
					modifyRightPageTextBox(jsObj2.CurPage - 2);
				}
			}
			else if (bi == 1)
			{
				if (jsObj1.CurPage > 1)
				{
					a7.ExecuteScriptAsync("$(window).bind('scroll');");
					a7.ExecuteScriptAsync("slideDown();");
					a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
					a7.ExecuteScriptAsync("$(window).unbind('scroll');");
					a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					modifyLeftPageTextBox(jsObj1.CurPage - 1);
				}
			}
			else if (jsObj2.CurPage > 2)
			{
				a7.ExecuteScriptAsync("$(window).bind('scroll');");
				a7.ExecuteScriptAsync("slideDown();slideDown();");
				a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
				a7.ExecuteScriptAsync("$(window).unbind('scroll');");
				a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				a8.ExecuteScriptAsync("$(window).bind('scroll');");
				a8.ExecuteScriptAsync("slideDown();slideDown();");
				a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj2.CurTop + "); android.selection.scrollLeft(0); return false;});");
				a8.ExecuteScriptAsync("$(window).unbind('scroll');");
				a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				modifyLeftPageTextBox(jsObj1.CurPage - 2);
				modifyRightPageTextBox(jsObj2.CurPage - 2);
			}
			if (this.m_v == 1)
			{
				ab();
			}
			setPageLabel();
		}

		private void n()
		{
			if (!ch && perFontFize < 300)
			{
				columnizedCount = 0;
				perFontFize += 10;
				a5 = true;
				this.m_ai = this.m_n;
				w();
				configMng.saveEpubFontSize = perFontFize;
			}
		}

		private void m()
		{
			if (!ch && perFontFize != 10)
			{
				columnizedCount = 0;
				perFontFize -= 10;
				a5 = true;
				this.m_ai = this.m_n;
				w();
				configMng.saveEpubFontSize = perFontFize;
			}
		}

		private void an(object A_0, EventArgs A_1)
		{
			r();
		}

		private void am(object A_0, EventArgs A_1)
		{
			p();
		}

		private void al(object A_0, EventArgs A_1)
		{
			if (br)
			{
				am(A_0, A_1);
			}
			else if (bk)
			{
				an(A_0, A_1);
			}
			else
			{
				am(A_0, A_1);
			}
		}

		private void ak(object A_0, EventArgs A_1)
		{
			if (br)
			{
				an(A_0, A_1);
			}
			else if (bk)
			{
				am(A_0, A_1);
			}
			else
			{
				an(A_0, A_1);
			}
		}

		private void aj(object A_0, EventArgs A_1)
		{
			n();
		}

		private void ai(object A_0, EventArgs A_1)
		{
			m();
		}

		private void ah(object A_0, EventArgs A_1)
		{
			perFontFize = 110;
			m();
		}

		private void ag(object A_0, EventArgs A_1)
		{
			a(2, 1);
		}

		private void af(object A_0, EventArgs A_1)
		{
			a(2, 3);
		}

		private void ae(object A_0, EventArgs A_1)
		{
			if (bi == 1)
			{
				a7.ExecuteScriptAsync("TongWen.trans2Simp(document);");
			}
			if (bi == 2)
			{
				a7.ExecuteScriptAsync("TongWen.trans2Simp(document);");
				a8.ExecuteScriptAsync("TongWen.trans2Simp(document);");
			}
			a2 = false;
		}

		private void ad(object A_0, EventArgs A_1)
		{
			if (bi == 1)
			{
				a7.ExecuteScriptAsync("TongWen.trans2Trad(document);");
			}
			if (bi == 2)
			{
				a7.ExecuteScriptAsync("TongWen.trans2Trad(document);");
				a8.ExecuteScriptAsync("TongWen.trans2Trad(document);");
			}
			a2 = true;
		}

		private void ac(object A_0, EventArgs A_1)
		{
			a7.ExecuteScriptAsync("clearBackCanvas();");
			a8.ExecuteScriptAsync("clearBackCanvas();");
			JSBindingObject.annotList.Clear();
		}

		private void a(int A_0, int A_1)
		{
			if (base.InvokeRequired)
			{
				deltoc_panel_Control method = new deltoc_panel_Control(a);
				Invoke(method, A_0, A_1);
				return;
			}
			switch (A_0)
			{
			case 0:
				dg.Visible = false;
				break;
			case 1:
				dg.Visible = true;
				break;
			case 2:
				if (A_1 == 1 && (dr.Visible || dw.Visible))
				{
					dg.Visible = true;
				}
				else if (A_1 == 2 && (dh.Visible || dw.Visible))
				{
					dg.Visible = true;
				}
				else if (A_1 == 3 && (dh.Visible || dr.Visible))
				{
					dg.Visible = true;
				}
				else
				{
					dg.Visible = !dg.Visible;
				}
				break;
			}
			dh.Visible = false;
			dr.Visible = false;
			dw.Visible = false;
			if (dg.Visible)
			{
				switch (A_1)
				{
				case 1:
					dh.Visible = true;
					break;
				case 2:
					dr.Visible = true;
					break;
				case 3:
					dw.Visible = true;
					break;
				}
			}
		}

		private void l()
		{
			if (!JSBindingObject.leftStartAndEnd.Equals(string.Empty))
			{
				string[] array = JSBindingObject.leftStartAndEnd.Split(';');
				for (int i = 0; i < array.Length; i++)
				{
					string[] array2 = array[i].Split(',');
					int num = int.Parse(array2[0]);
					int num2 = int.Parse(array2[1]);
					a7.ExecuteScriptAsync("highlighter.removeHighlightsByStartAndEnd(" + num + "," + num2 + "); ");
				}
			}
			if (!JSBindingObject.rightStartAndEnd.Equals(string.Empty))
			{
				string[] array = JSBindingObject.rightStartAndEnd.Split(';');
				for (int i = 0; i < array.Length; i++)
				{
					string[] array3 = array[i].Split(',');
					int num3 = int.Parse(array3[0]);
					int num4 = int.Parse(array3[1]);
					a8.ExecuteScriptAsync("highlighter.removeHighlightsByStartAndEnd(" + num3 + "," + num4 + "); ");
				}
			}
		}

		private void ab(object A_0, EventArgs A_1)
		{
			if (dc.Text == ck)
			{
				a((!dr.Visible) ? 1 : 0, 2);
				return;
			}
			l();
			if (dc.Text == string.Empty || dc.Text != ck)
			{
				a(0, 2);
				a7.ExecuteScriptAsync("clearBackCanvas();");
				a8.ExecuteScriptAsync("clearBackCanvas();");
				JSBindingObject.annotList.Clear();
				dr.Nodes.Clear();
			}
			ck = dc.Text;
			if (dc.Text != string.Empty)
			{
				if (bi == 1)
				{
					a7.ExecuteScriptAsync("custom_HighlightAllOccurencesOfString('" + ck + "');");
				}
				if (bi == 2)
				{
					a7.ExecuteScriptAsync("custom_HighlightAllOccurencesOfString('" + ck + "');");
					a8.ExecuteScriptAsync("custom_HighlightAllOccurencesOfString('" + ck + "');");
				}
				k();
			}
		}

		private void a(object A_0, KeyEventArgs A_1)
		{
			if (A_1.KeyCode == Keys.Return)
			{
				ab(A_0, A_1);
			}
		}

		private void aa(object A_0, EventArgs A_1)
		{
			StringBuilder stringBuilder = new StringBuilder();
			string sqlCommand = "select * from epubAnnotationPro where book_sno=" + this.m_aj + " and noteText<>'' and status<>'1' order by itemIndex, rangeTag0, rangeTag1, rangeTag2";
			QueryResult queryResult = Global.bookManager.sqlCommandQuery(sqlCommand);
			while (queryResult.fetchRow())
			{
				stringBuilder.AppendLine("%0d%0a");
				long num = queryResult.getLong("createTime") + 28800;
				long ticks = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).Ticks;
				DateTime dateTime = new DateTime(ticks + num * 10000000);
				stringBuilder.AppendLine(de.Text + "   " + dateTime.ToString() + "%0d%0a");
				stringBuilder.AppendLine(queryResult.getString("noteText") + "%0d%0a");
			}
			if (System.Windows.Forms.MessageBox.Show(Global.bookManager.LanqMng.getLangString("mailtoMessage"), "", MessageBoxButtons.YesNo).Equals(DialogResult.Yes))
			{
				new OpenProcess().mailToProcess("", "Notes of " + Text, stringBuilder.ToString(), "");
			}
		}

		private void a(string A_0, string A_1)
		{
			if (base.InvokeRequired)
			{
				b method = new b(a);
				Invoke(method, A_0, A_1);
				return;
			}
			string[] array = A_0.Split(';');
			List<int> list = new List<int>();
			for (int i = 0; i < array.Length; i++)
			{
				string[] array2 = array[i].Split(',');
				list.Add(Convert.ToInt32(array2[2]));
			}
			list.Sort();
			if (cl >= 0 && list.Count > 0)
			{
				cl = ((cl >= list.Count) ? (list.Count - 1) : cl);
				scrollToPosition(bj, jsObj1.CurLeft + list[cl], a7.Name);
				cl = -1;
			}
		}

		private void k()
		{
			a(1, 2);
			ck = dc.Text;
			a7.ExecuteScriptAsync("clearBackCanvasByRegion('0', '0','" + bc + "','" + bd + "');");
			if (ck != string.Empty && ck.Length > 0)
			{
				a7.ExecuteScriptAsync("custom_HighlightAllOccurencesOfString('" + ck + "');");
			}
			lavel = -1;
			Cursor = Cursors.WaitCursor;
			TreeNode treeNode = dr.Nodes.Add("搜尋結果");
			searchListData = new List<SearchListData>();
			for (int i = 0; i < this.m_v; i++)
			{
				string text = Enumerable.ElementAt(this.m_c.spineDictionary.Keys, i);
				string text2 = this.m_c.manifestDictionary[text].href.Replace("/", "\\");
				string a_ = this.m_ad.ContainsKey(text2) ? this.m_ad[text2] : text;
				if (!this.m_ae.ContainsKey(text))
				{
					this.m_ae.Add(text, "");
				}
				if (this.m_ae[text] == "")
				{
					this.m_ae[text] = a(text2, this.m_ag);
				}
				a(ck, treeNode, a_, this.m_ae[text], i);
				treeNode.Expand();
				System.Windows.Forms.Application.DoEvents();
			}
			treeNode.ExpandAll();
			if (treeNode.Nodes.Count > 0)
			{
				dr.SelectedNode = treeNode.Nodes[0];
			}
			Cursor = Cursors.Default;
		}

		private void a(string A_0, TreeNode A_1, string A_2, string A_3, int A_4)
		{
			string[] array = A_3.Split(new string[1]
			{
				"\r\n"
			}, StringSplitOptions.RemoveEmptyEntries);
			short num = 30;
			short num2 = 0;
			new Regex("<body.*?>(.|\n)*?</body>");
			Regex regex = new Regex("<[^>]+>|]+>");
			string text = "";
			string text2 = "";
			short num3 = 0;
			short num4 = 0;
			short num5 = 0;
			A_0 = A_0.ToUpper();
			string[] array2 = array;
			foreach (string text3 in array2)
			{
				if (text3.Trim().StartsWith("<title>"))
				{
					continue;
				}
				text = regex.Replace(text3, "");
				text = text.Replace("你的閱讀程式不支援聲音播放", "");
				text = text.Replace("你的閱讀程式不支援影片播放", "");
				text = text.ToUpper();
				num3 = 0;
				num4 = 0;
				num5 = 0;
				string text4 = text;
				foreach (char c in text4)
				{
					if (num3 < A_0.Length && c == A_0[num3])
					{
						if (num3 == 0)
						{
							num4 = num5;
						}
						num3 = (short)(num3 + 1);
					}
					else
					{
						num3 = 0;
					}
					if (num3 == A_0.Length && num4 > 0)
					{
						num3 = 0;
						text2 = text.Substring(num4);
						if (text2.Length > num)
						{
							text2 = text2.Substring(0, num - 1);
						}
						if (num2 == 0)
						{
							lavel++;
							A_1.Nodes.Add(A_2);
							A_1.Nodes[lavel].Tag = A_4 + "|||0";
						}
						A_1.Nodes[lavel].Nodes.Add(text2);
						A_1.Nodes[lavel].Nodes[num2].Tag = A_4 + "|||" + num2;
						num2 = (short)(num2 + 1);
					}
					num5 = (short)(num5 + 1);
				}
			}
		}

		private void b(object A_0, TreeNodeMouseClickEventArgs A_1)
		{
			if (A_1.Node.Tag == null)
			{
				return;
			}
			string[] array = A_1.Node.Tag.ToString().Split(new string[1]
			{
				"|||"
			}, StringSplitOptions.RemoveEmptyEntries);
			if (array.Length <= 1)
			{
				return;
			}
			cl = Convert.ToInt32(array[1]);
			int num = Convert.ToInt32(array[0]);
			if (num != this.m_p)
			{
				this.m_p = num;
				x();
				return;
			}
			ar = "LEFT_WEBVIEW";
			if (bi == 1)
			{
				a7.ExecuteScriptAsync("custom_HighlightAllOccurencesOfString('" + ck + "');");
			}
			if (bi == 2)
			{
				a7.ExecuteScriptAsync("custom_HighlightAllOccurencesOfString('" + ck + "');");
				a8.ExecuteScriptAsync("custom_HighlightAllOccurencesOfString('" + ck + "');");
			}
		}

		private void z(object A_0, EventArgs A_1)
		{
			if (cv)
			{
				d8.Hide();
				cv = false;
				e();
			}
			else
			{
				di.Location = d8.Location;
				d8.Hide();
				di.Show();
			}
		}

		private void y(object A_0, EventArgs A_1)
		{
			d8.Hide();
			d0.Text = "";
			@do.Visible = true;
		}

		private void x(object A_0, EventArgs A_1)
		{
			d8.Hide();
			di.Hide();
			dc.Text = this.m_ao;
			ab(A_0, A_1);
		}

		private void w(object A_0, EventArgs A_1)
		{
			d8.Hide();
			di.Hide();
			FormWebBrower formWebBrower = new FormWebBrower();
			string url = Uri.EscapeUriString("http://translate.google.com.tw/?hl=zh-TW&tab=wT#zh-CN/en/" + this.m_ao);
			formWebBrower.openSize = new System.Drawing.Size(Convert.ToInt32((double)base.Width * 0.8), Convert.ToInt32((double)base.Height * 0.8));
			formWebBrower.openType = 0;
			formWebBrower.keyword = this.m_ao;
			formWebBrower.url = url;
			formWebBrower.ShowDialog();
			g();
		}

		private void v(object A_0, EventArgs A_1)
		{
			d8.Hide();
			di.Hide();
			FormWebBrower formWebBrower = new FormWebBrower();
			string url = Uri.EscapeUriString("http://zh.wikipedia.org/wiki/" + this.m_ao);
			formWebBrower.openSize = new System.Drawing.Size(Convert.ToInt32((double)base.Width * 0.8), Convert.ToInt32((double)base.Height * 0.8));
			formWebBrower.openType = 1;
			formWebBrower.keyword = this.m_ao;
			formWebBrower.url = url;
			formWebBrower.ShowDialog();
			g();
		}

		private void c(string A_0)
		{
			if (base.InvokeRequired)
			{
				c method = new c(c);
				Invoke(method, A_0);
				return;
			}
			d8.Visible = false;
			di.Visible = false;
			switch (A_0)
			{
			case "37":
			case "38":
				p();
				break;
			case "39":
			case "40":
				r();
				break;
			case "33":
				if (this.m_p > 0)
				{
					this.m_p--;
					x();
				}
				break;
			case "34":
				if (this.m_p < this.m_c.spineDictionary.Count - 1)
				{
					this.m_p++;
					x();
				}
				break;
			case "48":
				perFontFize = 110;
				m();
				break;
			case "189":
			case "229":
				m();
				break;
			case "187":
				n();
				break;
			case "67":
				System.Windows.Forms.Clipboard.Clear();
				break;
			}
		}

		private void u(object A_0, EventArgs A_1)
		{
			a(SharedPlatform.Facebook);
		}

		private void t(object A_0, EventArgs A_1)
		{
			a(SharedPlatform.Plurk);
		}

		private void s(object A_0, EventArgs A_1)
		{
			a(SharedPlatform.Google);
		}

		private void r(object A_0, EventArgs A_1)
		{
			a(SharedPlatform.Twitter);
		}

		private void q(object A_0, EventArgs A_1)
		{
			a(SharedPlatform.Mail);
		}

		private void a(SharedPlatform A_0)
		{
			d8.Hide();
			a7.ExecuteScriptAsync("android.selection.clearSelection();");
			if (!this.m_ao.Equals("") && j())
			{
				if (A_0.Equals(SharedPlatform.Facebook))
				{
					Authorize authorize = new Authorize();
					authorize.postMsg = this.m_ao;
					authorize.ShowDialog();
				}
				else if (A_0.Equals(SharedPlatform.Plurk))
				{
					Process.Start("http://www.plurk.com/?qualifier=shares&status=" + Uri.EscapeDataString(this.m_ao));
				}
				else if (A_0.Equals(SharedPlatform.Mail))
				{
					string text = "";
					string text2 = "";
					text = Global.bookManager.LanqMng.getLangString("recommend") + "【" + Text + "】" + Global.bookManager.LanqMng.getLangString("recommend") + Global.bookManager.LanqMng.getLangString("forYou") + "，" + Global.bookManager.LanqMng.getLangString("thisEBook");
					text2 = Global.bookManager.LanqMng.getLangString("imReading") + "【" + Text + "】" + Global.bookManager.LanqMng.getLangString("thisEBook") + "，" + Global.bookManager.LanqMng.getLangString("welcomeToReader") + "%0d%0a%0d%0a" + this.m_ao;
					if (System.Windows.Forms.MessageBox.Show(Global.bookManager.LanqMng.getLangString("mailtoMessage"), "", MessageBoxButtons.YesNo).Equals(DialogResult.Yes))
					{
						try
						{
							Process.Start("mailto://?subject=" + text + "&body=" + text2);
						}
						catch
						{
							System.Windows.Forms.MessageBox.Show(Global.bookManager.LanqMng.getLangString("noEmailSoft"), Global.bookManager.LanqMng.getLangString("shareFail"));
						}
					}
				}
				else if (A_0.Equals(SharedPlatform.Google))
				{
					System.Windows.Forms.MessageBox.Show("施工中...");
				}
				else if (A_0.Equals(SharedPlatform.Twitter))
				{
					Process.Start("http://twitter.com/home/?status=" + Uri.EscapeDataString(this.m_ao));
				}
			}
			g();
		}

		private bool j()
		{
			int postTimes = Global.bookManager.getPostTimes(this.m_aj);
			if (!postTimes.Equals(-1))
			{
				if (postTimes < cm)
				{
					postTimes++;
					Global.bookManager.savePostTimes(this.m_aj, postTimes);
					return true;
				}
				System.Windows.Forms.MessageBox.Show(Global.bookManager.LanqMng.getLangString("overShare") + cm + Global.bookManager.LanqMng.getLangString("page"), Global.bookManager.LanqMng.getLangString("warning"));
				return false;
			}
			return false;
		}

		private void p(object A_0, EventArgs A_1)
		{
			a(this.m_am, 0);
		}

		private void o(object A_0, EventArgs A_1)
		{
			a(this.m_am, 1);
		}

		private void n(object A_0, EventArgs A_1)
		{
			a(this.m_am, 2);
		}

		private void m(object A_0, EventArgs A_1)
		{
			az = true;
			d8.Hide();
			di.Hide();
			if (bp)
			{
				if (cy == "LEFT_WEBVIEW")
				{
					a7.ExecuteScriptAsync("highlighter.removeHighlightsByStartAndEnd(" + cw + "," + cx + "); ");
				}
				else
				{
					a8.ExecuteScriptAsync("highlighter.removeHighlightsByStartAndEnd(" + cw + "," + cx + "); ");
				}
			}
			else if (bi == 1)
			{
				a7.ExecuteScriptAsync("highlighter.removeHighlightsByStartAndEnd(" + cw + "," + cx + ");");
				List<NOTE_ARRAYLIST> leftNoteList = JSBindingObject.leftNoteList;
				List<int> list = new List<int>();
				for (int i = 0; i < leftNoteList.Count; i++)
				{
					NOTE_ARRAYLIST nOTE_ARRAYLIST = Enumerable.ElementAt(leftNoteList, i);
					bool flag = false;
					int j;
					for (j = 0; j < nOTE_ARRAYLIST.items.Count; j++)
					{
						START_END_PAIR sTART_END_PAIR = Enumerable.ElementAt(nOTE_ARRAYLIST.items, j);
						if (sTART_END_PAIR.start == cw && sTART_END_PAIR.end == cx)
						{
							flag = true;
							break;
						}
					}
					if (flag)
					{
						nOTE_ARRAYLIST.items.RemoveAt(j);
					}
					if (nOTE_ARRAYLIST.items.Count == 0)
					{
						list.Add(i);
					}
					if (flag)
					{
						break;
					}
				}
				for (int i = list.Count - 1; i >= 0; i--)
				{
					NOTE_ARRAYLIST nOTE_ARRAYLIST2 = Enumerable.ElementAt(leftNoteList, Enumerable.ElementAt(list, i));
					a7.ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST2.left + "," + nOTE_ARRAYLIST2.top + "); ");
					leftNoteList.RemoveAt(Enumerable.ElementAt(list, i));
				}
			}
			else
			{
				a7.ExecuteScriptAsync("highlighter.removeHighlightsByStartAndEnd(" + cw + "," + cx + ");");
				a8.ExecuteScriptAsync("highlighter.removeHighlightsByStartAndEnd(" + cw + "," + cx + ");");
				List<NOTE_ARRAYLIST>[] array = new List<NOTE_ARRAYLIST>[2]
				{
					JSBindingObject.leftNoteList,
					JSBindingObject.rightNoteList
				};
				ChromiumWebBrowser[] array2 = new ChromiumWebBrowser[2]
				{
					a7,
					a8
				};
				for (int k = 0; k < 2; k++)
				{
					List<int> list2 = new List<int>();
					for (int l = 0; l < array[k].Count; l++)
					{
						NOTE_ARRAYLIST nOTE_ARRAYLIST3 = Enumerable.ElementAt(array[k], l);
						bool flag2 = false;
						int m;
						for (m = 0; m < nOTE_ARRAYLIST3.items.Count; m++)
						{
							START_END_PAIR sTART_END_PAIR2 = Enumerable.ElementAt(nOTE_ARRAYLIST3.items, m);
							if (sTART_END_PAIR2.start == cw && sTART_END_PAIR2.end == cx)
							{
								flag2 = true;
								break;
							}
						}
						if (flag2)
						{
							nOTE_ARRAYLIST3.items.RemoveAt(m);
						}
						if (nOTE_ARRAYLIST3.items.Count == 0)
						{
							list2.Add(l);
						}
						if (flag2)
						{
							break;
						}
					}
					for (int l = list2.Count - 1; l >= 0; l--)
					{
						NOTE_ARRAYLIST nOTE_ARRAYLIST4 = Enumerable.ElementAt(array[k], Enumerable.ElementAt(list2, l));
						array2[k].ExecuteScriptAsync("android.selection.removeNoteMarkByLeftAndTop(" + nOTE_ARRAYLIST4.left + "," + nOTE_ARRAYLIST4.top + "); ");
						array[k].RemoveAt(Enumerable.ElementAt(list2, l));
					}
				}
			}
			f();
		}

		private void a(string A_0, int A_1)
		{
			az = true;
			di.Hide();
			if (cy == "LEFT_WEBVIEW")
			{
				a7.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + cw + "," + cx + ",'" + au[A_1] + "');");
				for (int i = 0; i < JSBindingObject.leftNoteList.Count; i++)
				{
					for (int j = 0; j < JSBindingObject.leftNoteList[i].items.Count; j++)
					{
						if (JSBindingObject.leftNoteList[i].items[j].start == cw && JSBindingObject.leftNoteList[i].items[j].end == cx)
						{
							JSBindingObject.leftNoteList[i].items[j].penColorIndex = A_1;
							break;
						}
					}
				}
				return;
			}
			a8.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + cw + "," + cx + ",'" + au[A_1] + "');");
			for (int k = 0; k < JSBindingObject.rightNoteList.Count; k++)
			{
				for (int l = 0; l < JSBindingObject.rightNoteList[k].items.Count; l++)
				{
					if (JSBindingObject.rightNoteList[k].items[l].start == cw && JSBindingObject.rightNoteList[k].items[l].end == cx)
					{
						JSBindingObject.rightNoteList[k].items[l].penColorIndex = A_1;
						break;
					}
				}
			}
		}

		public void formShowNote(List<START_END_PAIR> ModifyNoteList, string webviewName, string id)
		{
			cp = 0;
			if (base.InvokeRequired)
			{
				delformShowNote method = new delformShowNote(formShowNote);
				Invoke(method, ModifyNoteList, webviewName, id);
			}
			else
			{
				co = ModifyNoteList;
				cs = webviewName;
				ct = id;
				d1.Text = co[cp].selectText;
				d0.Text = co[cp].noteText;
				i();
				@do.Show();
				az = true;
			}
		}

		private void i()
		{
			d3.Visible = true;
			d2.Visible = true;
			if (co.Count <= 1)
			{
				d3.Visible = false;
				d2.Visible = false;
			}
			else if (cp == 0)
			{
				d3.Visible = false;
			}
			else if (cp == co.Count - 1)
			{
				d2.Visible = false;
			}
		}

		private void l(object A_0, EventArgs A_1)
		{
			co[cp].noteText = d0.Text;
		}

		private void k(object A_0, EventArgs A_1)
		{
			if (cp > 0)
			{
				cp--;
				d1.Text = co[cp].selectText;
				d0.Text = co[cp].noteText;
			}
			i();
		}

		private void j(object A_0, EventArgs A_1)
		{
			if (cp < co.Count - 1)
			{
				cp++;
				d1.Text = co[cp].selectText;
				d0.Text = co[cp].noteText;
			}
			i();
		}

		private void i(object A_0, EventArgs A_1)
		{
			@do.Visible = false;
			h();
		}

		private void h(object A_0, EventArgs A_1)
		{
			@do.Visible = false;
			co[cp].noteText = "";
			d0.Text = "";
		}

		private void g(object A_0, EventArgs A_1)
		{
			@do.Visible = false;
		}

		private void h()
		{
			if (cq)
			{
				for (int i = 0; i < JSBindingObject.leftNoteList[cr].items.Count; i++)
				{
					JSBindingObject.leftNoteList[cr].items[i].noteText = co[i].noteText;
				}
			}
			else
			{
				for (int j = 0; j < JSBindingObject.rightNoteList[cr].items.Count; j++)
				{
					JSBindingObject.rightNoteList[cr].items[j].noteText = co[j].noteText;
				}
			}
		}

		private int[] b(string A_0)
		{
			int[] array = new int[3];
			string[] array2 = A_0.Split(':');
			array2 = array2[0].Split('/');
			for (int i = 0; i < array2.Length && i < 3; i++)
			{
				array[i] = Convert.ToInt32(array2[i]);
			}
			return array;
		}

		private void a(AnnotationData A_0, string A_1, string A_2)
		{
			switch (A_1)
			{
			default:
				return;
			case "add":
				bookAnnotation.Add(A_0);
				break;
			case "update":
			{
				for (int j = 0; j < bookAnnotation.Count; j++)
				{
					if (bookAnnotation[j].itemIndex == this.m_p && bookAnnotation[j].rangyRange == A_2)
					{
						bookAnnotation[j] = A_0;
						break;
					}
				}
				break;
			}
			case "delete":
			{
				for (int i = 0; i < bookAnnotation.Count; i++)
				{
					if (bookAnnotation[i].itemIndex == this.m_p && bookAnnotation[i].rangyRange == A_2)
					{
						bookAnnotation.RemoveAt(i);
						break;
					}
				}
				break;
			}
			}
			f();
			g();
		}

		private void g()
		{
			a7.ExecuteScriptAsync("clearBackCanvas();");
			a8.ExecuteScriptAsync("clearBackCanvas();");
			JSBindingObject.annotList.Clear();
			foreach (AnnotationData item in bookAnnotation)
			{
				if (item.itemIndex == this.m_p)
				{
					a7.ExecuteScriptAsync("android.selection.elementRectsByIdentifier('" + item.rangyRange + "'," + item.sno + ", '" + item.colorRGBA + "'," + item.annoType + ");");
				}
			}
		}

		public void loadAnnotationFromDB()
		{
			bookAnnotation = new List<AnnotationData>();
			string sqlCommand = "select * from epubAnnotationPro where book_sno=" + this.m_aj + " and status<>'1' and itemId<>'' and colorRGBA<>'' and htmlContent<>'' order by itemIndex, rangyRange";
			QueryResult queryResult = Global.bookManager.sqlCommandQuery(sqlCommand);
			string text = "";
			while (queryResult.fetchRow())
			{
				AnnotationData annotationData = new AnnotationData();
				annotationData.itemId = queryResult.getString("itemId");
				annotationData.rangyRange = queryResult.getString("rangyRange");
				int num = a(annotationData.itemId);
				if (num >= 0 && !text.Equals(annotationData.itemId + annotationData.rangyRange))
				{
					text = annotationData.itemId + annotationData.rangyRange;
					annotationData.itemIndex = num;
					annotationData.sno = queryResult.getInt("sno");
					annotationData.handleBounds = "";
					annotationData.menuBounds = queryResult.getString("menuBounds");
					annotationData.htmlContent = queryResult.getString("htmlContent");
					annotationData.locationX = queryResult.getInt("locationX");
					annotationData.locationY = queryResult.getInt("locationY");
					annotationData.colorRGBA = queryResult.getString("colorRGBA");
					annotationData.annoType = queryResult.getInt("annoType");
					annotationData.noteText = queryResult.getString("noteText");
					annotationData.orgHandle = annotationData.handleBounds;
					bookAnnotation.Add(annotationData);
				}
			}
			bookAnnotation.Sort(_003C_003Ec._003C_003E9__275_0 ?? (_003C_003Ec._003C_003E9__275_0 = new Comparison<AnnotationData>(_003C_003Ec._003C_003E9.a)));
		}

		private int a(string A_0)
		{
			string text = "";
			for (int i = 0; i < this.m_c.spineDictionary.Count; i++)
			{
				if (Enumerable.ElementAt(this.m_c.spineDictionary.Keys, i).EndsWith(A_0))
				{
					return i;
				}
			}
			foreach (KeyValuePair<string, Manifest> item in this.m_c.manifestDictionary)
			{
				if (item.Value.href.EndsWith(A_0))
				{
					text = item.Key;
					break;
				}
			}
			for (int j = 0; j < this.m_c.spineDictionary.Count; j++)
			{
				if (Enumerable.ElementAt(this.m_c.spineDictionary.Keys, j) == text)
				{
					return j;
				}
			}
			return -1;
		}

		private void f()
		{
			if (base.InvokeRequired)
			{
				d method = new d(f);
				Invoke(method);
				return;
			}
			if (bookAnnotation.Count == 0 && JSBindingObject.leftNoteList.Count == 0 && JSBindingObject.rightNoteList.Count == 0)
			{
				dv.Visible = false;
				dx.Visible = false;
				return;
			}
			dv.Visible = true;
			dw.Nodes.Clear();
			lavel = -1;
			TreeNode treeNode = dw.Nodes.Add(Global.bookManager.LanqMng.getLangString("noteList"));
			int num = -1;
			string text = "";
			int index = -1;
			int num2 = 0;
			foreach (AnnotationData item in bookAnnotation)
			{
				if (!a0 || item.itemIndex != this.m_p)
				{
					if (num != item.itemIndex)
					{
						num = item.itemIndex;
						string key = Enumerable.ElementAt(this.m_c.spineDictionary.Keys, num);
						string key2 = this.m_c.manifestDictionary[key].href.Replace("/", "\\");
						text = (this.m_ad.ContainsKey(key2) ? this.m_ad[key2] : "");
						lavel++;
						treeNode.Nodes.Add(text);
						treeNode.Nodes[lavel].Tag = num + ",0";
						treeNode.Nodes[lavel].ImageIndex = 0;
						treeNode.Nodes[lavel].SelectedImageIndex = 0;
						index = 0;
					}
					string htmlContent = item.htmlContent;
					if (item.annoType == 0)
					{
						treeNode.Nodes[lavel].Nodes.Add(htmlContent);
						treeNode.Nodes[lavel].Nodes[index].ImageIndex = 1;
						treeNode.Nodes[lavel].Nodes[index].SelectedImageIndex = 1;
					}
					else
					{
						treeNode.Nodes[lavel].Nodes.Add(item.noteText);
						treeNode.Nodes[lavel].Nodes[index].ImageIndex = 2;
						treeNode.Nodes[lavel].Nodes[index].SelectedImageIndex = 2;
					}
					treeNode.Nodes[lavel].Nodes[index++].Tag = num + ", " + num2++;
					if (treeNode.Nodes[lavel].Nodes.Count == 0)
					{
						treeNode.Nodes[lavel].Remove();
						lavel--;
					}
				}
			}
			if (a0 && (JSBindingObject.leftNoteList.Count > 0 || JSBindingObject.rightNoteList.Count > 0))
			{
				lavel++;
				treeNode.Nodes.Add("本章註記已編輯");
				foreach (NOTE_ARRAYLIST leftNote in JSBindingObject.leftNoteList)
				{
					treeNode.Nodes[lavel].Nodes.Add(leftNote.items[0].selectText);
				}
			}
			dw.ExpandAll();
		}

		private void a(object A_0, TreeNodeMouseClickEventArgs A_1)
		{
			if (A_1.Node.Tag == null)
			{
				return;
			}
			string[] array = A_1.Node.Tag.ToString().Split(new string[1]
			{
				","
			}, StringSplitOptions.RemoveEmptyEntries);
			int num = Convert.ToInt32(array[0]);
			cu = ((array.Length > 1) ? Convert.ToInt32(array[1]) : 0);
			if (this.m_p != num)
			{
				this.m_p = num;
				x();
				return;
			}
			lock (ax)
			{
				bookAnnotation[cu].handleBounds.Split(',');
				int locationX = bookAnnotation[cu].locationX;
				scrollToPosition(bj, locationX, a7.Name);
				cu = -1;
			}
		}

		private void b(int A_0)
		{
			if (base.InvokeRequired)
			{
				e method = new e(b);
				Invoke(method, A_0);
			}
			else if (bo)
			{
				if (!bj && bk)
				{
					if (bi == 1)
					{
						if (A_0 >= 1 && jsObj1.CurPage != A_0 && A_0 <= jsObj1.TotalPages)
						{
							if (A_0 > jsObj1.CurPage)
							{
								for (int i = jsObj1.CurPage; i < A_0; i++)
								{
									a7.ExecuteScriptAsync("$(window).bind('scroll');");
									a7.ExecuteScriptAsync("slideRight();");
									a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
									a7.ExecuteScriptAsync("$(window).unbind('scroll');");
									a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
								}
								modifyLeftPageTextBox(A_0);
							}
							else
							{
								int curPage = jsObj1.CurPage;
								for (int j = A_0; j < curPage; j++)
								{
									a7.ExecuteScriptAsync("$(window).bind('scroll');");
									a7.ExecuteScriptAsync("slideLeft();");
									a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
									a7.ExecuteScriptAsync("$(window).unbind('scroll');");
									a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
								}
								modifyLeftPageTextBox(A_0);
							}
						}
					}
					else
					{
						A_0 = ((A_0 % 2 == 1) ? A_0 : (A_0 - 1));
						if (A_0 > jsObj1.TotalPages)
						{
							A_0 = jsObj1.TotalPages - 1;
						}
						if (A_0 >= 1 && jsObj1.CurPage != A_0 && A_0 <= jsObj1.TotalPages - 1)
						{
							if (A_0 > jsObj1.CurPage)
							{
								for (int k = jsObj1.CurPage; k < A_0; k += 2)
								{
									a7.ExecuteScriptAsync("$(window).bind('scroll');");
									a7.ExecuteScriptAsync("slideRight();slideRight();");
									a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
									a7.ExecuteScriptAsync("$(window).unbind('scroll');");
									a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
									a8.ExecuteScriptAsync("$(window).bind('scroll');");
									a8.ExecuteScriptAsync("slideRight();slideRight();");
									a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
									a8.ExecuteScriptAsync("$(window).unbind('scroll');");
									a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
								}
								modifyLeftPageTextBox(A_0);
								modifyRightPageTextBox(A_0 + 1);
							}
							else
							{
								int curPage2 = jsObj1.CurPage;
								for (int l = A_0; l < curPage2; l += 2)
								{
									a7.ExecuteScriptAsync("$(window).bind('scroll');");
									a7.ExecuteScriptAsync("slideLeft();slideLeft();");
									a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
									a7.ExecuteScriptAsync("$(window).unbind('scroll');");
									a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
									a8.ExecuteScriptAsync("$(window).bind('scroll');");
									a8.ExecuteScriptAsync("slideLeft();slideLeft();");
									a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
									a8.ExecuteScriptAsync("$(window).unbind('scroll');");
									a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
								}
								modifyLeftPageTextBox(A_0);
								modifyRightPageTextBox(A_0 + 1);
							}
						}
					}
					c7.Text = A_0 + "-" + (A_0 + 1) + "(" + this.m_m + ")";
				}
				else
				{
					Console.WriteLine("PAGE_PROGRESSION_DIRECTION + VERTICAL_WRITING_MODE && !LEFT_TO_RIGHT");
				}
			}
			else if (!bj && bk)
			{
				if (bi == 1)
				{
					if (A_0 < 1 || jsObj1.CurPage == A_0 || A_0 > jsObj1.TotalPages)
					{
						return;
					}
					if (A_0 > jsObj1.CurPage)
					{
						for (int m = jsObj1.CurPage; m < A_0; m++)
						{
							a7.ExecuteScriptAsync("$(window).bind('scroll');");
							a7.ExecuteScriptAsync("slideRight();");
							a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
							a7.ExecuteScriptAsync("$(window).unbind('scroll');");
							a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						}
						modifyLeftPageTextBox(A_0);
						return;
					}
					int curPage3 = jsObj1.CurPage;
					for (int n = A_0; n < curPage3; n++)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideLeft();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					}
					modifyLeftPageTextBox(A_0);
					return;
				}
				A_0 = ((A_0 % 2 == 1) ? A_0 : (A_0 - 1));
				if (A_0 >= 1 && jsObj2.CurPage != A_0 && A_0 <= jsObj2.TotalPages - 1)
				{
					if (A_0 > jsObj2.CurPage)
					{
						for (int num = jsObj2.CurPage; num < A_0; num += 2)
						{
							a7.ExecuteScriptAsync("$(window).bind('scroll');");
							a7.ExecuteScriptAsync("slideRight();slideRight();");
							a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
							a7.ExecuteScriptAsync("$(window).unbind('scroll');");
							a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
							a8.ExecuteScriptAsync("$(window).bind('scroll');");
							a8.ExecuteScriptAsync("slideRight();slideRight();");
							a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
							a8.ExecuteScriptAsync("$(window).unbind('scroll');");
							a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						}
						modifyLeftPageTextBox(A_0 + 1);
						modifyRightPageTextBox(A_0);
					}
					else
					{
						int curPage4 = jsObj2.CurPage;
						for (int num2 = A_0; num2 < curPage4; num2 += 2)
						{
							a7.ExecuteScriptAsync("$(window).bind('scroll');");
							a7.ExecuteScriptAsync("slideLeft();slideLeft();");
							a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
							a7.ExecuteScriptAsync("$(window).unbind('scroll');");
							a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
							a8.ExecuteScriptAsync("$(window).bind('scroll');");
							a8.ExecuteScriptAsync("slideLeft();slideLeft();");
							a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
							a8.ExecuteScriptAsync("$(window).unbind('scroll');");
							a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						}
						modifyLeftPageTextBox(A_0 + 1);
						modifyRightPageTextBox(A_0);
					}
				}
				c7.Text = A_0 + 1 + "-" + A_0 + "(" + this.m_m + ")";
			}
			else if (bi == 1)
			{
				if (A_0 < 1 || jsObj1.CurPage == A_0 || A_0 > jsObj1.TotalPages)
				{
					return;
				}
				if (A_0 > jsObj1.CurPage)
				{
					for (int num3 = jsObj1.CurPage; num3 < A_0; num3++)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideUp();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					}
					modifyLeftPageTextBox(A_0);
					return;
				}
				int curPage5 = jsObj1.CurPage;
				for (int num4 = A_0; num4 < curPage5; num4++)
				{
					a7.ExecuteScriptAsync("$(window).bind('scroll');");
					a7.ExecuteScriptAsync("slideDown();");
					a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
					a7.ExecuteScriptAsync("$(window).unbind('scroll');");
					a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				}
				modifyLeftPageTextBox(A_0);
			}
			else
			{
				if (A_0 < 1)
				{
					return;
				}
				A_0 = ((A_0 % 2 == 1) ? A_0 : (A_0 - 1));
				if (A_0 < 1 || jsObj2.CurPage == A_0 || A_0 > jsObj2.TotalPages - 1)
				{
					return;
				}
				if (A_0 > jsObj2.CurPage)
				{
					for (int num5 = jsObj2.CurPage; num5 < A_0; num5 += 2)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideUp();slideUp();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						a8.ExecuteScriptAsync("$(window).bind('scroll');");
						a8.ExecuteScriptAsync("slideUp();slideUp();");
						a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj2.CurTop + "); android.selection.scrollLeft(0); return false;});");
						a8.ExecuteScriptAsync("$(window).unbind('scroll');");
						a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					}
					modifyLeftPageTextBox(A_0 + 1);
					modifyRightPageTextBox(A_0);
				}
				else
				{
					int curPage6 = jsObj2.CurPage;
					for (int num6 = A_0; num6 < curPage6; num6 += 2)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideDown();slideDown();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						a8.ExecuteScriptAsync("$(window).bind('scroll');");
						a8.ExecuteScriptAsync("slideDown();slideDown();");
						a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj2.CurTop + "); android.selection.scrollLeft(0); return false;});");
						a8.ExecuteScriptAsync("$(window).unbind('scroll');");
						a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					}
					modifyLeftPageTextBox(A_0 + 1);
					modifyRightPageTextBox(A_0);
				}
				c7.Text = A_0 + 1 + "-" + A_0 + "(" + this.m_m + ")";
			}
		}

		private void a(int A_0)
		{
			if (base.InvokeRequired)
			{
				e method = new e(b);
				Invoke(method, A_0);
			}
			else if (!bj && bk)
			{
				if (bi == 1)
				{
					if (A_0 < 1 || jsObj1.CurPage == A_0 || A_0 > jsObj1.TotalPages)
					{
						return;
					}
					if (A_0 > jsObj1.CurPage)
					{
						for (int i = jsObj1.CurPage; i < A_0; i++)
						{
							a7.ExecuteScriptAsync("$(window).bind('scroll');");
							a7.ExecuteScriptAsync("slideRight();");
							a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
							a7.ExecuteScriptAsync("$(window).unbind('scroll');");
							a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						}
						modifyLeftPageTextBox(A_0);
						return;
					}
					int curPage = jsObj1.CurPage;
					for (int j = A_0; j < curPage; j++)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideLeft();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					}
					modifyLeftPageTextBox(A_0);
					return;
				}
				A_0 = ((A_0 % 2 == 1) ? A_0 : (A_0 - 1));
				if (A_0 < 1 || jsObj1.CurPage == A_0 || A_0 > jsObj1.TotalPages - 1)
				{
					return;
				}
				if (A_0 > jsObj1.CurPage)
				{
					for (int k = jsObj1.CurPage; k < A_0; k += 2)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideRight();slideRight();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						a8.ExecuteScriptAsync("$(window).bind('scroll');");
						a8.ExecuteScriptAsync("slideRight();slideRight();");
						a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
						a8.ExecuteScriptAsync("$(window).unbind('scroll');");
						a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					}
					modifyLeftPageTextBox(A_0);
					modifyRightPageTextBox(A_0 + 1);
					return;
				}
				int curPage2 = jsObj1.CurPage;
				for (int l = A_0; l < curPage2; l += 2)
				{
					a7.ExecuteScriptAsync("$(window).bind('scroll');");
					a7.ExecuteScriptAsync("slideLeft();slideLeft();");
					a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj1.CurLeft + "); return false;});");
					a7.ExecuteScriptAsync("$(window).unbind('scroll');");
					a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					a8.ExecuteScriptAsync("$(window).bind('scroll');");
					a8.ExecuteScriptAsync("slideLeft();slideLeft();");
					a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(0); android.selection.scrollLeft(" + jsObj2.CurLeft + "); return false;});");
					a8.ExecuteScriptAsync("$(window).unbind('scroll');");
					a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				}
				modifyLeftPageTextBox(A_0);
				modifyRightPageTextBox(A_0 + 1);
			}
			else if (bi == 1)
			{
				if (A_0 < 1 || jsObj1.CurPage == A_0 || A_0 > jsObj1.TotalPages)
				{
					return;
				}
				if (A_0 > jsObj1.CurPage)
				{
					for (int m = jsObj1.CurPage; m < A_0; m++)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideUp();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					}
					modifyLeftPageTextBox(A_0);
					return;
				}
				int curPage3 = jsObj1.CurPage;
				for (int n = A_0; n < curPage3; n++)
				{
					a7.ExecuteScriptAsync("$(window).bind('scroll');");
					a7.ExecuteScriptAsync("slideDown();");
					a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
					a7.ExecuteScriptAsync("$(window).unbind('scroll');");
					a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				}
				modifyLeftPageTextBox(A_0);
			}
			else
			{
				if (A_0 < 1)
				{
					return;
				}
				A_0 = ((A_0 % 2 == 1) ? A_0 : (A_0 - 1));
				if (A_0 < 1 || jsObj2.CurPage == A_0 || A_0 > jsObj2.TotalPages - 1)
				{
					return;
				}
				if (A_0 > jsObj2.CurPage)
				{
					for (int num = jsObj2.CurPage; num < A_0; num += 2)
					{
						a7.ExecuteScriptAsync("$(window).bind('scroll');");
						a7.ExecuteScriptAsync("slideUp();slideUp();");
						a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
						a7.ExecuteScriptAsync("$(window).unbind('scroll');");
						a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
						a8.ExecuteScriptAsync("$(window).bind('scroll');");
						a8.ExecuteScriptAsync("slideUp();slideUp();");
						a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj2.CurTop + "); android.selection.scrollLeft(0); return false;});");
						a8.ExecuteScriptAsync("$(window).unbind('scroll');");
						a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					}
					modifyLeftPageTextBox(A_0 + 1);
					modifyRightPageTextBox(A_0);
					return;
				}
				int curPage4 = jsObj2.CurPage;
				for (int num2 = A_0; num2 < curPage4; num2 += 2)
				{
					a7.ExecuteScriptAsync("$(window).bind('scroll');");
					a7.ExecuteScriptAsync("slideDown();slideDown();");
					a7.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj1.CurTop + "); android.selection.scrollLeft(0); return false;});");
					a7.ExecuteScriptAsync("$(window).unbind('scroll');");
					a7.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
					a8.ExecuteScriptAsync("$(window).bind('scroll');");
					a8.ExecuteScriptAsync("slideDown();slideDown();");
					a8.ExecuteScriptAsync("$(window).scroll(function(){android.selection.scrollTop(" + jsObj2.CurTop + "); android.selection.scrollLeft(0); return false;});");
					a8.ExecuteScriptAsync("$(window).unbind('scroll');");
					a8.ExecuteScriptAsync("$(document).bind('mousewheel DOMMouseScroll',function(){stopWheel();}); function stopWheel(e){ e = window.event; e.preventDefault(); }");
				}
				modifyLeftPageTextBox(A_0 + 1);
				modifyRightPageTextBox(A_0);
			}
		}

		public void scrollToPosition(bool flag_HorizontalOrVertical, int pos, string webviewName)
		{
			if (webviewName == "RIGHT_WEBVIEW")
			{
				return;
			}
			if (base.InvokeRequired)
			{
				delScrollToPosition method = new delScrollToPosition(scrollToPosition);
				Invoke(method, flag_HorizontalOrVertical, pos, webviewName);
				return;
			}
			lock (ax)
			{
				if (bo)
				{
					if (!bj && bk)
					{
						int num = (int)Math.Ceiling((double)actual_webkit_column_width * (bl / 96.0));
						int num2 = (int)Math.Ceiling((double)pos / (double)num);
						num2++;
						if (bi == 1)
						{
							b(num2);
						}
						else if (bi == 2)
						{
							if (num2 % 2 == 0 && num2 > 1)
							{
								num2--;
							}
							b(num2);
						}
					}
					else if (bj && !bk)
					{
						Console.WriteLine("Not implemented!");
					}
				}
				else if (bj && !bk)
				{
					int num3 = (int)Math.Ceiling((double)actual_webkit_column_height * (bl / 96.0));
					int num4 = pos / num3;
					num4++;
					if (bi == 1)
					{
						b(num4);
					}
					else if (bi == 2)
					{
						if (num4 % 2 == 0 && num4 > 1)
						{
							num4--;
						}
						b(num4);
					}
				}
				else
				{
					if (bj || !bk)
					{
						return;
					}
					int num5 = (int)Math.Ceiling((double)actual_webkit_column_width * (bl / 96.0));
					int num6 = pos / num5;
					num6++;
					if (bi == 1)
					{
						b(num6);
					}
					else if (bi == 2)
					{
						if (num6 % 2 == 0 && num6 > 1)
						{
							num6--;
						}
						b(num6);
					}
					return;
				}
			}
		}

		public void scrollToPosition_old(bool flag_HorizontalOrVertical, int pos, string webviewName)
		{
			if (webviewName == "RIGHT_WEBVIEW")
			{
				return;
			}
			if (base.InvokeRequired)
			{
				delScrollToPosition method = new delScrollToPosition(scrollToPosition);
				Invoke(method, flag_HorizontalOrVertical, pos, webviewName);
				return;
			}
			lock (ax)
			{
				if (!bj)
				{
					int num = (int)((double)(actual_webkit_column_width + 50 + 50) * (bl / 96.0));
					int num2 = pos / num;
					num2++;
					if (bi == 1)
					{
						b(num2);
					}
					else if (bi == 2)
					{
						if (num2 % 2 == 0 && num2 > 1)
						{
							num2--;
						}
						b(num2);
					}
					return;
				}
				int num3 = (int)((double)(actual_webkit_column_height + 50 + 50) * (bl / 96.0));
				int num4 = pos / num3;
				num4++;
				if (bi == 1)
				{
					b(num4);
				}
				else if (bi == 2)
				{
					if (num4 % 2 == 0 && num4 > 1)
					{
						num4--;
					}
					b(num4);
				}
			}
		}

		private void f(object A_0, EventArgs A_1)
		{
		}

		public void processStartAndEnd(string name, int start, int end, int x, int y, string hBounds, string textContent)
		{
			if (base.InvokeRequired)
			{
				delprocessStartAndEnd method = new delprocessStartAndEnd(processStartAndEnd);
				Invoke(method, name, start, end, x, y, hBounds, textContent);
			}
			else if (start == end)
			{
				closeFormMenu();
			}
			else
			{
				this.m_ao = textContent;
				cw = start;
				cx = end;
				ar = name;
				cv = true;
				d8.Location = a(name, x, y);
				d8.Show();
			}
		}

		private void e()
		{
			if (bp)
			{
				if (ar == "LEFT_WEBVIEW")
				{
					a7.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + cw + "," + cx + ",'" + au[0] + "'); ");
				}
				else if (ar == "RIGHT_WEBVIEW")
				{
					a8.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + cw + "," + cx + ",'" + au[0] + "'); ");
				}
			}
			else if (ar == "LEFT_WEBVIEW")
			{
				a7.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + cw + "," + cx + ",'" + au[0] + "'); ");
				if (bi == 2)
				{
					a8.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + cw + "," + cx + ",'" + au[0] + "'); ");
				}
			}
			else if (ar == "RIGHT_WEBVIEW")
			{
				a8.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + cw + "," + cx + ",'" + au[0] + "'); ");
				a7.ExecuteScriptAsync("highlighter.modifyHighlightsByStartAndEnd(" + cw + "," + cx + ",'" + au[0] + "'); ");
			}
		}

		public void formclickHighlight(string webviewName, int x, int y, int start, int end, string className)
		{
			if (base.InvokeRequired)
			{
				delformclickHighlight method = new delformclickHighlight(formclickHighlight);
				Invoke(method, webviewName, x, y, start, end, className);
			}
			else
			{
				cw = start;
				cx = end;
				cy = webviewName;
				d();
				d8.Location = a(webviewName, x, y);
				d8.Show();
			}
		}

		private void d()
		{
			foreach (NOTE_ARRAYLIST item in cy.Equals("LEFT_WEBVIEW") ? JSBindingObject.leftNoteList : JSBindingObject.rightNoteList)
			{
				for (int i = 0; i < item.items.Count; i++)
				{
					if (item.items[i].start == cw && item.items[i].end == cx)
					{
						this.m_ao = item.items[i].selectText;
						break;
					}
				}
			}
		}

		private System.Drawing.Point a(string A_0, int A_1, int A_2)
		{
			A_1 = Convert.ToInt32((double)A_1 * cj);
			A_2 = Convert.ToInt32((double)A_2 * cj);
			A_1 = ((!(A_0 == "LEFT_WEBVIEW")) ? (A_1 + c3.Left) : (A_1 + c2.Left));
			if (A_1 + d8.Width > this.m_b.Width)
			{
				A_1 = this.m_b.Width - d8.Width - ds.Width;
			}
			return new System.Drawing.Point(A_1, A_2);
		}

		private void a(object A_0, FormClosedEventArgs A_1)
		{
			float num = (this.m_n == 0) ? 0f : ((float)this.m_m / (float)this.m_n);
			string sqlCommand = "update userbook_metadata set epubLastNode=" + this.m_p + ", epubLastPageRate=" + num + " Where Sno= " + this.m_aj;
			Global.bookManager.sqlCommandNonQuery(sqlCommand);
			b();
		}

		private void c()
		{
			for (int i = 0; i < JSBindingObject.leftNoteList.Count; i++)
			{
				for (int j = 0; j < JSBindingObject.leftNoteList[i].items.Count; j++)
				{
					foreach (START_END_PAIR item in cg)
					{
						if (JSBindingObject.leftNoteList[i].items[j].start == item.start && JSBindingObject.leftNoteList[i].items[j].end == item.end)
						{
							JSBindingObject.leftNoteList[i].items[j].rangy = item.rangy;
						}
					}
				}
			}
			for (int k = 0; k < JSBindingObject.rightNoteList.Count; k++)
			{
				for (int l = 0; l < JSBindingObject.rightNoteList[k].items.Count; l++)
				{
					foreach (START_END_PAIR item2 in cg)
					{
						if (JSBindingObject.rightNoteList[k].items[l].start == item2.start && JSBindingObject.rightNoteList[k].items[l].end == item2.end)
						{
							JSBindingObject.rightNoteList[k].items[l].rangy = item2.rangy;
						}
					}
				}
			}
		}

		private void b()
		{
			if (!az)
			{
				return;
			}
			c();
			string sqlCommand = "update epubAnnotationPro set status='1' Where book_sno= " + this.m_aj + " and itemId='" + this.m_u + "'";
			Global.bookManager.sqlCommandNonQuery(sqlCommand);
			DateTime value = new DateTime(1970, 1, 1);
			long num = DateTime.Now.ToUniversalTime().Subtract(value).Ticks / 10000000;
			string str = "insert into epubAnnotationPro( book_sno, itemIndex, itemId, rangyRange, htmlContent, colorRGBA, noteText, status, createTime, updateTime, syncTime, locationX, locationY  ) ";
			foreach (NOTE_ARRAYLIST leftNote in JSBindingObject.leftNoteList)
			{
				foreach (START_END_PAIR item in leftNote.items)
				{
					int start = item.start;
					int end = item.end;
					Task<JavascriptResponse> task = a7.EvaluateScriptAsync("(function(){ var oldSerialID = highlighter.converterStartAndEndToOldSerialId(" + start + "," + end + "); return oldSerialID; })();");
					task.ContinueWith(_003C_003Ec._003C_003E9__301_0 ?? (_003C_003Ec._003C_003E9__301_0 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.s)), TaskScheduler.Default);
					string text = task.Result.Result.ToString();
					text = text.Substring(0, text.IndexOf("{"));
					string text2 = (item.noteText != null) ? item.noteText.Replace("'", "''") : "";
					bool flag = true;
					foreach (AnnotationData item2 in bookAnnotation)
					{
						if (this.m_r == item2.itemId && text == item2.rangyRange)
						{
							flag = false;
							break;
						}
					}
					if (flag)
					{
						string str2 = " values ( " + this.m_aj + ", " + this.m_q + ", '" + this.m_u + "', '" + text + "', '" + item.selectText + "', '" + at[item.penColorIndex] + "', '" + text2 + "', '0', " + num + ", " + num + ", 0, " + start + ", " + end + " )";
						Global.bookManager.sqlCommandNonQuery(str + str2);
					}
					else
					{
						string sqlCommand2 = "update epubAnnotationPro set status='0',  colorRGBA='" + at[item.penColorIndex] + "', noteText='" + text2 + "', itemIndex=" + this.m_q + " Where book_sno= " + this.m_aj + " and itemId='" + this.m_r + "' and rangyRange='" + text + "'";
						Global.bookManager.sqlCommandNonQuery(sqlCommand2);
					}
				}
			}
			if (bi == 2 && bp)
			{
				foreach (NOTE_ARRAYLIST rightNote in JSBindingObject.rightNoteList)
				{
					foreach (START_END_PAIR item3 in rightNote.items)
					{
						int start2 = item3.start;
						int end2 = item3.end;
						Task<JavascriptResponse> task2 = a8.EvaluateScriptAsync("(function(){ var oldSerialID = highlighter.converterStartAndEndToOldSerialId(" + start2 + "," + end2 + "); return oldSerialID; })();");
						task2.ContinueWith(_003C_003Ec._003C_003E9__301_1 ?? (_003C_003Ec._003C_003E9__301_1 = new Action<Task<JavascriptResponse>>(_003C_003Ec._003C_003E9.t)), TaskScheduler.Default);
						string text3 = task2.Result.Result.ToString();
						text3 = text3.Substring(0, text3.IndexOf("{"));
						string text4 = (item3.noteText != null) ? item3.noteText.Replace("'", "''") : "";
						int num2 = bp ? (this.m_q + 1) : this.m_q;
						string text5 = bp ? c(num2) : this.m_u;
						bool flag2 = true;
						foreach (AnnotationData item4 in bookAnnotation)
						{
							if (this.m_r == item4.itemId && item4.locationX == start2 && item4.locationY == end2)
							{
								flag2 = false;
								break;
							}
						}
						if (flag2)
						{
							string str3 = " values ( " + this.m_aj + ", " + num2 + ", '" + text5 + "', '" + text3 + "', '" + item3.selectText + "', '" + at[item3.penColorIndex] + "', '" + text4 + "', '0', " + num + ", " + num + ", 0, " + start2 + ", " + end2 + " )";
							Global.bookManager.sqlCommandNonQuery(str + str3);
						}
						else
						{
							string sqlCommand3 = "update epubAnnotationPro set status='0',  colorRGBA='" + at[item3.penColorIndex] + "', noteText='" + text4 + "' Where book_sno= " + this.m_aj + " and itemId=" + this.m_r + " and locationX=" + start2 + " and locationY=" + end2;
							Global.bookManager.sqlCommandNonQuery(sqlCommand3);
						}
					}
				}
			}
			JSBindingObject.leftNoteList.Clear();
			JSBindingObject.rightNoteList.Clear();
		}

		public void mediaOverlayPlay(string webviewName, double startTime)
		{
			if (bp)
			{
				if (webviewName == "LEFT_WEBVIEW")
				{
					if (leftAudioCanPlay)
					{
						if (!cz)
						{
							a7.ExecuteScriptAsync("android.selection.playAudioByTime(" + startTime + ");");
							cz = true;
						}
						else
						{
							a7.ExecuteScriptAsync("android.selection.pauseAudio();");
							cz = false;
						}
					}
				}
				else if (rightAudioCanPlay)
				{
					if (!cz)
					{
						a8.ExecuteScriptAsync("android.selection.playAudioByTime(" + startTime + ");");
						cz = true;
					}
					else
					{
						a8.ExecuteScriptAsync("android.selection.pauseAudio();");
						cz = false;
					}
				}
			}
			else if (webviewName == "LEFT_WEBVIEW")
			{
				if (audioCanPlay)
				{
					if (!cz)
					{
						a7.ExecuteScriptAsync("android.selection.playAudio();");
						cz = true;
					}
					else
					{
						a7.ExecuteScriptAsync("android.selection.pauseAudio();");
						cz = false;
					}
				}
			}
			else if (audioCanPlay)
			{
				if (!cz)
				{
					a8.ExecuteScriptAsync("android.selection.playAudio();");
					cz = true;
				}
				else
				{
					a8.ExecuteScriptAsync("android.selection.pauseAudio();");
					cz = false;
				}
			}
		}

		private void e(object A_0, EventArgs A_1)
		{
			d4.Visible = false;
			d5.Visible = true;
			mediaOverlayPlay("LEFT_WEBVIEW", this.m_ab);
		}

		private void d(object A_0, EventArgs A_1)
		{
			d4.Visible = true;
			d5.Visible = false;
			a7.ExecuteScriptAsync("android.selection.stopAudio();");
			a8.ExecuteScriptAsync("android.selection.stopAudio();");
			mediaOverLayAutoPlayFlag = false;
			cz = false;
		}

		private void c(object A_0, EventArgs A_1)
		{
		}

		private void b(object A_0, EventArgs A_1)
		{
			m(A_0, A_1);
		}

		private void a(object A_0, ToolStripItemClickedEventArgs A_1)
		{
		}

		private void a(object A_0, EventArgs A_1)
		{
			c0 = a(this);
			PrintDocument printDocument = new PrintDocument();
			printDocument.DefaultPageSettings.Landscape = true;
			printDocument.PrintPage += new PrintPageEventHandler(a);
			PrintDialog printDialog = new PrintDialog();
			printDialog.Document = printDocument;
			if (printDialog.ShowDialog() == DialogResult.OK)
			{
				printDocument.Print();
			}
		}

		private void a(object A_0, PrintPageEventArgs A_1)
		{
			int left = A_1.MarginBounds.Left;
			int top = A_1.MarginBounds.Top;
			double num = 2.54;
			int num2 = Convert.ToInt32(29.7 / num * 100.0);
			int num3 = Convert.ToInt32(21.0 / num * 100.0);
			Bitmap bitmap = new Bitmap(num2, num3);
			Graphics graphics = Graphics.FromImage(bitmap);
			graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.DrawImage(c0, new Rectangle(0, 0, num2, num3));
			A_1.Graphics.DrawImage(bitmap, new Rectangle(0, 0, bitmap.Width, bitmap.Height), 0f, 0f, num2, num3, GraphicsUnit.Pixel);
		}

		private Bitmap a(Form A_0)
		{
			Bitmap bitmap = new Bitmap(A_0.Width, A_0.Height - c4.Height);
			System.Drawing.Point point = A_0.PointToScreen(new System.Drawing.Point(0, 0));
			Rect rect = new Rect(point.X, point.Y + c4.Height, A_0.Width, A_0.Height - c4.Height);
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				graphics.CopyFromScreen((int)rect.X, (int)rect.Y, 0, 0, bitmap.Size, CopyPixelOperation.SourceCopy);
				return bitmap;
			}
		}

		private Bitmap a(Panel A_0)
		{
			Bitmap bitmap = new Bitmap(A_0.Width, A_0.Height);
			System.Drawing.Point point = A_0.PointToScreen(new System.Drawing.Point(0, 0));
			Rect rect = new Rect(point.X, point.Y, A_0.Width, A_0.Height);
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				graphics.CopyFromScreen((int)rect.X, (int)rect.Y, 0, 0, bitmap.Size, CopyPixelOperation.SourceCopy);
				return bitmap;
			}
		}

		private Bitmap a(ChromiumWebBrowser A_0)
		{
			Bitmap bitmap = new Bitmap(A_0.Width, A_0.Height);
			System.Drawing.Point point = A_0.PointToScreen(new System.Drawing.Point(0, 0));
			Rect rect = new Rect(point.X, point.Y, A_0.Width, A_0.Height);
			using (Graphics graphics = Graphics.FromImage(bitmap))
			{
				graphics.CopyFromScreen((int)rect.X, (int)rect.Y, 0, 0, bitmap.Size, CopyPixelOperation.SourceCopy);
				return bitmap;
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && c1 != null)
			{
				c1.Dispose();
			}
			base.Dispose(disposing);
		}

		private void a()
		{
			c1 = new Container();
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(epubReadPage));
			c2 = new Panel();
			dg = new Panel();
			dw = new TreeView();
			dy = new ImageList(c1);
			dr = new TreeView();
			dh = new TreeView();
			c3 = new Panel();
			c4 = new ToolStrip();
			df = new ToolStripButton();
			dv = new ToolStripButton();
			c5 = new ToolStripButton();
			c6 = new ToolStripButton();
			dn = new ToolStripButton();
			dx = new ToolStripButton();
			d4 = new ToolStripButton();
			d5 = new ToolStripButton();
			c8 = new ToolStripLabel();
			da = new ToolStripButton();
			c9 = new ToolStripLabel();
			db = new ToolStripButton();
			dc = new ToolStripTextBox();
			dd = new ToolStripButton();
			de = new ToolStripLabel();
			c7 = new ToolStripLabel();
			ek = new ToolStripButton();
			di = new ToolStrip();
			dj = new ToolStripButton();
			dk = new ToolStripButton();
			dl = new ToolStripButton();
			dm = new ToolStripButton();
			@do = new Panel();
			d3 = new Button();
			d2 = new Button();
			dp = new Button();
			dq = new Button();
			du = new Button();
			d0 = new TextBox();
			d1 = new TextBox();
			ds = new Button();
			dt = new Button();
			dz = new Panel();
			d6 = new PictureBox();
			d7 = new Panel();
			d8 = new ToolStrip();
			d9 = new ToolStripButton();
			ea = new ToolStripButton();
			eb = new ToolStripButton();
			ec = new ToolStripDropDownButton();
			ed = new ToolStripMenuItem();
			ee = new ToolStripMenuItem();
			ef = new ToolStripMenuItem();
			eg = new ToolStripMenuItem();
			eh = new ToolStripButton();
			ei = new ToolStripButton();
			ej = new ToolStripButton();
			dg.SuspendLayout();
			c4.SuspendLayout();
			di.SuspendLayout();
			@do.SuspendLayout();
			((ISupportInitialize)d6).BeginInit();
			d7.SuspendLayout();
			d8.SuspendLayout();
			SuspendLayout();
			c2.BackColor = Color.White;
			c2.ForeColor = Color.White;
			c2.Location = new System.Drawing.Point(32, 44);
			c2.Margin = new Padding(0);
			c2.Name = "panel1";
			c2.Size = new System.Drawing.Size(272, 254);
			c2.TabIndex = 2;
			dg.BackColor = Color.Transparent;
			dg.BackgroundImageLayout = ImageLayout.None;
			dg.Controls.Add(dw);
			dg.Controls.Add(dr);
			dg.Controls.Add(dh);
			dg.ForeColor = Color.Transparent;
			dg.Location = new System.Drawing.Point(57, 42);
			dg.Name = "toc_panel";
			dg.Size = new System.Drawing.Size(200, 191);
			dg.TabIndex = 24;
			dg.Visible = false;
			dw.BorderStyle = BorderStyle.FixedSingle;
			dw.Font = new Font("新細明體", 11.25f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			dw.ImageIndex = 0;
			dw.ImageList = dy;
			dw.Location = new System.Drawing.Point(0, 0);
			dw.Name = "tvw_Note";
			dw.SelectedImageIndex = 0;
			dw.Size = new System.Drawing.Size(98, 107);
			dw.TabIndex = 6;
			dw.Visible = false;
			dw.NodeMouseClick += new TreeNodeMouseClickEventHandler(a);
			dy.ImageStream = (ImageListStreamer)componentResourceManager.GetObject("imageList1.ImageStream");
			dy.TransparentColor = Color.Transparent;
			dy.Images.SetKeyName(0, "btn_10.png");
			dy.Images.SetKeyName(1, "btn_15_over.png");
			dy.Images.SetKeyName(2, "note.png");
			dy.Images.SetKeyName(3, "btn_note_over.png");
			dr.BorderStyle = BorderStyle.FixedSingle;
			dr.Font = new Font("新細明體", 11.25f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			dr.Location = new System.Drawing.Point(0, 0);
			dr.Name = "tvw_Search";
			dr.Size = new System.Drawing.Size(136, 50);
			dr.TabIndex = 5;
			dr.Visible = false;
			dr.NodeMouseClick += new TreeNodeMouseClickEventHandler(b);
			dh.BackColor = System.Drawing.SystemColors.Window;
			dh.BorderStyle = BorderStyle.FixedSingle;
			dh.Font = new Font("新細明體", 12f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			dh.Location = new System.Drawing.Point(0, 0);
			dh.Name = "tvw_Toc";
			dh.Size = new System.Drawing.Size(49, 160);
			dh.TabIndex = 4;
			dh.Visible = false;
			dh.NodeMouseClick += new TreeNodeMouseClickEventHandler(c);
			dh.KeyDown += new KeyEventHandler(b);
			c3.BackColor = Color.White;
			c3.ForeColor = Color.White;
			c3.Location = new System.Drawing.Point(370, 44);
			c3.Margin = new Padding(0);
			c3.Name = "panel2";
			c3.Size = new System.Drawing.Size(218, 254);
			c3.TabIndex = 3;
			c4.BackColor = Color.FromArgb(25, 25, 25);
			c4.Font = new Font("Microsoft JhengHei UI", 14.25f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			c4.ImageScalingSize = new System.Drawing.Size(32, 32);
			c4.Items.AddRange(new ToolStripItem[17]
			{
				df,
				dv,
				c5,
				c6,
				dn,
				dx,
				d4,
				d5,
				c8,
				da,
				c9,
				db,
				dc,
				dd,
				de,
				c7,
				ek
			});
			c4.Location = new System.Drawing.Point(0, 0);
			c4.Name = "toolStrip1";
			c4.Size = new System.Drawing.Size(1143, 39);
			c4.TabIndex = 19;
			c4.Text = "toolStrip1";
			c4.ItemClicked += new ToolStripItemClickedEventHandler(a);
			df.DisplayStyle = ToolStripItemDisplayStyle.Image;
			df.Image = (Image)componentResourceManager.GetObject("tcpBtn.Image");
			df.ImageTransparentColor = Color.Magenta;
			df.Name = "tcpBtn";
			df.Size = new System.Drawing.Size(36, 36);
			df.ToolTipText = "目錄";
			df.Click += new EventHandler(ag);
			dv.DisplayStyle = ToolStripItemDisplayStyle.Image;
			dv.Image = (Image)componentResourceManager.GetObject("NoteBtn.Image");
			dv.ImageTransparentColor = Color.Magenta;
			dv.Name = "NoteBtn";
			dv.Size = new System.Drawing.Size(36, 36);
			dv.ToolTipText = "註記列表";
			dv.Click += new EventHandler(af);
			c5.BackgroundImageLayout = ImageLayout.Zoom;
			c5.DisplayStyle = ToolStripItemDisplayStyle.Image;
			c5.Image = (Image)componentResourceManager.GetObject("zoomOut.Image");
			c5.ImageTransparentColor = Color.Magenta;
			c5.Name = "zoomOut";
			c5.Size = new System.Drawing.Size(36, 36);
			c5.ToolTipText = "字體縮小";
			c5.Click += new EventHandler(ai);
			c6.DisplayStyle = ToolStripItemDisplayStyle.Image;
			c6.Image = (Image)componentResourceManager.GetObject("roomIn.Image");
			c6.ImageTransparentColor = Color.Magenta;
			c6.Name = "roomIn";
			c6.Size = new System.Drawing.Size(36, 36);
			c6.Text = "AAA";
			c6.ToolTipText = "字體放大";
			c6.Click += new EventHandler(aj);
			dn.DisplayStyle = ToolStripItemDisplayStyle.Image;
			dn.Image = (Image)componentResourceManager.GetObject("btn_resetSize.Image");
			dn.ImageTransparentColor = Color.Magenta;
			dn.Name = "btn_resetSize";
			dn.Size = new System.Drawing.Size(36, 36);
			dn.Text = "toolStripButton2";
			dn.ToolTipText = "還原文字大小";
			dn.Visible = false;
			dn.Click += new EventHandler(ah);
			dx.DisplayStyle = ToolStripItemDisplayStyle.Image;
			dx.Image = (Image)componentResourceManager.GetObject("exportNote.Image");
			dx.ImageTransparentColor = Color.Magenta;
			dx.Name = "exportNote";
			dx.Size = new System.Drawing.Size(36, 36);
			dx.Text = "toolStripButton2";
			dx.ToolTipText = "匯出註記";
			dx.Click += new EventHandler(aa);
			d4.DisplayStyle = ToolStripItemDisplayStyle.Image;
			d4.Image = (Image)componentResourceManager.GetObject("mediaPlay.Image");
			d4.ImageTransparentColor = Color.Magenta;
			d4.Name = "mediaPlay";
			d4.Size = new System.Drawing.Size(36, 36);
			d4.Text = "toolStripButton2";
			d4.ToolTipText = "play";
			d4.Visible = false;
			d4.Click += new EventHandler(e);
			d5.DisplayStyle = ToolStripItemDisplayStyle.Image;
			d5.Image = (Image)componentResourceManager.GetObject("mediaPause.Image");
			d5.ImageTransparentColor = Color.Magenta;
			d5.Name = "mediaPause";
			d5.Size = new System.Drawing.Size(36, 36);
			d5.Text = "toolStripButton2";
			d5.ToolTipText = "stop";
			d5.Visible = false;
			d5.Click += new EventHandler(d);
			c8.Name = "toolStripLabel1";
			c8.Size = new System.Drawing.Size(18, 36);
			c8.Text = "/";
			c8.Click += new EventHandler(c);
			da.DisplayStyle = ToolStripItemDisplayStyle.Text;
			da.Font = new Font("Microsoft JhengHei UI", 12f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			da.ForeColor = Color.White;
			da.ImageTransparentColor = Color.Magenta;
			da.Name = "proc";
			da.Size = new System.Drawing.Size(29, 36);
			da.Text = "簡";
			da.Click += new EventHandler(ae);
			c9.Name = "Tpage";
			c9.Size = new System.Drawing.Size(0, 36);
			db.DisplayStyle = ToolStripItemDisplayStyle.Text;
			db.Font = new Font("Microsoft JhengHei UI", 12f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			db.ForeColor = Color.White;
			db.ImageTransparentColor = Color.Magenta;
			db.Name = "roc";
			db.Size = new System.Drawing.Size(29, 36);
			db.Text = "繁";
			db.Click += new EventHandler(ad);
			dc.Name = "searchKey";
			dc.Size = new System.Drawing.Size(150, 39);
			dc.KeyDown += new KeyEventHandler(a);
			dd.DisplayStyle = ToolStripItemDisplayStyle.Image;
			dd.ForeColor = Color.White;
			dd.Image = (Image)componentResourceManager.GetObject("btn_search.Image");
			dd.ImageTransparentColor = Color.Magenta;
			dd.Name = "btn_search";
			dd.Size = new System.Drawing.Size(36, 36);
			dd.Text = "Search";
			dd.Click += new EventHandler(ab);
			de.Font = new Font("Microsoft JhengHei UI", 12f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			de.ForeColor = Color.White;
			de.Name = "chapterName";
			de.Size = new System.Drawing.Size(41, 36);
			de.Text = "章節";
			de.Click += new EventHandler(f);
			c7.Font = new Font("Microsoft JhengHei UI", 12f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			c7.ForeColor = Color.White;
			c7.Name = "pagesLabel";
			c7.Size = new System.Drawing.Size(0, 36);
			ek.Alignment = ToolStripItemAlignment.Right;
			ek.DisplayStyle = ToolStripItemDisplayStyle.Image;
			ek.Image = (Image)componentResourceManager.GetObject("epubPrint.Image");
			ek.ImageTransparentColor = Color.Magenta;
			ek.Name = "epubPrint";
			ek.Size = new System.Drawing.Size(36, 36);
			ek.Text = "列印";
			ek.Visible = false;
			ek.Click += new EventHandler(a);
			di.BackColor = Color.Black;
			di.Dock = DockStyle.None;
			di.Font = new Font("Microsoft JhengHei UI", 11.25f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			di.ImageScalingSize = new System.Drawing.Size(20, 20);
			di.Items.AddRange(new ToolStripItem[4]
			{
				dj,
				dk,
				dl,
				dm
			});
			di.Location = new System.Drawing.Point(739, 521);
			di.Name = "popSubMenu";
			di.Size = new System.Drawing.Size(104, 26);
			di.TabIndex = 25;
			di.Text = "toolStrip2";
			di.Visible = false;
			dj.BackColor = Color.FromArgb(255, 179, 216);
			dj.DisplayStyle = ToolStripItemDisplayStyle.None;
			dj.ImageTransparentColor = Color.Magenta;
			dj.Name = "color_red";
			dj.Size = new System.Drawing.Size(23, 23);
			dj.Text = "螢光筆選色";
			dj.Click += new EventHandler(p);
			dk.BackColor = Color.FromArgb(176, 207, 252);
			dk.DisplayStyle = ToolStripItemDisplayStyle.None;
			dk.ImageTransparentColor = Color.Magenta;
			dk.Name = "color_blue";
			dk.Size = new System.Drawing.Size(23, 23);
			dk.Text = "螢光筆選色";
			dk.Click += new EventHandler(n);
			dl.BackColor = Color.FromArgb(214, 247, 142);
			dl.DisplayStyle = ToolStripItemDisplayStyle.None;
			dl.ImageTransparentColor = Color.Magenta;
			dl.Name = "color_green";
			dl.Size = new System.Drawing.Size(23, 23);
			dl.Text = "螢光筆選色";
			dl.Click += new EventHandler(o);
			dm.DisplayStyle = ToolStripItemDisplayStyle.Text;
			dm.ForeColor = Color.White;
			dm.ImageTransparentColor = Color.Magenta;
			dm.Name = "delPen";
			dm.Size = new System.Drawing.Size(23, 23);
			dm.Text = "X";
			dm.ToolTipText = "刪除螢光筆";
			dm.Click += new EventHandler(m);
			@do.BackColor = Color.LightGoldenrodYellow;
			@do.BorderStyle = BorderStyle.FixedSingle;
			@do.Controls.Add(d3);
			@do.Controls.Add(d2);
			@do.Controls.Add(dp);
			@do.Controls.Add(dq);
			@do.Controls.Add(du);
			@do.Controls.Add(d0);
			@do.Controls.Add(d1);
			@do.Location = new System.Drawing.Point(718, 54);
			@do.Name = "NotePanel";
			@do.Size = new System.Drawing.Size(400, 432);
			@do.TabIndex = 29;
			@do.Visible = false;
			d3.AutoSize = true;
			d3.FlatAppearance.BorderSize = 0;
			d3.FlatStyle = FlatStyle.Flat;
			d3.Image = (Image)componentResourceManager.GetObject("note_pre.Image");
			d3.Location = new System.Drawing.Point(2, 395);
			d3.Name = "note_pre";
			d3.Size = new System.Drawing.Size(33, 27);
			d3.TabIndex = 8;
			d3.UseVisualStyleBackColor = true;
			d3.Click += new EventHandler(k);
			d2.AutoSize = true;
			d2.FlatAppearance.BorderSize = 0;
			d2.FlatStyle = FlatStyle.Flat;
			d2.Image = (Image)componentResourceManager.GetObject("note_next.Image");
			d2.Location = new System.Drawing.Point(363, 393);
			d2.Name = "note_next";
			d2.Size = new System.Drawing.Size(33, 27);
			d2.TabIndex = 9;
			d2.UseVisualStyleBackColor = true;
			d2.Click += new EventHandler(j);
			dp.FlatStyle = FlatStyle.Flat;
			dp.Font = new Font("新細明體", 11.25f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			dp.Location = new System.Drawing.Point(282, 395);
			dp.Name = "btn_closeNote";
			dp.Size = new System.Drawing.Size(75, 27);
			dp.TabIndex = 2;
			dp.Text = "取消";
			dp.UseVisualStyleBackColor = true;
			dp.Click += new EventHandler(g);
			dq.FlatStyle = FlatStyle.Flat;
			dq.Font = new Font("新細明體", 11.25f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			dq.Location = new System.Drawing.Point(166, 395);
			dq.Name = "btn_delNote";
			dq.Size = new System.Drawing.Size(75, 27);
			dq.TabIndex = 3;
			dq.Text = "刪除";
			dq.UseVisualStyleBackColor = true;
			dq.Click += new EventHandler(h);
			du.FlatStyle = FlatStyle.Flat;
			du.Font = new Font("新細明體", 11.25f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			du.Location = new System.Drawing.Point(43, 395);
			du.Name = "btn_saveNote";
			du.Size = new System.Drawing.Size(75, 27);
			du.TabIndex = 4;
			du.Text = "存檔";
			du.UseVisualStyleBackColor = true;
			du.Click += new EventHandler(i);
			d0.BackColor = Color.LightGoldenrodYellow;
			d0.BorderStyle = BorderStyle.FixedSingle;
			d0.Font = new Font("新細明體", 14.25f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			d0.Location = new System.Drawing.Point(2, 133);
			d0.Multiline = true;
			d0.Name = "textNote";
			d0.Size = new System.Drawing.Size(394, 255);
			d0.TabIndex = 1;
			d0.TextChanged += new EventHandler(l);
			d1.BackColor = Color.PaleGoldenrod;
			d1.BorderStyle = BorderStyle.None;
			d1.Font = new Font("新細明體", 12f, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, GraphicsUnit.Point, 136);
			d1.Location = new System.Drawing.Point(8, 7);
			d1.Multiline = true;
			d1.Name = "noteHtml";
			d1.ReadOnly = true;
			d1.Size = new System.Drawing.Size(382, 120);
			d1.TabIndex = 8;
			ds.BackColor = Color.White;
			ds.BackgroundImageLayout = ImageLayout.Center;
			ds.FlatStyle = FlatStyle.Flat;
			ds.ForeColor = Color.White;
			ds.Location = new System.Drawing.Point(1114, 39);
			ds.Name = "btn_TurnRight_hide";
			ds.Size = new System.Drawing.Size(29, 2048);
			ds.TabIndex = 30;
			ds.UseVisualStyleBackColor = false;
			ds.Visible = false;
			ds.Click += new EventHandler(al);
			dt.BackColor = Color.White;
			dt.BackgroundImageLayout = ImageLayout.Center;
			dt.FlatStyle = FlatStyle.Flat;
			dt.ForeColor = Color.White;
			dt.Location = new System.Drawing.Point(0, 39);
			dt.Name = "btn_TurnLeft_hide";
			dt.Size = new System.Drawing.Size(29, 2048);
			dt.TabIndex = 31;
			dt.UseVisualStyleBackColor = false;
			dt.Visible = false;
			dt.Click += new EventHandler(ak);
			dz.BackgroundImage = (Image)componentResourceManager.GetObject("panel4.BackgroundImage");
			dz.BackgroundImageLayout = ImageLayout.Stretch;
			dz.Location = new System.Drawing.Point(35, 310);
			dz.Name = "panel4";
			dz.Size = new System.Drawing.Size(269, 336);
			dz.TabIndex = 32;
			dz.Visible = false;
			d6.BackColor = Color.Transparent;
			d6.Image = (Image)componentResourceManager.GetObject("pictureBox1.Image");
			d6.Location = new System.Drawing.Point(65, 30);
			d6.Name = "pictureBox1";
			d6.Size = new System.Drawing.Size(200, 200);
			d6.TabIndex = 33;
			d6.TabStop = false;
			d7.BackColor = Color.White;
			d7.BackgroundImageLayout = ImageLayout.Center;
			d7.Controls.Add(d6);
			d7.Location = new System.Drawing.Point(383, 368);
			d7.Name = "panel3";
			d7.Size = new System.Drawing.Size(294, 257);
			d7.TabIndex = 34;
			d8.AllowDrop = true;
			d8.BackColor = System.Drawing.SystemColors.ButtonShadow;
			d8.Dock = DockStyle.None;
			d8.Font = new Font("Microsoft JhengHei UI", 11.25f, System.Drawing.FontStyle.Regular, GraphicsUnit.Point, 136);
			d8.ImageScalingSize = new System.Drawing.Size(20, 20);
			d8.Items.AddRange(new ToolStripItem[7]
			{
				d9,
				ea,
				eb,
				ec,
				eh,
				ei,
				ej
			});
			d8.Location = new System.Drawing.Point(727, 572);
			d8.Name = "popMainMenu";
			d8.Size = new System.Drawing.Size(291, 26);
			d8.TabIndex = 35;
			d8.Text = "toolStrip2";
			d8.Visible = false;
			d9.DisplayStyle = ToolStripItemDisplayStyle.Text;
			d9.ImageTransparentColor = Color.Magenta;
			d9.Name = "highlighter";
			d9.Size = new System.Drawing.Size(58, 23);
			d9.Text = "螢光筆";
			d9.Click += new EventHandler(z);
			ea.DisplayStyle = ToolStripItemDisplayStyle.Text;
			ea.ImageTransparentColor = Color.Magenta;
			ea.Name = "note";
			ea.Size = new System.Drawing.Size(43, 23);
			ea.Text = "註記";
			ea.Visible = false;
			ea.Click += new EventHandler(y);
			eb.DisplayStyle = ToolStripItemDisplayStyle.Text;
			eb.ImageTransparentColor = Color.Magenta;
			eb.Name = "toolStripButton1";
			eb.Size = new System.Drawing.Size(43, 23);
			eb.Text = "搜尋";
			eb.Click += new EventHandler(x);
			ec.DisplayStyle = ToolStripItemDisplayStyle.Text;
			ec.DropDownItems.AddRange(new ToolStripItem[4]
			{
				ed,
				ee,
				ef,
				eg
			});
			ec.ImageTransparentColor = Color.Magenta;
			ec.Name = "share";
			ec.Size = new System.Drawing.Size(52, 23);
			ec.Text = "分享";
			ed.Image = (Image)componentResourceManager.GetObject("share_facebook.Image");
			ed.Name = "share_facebook";
			ed.Size = new System.Drawing.Size(145, 26);
			ed.Text = "faceBook";
			ed.Click += new EventHandler(u);
			ee.Image = (Image)componentResourceManager.GetObject("share_twitter.Image");
			ee.Name = "share_twitter";
			ee.Size = new System.Drawing.Size(145, 26);
			ee.Text = "twitter";
			ee.Click += new EventHandler(r);
			ef.Image = (Image)componentResourceManager.GetObject("share_plurk.Image");
			ef.Name = "share_plurk";
			ef.Size = new System.Drawing.Size(145, 26);
			ef.Text = "Plurk";
			ef.Click += new EventHandler(t);
			eg.Image = (Image)componentResourceManager.GetObject("share_email.Image");
			eg.Name = "share_email";
			eg.Size = new System.Drawing.Size(145, 26);
			eg.Text = "email";
			eg.Click += new EventHandler(q);
			eh.DisplayStyle = ToolStripItemDisplayStyle.Text;
			eh.ImageTransparentColor = Color.Magenta;
			eh.Name = "translate";
			eh.Size = new System.Drawing.Size(43, 23);
			eh.Text = "翻譯";
			eh.Click += new EventHandler(w);
			ei.DisplayStyle = ToolStripItemDisplayStyle.Text;
			ei.ImageTransparentColor = Color.Magenta;
			ei.Name = "wiki";
			ei.Size = new System.Drawing.Size(43, 23);
			ei.Text = "維基";
			ei.Click += new EventHandler(v);
			ej.AutoSize = false;
			ej.BackgroundImage = (Image)componentResourceManager.GetObject("tool_del.BackgroundImage");
			ej.BackgroundImageLayout = ImageLayout.Stretch;
			ej.DisplayStyle = ToolStripItemDisplayStyle.Image;
			ej.ImageTransparentColor = Color.Transparent;
			ej.Name = "tool_del";
			ej.Size = new System.Drawing.Size(40, 23);
			ej.Text = "toolStripButton2";
			ej.ToolTipText = "Delete";
			ej.Click += new EventHandler(b);
			base.AutoScaleDimensions = new SizeF(96f, 96f);
			base.AutoScaleMode = AutoScaleMode.Dpi;
			AutoSize = true;
			BackColor = Color.White;
			base.ClientSize = new System.Drawing.Size(1143, 741);
			base.Controls.Add(di);
			base.Controls.Add(d8);
			base.Controls.Add(@do);
			base.Controls.Add(c4);
			base.Controls.Add(d7);
			base.Controls.Add(dz);
			base.Controls.Add(dt);
			base.Controls.Add(ds);
			base.Controls.Add(dg);
			base.Controls.Add(c3);
			base.Controls.Add(c2);
			base.FormBorderStyle = FormBorderStyle.FixedSingle;
			base.Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
			base.Margin = new Padding(3, 2, 3, 2);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "epubReadPage";
			base.StartPosition = FormStartPosition.CenterScreen;
			Text = "ePub Reader";
			base.WindowState = FormWindowState.Maximized;
			base.FormClosed += new FormClosedEventHandler(a);
			base.Load += new EventHandler(aq);
			dg.ResumeLayout(false);
			c4.ResumeLayout(false);
			c4.PerformLayout();
			di.ResumeLayout(false);
			di.PerformLayout();
			@do.ResumeLayout(false);
			@do.PerformLayout();
			((ISupportInitialize)d6).EndInit();
			d7.ResumeLayout(false);
			d8.ResumeLayout(false);
			d8.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
