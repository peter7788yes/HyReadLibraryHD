using Network;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Xml;
using Utility;

namespace HyReadLibraryHD
{
	public class ReserveBook : Window, IComponentConnector
	{
		private XMLTool m_a = new XMLTool();

		public string hyreadType;

		public string vendorId = "";

		public string serviceBaseUrl = "";

		public string colibId = "";

		public string userId = "";

		public string password = "";

		public string bookId = "";

		public string serialId = "";

		public string authId = "";

		public string ownerCode = "";

		internal TextBox b;

		internal Button c;

		internal Button d;

		private bool e;

		public ReserveBook()
		{
			InitializeComponent();
		}

		private void b(object A_0, RoutedEventArgs A_1)
		{
			if (a(this.b.Text))
			{
				string url = serviceBaseUrl + "/hdbook/reservebook";
				XmlDocument xmlDocument = new XmlDocument();
				xmlDocument.LoadXml("<body></body>");
				this.m_a.appendChildToXML("hyreadType", hyreadType, xmlDocument);
				this.m_a.appendChildToXML("userId", userId, xmlDocument);
				this.m_a.appendChildToXML("serialId", serialId, xmlDocument);
				this.m_a.appendChildToXML("bookId", bookId, xmlDocument);
				this.m_a.appendChildToXML("email", this.b.Text, xmlDocument);
				this.m_a.appendChildToXML("ownerCode", ownerCode, xmlDocument);
				this.m_a.appendChildToXML("authId", authId, xmlDocument);
				if (vendorId == "ntl-ebookftp")
				{
					this.m_a.appendChildToXML("device", "1", xmlDocument);
					this.m_a.appendChildToXML("password", password, xmlDocument);
				}
				else
				{
					this.m_a.appendChildToXML("device", "3", xmlDocument);
				}
				XmlDocument xmlDocument2 = new HttpRequest().postXMLAndLoadXML(url, xmlDocument);
				try
				{
					string value = xmlDocument2.SelectSingleNode("//result/text()").Value;
					MessageBox.Show(xmlDocument2.SelectSingleNode("//message/text()").Value);
				}
				catch
				{
					MessageBox.Show((xmlDocument2.SelectSingleNode("//result/text()").Value == "true") ? Global.bookManager.LanqMng.getLangString("reserveSuccess") : Global.bookManager.LanqMng.getLangString("reserveFailure"));
				}
			}
			else
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("emailIllegal"));
			}
			Close();
		}

		private void a(object A_0, RoutedEventArgs A_1)
		{
			Close();
		}

		private bool a(string A_0)
		{
			return Regex.IsMatch(A_0, "^([\\w-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([\\w-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$");
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!e)
			{
				e = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/reservebook..xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[DebuggerNonUserCode]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.b = (TextBox)target;
				break;
			case 2:
				c = (Button)target;
				c.Click += new RoutedEventHandler(b);
				break;
			case 3:
				d = (Button)target;
				d.Click += new RoutedEventHandler(a);
				break;
			default:
				e = true;
				break;
			}
		}
	}
}
