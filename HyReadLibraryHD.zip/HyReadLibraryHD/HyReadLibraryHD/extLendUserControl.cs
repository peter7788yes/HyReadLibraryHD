using BookManagerModule;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace HyReadLibraryHD
{
	public class extLendUserControl : UserControl, IComponentConnector, IStyleConnector
	{
		public List<ExtLibInfo> listExtLibInfo = new List<ExtLibInfo>();

		private List<ExtLib> extLibs = new List<ExtLib>();

		internal Grid extLendListBoxPop;

		internal ListBox extLendListBox;

		private bool _contentLoaded;

		public event EventHandler<selectEventArgs> selectEventHandlerEvent;

		public void triggerSelectHandlerEvent(selectEventArgs eventArgs)
		{
			if (this.selectEventHandlerEvent != null)
			{
				this.selectEventHandlerEvent(this, eventArgs);
			}
		}

		public void setListBox(List<ExtLibInfo> listExtLibInfo)
		{
			string langString = Global.bookManager.LanqMng.getLangString("nowLending");
			string langString2 = Global.bookManager.LanqMng.getLangString("iWantReserve");
			foreach (ExtLibInfo item in listExtLibInfo)
			{
				if (item.availableCount > 0)
				{
					List<ExtLib> list = extLibs;
					ExtLib extLib = new ExtLib();
					extLib.vendorId = item.ownerCode;
					extLib.vendorName = item.name;
					extLib.vcount = item.availableCount;
					extLib.btName = langString;
					list.Add(extLib);
				}
				else
				{
					List<ExtLib> list2 = extLibs;
					ExtLib extLib2 = new ExtLib();
					extLib2.vendorId = item.ownerCode;
					extLib2.vendorName = item.name;
					extLib2.vcount = item.availableCount;
					extLib2.btName = langString2;
					list2.Add(extLib2);
				}
			}
		}

		public extLendUserControl()
		{
			InitializeComponent();
			extLendListBox.ItemsSource = extLibs;
		}

		private void a(object A_0, RoutedEventArgs A_1)
		{
			Button button = (Button)A_1.OriginalSource;
			selectEventArgs selectEventArgs = new selectEventArgs();
			selectEventArgs.vendorId = button.Tag.ToString();
			triggerSelectHandlerEvent(selectEventArgs);
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/extlendusercontrol.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				extLendListBoxPop = (Grid)target;
				break;
			case 2:
				extLendListBox = (ListBox)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 3)
			{
				((Button)target).Click += new RoutedEventHandler(a);
			}
		}
	}
}
