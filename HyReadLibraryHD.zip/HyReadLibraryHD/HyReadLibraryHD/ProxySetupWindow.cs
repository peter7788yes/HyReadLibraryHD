using ConfigureManagerModule;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace HyReadLibraryHD
{
	public class ProxySetupWindow : Form
	{
		public ConfigurationManager ConfigMng = new ConfigurationManager(Global.bookManager);

		private int m_a = 1;

		private string m_b = "";

		private IContainer m_c;

		private GroupBox m_d;

		private TextBox e;

		private Label f;

		private TextBox g;

		private Label h;

		private RadioButton i;

		private RadioButton j;

		private RadioButton k;

		private Button l;

		private Button m;

		private Button n;

		public ProxySetupWindow()
		{
			a();
			b();
		}

		private void b()
		{
			this.m_a = ConfigMng.saveProxyMode;
			this.m_b = ConfigMng.saveProxyHttpPort;
			string[] array = this.m_b.Split('|');
			g.Text = (array[0].Equals("") ? "http://" : array[0]);
			if (array.Length > 1)
			{
				e.Text = array[1];
			}
			switch (this.m_a)
			{
			case 0:
				k.Checked = true;
				break;
			case 1:
				j.Checked = true;
				break;
			case 2:
				i.Checked = true;
				break;
			}
			Text = Global.bookManager.LanqMng.getLangString("");
			this.m_d.Text = Global.bookManager.LanqMng.getLangString("setProxyServer");
			k.Text = Global.bookManager.LanqMng.getLangString("notUseProxy");
			j.Text = Global.bookManager.LanqMng.getLangString("useSystemProxy");
			i.Text = Global.bookManager.LanqMng.getLangString("ManualProxy");
			n.Text = Global.bookManager.LanqMng.getLangString("useDefaultValues");
			l.Text = Global.bookManager.LanqMng.getLangString("submit");
			m.Text = Global.bookManager.LanqMng.getLangString("cancel");
		}

		private void d(object A_0, EventArgs A_1)
		{
			if (k.Checked)
			{
				this.m_a = 0;
				a(false);
			}
			else if (j.Checked)
			{
				this.m_a = 1;
				a(false);
			}
			else
			{
				this.m_a = 2;
				a(true);
			}
		}

		private void a(bool A_0)
		{
			h.Enabled = A_0;
			f.Enabled = A_0;
			g.Enabled = A_0;
			e.Enabled = A_0;
		}

		private void c(object A_0, EventArgs A_1)
		{
			ConfigMng.saveProxyMode = this.m_a;
			ConfigMng.saveProxyHttpPort = g.Text + "|" + e.Text;
			MessageBox.Show("網路連線設定後，需重新啟動程式才能生效", "請重啟程式");
			Close();
		}

		private void b(object A_0, EventArgs A_1)
		{
			Close();
		}

		private void a(object A_0, EventArgs A_1)
		{
			j.Checked = true;
			this.m_a = 1;
			ConfigMng.saveProxyMode = this.m_a;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.m_c != null)
			{
				this.m_c.Dispose();
			}
			base.Dispose(disposing);
		}

		private void a()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(ProxySetupWindow));
			this.m_d = new GroupBox();
			e = new TextBox();
			f = new Label();
			g = new TextBox();
			h = new Label();
			i = new RadioButton();
			j = new RadioButton();
			k = new RadioButton();
			l = new Button();
			m = new Button();
			n = new Button();
			this.m_d.SuspendLayout();
			SuspendLayout();
			this.m_d.Controls.Add(e);
			this.m_d.Controls.Add(f);
			this.m_d.Controls.Add(g);
			this.m_d.Controls.Add(h);
			this.m_d.Controls.Add(i);
			this.m_d.Controls.Add(j);
			this.m_d.Controls.Add(k);
			this.m_d.Font = new Font("新細明體", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 136);
			this.m_d.Location = new Point(12, 13);
			this.m_d.Name = "groupBox1";
			this.m_d.Size = new Size(424, 160);
			this.m_d.TabIndex = 0;
			this.m_d.TabStop = false;
			this.m_d.Text = "設定存取網路的代理伺服器 (Proxy)";
			e.BorderStyle = BorderStyle.FixedSingle;
			e.Enabled = false;
			e.Location = new Point(346, 116);
			e.Name = "txt_port";
			e.Size = new Size(63, 25);
			e.TabIndex = 6;
			f.AutoSize = true;
			f.Enabled = false;
			f.Font = new Font("新細明體", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 136);
			f.Location = new Point(309, 119);
			f.Name = "label2";
			f.Size = new Size(31, 15);
			f.TabIndex = 5;
			f.Text = "Port";
			g.BorderStyle = BorderStyle.FixedSingle;
			g.Enabled = false;
			g.Location = new Point(95, 116);
			g.Name = "txt_address";
			g.Size = new Size(203, 25);
			g.TabIndex = 4;
			h.AutoSize = true;
			h.Enabled = false;
			h.Font = new Font("新細明體", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 136);
			h.Location = new Point(19, 119);
			h.Name = "label1";
			h.Size = new Size(70, 15);
			h.TabIndex = 3;
			h.Text = "Http Proxy";
			i.AutoSize = true;
			i.Font = new Font("新細明體", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 136);
			i.Location = new Point(22, 82);
			i.Name = "radioButton3";
			i.Size = new Size(127, 19);
			i.TabIndex = 2;
			i.Text = "手動設定 Proxy ";
			i.UseVisualStyleBackColor = true;
			i.CheckedChanged += new EventHandler(d);
			j.AutoSize = true;
			j.Checked = true;
			j.Font = new Font("新細明體", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 136);
			j.Location = new Point(22, 57);
			j.Name = "radioButton2";
			j.Size = new Size(157, 19);
			j.TabIndex = 1;
			j.TabStop = true;
			j.Text = "使用系統 Proxy 設定";
			j.UseVisualStyleBackColor = true;
			j.CheckedChanged += new EventHandler(d);
			k.AutoSize = true;
			k.Font = new Font("新細明體", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 136);
			k.Location = new Point(22, 32);
			k.Name = "radioButton1";
			k.Size = new Size(108, 19);
			k.TabIndex = 0;
			k.Text = "不使用 Proxy";
			k.UseVisualStyleBackColor = true;
			k.CheckedChanged += new EventHandler(d);
			l.AutoSize = true;
			l.Font = new Font("新細明體", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 136);
			l.Location = new Point(179, 189);
			l.Name = "button1";
			l.Size = new Size(75, 25);
			l.TabIndex = 1;
			l.Text = "確定";
			l.UseVisualStyleBackColor = true;
			l.Click += new EventHandler(c);
			m.AutoSize = true;
			m.Font = new Font("新細明體", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 136);
			m.Location = new Point(324, 189);
			m.Name = "button2";
			m.Size = new Size(75, 25);
			m.TabIndex = 2;
			m.Text = "取消";
			m.UseVisualStyleBackColor = true;
			m.Click += new EventHandler(b);
			n.AutoSize = true;
			n.Font = new Font("新細明體", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 136);
			n.Location = new Point(34, 189);
			n.Name = "button3";
			n.Size = new Size(92, 25);
			n.TabIndex = 3;
			n.Text = "使用預設值";
			n.UseVisualStyleBackColor = true;
			n.Click += new EventHandler(a);
			base.AutoScaleDimensions = new SizeF(6f, 12f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(448, 226);
			base.Controls.Add(n);
			base.Controls.Add(m);
			base.Controls.Add(l);
			base.Controls.Add(this.m_d);
			base.FormBorderStyle = FormBorderStyle.FixedSingle;
			base.Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "ProxySetupWindow";
			base.StartPosition = FormStartPosition.CenterScreen;
			Text = "Proxy 連線設定";
			this.m_d.ResumeLayout(false);
			this.m_d.PerformLayout();
			ResumeLayout(false);
			PerformLayout();
		}
	}
}
