namespace HyReadLibraryHD
{
	public enum BookDetailPopUpCloseReason
	{
		NONE,
		DOWNLOAD,
		READHEJ,
		LENDBOOK,
		RETURNBOOK,
		READPHEJ,
		READEPUB,
		TRYREADHEJ,
		TRYREADPHEJ,
		TRYREADEPUB,
		DELBOOK,
		REQUIRELOGIN,
		RENEWDAY
	}
}
