using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace HyReadLibraryHD
{
	public class FormWebBrower : Form
	{
		public string url = "";

		public int openType;

		public string keyword = "";

		public Size openSize = new Size(800, 600);

		private IContainer m_a;

		private WebBrowser b;

		public FormWebBrower()
		{
			a();
		}

		private void a(object A_0, EventArgs A_1)
		{
			base.Size = openSize;
			base.Location = new Point((Screen.PrimaryScreen.Bounds.Width - base.Width) / 2, (Screen.PrimaryScreen.Bounds.Height - base.Height) / 2);
			if (openType == 0)
			{
				Text = "google " + Global.bookManager.LanqMng.getLangString("translation") + " ：" + keyword;
			}
			else if (openType == 1)
			{
				Text = Global.bookManager.LanqMng.getLangString("wiki") + " ：" + keyword;
			}
			b.ScriptErrorsSuppressed = true;
			b.Navigate(url);
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.m_a != null)
			{
				this.m_a.Dispose();
			}
			base.Dispose(disposing);
		}

		private void a()
		{
			b = new WebBrowser();
			SuspendLayout();
			b.Dock = DockStyle.Fill;
			b.Location = new Point(0, 0);
			b.MinimumSize = new Size(20, 20);
			b.Name = "webBrowser1";
			b.Size = new Size(784, 561);
			b.TabIndex = 0;
			b.Url = new Uri("", UriKind.Relative);
			base.AutoScaleDimensions = new SizeF(6f, 12f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(784, 561);
			base.Controls.Add(b);
			base.Name = "FormWebBrower";
			base.StartPosition = FormStartPosition.CenterScreen;
			Text = "FormWebBrower";
			base.Load += new EventHandler(a);
			ResumeLayout(false);
		}
	}
}
