using BookManagerModule;
using MultiLanquageModule;
using NLog;
using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Net;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace HyReadLibraryHD
{
	public class App : Application
	{
		internal delegate void a(SplashWindow A_0);

		private static Logger m_a = LogManager.GetCurrentClassLogger();

		private bool b;

		internal a c;

		private SplashWindow d;

		private bool e;

		public new static App Current
		{
			get
			{
				return Application.Current as App;
			}
		}

		public App()
		{
			ServicePointManager.DefaultConnectionLimit = 200;
			c = new a(a);
		}

		private void a(SplashWindow A_0)
		{
			App.m_a.Trace("in _applicationInitialize");
			if (RunningInstance() == null)
			{
				Application.Current.DispatcherUnhandledException += new DispatcherUnhandledExceptionEventHandler(a);
				string curSysVersion = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion.ToString();
				d = A_0;
				try
				{
					Global.bookManager.curSysVersion = curSysVersion;
					Global.bookManager.initializeStepFinished += new EventHandler<InitializeProgressChangedEventArgs>(a);
					Global.bookManager.initializeMessageAlerted += new EventHandler<InitializeMessageAlertEventArgs>(a);
					Global.bookManager.initialize();
					App.m_a.Trace("in _applicationInitialize try Catch");
				}
				catch (Exception ex)
				{
					App.m_a.Trace("exception @ bookManager.initialize():" + ex.Message);
				}
				while (!b)
				{
					Thread.Sleep(100);
				}
				App.m_a.Trace("out _applicationInitialize");
			}
		}

		private void a(object A_0, InitializeProgressChangedEventArgs A_1)
		{
			App.m_a.Trace("begin updateSplashWindow");
			d.SetProgress((float)A_1.stepsFinished / (float)A_1.totalSteps);
			if (A_1.stepsFinished == A_1.totalSteps)
			{
				App.m_a.Trace("開啟主視窗");
				b = true;
				Global.syncCenter.bookManager = Global.bookManager;
				base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new k(a));
			}
			App.m_a.Trace("end updateSplashWindow");
		}

		private void a(object A_0, InitializeMessageAlertEventArgs A_1)
		{
			App.m_a.Trace("int messageAlert");
			if (A_1.msgAlert == InitializeMessageAlert.CLOSE_SPLASHWINDOW)
			{
				d.Close();
			}
			else if (MessageBox.Show(A_1.messageBoxText, A_1.messageBoxCaptain, MessageBoxButton.YesNo, MessageBoxImage.Exclamation).Equals(MessageBoxResult.Yes))
			{
				switch (A_1.msgAlert)
				{
				case InitializeMessageAlert.OPEN_BROWSER:
					Process.Start((string)A_1.callBackParams[0]);
					Global.bookManager.needUpdateApp = true;
					break;
				case InitializeMessageAlert.SYSTEM_RESET:
				{
					string canvasText = (string)A_1.callBackParams[0];
					d.OpenLoadingPanel(canvasText);
					Global.bookManager.resetSystem();
					break;
				}
				}
			}
			App.m_a.Trace("out messageAlert");
		}

		private void a(object A_0, StartupEventArgs A_1)
		{
		}

		private void a(object A_0, DispatcherUnhandledExceptionEventArgs A_1)
		{
			App.m_a.Debug("in AppDispatcherUnhandledException");
			A_1.Handled = false;
			a(A_1);
		}

		private void a(DispatcherUnhandledExceptionEventArgs A_0)
		{
			A_0.Handled = true;
			MultiLanquageManager multiLanquageManager = new MultiLanquageManager(Global.langName);
			App.m_a.Debug("UnhandeledException:{0}", MessageBoxImage.Hand);
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine(multiLanquageManager.getLangString("unhandeledExceptionMsg"));
			stringBuilder.AppendLine(multiLanquageManager.getLangString("bugreportMsg"));
			stringBuilder.AppendLine("");
			stringBuilder.AppendLine("Error : " + A_0.Exception.Message + ((A_0.Exception.InnerException != null) ? ("\n" + A_0.Exception.InnerException.Message) : null));
			MessageBox.Show(stringBuilder.ToString(), "Application Error", MessageBoxButton.OK, MessageBoxImage.Hand);
			Application.Current.Shutdown();
		}

		public static Process RunningInstance()
		{
			try
			{
				Process currentProcess = Process.GetCurrentProcess();
				Process[] processesByName = Process.GetProcessesByName(currentProcess.ProcessName);
				foreach (Process process in processesByName)
				{
					if (process.Id != currentProcess.Id && Assembly.GetExecutingAssembly().Location.Replace("/", "\\") == currentProcess.MainModule.FileName)
					{
						return process;
					}
				}
			}
			catch
			{
			}
			return null;
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!e)
			{
				e = true;
				base.StartupUri = new Uri("SplashWindow.xaml", UriKind.Relative);
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/app.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[STAThread]
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public static void Main()
		{
			App app = new App();
			app.InitializeComponent();
			app.Run();
		}

		[CompilerGenerated]
		private void a()
		{
			App.m_a.Trace("call MainWindow.Show()");
			base.MainWindow = new MainWindow();
			base.MainWindow.Show();
			App.m_a.Trace("after show MainWindow.Show()");
		}
	}
}
