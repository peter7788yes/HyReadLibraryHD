using BookManagerModule;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;

namespace HyReadLibraryHD
{
	public class TagCategoriesFilterButton : UserControl, IComponentConnector, IStyleConnector
	{
		public string curTagName = "all";

		private ObservableCollection<TagListCountData> tagDataList = new ObservableCollection<TagListCountData>();

		private List<string> tagList;

		internal Button TagCategoryFilterButton;

		internal Image CheckMark;

		internal TextBlock FileterConditionTextBlock;

		internal Popup tagPopup;

		internal Grid tagPanelGrid;

		internal ListBox tagListBox;

		private bool _contentLoaded;

		public event FilterEvent filterEvent;

		public TagCategoriesFilterButton()
		{
			InitializeComponent();
		}

		private void c(object A_0, RoutedEventArgs A_1)
		{
			tagPopup.IsOpen = !tagPopup.IsOpen;
			if (!tagPopup.IsOpen)
			{
				return;
			}
			tagDataList.Clear();
			int num = 0;
			bool flag = Global.bookManager.isFilterFreeBooks();
			for (int i = 0; i < Global.bookManager.bookShelf.Count; i++)
			{
				if (flag || !(Global.bookManager.bookShelf[i].vendorId == "free"))
				{
					num++;
				}
			}
			TagListCountData tagListCountData = new TagListCountData();
			tagListCountData.tagName = Global.bookManager.LanqMng.getLangString("all");
			tagListCountData.tagCount = num;
			TagListCountData item = tagListCountData;
			tagDataList.Add(item);
			tagList = Global.bookManager.getAllTagCategories();
			for (int j = 0; j < tagList.Count; j++)
			{
				TagListCountData tagListCountData2 = new TagListCountData();
				tagListCountData2.tagName = tagList[j];
				tagListCountData2.tagCount = 0;
				item = tagListCountData2;
				tagDataList.Add(item);
			}
			List<TagData> allTagNamesList = Global.bookManager.getAllTagNamesList();
			for (int k = 0; k < num; k++)
			{
				string bookId = Global.bookManager.bookShelf[k].bookId;
				string vendorId = Global.bookManager.bookShelf[k].vendorId;
				string userId = Global.bookManager.bookShelf[k].userId;
				for (int l = 0; l < allTagNamesList.Count; l++)
				{
					if (!allTagNamesList[l].vendor.Equals(vendorId) || !allTagNamesList[l].bookid.Equals(bookId) || !allTagNamesList[l].userid.Equals(userId))
					{
						continue;
					}
					string text = allTagNamesList[l].tags;
					for (int m = 0; m < tagDataList.Count; m++)
					{
						if (text.Contains(tagDataList[m].tagName))
						{
							tagDataList[m].tagCount++;
							text = text.Replace(tagDataList[m].tagName, "");
						}
					}
					if (string.IsNullOrEmpty(text))
					{
						continue;
					}
					string[] array = text.Split(new char[1]
					{
						','
					}, StringSplitOptions.RemoveEmptyEntries);
					if (array != null && array.Length != 0)
					{
						for (int n = 0; n < array.Length; n++)
						{
							Global.bookManager.saveTagCategory(array[n]);
							TagListCountData tagListCountData3 = new TagListCountData();
							tagListCountData3.tagName = array[n];
							tagListCountData3.tagCount = 1;
							item = tagListCountData3;
							tagDataList.Add(item);
						}
					}
				}
			}
			tagListBox.ItemsSource = tagDataList;
		}

		private void b(object A_0, RoutedEventArgs A_1)
		{
			string text = (string)((Button)A_0).Tag;
			string langString = Global.bookManager.LanqMng.getLangString("all");
			curTagName = ((text == langString) ? "all" : text);
			if (this.filterEvent != null)
			{
				this.filterEvent(curTagName);
			}
			FileterConditionTextBlock.Text = text;
		}

		private void a(object A_0, RoutedEventArgs A_1)
		{
			string text = (string)((MenuItem)A_0).Tag;
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			Global.bookManager.delTagCategory(text);
			for (int num = tagDataList.Count - 1; num >= 0; num--)
			{
				if (tagDataList[num].tagName == text)
				{
					tagDataList.Remove(tagDataList[num]);
				}
			}
			List<TagData> allTagNamesList = Global.bookManager.getAllTagNamesList();
			for (int i = 0; i < allTagNamesList.Count; i++)
			{
				TagData tagData = allTagNamesList[i];
				if (tagData.tags.Contains(text))
				{
					List<string> list = Enumerable.ToList(tagData.tags.Split(new char[1]
					{
						','
					}, StringSplitOptions.RemoveEmptyEntries));
					list.Remove(text);
					string text2 = "";
					for (int j = 0; j < list.Count; j++)
					{
						text2 = text2 + list[j] + ",";
					}
					text2 = (tagData.tags = ((text2 == "") ? "" : text2.Substring(0, text2.LastIndexOf(','))));
					Global.bookManager.saveTagData(true, tagData);
				}
			}
		}

		private void a(object A_0, ContextMenuEventArgs A_1)
		{
			Button obj = (Button)A_0;
			string langString = Global.bookManager.LanqMng.getLangString("all");
			if ((string)obj.Tag == langString)
			{
				A_1.Handled = true;
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/tagcategoriesfilterbutton.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				TagCategoryFilterButton = (Button)target;
				TagCategoryFilterButton.Click += new RoutedEventHandler(c);
				break;
			case 2:
				CheckMark = (Image)target;
				break;
			case 3:
				FileterConditionTextBlock = (TextBlock)target;
				break;
			case 4:
				tagPopup = (Popup)target;
				break;
			case 5:
				tagPanelGrid = (Grid)target;
				break;
			case 6:
				tagListBox = (ListBox)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 7:
				((Button)target).Click += new RoutedEventHandler(b);
				((Button)target).ContextMenuOpening += new ContextMenuEventHandler(a);
				break;
			case 8:
				((MenuItem)target).Click += new RoutedEventHandler(a);
				break;
			}
		}
	}
}
