namespace HyReadLibraryHD
{
	public delegate void LibsButtonClickEvent(string clickItemId, string clickItemName);
}
