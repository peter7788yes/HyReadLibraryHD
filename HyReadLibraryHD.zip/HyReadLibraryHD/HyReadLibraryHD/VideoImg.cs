namespace HyReadLibraryHD
{
	public class VideoImg
	{
		public string id;

		public int left;

		public int top;

		public int width;

		public int height;
	}
}
