namespace HyReadLibraryHD
{
	public class SearchListData
	{
		public string result;

		public string display;
	}
}
