using BookManagerModule;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Forms;

namespace HyReadLibraryHD
{
	public class SSOBrowser : Form
	{
		private const int m_a = 42;

		public bool isCancelled = true;

		private string b = "";

		private IContainer c;

		private WebBrowser d;

		[DllImport("wininet.dll", SetLastError = true)]
		private static extern bool InternetSetOption(IntPtr A_0, int A_1, IntPtr A_2, int A_3);

		public SSOBrowser(string VendorId, string loginApi)
		{
			a();
			b = VendorId;
			InternetSetOption(IntPtr.Zero, 42, IntPtr.Zero, 0);
			a(loginApi);
		}

		private void a(string A_0)
		{
			if (!string.IsNullOrEmpty(A_0) && !A_0.Equals("about:blank"))
			{
				if (!A_0.StartsWith("http://") && !A_0.StartsWith("https://"))
				{
					A_0 = "http://" + A_0;
				}
				try
				{
					d.Navigate(new Uri(A_0));
				}
				catch (UriFormatException)
				{
				}
			}
		}

		private void a(object A_0, WebBrowserDocumentCompletedEventArgs A_1)
		{
			string text = "";
			string text2 = "";
			if (!d.Url.AbsolutePath.Contains("success.jsp"))
			{
				return;
			}
			try
			{
				foreach (HtmlElement item in d.Document.GetElementsByTagName("input"))
				{
					if (item.GetAttribute("name").Equals("sid"))
					{
						text2 = item.GetAttribute("value");
					}
					if (item.GetAttribute("name").Equals("uid"))
					{
						text = item.GetAttribute("value");
					}
				}
			}
			catch
			{
			}
			if (!text.Equals("") && !text2.Equals(""))
			{
				isCancelled = false;
				Dictionary<string, CoLib> colibs = Global.bookManager.bookProviders[b].colibs;
				string colibId = "";
				foreach (KeyValuePair<string, CoLib> item2 in colibs)
				{
					colibId = item2.Value.venderId;
				}
				try
				{
					Global.bookManager.loginForSSO(b, colibId, text, text2);
				}
				catch (Exception)
				{
				}
			}
			else
			{
				System.Windows.MessageBox.Show("登入失敗");
			}
			Close();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && c != null)
			{
				c.Dispose();
			}
			base.Dispose(disposing);
		}

		private void a()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(SSOBrowser));
			d = new WebBrowser();
			SuspendLayout();
			d.Dock = DockStyle.Fill;
			d.IsWebBrowserContextMenuEnabled = false;
			d.Location = new System.Drawing.Point(0, 0);
			d.MinimumSize = new System.Drawing.Size(20, 20);
			d.Name = "webviewSSO";
			d.Size = new System.Drawing.Size(784, 561);
			d.TabIndex = 0;
			d.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(a);
			base.AutoScaleDimensions = new SizeF(6f, 12f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(784, 561);
			base.Controls.Add(d);
			base.Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "SSOBrowser";
			base.StartPosition = FormStartPosition.CenterParent;
			Text = "圖書館單一登入";
			ResumeLayout(false);
		}
	}
}
