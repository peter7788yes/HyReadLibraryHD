using BookManagerModule;
using CACodec;
using ConfigureManagerModule;
using DataAccessObject;
using DownloadManagerModule;
using LocalFilesManagerModule;
using Network;
using SyncCenterModule;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;
using System.Xml;
using Utility;

namespace HyReadLibraryHD
{
	public class bookShelfDetailPopup : Window, IComponentConnector
	{
		private delegate void a(string A_0, Dictionary<string, string> A_1, List<string> A_2);

		[CompilerGenerated]
		private sealed class b
		{
			public DownloadProgressChangedEventArgs a;

			public bookShelfDetailPopup b;
		}

		[CompilerGenerated]
		private sealed class c
		{
			public string a;

			public b b;

			internal void c()
			{
				if (BookType.EPUB.Equals(b.a.booktype))
				{
					b.b.a7.Text = a;
				}
				else if (BookType.PHEJ.Equals(b.a.booktype))
				{
					b.b.av.Text = a;
				}
				else
				{
					b.b.a3.Text = a;
				}
			}
		}

		[CompilerGenerated]
		private sealed class d
		{
			public SchedulingStateChangedEventArgs a;

			public bookShelfDetailPopup b;

			internal void c()
			{
				if (BookType.EPUB.Equals(a.booktype))
				{
					b.a5.IsEnabled = true;
					b.a5.Content = b.r[0];
					b.a5.Visibility = Visibility.Visible;
					b.a6.Visibility = Visibility.Collapsed;
					b.a7.Text = "";
				}
				else if (BookType.PHEJ.Equals(a.booktype))
				{
					b.aq.IsEnabled = true;
					b.aq.Content = b.q[2];
					b.au.Visibility = Visibility.Collapsed;
					b.av.Text = "";
				}
				else
				{
					b.ay.IsEnabled = true;
					b.ay.Content = b.q[2];
					b.a2.Visibility = Visibility.Collapsed;
					b.a3.Text = "";
				}
			}
		}

		private List<ExtLibInfo> m_a = new List<ExtLibInfo>();

		private object m_b;

		private string m_c = "";

		private string m_d = "";

		public BookDetailPopUpCloseReason closeReason;

		private BookThumbnail m_e;

		private BookProvider m_f;

		public int trialPages;

		private string m_g = "";

		public ConfigurationManager configMng;

		private NetworkStatusCode m_h;

		private int m_i = 1;

		private string m_j = "";

		private HttpRequest m_k = new HttpRequest();

		private Dictionary<string, string> m_l;

		private Dictionary<string, string> m_m;

		private static Dictionary<string, string> m_n = new Dictionary<string, string>();

		private bool m_o;

		private string m_p;

		private List<TextBlock> q;

		private List<TextBlock> r;

		private Dictionary<string, string> s;

		internal Grid t;

		internal Image u;

		internal TextBlock v;

		internal TextBlock w;

		internal TextBlock x;

		internal TextBlock y;

		internal TextBlock z;

		internal TextBlock aa;

		internal TextBlock ab;

		internal StackPanel ac;

		internal TextBlock ad;

		internal StackPanel ae;

		internal TextBlock af;

		internal StackPanel ag;

		internal TextBlock ah;

		internal StackPanel ai;

		internal TextBlock aj;

		internal TextBlock ak;

		internal StackPanel al;

		internal TextBlock am;

		internal Grid an;

		internal Grid ao;

		internal TextBlock ap;

		internal RadioButton aq;

		internal TextBlock ar;

		internal RadioButton @as;

		internal TextBlock at;

		internal RadioButton au;

		internal TextBlock av;

		internal Grid aw;

		internal TextBlock ax;

		internal RadioButton ay;

		internal TextBlock az;

		internal RadioButton a0;

		internal TextBlock a1;

		internal RadioButton a2;

		internal TextBlock a3;

		internal Grid a4;

		internal RadioButton a5;

		internal RadioButton a6;

		internal TextBlock a7;

		internal Grid a8;

		internal RadioButton a9;

		internal RadioButton ba;

		internal TextBlock bb;

		internal Grid bc;

		internal RadioButton bd;

		internal RadioButton be;

		internal RadioButton bf;

		internal Grid bg;

		internal RadioButton bh;

		internal TextBlock bi;

		internal TextBlock bj;

		internal TagButton bk;

		internal TextBlock bl;

		private bool bm;

		public bookShelfDetailPopup(object selectedItem, string inWhichPage, string curVendorId)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("Accept-Language", Global.langName);
			this.m_l = dictionary;
			this.m_m = new Dictionary<string, string>();
			this.m_p = "";
			List<TextBlock> list = new List<TextBlock>();
			TextBlock textBlock = new TextBlock();
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			textBlock.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock.Foreground = Brushes.White;
			textBlock.Text = Global.bookManager.LanqMng.getLangString("iWantReserve");
			list.Add(textBlock);
			TextBlock textBlock2 = new TextBlock();
			textBlock2.VerticalAlignment = VerticalAlignment.Center;
			textBlock2.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock2.Foreground = Brushes.White;
			textBlock2.Text = Global.bookManager.LanqMng.getLangString("nowLending");
			list.Add(textBlock2);
			TextBlock textBlock3 = new TextBlock();
			textBlock3.VerticalAlignment = VerticalAlignment.Center;
			textBlock3.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock3.Foreground = Brushes.White;
			textBlock3.Text = Global.bookManager.LanqMng.getLangString("read");
			list.Add(textBlock3);
			TextBlock textBlock4 = new TextBlock();
			textBlock4.VerticalAlignment = VerticalAlignment.Center;
			textBlock4.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock4.Foreground = Brushes.White;
			textBlock4.Text = Global.bookManager.LanqMng.getLangString("readAndDownload");
			list.Add(textBlock4);
			TextBlock textBlock5 = new TextBlock();
			textBlock5.VerticalAlignment = VerticalAlignment.Center;
			textBlock5.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock5.Foreground = Brushes.White;
			textBlock5.Text = Global.bookManager.LanqMng.getLangString("pauseDownload");
			list.Add(textBlock5);
			TextBlock textBlock6 = new TextBlock();
			textBlock6.VerticalAlignment = VerticalAlignment.Center;
			textBlock6.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock6.Foreground = Brushes.White;
			textBlock6.Text = Global.bookManager.LanqMng.getLangString("continueDownload");
			list.Add(textBlock6);
			q = list;
			List<TextBlock> list2 = new List<TextBlock>();
			TextBlock textBlock7 = new TextBlock();
			textBlock7.VerticalAlignment = VerticalAlignment.Center;
			textBlock7.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock7.Foreground = Brushes.White;
			textBlock7.Text = Global.bookManager.LanqMng.getLangString("read");
			list2.Add(textBlock7);
			TextBlock textBlock8 = new TextBlock();
			textBlock8.VerticalAlignment = VerticalAlignment.Center;
			textBlock8.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock8.Foreground = Brushes.White;
			textBlock8.Text = Global.bookManager.LanqMng.getLangString("pauseDownload");
			list2.Add(textBlock8);
			TextBlock textBlock9 = new TextBlock();
			textBlock9.VerticalAlignment = VerticalAlignment.Center;
			textBlock9.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock9.Foreground = Brushes.White;
			textBlock9.Text = Global.bookManager.LanqMng.getLangString("continueDownload");
			list2.Add(textBlock9);
			r = list2;
			s = new Dictionary<string, string>();
			base._002Ector();
			Matrix transformToDevice = PresentationSource.FromVisual(Application.Current.MainWindow).CompositionTarget.TransformToDevice;
			double num = transformToDevice.M11 * 96.0;
			double m2 = transformToDevice.M22;
			if (((num == 96.0) ? 100 : ((num == 120.0) ? 125 : 150)) > 100)
			{
				base.WindowStartupLocation = WindowStartupLocation.Manual;
			}
			this.m_h = this.m_k.checkNetworkStatus();
			this.m_b = selectedItem;
			this.m_d = inWhichPage;
			this.m_c = curVendorId;
			InitializeComponent();
			base.Loaded += new RoutedEventHandler(a);
		}

		private void a(object A_0, EventArgs A_1)
		{
			base.Loaded -= new RoutedEventHandler(a);
			this.m_i = configMng.saveProxyMode;
			this.m_j = configMng.saveProxyHttpPort;
			this.m_k = new HttpRequest(this.m_i, this.m_j);
			this.m_e = (BookThumbnail)this.m_b;
			this.m_f = Global.bookManager.bookProviders[this.m_e.vendorId];
			if (!this.m_e.ownerName.Equals(""))
			{
				ah.Text = this.m_e.ownerName;
			}
			else
			{
				try
				{
					ah.Text = Global.bookManager.bookProviders[this.m_e.vendorId].name;
				}
				catch
				{
				}
			}
			int num = DateTime.Parse(this.m_e.loanDue).Subtract(DateTime.Now).Days + 1;
			if (this.m_e.vendorId.Equals("free"))
			{
				ag.Visibility = Visibility.Collapsed;
				ai.Visibility = Visibility.Collapsed;
			}
			else if (this.m_e.hyreadType == HyreadType.BOOK_STORE || this.m_e.userId == "hyread")
			{
				aj.Text = Global.bookManager.LanqMng.getLangString("expireUse");
				ag.Visibility = Visibility.Collapsed;
				if (num / 365 > 9)
				{
					ai.Visibility = Visibility.Collapsed;
				}
				bf.Visibility = Visibility.Collapsed;
			}
			if (this.m_e.renewDay < num)
			{
				bf.Visibility = Visibility.Collapsed;
			}
			this.m_p = this.m_e.keyDate + "000";
			setBookShelfUIValue();
			t.DataContext = this.m_e;
			base.Loaded -= new RoutedEventHandler(a);
		}

		public void setBookShelfUIValue()
		{
			string str = "";
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			if (Global.regPath.Equals("NCLReader"))
			{
				ag.Visibility = Visibility.Collapsed;
				al.Visibility = Visibility.Collapsed;
			}
			for (int i = 0; i < this.m_e.mediaType.Count; i++)
			{
				if (this.m_e.mediaType[i].Contains("application/epub+phej+zip") || this.m_e.mediaType[i].Contains("application/phej") || this.m_e.mediaType[i].Contains("application/pdf"))
				{
					flag = true;
				}
				else if (this.m_e.mediaType[i].Contains("application/epub+hej+zip") || this.m_e.mediaType[i].Contains("application/hej"))
				{
					flag2 = true;
				}
				if (this.m_e.mediaType[i].Contains("application/epub+zip") || this.m_e.mediaType[i].Equals("application/epub"))
				{
					flag3 = true;
				}
			}
			bool flag4 = false;
			bool flag5 = false;
			bool flag6 = false;
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			string sqlCommand = "SELECT  b.bookType, b.downloadState, b.downloadPercent from downloadstatus a, downloadstatusDetail b where a.sno in ( select ub.sno from userbook_metadata as ub where ub.vendorid = '" + this.m_e.vendorId + "'  and ub.colibid = '" + this.m_e.colibId + "'  and ub.account = '" + this.m_e.userId + "'  and ub.bookid = '" + this.m_e.bookID + "'  and ub.owner = '" + this.m_e.owner + "' )  and a.sno = b.sno ";
			QueryResult queryResult = Global.bookManager.sqlCommandQuery(sqlCommand);
			bd.Visibility = Visibility.Hidden;
			av.Text = "";
			a7.Text = "";
			a3.Text = "";
			while (queryResult.fetchRow())
			{
				int @int = queryResult.getInt("booktype");
				int int2 = queryResult.getInt("downloadPercent");
				if (int2 > 0 && int2 < 100)
				{
					this.m_o = true;
				}
				if (int2 == 100)
				{
					switch (queryResult.getInt("bookType"))
					{
					case 1:
						flag5 = true;
						break;
					case 2:
						flag4 = true;
						break;
					case 4:
						flag6 = true;
						break;
					}
				}
				else
				{
					switch (@int)
					{
					case 1:
						num2 = queryResult.getInt("downloadState");
						break;
					case 2:
						num = queryResult.getInt("downloadState");
						break;
					case 4:
						num3 = queryResult.getInt("downloadState");
						break;
					}
				}
				if (queryResult.getInt("downloadState") != 10)
				{
					bd.Visibility = Visibility.Visible;
				}
				if (int2 != 0 && int2 != 100)
				{
					if (@int == BookType.PHEJ.GetHashCode())
					{
						av.Text = int2 + " %";
					}
					if (@int == BookType.EPUB.GetHashCode())
					{
						a7.Text = int2 + " %";
					}
					if (@int == BookType.HEJ.GetHashCode())
					{
						a3.Text = int2 + " %";
					}
				}
			}
			aw.Visibility = Visibility.Collapsed;
			ao.Visibility = Visibility.Collapsed;
			a4.Visibility = Visibility.Hidden;
			if (flag)
			{
				str += "PDF";
				ao.Visibility = Visibility.Visible;
				if (flag4)
				{
					aq.IsEnabled = true;
					aq.Content = q[2];
					au.IsEnabled = false;
				}
				else
				{
					aq.IsEnabled = true;
					aq.Content = q[3];
					au.Visibility = Visibility.Visible;
					switch (num)
					{
					case 2:
						au.Content = q[4];
						break;
					case 3:
						au.Content = q[5];
						break;
					case 1:
						au.Content = q[4];
						break;
					}
				}
			}
			else if (flag2)
			{
				str += "JPEG";
				aw.Visibility = Visibility.Visible;
				if (flag5)
				{
					ay.IsEnabled = true;
					ay.Content = q[2];
					a2.IsEnabled = false;
				}
				else
				{
					ay.IsEnabled = true;
					ay.Content = q[3];
					a2.Visibility = Visibility.Visible;
					switch (num2)
					{
					case 2:
						a2.Content = q[4];
						break;
					case 3:
						a2.Content = q[5];
						break;
					case 1:
						a2.Content = q[4];
						break;
					}
				}
			}
			else
			{
				aw.Visibility = Visibility.Hidden;
			}
			if (flag3)
			{
				TextBlock textBlock = new TextBlock();
				textBlock.VerticalAlignment = VerticalAlignment.Center;
				textBlock.HorizontalAlignment = HorizontalAlignment.Center;
				textBlock.Foreground = Brushes.White;
				textBlock.Text = Global.bookManager.LanqMng.getLangString("iWantReserve");
				str += ((flag2 || flag) ? ", EPUB" : "EPUB");
				a4.Visibility = Visibility.Visible;
				if (flag6)
				{
					a5.IsEnabled = true;
					a5.Content = r[0];
					a6.IsEnabled = false;
				}
				else
				{
					a5.IsEnabled = false;
					a5.Visibility = Visibility.Collapsed;
					a6.Visibility = Visibility.Visible;
					switch (num3)
					{
					case 2:
						a6.Content = r[1];
						break;
					case 3:
						a6.Content = r[2];
						break;
					case 1:
						a6.Content = r[1];
						break;
					}
				}
			}
			if (this.m_e.hyreadType == HyreadType.BOOK_STORE || this.m_e.userId == "free" || this.m_e.userId == "hyread")
			{
				be.Visibility = Visibility.Collapsed;
			}
			else
			{
				be.Visibility = Visibility.Visible;
			}
			if (this.m_e.ecourseOpen.Equals("1"))
			{
				bg.Visibility = Visibility.Visible;
			}
			TagData tagData = Global.bookManager.getTagName(this.m_e.userId, this.m_e.vendorId, this.m_e.bookID);
			if (tagData == null)
			{
				tagData = a();
				Global.bookManager.saveTagData(false, tagData);
			}
			bk.tagData = tagData;
			if (!string.IsNullOrEmpty(tagData.tags))
			{
				string text = "";
				List<string> allTagCategories = Global.bookManager.getAllTagCategories();
				for (int j = 0; j < allTagCategories.Count; j++)
				{
					if (tagData.tags.Contains(allTagCategories[j]))
					{
						text = ((text == "") ? allTagCategories[j] : (text + "," + allTagCategories[j]));
					}
				}
				bl.Text = text;
				tagData.tags = text;
				Global.bookManager.saveTagData(true, tagData);
			}
			a(flag3, flag2, flag);
			t.DataContext = this.m_e;
			if (this.m_h == NetworkStatusCode.OK)
			{
				this.m_f.bookInfoFetched += new EventHandler<FetchBookInfoResultEventArgs>(a);
				this.m_f.fetchSimpleBookInfoAsync(this.m_e.bookID);
			}
			if (this.m_e.bookType.ToLower().Equals("video"))
			{
				w.Text = w.Text + " / " + Global.bookManager.LanqMng.getLangString("Director");
				y.Text = y.Text + " / " + Global.bookManager.LanqMng.getLangString("Publisher");
				aa.Text = aa.Text + " / " + Global.bookManager.LanqMng.getLangString("IssueDate");
				aj.Text = Global.bookManager.LanqMng.getLangString("playExpireDate");
				al.Visibility = Visibility.Collapsed;
				aq.Visibility = Visibility.Collapsed;
				ay.Visibility = Visibility.Collapsed;
				a0.IsEnabled = true;
				@as.IsEnabled = true;
				ap.Text = "Video : ";
				ax.Text = "Video : ";
			}
			bk.newTagChangedEvent += new NewTagNameEvent(c);
		}

		private void c(string A_0)
		{
			SyncManager<TagData> syncManager = new SyncManager<TagData>("https://cloudservice.ebook.hyread.com.tw/DataService/1/classes/", this.m_f.loginUserId, this.m_f.vendorId, "", 0, "STags", this.m_i, this.m_j);
			Global.syncCenter.addSyncConditions("STags", syncManager);
			if (!string.IsNullOrEmpty(A_0))
			{
				bl.Text = A_0;
			}
			else
			{
				bl.Text = Global.bookManager.LanqMng.getLangString("NoTagsExist");
			}
		}

		private TagData a()
		{
			DateTime value = new DateTime(1970, 1, 1);
			long num = DateTime.Now.ToUniversalTime().Subtract(value).Ticks / 10000000;
			TagData tagData = new TagData();
			tagData.objectId = "";
			tagData.createtime = num;
			tagData.updatetime = num;
			tagData.tags = "";
			tagData.status = "0";
			tagData.synctime = 0L;
			tagData.userid = this.m_e.userId;
			tagData.vendor = this.m_e.vendorId;
			tagData.bookid = this.m_e.bookID;
			return tagData;
		}

		private void a(object A_0, FetchBookInfoResultEventArgs A_1)
		{
			BookProvider obj = (BookProvider)A_0;
			obj.bookInfoFetched -= new EventHandler<FetchBookInfoResultEventArgs>(a);
			if (obj.vendorId.Equals(this.m_c))
			{
				Dictionary<string, string> bookInfoMeta = A_1.bookInfoMeta;
				List<string> mediaType = A_1.mediaType;
				b(this.m_c, bookInfoMeta, mediaType);
			}
		}

		private void b(string A_0, Dictionary<string, string> A_1, List<string> A_2)
		{
			a method = new a(a);
			base.Dispatcher.Invoke(method, A_0, A_1, A_2);
		}

		private void a(string A_0, Dictionary<string, string> A_1, List<string> A_2)
		{
			if (!Global.bookManager.bookProviders.ContainsKey(A_0) || this.m_e == null)
			{
				return;
			}
			getBookRightsAsync(this.m_e.bookID);
			getEcourseRateAsync();
			if (bookShelfDetailPopup.m_n.ContainsKey(this.m_e.bookID))
			{
				return;
			}
			string text = A_1.ContainsKey("editDate") ? A_1["editDate"] : "";
			bookShelfDetailPopup.m_n.Add(this.m_e.bookID, text);
			string text2 = A_1.ContainsKey("keyDate") ? A_1["keyDate"] : "";
			if (!text2.Equals("") && !text2.Equals(this.m_p))
			{
				string sqlCommand = "update userbook_metadata set keyDate=" + Convert.ToInt64(text2) / 1000 + " where bookId='" + this.m_e.bookID + "'  and account = '" + this.m_e.userId + "'  and owner = '" + this.m_e.owner + "'  ";
				Global.bookManager.sqlCommandNonQuery(sqlCommand);
				if (this.m_o)
				{
					MessageBox.Show(Global.bookManager.LanqMng.getLangString("keyDateChangeMsg"));
					closeReason = BookDetailPopUpCloseReason.DELBOOK;
					Close();
				}
			}
			if (this.m_g.Equals("") || !(text != "") || Convert.ToDateTime(text).Equals(Convert.ToDateTime(this.m_g)) || MessageBox.Show(Global.bookManager.LanqMng.getLangString("renewBookAlert"), Global.bookManager.LanqMng.getLangString("renewBook"), MessageBoxButton.YesNo) != MessageBoxResult.Yes)
			{
				return;
			}
			string text3 = A_1.ContainsKey("title") ? A_1["title"] : "";
			string text4 = A_1.ContainsKey("author") ? A_1["author"] : "";
			string text5 = A_1.ContainsKey("publisher") ? A_1["publisher"] : "";
			string text6 = A_1.ContainsKey("publishDate") ? A_1["publishDate"] : "";
			string text7 = "update book_metadata set title='" + text3 + "', author='" + text4 + "', ";
			text7 = text7 + " publisher='" + text5 + "', publishDate='" + text6 + "' where bookId='" + this.m_e.bookID + "' ";
			Global.bookManager.sqlCommandNonQuery(text7);
			text7 = "update userbook_metadata set lastCreateDate='" + text + "' ";
			text7 = text7 + " where bookId='" + this.m_e.bookID + "'  and colibid = '" + this.m_e.colibId + "'  and account = '" + this.m_e.userId + "'  and owner = '" + this.m_e.owner + "'  ";
			Global.bookManager.sqlCommandNonQuery(text7);
			text7 = "Delete from book_media_type where bookId='" + this.m_e.bookID + "' ";
			Global.bookManager.sqlCommandNonQuery(text7);
			List<string> list = new List<string>();
			foreach (string item in A_2)
			{
				list.Add(item);
				text7 = "Insert into book_media_type(bookId, media_type) values ('" + this.m_e.bookID + "', '" + item + "')";
				Global.bookManager.sqlCommandNonQuery(text7);
			}
			this.m_e.mediaType = list;
			closeReason = BookDetailPopUpCloseReason.DELBOOK;
			Close();
		}

		private void a(bool A_0, bool A_1, bool A_2)
		{
			string sqlCommand = "SELECT epub_filesize, hej_filesize, phej_filesize, expireDate, readTimes, LastCreateDate, canPrint  from userbook_metadata as a  where a.vendorid = '" + this.m_e.vendorId + "'  and a.colibid = '" + this.m_e.colibId + "'  and a.account = '" + this.m_e.userId + "'  and a.bookid = '" + this.m_e.bookID + "'  and a.owner = '" + this.m_e.owner + "' ";
			QueryResult queryResult = Global.bookManager.sqlCommandQuery(sqlCommand);
			if (queryResult.fetchRow())
			{
				CACodecTools cACodecTools = new CACodecTools();
				this.m_g = queryResult.getString("LastCreateDate");
				af.Text = queryResult.getInt("readTimes").ToString();
				string text = cACodecTools.stringDecode(queryResult.getString("expireDate"), true);
				if (text.Contains(" "))
				{
					text = text.Substring(0, text.IndexOf(" "));
				}
				ak.Text = text;
				float num = 0f;
				num = ((A_0 && queryResult.getInt("epub_filesize") > 0) ? ((float)queryResult.getInt("epub_filesize")) : num);
				num = ((A_1 && queryResult.getInt("hej_filesize") > 0) ? ((float)queryResult.getInt("hej_filesize")) : num);
				num = ((A_2 && queryResult.getInt("phej_filesize") > 0) ? ((float)queryResult.getInt("phej_filesize")) : num);
				float num2 = 1048576f;
				ad.Text = string.Format("{0:0.0 MB}", (num > 0f) ? (num / num2) : 0f);
			}
		}

		public void getBookRightsAsync(string bookId)
		{
			if (this.m_k.checkNetworkStatus() != 0)
			{
				bool flag = false;
				string sqlCommand = "SELECT bookRightsDRM FROM userbook_metadata  WHERE userbook_metadata.vendorid = '" + this.m_e.vendorId + "'  and userbook_metadata.colibid = '" + this.m_e.colibId + "'  and userbook_metadata.account = '" + this.m_e.userId + "'  and userbook_metadata.bookid = '" + this.m_e.bookID + "'  and userbook_metadata.owner = '" + this.m_e.owner + "' ";
				try
				{
					QueryResult queryResult = Global.bookManager.sqlCommandQuery(sqlCommand);
					if (queryResult.fetchRow())
					{
						new XMLTool();
						CACodecTools cACodecTools = new CACodecTools();
						string @string = queryResult.getString("bookRightsDRM");
						if (@string != null && @string != "")
						{
							XmlDocument xmlDocument = new XmlDocument();
							string xml = cACodecTools.stringDecode(@string, true);
							xmlDocument.LoadXml(xml);
							foreach (XmlNode item in xmlDocument.SelectNodes("/drm/functions"))
							{
								if (item.InnerText.Contains("canPrint"))
								{
									flag = true;
									break;
								}
							}
						}
					}
				}
				catch
				{
				}
				this.m_e.printRights = (flag ? "Yes" : "No");
			}
			else
			{
				string url = Global.bookManager.bookProviders[this.m_c].serviceBaseUrl + "/hdbook/bookinfo";
				XmlDocument xmlDocument2 = new XmlDocument();
				xmlDocument2.LoadXml("<body></body>");
				HyreadType hyreadType = Global.bookManager.bookProviders[this.m_c].hyreadType;
				a("hyreadType", hyreadType.GetHashCode().ToString(), xmlDocument2);
				a("colibId", "", xmlDocument2);
				a("bookId", bookId, xmlDocument2);
				a("merge", "1", xmlDocument2);
				HttpRequest httpRequest = new HttpRequest(this.m_i, this.m_j);
				httpRequest.xmlResponsed += new EventHandler<HttpResponseXMLEventArgs>(b);
				httpRequest.postXMLAndLoadXMLAsync(url, xmlDocument2.InnerXml);
			}
		}

		private void b(object A_0, HttpResponseXMLEventArgs A_1)
		{
			((HttpRequest)A_0).xmlResponsed -= new EventHandler<HttpResponseXMLEventArgs>(b);
			XmlDocument responseXML = A_1.responseXML;
			bool flag = false;
			if (responseXML != null)
			{
				string base64EncodedData = "";
				try
				{
					base64EncodedData = responseXML.SelectSingleNode("//drm/text()").Value;
				}
				catch
				{
				}
				if (base64EncodedData != "")
				{
					CACodecTools cACodecTools = new CACodecTools();
					string text = cACodecTools.Base64Decode(base64EncodedData);
					responseXML.LoadXml(text);
					foreach (XmlNode item in responseXML.SelectNodes("/drm/functions"))
					{
						if (item.InnerText.Contains("canPrint"))
						{
							flag = true;
							break;
						}
					}
					base64EncodedData = cACodecTools.stringEncode(text, true);
					string sqlCommand = "UPDATE userbook_metadata SET bookRightsDRM ='" + base64EncodedData + "', canPrint=" + flag + " WHERE userbook_metadata.vendorid = '" + this.m_e.vendorId + "'  and userbook_metadata.colibid = '" + this.m_e.colibId + "'  and userbook_metadata.account = '" + this.m_e.userId + "'  and userbook_metadata.bookid = '" + this.m_e.bookID + "'  and userbook_metadata.owner = '" + this.m_e.owner + "' ";
					try
					{
						Global.bookManager.sqlCommandNonQuery(sqlCommand);
					}
					catch
					{
					}
				}
			}
			this.m_e.printRights = (flag ? "Yes" : "No");
		}

		public void getEcourseRateAsync()
		{
			if (this.m_k.checkNetworkStatus() == NetworkStatusCode.OK)
			{
				string url = Global.bookManager.bookProviders[this.m_c].serviceBaseUrl + "/hdbook/ecoursescore";
				XmlDocument xmlDocument = new XmlDocument();
				xmlDocument.LoadXml("<body></body>");
				a("userId", this.m_e.userId, xmlDocument);
				a("bookId", this.m_e.bookID, xmlDocument);
				HttpRequest httpRequest = new HttpRequest(this.m_i, this.m_j);
				httpRequest.xmlResponsed += new EventHandler<HttpResponseXMLEventArgs>(a);
				httpRequest.postXMLAndLoadXMLAsync(url, xmlDocument.InnerXml);
			}
		}

		private void a(object A_0, HttpResponseXMLEventArgs A_1)
		{
			((HttpRequest)A_0).xmlResponsed -= new EventHandler<HttpResponseXMLEventArgs>(a);
			XmlDocument responseXML = A_1.responseXML;
			string str = Global.bookManager.LanqMng.getLangString("correctRate") + ":";
			string str2 = Global.bookManager.LanqMng.getLangString("coverRate") + ":";
			if (responseXML != null)
			{
				str = str + responseXML.SelectSingleNode("//correctRate/text()").Value + "%";
				str2 = str2 + responseXML.SelectSingleNode("//coverRate/text()").Value + "%";
				this.m_e.correctRate = str;
				this.m_e.coverRate = str2;
			}
		}

		private string a(SchedulingState A_0)
		{
			switch (A_0)
			{
			case SchedulingState.DOWNLOADING:
				return Global.bookManager.LanqMng.getLangString("downloading");
			case SchedulingState.FAILED:
				return Global.bookManager.LanqMng.getLangString("downloadFailed");
			case SchedulingState.FINISHED:
				return Global.bookManager.LanqMng.getLangString("downloaded");
			case SchedulingState.PAUSED:
				return Global.bookManager.LanqMng.getLangString("pauseDownload");
			case SchedulingState.SCHEDULING:
				return Global.bookManager.LanqMng.getLangString("scheduling");
			case SchedulingState.UNKNOWN:
				return Global.bookManager.LanqMng.getLangString("download");
			case SchedulingState.WAITING:
				return Global.bookManager.LanqMng.getLangString("waitDownload");
			default:
				return "";
			}
		}

		private int b(string A_0)
		{
			try
			{
				if (!A_0.Equals(""))
				{
					return Convert.ToInt32(A_0);
				}
			}
			catch
			{
			}
			return 0;
		}

		private void a(ref decimal A_0, string A_1)
		{
			try
			{
				if (!A_1.Equals(""))
				{
					A_0 = Convert.ToDecimal(A_1);
				}
			}
			catch
			{
			}
		}

		private void a(ref int A_0, string A_1)
		{
			try
			{
				if (!A_1.Equals(""))
				{
					A_0 = Convert.ToInt32(A_1);
				}
			}
			catch
			{
			}
		}

		private void a(ref double A_0, string A_1)
		{
			try
			{
				if (!A_1.Equals(""))
				{
					A_0 = Convert.ToDouble(A_1);
				}
			}
			catch
			{
			}
		}

		private string a(XmlNode A_0)
		{
			if (A_0 == null)
			{
				return "";
			}
			if (A_0.HasChildNodes)
			{
				return A_0.InnerText;
			}
			return "";
		}

		private static void a(string A_0, string A_1, XmlDocument A_2)
		{
			XmlElement newChild = A_2.CreateElement(A_0);
			XmlText newChild2 = A_2.CreateTextNode(A_1);
			A_2.DocumentElement.AppendChild(newChild);
			A_2.DocumentElement.LastChild.AppendChild(newChild2);
		}

		private void p(object A_0, RoutedEventArgs A_1)
		{
			closeReason = BookDetailPopUpCloseReason.NONE;
			Close();
		}

		private void a(BookType A_0, bool A_1, bool A_2)
		{
			if (this.m_h == NetworkStatusCode.OK)
			{
				BookThumbnail bookThumbnail = (BookThumbnail)this.m_b;
				string serviceBaseUrl = this.m_f.serviceBaseUrl;
				string contentServer = bookThumbnail.contentServer.Equals("") ? serviceBaseUrl : bookThumbnail.contentServer;
				Global.bookManager.startOrResumeDownload(bookThumbnail.assetUuid, bookThumbnail.s3Url, contentServer, serviceBaseUrl, this.m_f.vendorId, this.m_f.loginColibId, bookThumbnail.userId, bookThumbnail.bookID, A_0.GetHashCode(), A_2, bookThumbnail.owner, A_1, trialPages);
			}
		}

		private void o(object A_0, RoutedEventArgs A_1)
		{
			this.m_h = this.m_k.checkNetworkStatus();
			if (this.m_h != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetCannotDownload"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
			}
			a(BookType.PHEJ, false, false);
			closeReason = BookDetailPopUpCloseReason.DOWNLOAD;
			Close();
		}

		private void n(object A_0, RoutedEventArgs A_1)
		{
			this.m_h = this.m_k.checkNetworkStatus();
			if (this.m_h != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetCannotDownload"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
			}
			a(BookType.HEJ, false, false);
			closeReason = BookDetailPopUpCloseReason.DOWNLOAD;
			Close();
		}

		private bool a(int A_0)
		{
			string userBookPath = new LocalFilesManager(Global.localDataPath, this.m_e.vendorId, this.m_e.colibId, this.m_e.userId).getUserBookPath(this.m_e.bookID, A_0, this.m_e.owner);
			bool flag = File.Exists(userBookPath + "\\book.xml");
			bool flag2 = File.Exists(userBookPath + "\\HYWEB\\thumbs\\thumbs_ok");
			bool flag3 = File.Exists(userBookPath + "\\HYWEB\\infos_ok");
			if (!flag || !flag2 || !flag3)
			{
				return false;
			}
			return true;
		}

		private void m(object A_0, RoutedEventArgs A_1)
		{
			BookThumbnail bookThumbnail = (BookThumbnail)this.m_b;
			if (!a(1))
			{
				this.m_h = this.m_k.checkNetworkStatus();
				if (this.m_h != 0)
				{
					MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetCannotDownload"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
					Close();
					return;
				}
			}
			a(BookType.HEJ, true, false);
			closeReason = BookDetailPopUpCloseReason.READHEJ;
			Close();
		}

		private void l(object A_0, RoutedEventArgs A_1)
		{
			BookThumbnail bookThumbnail = (BookThumbnail)this.m_b;
			if (!a(2))
			{
				this.m_h = this.m_k.checkNetworkStatus();
				if (this.m_h != 0)
				{
					MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetCannotDownload"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
					Close();
					return;
				}
			}
			a(BookType.PHEJ, true, false);
			closeReason = BookDetailPopUpCloseReason.READPHEJ;
			Close();
		}

		private void k(object A_0, RoutedEventArgs A_1)
		{
			this.m_h = this.m_k.checkNetworkStatus();
			if (this.m_h != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetCannotDownload"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
				Close();
			}
			else
			{
				a(BookType.EPUB, false, false);
				closeReason = BookDetailPopUpCloseReason.DOWNLOAD;
				Close();
			}
		}

		private void j(object A_0, RoutedEventArgs A_1)
		{
			closeReason = BookDetailPopUpCloseReason.READEPUB;
			Close();
		}

		private void i(object A_0, RoutedEventArgs A_1)
		{
			a(BookType.HEJ, true, true);
			closeReason = BookDetailPopUpCloseReason.TRYREADHEJ;
			Close();
		}

		private void h(object A_0, RoutedEventArgs A_1)
		{
			a(BookType.PHEJ, true, true);
			closeReason = BookDetailPopUpCloseReason.TRYREADPHEJ;
			Close();
		}

		private void g(object A_0, RoutedEventArgs A_1)
		{
			closeReason = BookDetailPopUpCloseReason.TRYREADEPUB;
			Close();
		}

		private void f(object A_0, RoutedEventArgs A_1)
		{
			if (MessageBox.Show(Global.bookManager.LanqMng.getLangString("readAgainReDownload"), Global.bookManager.LanqMng.getLangString("areEmptyFile"), MessageBoxButton.YesNo) == MessageBoxResult.Yes)
			{
				closeReason = BookDetailPopUpCloseReason.DELBOOK;
			}
			Close();
		}

		private void e(object A_0, RoutedEventArgs A_1)
		{
			this.m_h = this.m_k.checkNetworkStatus();
			if (this.m_h != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("offlineCannotReturn"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
				return;
			}
			base.Cursor = Cursors.Wait;
			string serviceBaseUrl = this.m_f.serviceBaseUrl;
			HyreadType hyreadType = this.m_f.hyreadType;
			if (hyreadType.Equals(HyreadType.LIBRARY_CONSORTIUM))
			{
				serviceBaseUrl = Global.bookManager.bookProviders[this.m_f.loginColibId].serviceBaseUrl;
			}
			string url = serviceBaseUrl + "/book/return/" + this.m_e.bookID;
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml("<body></body>");
			a("account", this.m_e.userId, xmlDocument);
			a("hyreadType", Convert.ToString(this.m_e.hyreadType.GetHashCode()), xmlDocument);
			a("colibId", this.m_c, xmlDocument);
			if (this.m_e.hyreadType == HyreadType.LIBRARY_CONSORTIUM)
			{
				a("ownerCode", this.m_e.owner, xmlDocument);
			}
			else
			{
				a("ownerCode", this.m_e.colibId, xmlDocument);
			}
			if (Global.regPath.Equals("NCLReader"))
			{
				a("password", this.m_f.loginUserPassword, xmlDocument);
			}
			string userP12FullPath = new LocalFilesManager(Global.localDataPath, this.m_e.vendorId, this.m_e.colibId, this.m_e.userId).getUserP12FullPath();
			CACodecTools cACodecTools = new CACodecTools();
			s = new Dictionary<string, string>();
			if (!Global.regPath.Equals("NCLReader") && !this.m_e.hyreadType.Equals(HyreadType.LIBRARY_CONSORTIUM))
			{
				s = cACodecTools.getDigestHeaders(userP12FullPath, this.m_e.vendorId, this.m_e.colibId, this.m_e.userId, this.m_f.loginUserPassword, xmlDocument.InnerXml);
			}
			s.Add("Accept-Language", Global.langName);
			string innerText = this.m_k.postXMLAndLoadXML(url, xmlDocument, s).InnerText;
			Global.bookManager.returnBook(this.m_e.vendorId, this.m_e.colibId, this.m_e.userId, this.m_e.bookID, this.m_e.owner);
			closeReason = BookDetailPopUpCloseReason.RETURNBOOK;
			base.Cursor = Cursors.None;
			Close();
		}

		private void a(object A_0, CancelEventArgs A_1)
		{
			bk.newTagChangedEvent -= new NewTagNameEvent(c);
			BindingOperations.ClearAllBindings(this);
		}

		public void downloadProgressChange(object sender, DownloadProgressChangedEventArgs progressArgs)
		{
			b b = new b();
			b.a = progressArgs;
			b.b = this;
			if (this.m_e != null && this.m_e.owner.Equals(b.a.ownerCode) && this.m_e.bookID.Equals(b.a.bookId))
			{
				c c = new c();
				c.b = b;
				c.a = (int)c.b.a.newProgress + "%";
				SchedulingState schedulingState = c.b.a.schedulingState;
				int num = 2;
				base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new k(c.c));
			}
		}

		public void scheculeStateChange(object sender, SchedulingStateChangedEventArgs stateArgs)
		{
			d d = new d();
			d.a = stateArgs;
			d.b = this;
			if (this.m_e != null && this.m_e.owner.Equals(d.a.ownerCode) && this.m_e.bookID.Equals(d.a.bookId) && d.a.newSchedulingState == SchedulingState.FINISHED)
			{
				this.m_e.downloadStateStr = "";
				base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new k(d.c));
			}
		}

		private void d(object A_0, RoutedEventArgs A_1)
		{
			string text = "";
			string text2 = "";
			if (!Global.localDataPath.Equals("HyReadCN"))
			{
				text = "http://ebook.hyread.com.tw/service/authCenter.jsp?data=";
				text2 = a("http://ebook.hyread.com.tw/service/getServerTime.jsp");
			}
			else
			{
				text = "http://ebook.hyread.com.cn/service/authCenter.jsp?data=";
				text2 = a("http://ebook.hyread.com.cn/service/getServerTime.jsp");
			}
			string str = "<request>";
			str += "<action>ecourseOpen</action>";
			str = str + "<time><![CDATA[" + text2 + "]]></time>";
			str = str + "<unit>" + this.m_e.vendorId + "</unit>";
			str = str + "<userid><![CDATA[" + this.m_e.userId + "]]></userid>";
			str = str + "<brn>" + this.m_e.bookID + "</brn>";
			str += "</request>";
			byte[] bytes = Encoding.Default.GetBytes("hyweb101S00ebook");
			string str2 = Uri.EscapeDataString(new CACodecTools().stringEncode(str, bytes, true));
			text += str2;
			Process.Start(text);
			Close();
		}

		private string a(string A_0)
		{
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml("<body></body>");
			return this.m_k.postXMLAndLoadXML(A_0, xmlDocument).InnerText;
		}

		private void c(object A_0, RoutedEventArgs A_1)
		{
			this.m_h = this.m_k.checkNetworkStatus();
			if (this.m_h != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("offlineCannotRenew"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
				base.Cursor = Cursors.None;
				Close();
				return;
			}
			base.Cursor = Cursors.Wait;
			string url = this.m_f.serviceBaseUrl + "/hdbook/renewbook/";
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml("<body></body>");
			a("lendId", this.m_e.lendId, xmlDocument);
			XmlDocument xmlDocument2 = this.m_k.postXMLAndLoadXML(url, xmlDocument, this.m_l);
			if (xmlDocument2 != null)
			{
				string value = xmlDocument2.SelectSingleNode("//result/text()").Value;
				string value2 = xmlDocument2.SelectSingleNode("//message/text()").Value;
				if (value != null && value.ToUpper().Equals("TRUE"))
				{
					string value3 = xmlDocument2.SelectSingleNode("//expireDate/text()").Value;
					string sqlCommand = "update userbook_matadata set expireDate='" + value3 + "'  where bookId='" + this.m_e.bookID + "'  and vendorId='" + this.m_e.lendId + "'  and vendorId='" + this.m_e.colibId + "'  and account ='" + this.m_e.userId + "' ";
					Global.bookManager.sqlCommandNonQuery(sqlCommand);
					closeReason = BookDetailPopUpCloseReason.RENEWDAY;
					MessageBox.Show(value2);
				}
				else
				{
					closeReason = BookDetailPopUpCloseReason.NONE;
					MessageBox.Show(value2);
				}
			}
			else
			{
				closeReason = BookDetailPopUpCloseReason.NONE;
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("netAnomaly"));
			}
			base.Cursor = Cursors.None;
			Close();
		}

		private void b(object A_0, RoutedEventArgs A_1)
		{
		}

		private void a(object A_0, RoutedEventArgs A_1)
		{
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!bm)
			{
				bm = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/bookshelfdetailpopup.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate a(Type A_0, string A_1)
		{
			return Delegate.CreateDelegate(A_0, this, A_1);
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((bookShelfDetailPopup)target).Closing += new CancelEventHandler(a);
				break;
			case 2:
				t = (Grid)target;
				break;
			case 3:
				u = (Image)target;
				break;
			case 4:
				v = (TextBlock)target;
				break;
			case 5:
				w = (TextBlock)target;
				break;
			case 6:
				x = (TextBlock)target;
				break;
			case 7:
				y = (TextBlock)target;
				break;
			case 8:
				z = (TextBlock)target;
				break;
			case 9:
				aa = (TextBlock)target;
				break;
			case 10:
				ab = (TextBlock)target;
				break;
			case 11:
				ac = (StackPanel)target;
				break;
			case 12:
				ad = (TextBlock)target;
				break;
			case 13:
				ae = (StackPanel)target;
				break;
			case 14:
				af = (TextBlock)target;
				break;
			case 15:
				ag = (StackPanel)target;
				break;
			case 16:
				ah = (TextBlock)target;
				break;
			case 17:
				ai = (StackPanel)target;
				break;
			case 18:
				aj = (TextBlock)target;
				break;
			case 19:
				ak = (TextBlock)target;
				break;
			case 20:
				al = (StackPanel)target;
				break;
			case 21:
				am = (TextBlock)target;
				break;
			case 22:
				an = (Grid)target;
				break;
			case 23:
				ao = (Grid)target;
				break;
			case 24:
				ap = (TextBlock)target;
				break;
			case 25:
				aq = (RadioButton)target;
				aq.Click += new RoutedEventHandler(l);
				break;
			case 26:
				ar = (TextBlock)target;
				break;
			case 27:
				@as = (RadioButton)target;
				@as.Click += new RoutedEventHandler(l);
				break;
			case 28:
				at = (TextBlock)target;
				break;
			case 29:
				au = (RadioButton)target;
				au.Click += new RoutedEventHandler(o);
				break;
			case 30:
				av = (TextBlock)target;
				break;
			case 31:
				aw = (Grid)target;
				break;
			case 32:
				ax = (TextBlock)target;
				break;
			case 33:
				ay = (RadioButton)target;
				ay.Click += new RoutedEventHandler(m);
				break;
			case 34:
				az = (TextBlock)target;
				break;
			case 35:
				a0 = (RadioButton)target;
				a0.Click += new RoutedEventHandler(m);
				break;
			case 36:
				a1 = (TextBlock)target;
				break;
			case 37:
				a2 = (RadioButton)target;
				a2.Click += new RoutedEventHandler(n);
				break;
			case 38:
				a3 = (TextBlock)target;
				break;
			case 39:
				a4 = (Grid)target;
				break;
			case 40:
				a5 = (RadioButton)target;
				a5.Click += new RoutedEventHandler(j);
				break;
			case 41:
				a6 = (RadioButton)target;
				a6.Click += new RoutedEventHandler(k);
				break;
			case 42:
				a7 = (TextBlock)target;
				break;
			case 43:
				a8 = (Grid)target;
				break;
			case 44:
				a9 = (RadioButton)target;
				a9.Click += new RoutedEventHandler(m);
				break;
			case 45:
				ba = (RadioButton)target;
				ba.Click += new RoutedEventHandler(n);
				break;
			case 46:
				bb = (TextBlock)target;
				break;
			case 47:
				bc = (Grid)target;
				break;
			case 48:
				bd = (RadioButton)target;
				bd.Click += new RoutedEventHandler(f);
				break;
			case 49:
				be = (RadioButton)target;
				be.Click += new RoutedEventHandler(e);
				break;
			case 50:
				bf = (RadioButton)target;
				bf.Click += new RoutedEventHandler(c);
				break;
			case 51:
				bg = (Grid)target;
				break;
			case 52:
				bh = (RadioButton)target;
				bh.Click += new RoutedEventHandler(d);
				break;
			case 53:
				bi = (TextBlock)target;
				break;
			case 54:
				bj = (TextBlock)target;
				break;
			case 55:
				bk = (TagButton)target;
				break;
			case 56:
				bl = (TextBlock)target;
				break;
			default:
				bm = true;
				break;
			}
		}
	}
}
