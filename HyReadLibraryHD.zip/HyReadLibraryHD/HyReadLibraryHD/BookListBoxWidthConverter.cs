using System;
using System.Globalization;
using System.Windows.Data;

namespace HyReadLibraryHD
{
	public class BookListBoxWidthConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			if (targetType != typeof(double))
			{
				throw new InvalidOperationException("it is not a double");
			}
			double num = double.Parse(value.ToString());
			int num2 = int.Parse(parameter.ToString());
			if (num.Equals(0.0))
			{
				return 0;
			}
			return num / (double)num2 - 17.5;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return null;
		}
	}
}
