using BookManagerModule;
using CACodec;
using Microsoft.Win32;
using ReadPageModule;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using System.Xml;

namespace HyReadLibraryHD
{
	[ComVisible(true)]
	[PermissionSet(SecurityAction.Demand, Name = "FullTrust")]
	public class HlsPlayer : Form
	{
		[CompilerGenerated]
		private EventHandler<DataRequestEventArgs> m_a;

		private HttpListener m_b;

		private volatile bool m_c = true;

		private IAsyncResult m_d;

		private Thread e;

		private string f = "";

		private string g = "";

		private string h = "";

		private string i = "";

		private string j = "";

		private string k = "";

		private int l;

		private int m;

		private long n;

		private byte[] o;

		private static CACodecTools p = new CACodecTools();

		private System.Windows.Forms.Timer q = new System.Windows.Forms.Timer();

		private bool r;

		private string s = "";

		private IContainer t;

		private WebBrowser u;

		public event EventHandler<DataRequestEventArgs> HlsPlayerDataRequest
		{
			[CompilerGenerated]
			add
			{
				EventHandler<DataRequestEventArgs> eventHandler = this.m_a;
				EventHandler<DataRequestEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<DataRequestEventArgs> value2 = (EventHandler<DataRequestEventArgs>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange(ref this.m_a, value2, eventHandler2);
				}
				while ((object)eventHandler != eventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				EventHandler<DataRequestEventArgs> eventHandler = this.m_a;
				EventHandler<DataRequestEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<DataRequestEventArgs> value2 = (EventHandler<DataRequestEventArgs>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange(ref this.m_a, value2, eventHandler2);
				}
				while ((object)eventHandler != eventHandler2);
			}
		}

		public HlsPlayer(string title, BookThumbnail bt, string BookPath, string sourcePath, int bookSno, long hlsLastTime)
		{
			a();
			Text = title;
			j = BookPath;
			k = sourcePath;
			m = bookSno;
			n = hlsLastTime;
			h = bt.bookID;
			i = bt.userId;
			f = bt.vendorId;
			g = bt.colibId;
			o = d();
			if (!b())
			{
				if (System.Windows.MessageBox.Show(Global.bookManager.LanqMng.getLangString("grantUrlaclMsg"), Global.bookManager.LanqMng.getLangString("grantUrlacl"), MessageBoxButton.YesNo, MessageBoxImage.Exclamation).Equals(MessageBoxResult.Yes))
				{
					c();
				}
				else
				{
					r = true;
				}
			}
			if (!r)
			{
				e = new Thread(new ParameterizedThreadStart(SimpleListenerExample));
				e.Start(new string[1]
				{
					"http://+:9000/"
				});
				Thread.Sleep(1);
			}
		}

		private byte[] d()
		{
			byte[] array = new byte[1];
			string encryptionFile = j + "\\HYWEB\\encryption.xml";
			string str = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\" + Global.localDataPath;
			string text = Global.bookManager.bookProviders[f].loginUserPassword;
			if (f.Equals("free"))
			{
				text = "free";
			}
			if (Global.regPath.Equals("HyReadCN") && text == "free")
			{
				text = "MMF2wqY8fNDXT";
			}
			str = ((l <= 0) ? (str + "\\" + p.CreateMD5Hash(f + g + this.i).ToUpper()) : (str + "\\" + p.CreateMD5Hash("tryreadtryreadtryread").ToUpper()));
			string cipherValue = getCipherValue(encryptionFile);
			string p12Path = str + "\\HyHDWL.ps2";
			if (text == null || text == "")
			{
				try
				{
					text = Global.bookManager.bookProviders[g].loginUserPassword;
				}
				catch
				{
					text = "";
				}
			}
			text = p.CreateMD5Hash(text);
			text += ":";
			array = p.encryptStringDecode2ByteArray(cipherValue, p12Path, text, true);
			string str2 = "";
			byte[] array2 = array;
			foreach (byte b in array2)
			{
				str2 += string.Format("0x{0:x2},", b);
			}
			return array;
		}

		public string getCipherValue(string encryptionFile)
		{
			string result = "";
			if (!File.Exists(encryptionFile))
			{
				return result;
			}
			XmlDocument xmlDocument = new XmlDocument();
			try
			{
				xmlDocument.Load(encryptionFile);
				result = xmlDocument.GetElementsByTagName("enc:CipherValue")[0].InnerText;
				return result;
			}
			catch (Exception ex)
			{
				Console.WriteLine("getCipherValue error=" + ex.ToString());
				return result;
			}
		}

		private void c()
		{
			string arguments = string.Format("http add urlacl url={0} user=everyone", "http://+:9000/");
			ProcessStartInfo processStartInfo = new ProcessStartInfo("netsh", arguments);
			processStartInfo.Verb = "runas";
			processStartInfo.CreateNoWindow = true;
			processStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			processStartInfo.UseShellExecute = true;
			Process.Start(processStartInfo).WaitForExit();
		}

		private bool b()
		{
			if (Registry.GetValue("HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\HTTP\\Parameters\\UrlAclInfo", "http://+:9000/", "").Equals(""))
			{
				return false;
			}
			return true;
		}

		private void b(object A_0, EventArgs A_1)
		{
			if (r)
			{
				Close();
				return;
			}
			u.ScriptErrorsSuppressed = true;
			u.AllowWebBrowserDrop = false;
			u.IsWebBrowserContextMenuEnabled = false;
			u.WebBrowserShortcutsEnabled = false;
			u.ObjectForScripting = this;
			if (n > 0)
			{
				if (!System.Windows.MessageBox.Show(Global.bookManager.LanqMng.getLangString("resetHlsPlayTimeMsg"), Global.bookManager.LanqMng.getLangString("resetHlsPlayTime"), MessageBoxButton.YesNo, MessageBoxImage.Exclamation).Equals(MessageBoxResult.Yes))
				{
					n = 0L;
				}
				q.Interval = 1000;
				q.Tick += new EventHandler(a);
				q.Start();
			}
			u.Navigate("http://127.0.0.1:9000/flashls/index.html");
		}

		private void a(object A_0, EventArgs A_1)
		{
			if (u.Document != null)
			{
				q.Stop();
				q.Tick -= new EventHandler(a);
				u.Document.InvokeScript("seekToSpecificTime", new object[1]
				{
					n
				});
			}
		}

		public void SimpleListenerExample(object prefixes)
		{
			if (!HttpListener.IsSupported)
			{
				Console.WriteLine("Windows XP SP2 or Server 2003 is required to use the HttpListener class.");
				return;
			}
			string[] array = prefixes as string[];
			if (prefixes == null || array.Length == 0)
			{
				throw new ArgumentException("prefixes");
			}
			this.m_b = new HttpListener();
			this.m_b.Prefixes.Add(array[0]);
			this.m_b.Start();
			Console.WriteLine("Listening...");
			while (this.m_c)
			{
				this.m_d = this.m_b.BeginGetContext(new AsyncCallback(ListenerCallback), this.m_b);
				this.m_d.AsyncWaitHandle.WaitOne();
			}
			this.m_b.Stop();
			this.m_b.Close();
		}

		public void ListenerCallback(IAsyncResult result)
		{
			IDictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary[".ico"] = "image/x-icon";
			dictionary[".html"] = "text/html";
			dictionary[".css"] = "text/css";
			dictionary[".js"] = "application/javascript";
			dictionary[".png"] = "image/png";
			dictionary[".jpeg"] = "image/jpeg";
			dictionary[".mp3"] = "audio/mpeg3";
			dictionary[".mp4"] = "vidio/mpeg";
			dictionary[".m3u8"] = "application/x-mpegURL";
			dictionary[".ts"] = "video/MP2T";
			dictionary[".key"] = "hyweb/key";
			dictionary[".swf"] = "application/x-shockwave-flash";
			HttpListener httpListener = (HttpListener)result.AsyncState;
			HttpListenerContext httpListenerContext;
			try
			{
				httpListenerContext = httpListener.EndGetContext(result);
			}
			catch (Exception ex)
			{
				Console.WriteLine("e=" + ex.Message);
				return;
			}
			HttpListenerRequest request = httpListenerContext.Request;
			NameValueCollection headers = request.Headers;
			string rawUrl = request.RawUrl;
			dictionary.ContainsKey(Path.GetExtension(rawUrl));
			string text2 = headers["Range"];
			string text = "." + rawUrl;
			HttpListenerResponse response = httpListenerContext.Response;
			StreamWriter streamWriter = new StreamWriter(new BufferedStream(response.OutputStream));
			if (Path.GetExtension(rawUrl) == ".m3u8")
			{
				text = j + "\\HYWEB\\" + k;
			}
			else if (Path.GetExtension(rawUrl) == ".ts" || Path.GetExtension(rawUrl) == ".key")
			{
				text = j + "\\HYWEB" + rawUrl;
			}
			Console.WriteLine("mediaFilename: {0}", text);
			if (!File.Exists(text))
			{
				if (this.m_a != null)
				{
					string filename = rawUrl.Substring(1, rawUrl.Length - 1);
					this.m_a(this, new DataRequestEventArgs(h, i, filename));
				}
				response.StatusCode = 404;
				response.KeepAlive = false;
				streamWriter.Flush();
				streamWriter.Close();
			}
			else if (Path.GetExtension(rawUrl) == ".m3u8" || Path.GetExtension(rawUrl) == ".ts" || Path.GetExtension(rawUrl) == ".key")
			{
				string[] array = rawUrl.Split('/');
				int length = array.GetLength(0);
				string extension = Path.GetExtension(array[length - 1]);
				if (Path.GetExtension(rawUrl) == ".key" && new FileInfo(text).Length < 32)
				{
					s = "AES/ECB/NoPadding";
				}
				using (Stream stream = (Path.GetExtension(rawUrl) == ".key") ? ((Stream)p.fileAESDecodeMode(text, o, false, s)) : ((Stream)new FileStream(text, FileMode.Open)))
				{
					int num = -1;
					int result2 = -1;
					if (headers["Range"] != null)
					{
						string[] array2 = headers["Range"].ToString().Replace("bytes=", "").Split('-');
						num = int.Parse(array2[0]);
						if (array2[1].Trim().Length > 0)
						{
							int.TryParse(array2[1], out result2);
						}
						if (result2 == -1)
						{
							result2 = (int)stream.Length;
						}
					}
					else
					{
						num = 0;
						result2 = (int)stream.Length;
					}
					byte[] array3 = new byte[result2 - num];
					stream.Position = num;
					stream.Read(array3, 0, result2 - num);
					stream.Flush();
					stream.Close();
					int num2 = num + array3.Length;
					try
					{
						response.StatusCode = 206;
						response.ContentType = dictionary[extension];
						response.AddHeader("Accept-Ranges", "bytes");
						response.AddHeader("Content-Range", string.Format("bytes {0}-{1}/{2}", num, num2 - 1, num2));
						response.KeepAlive = false;
						response.ContentLength64 = array3.Length;
						streamWriter.BaseStream.Write(array3, 0, array3.Length);
						streamWriter.Flush();
						streamWriter.Close();
					}
					catch (Exception ex2)
					{
						Console.WriteLine(ex2.Message);
					}
				}
			}
			else
			{
				string[] array4 = rawUrl.Split('/');
				int length2 = array4.GetLength(0);
				string extension2 = Path.GetExtension(array4[length2 - 1]);
				byte[] array5 = File.ReadAllBytes("./" + rawUrl);
				try
				{
					response.StatusCode = 200;
					response.ContentType = dictionary[extension2];
					response.KeepAlive = false;
					response.ContentLength64 = array5.Length;
					streamWriter.BaseStream.Write(array5, 0, array5.Length);
					streamWriter.Flush();
					streamWriter.Close();
				}
				catch (Exception ex3)
				{
					Console.WriteLine(ex3.Message);
				}
			}
		}

		public void getCurrentPlayTime(double playTime)
		{
			if (playTime > 3.0)
			{
				playTime -= 3.0;
			}
			string sqlCommand = "update userbook_metadata set hlsLastTime = " + playTime + " Where Sno= " + m;
			Global.bookManager.sqlCommandNonQuery(sqlCommand);
		}

		private void a(object A_0, FormClosingEventArgs A_1)
		{
			if (!r)
			{
				try
				{
					u.Document.InvokeScript("getCurrentPlayTime", new object[0]);
					this.m_c = false;
					this.m_d.AsyncWaitHandle.Close();
					e.Abort();
					this.m_b.Stop();
					this.m_b.Close();
				}
				catch
				{
				}
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && t != null)
			{
				t.Dispose();
			}
			base.Dispose(disposing);
		}

		private void a()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(HlsPlayer));
			u = new WebBrowser();
			SuspendLayout();
			u.Dock = DockStyle.Fill;
			u.Location = new System.Drawing.Point(0, 0);
			u.MinimumSize = new System.Drawing.Size(20, 20);
			u.Name = "webBrowser1";
			u.Size = new System.Drawing.Size(593, 469);
			u.TabIndex = 0;
			base.AutoScaleDimensions = new SizeF(6f, 12f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new System.Drawing.Size(593, 469);
			base.Controls.Add(u);
			base.FormBorderStyle = FormBorderStyle.FixedToolWindow;
			base.Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
			base.MinimizeBox = false;
			base.Name = "HlsPlayer";
			Text = "Media Player";
			base.WindowState = FormWindowState.Maximized;
			base.FormClosing += new FormClosingEventHandler(a);
			base.Load += new EventHandler(b);
			ResumeLayout(false);
		}
	}
}
