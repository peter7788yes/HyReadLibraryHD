using System.Runtime.CompilerServices;

namespace HyReadLibraryHD
{
	public class ExtLib
	{
		[CompilerGenerated]
		private string a;

		[CompilerGenerated]
		private string b;

		[CompilerGenerated]
		private int c;

		[CompilerGenerated]
		private string d;

		public string vendorId
		{
			[CompilerGenerated]
			get
			{
				return a;
			}
			[CompilerGenerated]
			set
			{
				a = value;
			}
		}

		public string vendorName
		{
			[CompilerGenerated]
			get
			{
				return b;
			}
			[CompilerGenerated]
			set
			{
				b = value;
			}
		}

		public int vcount
		{
			[CompilerGenerated]
			get
			{
				return c;
			}
			[CompilerGenerated]
			set
			{
				c = value;
			}
		}

		public string btName
		{
			[CompilerGenerated]
			get
			{
				return d;
			}
			[CompilerGenerated]
			set
			{
				d = value;
			}
		}
	}
}
