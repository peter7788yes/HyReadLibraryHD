using BookManagerModule;
using MultiLanquageModule;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace HyReadLibraryHD
{
	public class LibraryTreeView : UserControl, IComponentConnector, IStyleConnector
	{
		[CompilerGenerated]
		private sealed class a
		{
			public List<string> a;

			public Func<BookProvider, bool> b;

			public Func<BookProvider, bool> c;

			internal bool d(BookProvider A_0)
			{
				return Enumerable.Any(a, new Func<string, bool>(A_0.name.Contains));
			}

			internal bool e(BookProvider A_0)
			{
				return !Enumerable.Any(a, new Func<string, bool>(A_0.name.Contains));
			}
		}

		private MultiLanquageManager LanqMng;

		[CompilerGenerated]
		private List<string> _003ClibsCatTitle_003Ek__BackingField;

		public ObservableCollection<Libraries> libraries;

		internal Grid searchLibPanel;

		internal TextBox txtLibKeyword;

		internal Button defaultLibName;

		internal TreeView librarieListTreeView;

		private bool _contentLoaded;

		private List<string> libsCatTitle
		{
			[CompilerGenerated]
			get
			{
				return _003ClibsCatTitle_003Ek__BackingField;
			}
			[CompilerGenerated]
			set
			{
				_003ClibsCatTitle_003Ek__BackingField = value;
			}
		}

		public event LibsButtonClickEvent libsButtonClickEvent;

		public event LibsContextMenuEvent libsContextMenuEvent;

		public LibraryTreeView()
		{
			InitializeComponent();
			LanqMng = Global.bookManager.LanqMng;
			libraries = new ObservableCollection<Libraries>();
			if (Global.bookManager.libTypes == null || Global.bookManager.libTypes.Count == 0)
			{
				List<string> list = new List<string>();
				list.Add(LanqMng.getLangString("publicLib"));
				list.Add(LanqMng.getLangString("universitiesLib"));
				list.Add(LanqMng.getLangString("highSchoolLib"));
				list.Add(LanqMng.getLangString("stateSchoolLib"));
				list.Add(LanqMng.getLangString("specialLib"));
				list.Add(LanqMng.getLangString("otherLib"));
				libsCatTitle = list;
				if (Global.regPath.Equals("NTPCReader"))
				{
					List<string> list2 = new List<string>();
					list2.Add(LanqMng.getLangString("publicLib"));
					list2.Add(LanqMng.getLangString("universitiesLib"));
					list2.Add("學校圖書館");
					list2.Add(LanqMng.getLangString("stateSchoolLib"));
					list2.Add("公務圖書館");
					list2.Add(LanqMng.getLangString("otherLib"));
					libsCatTitle = list2;
				}
				for (int i = 0; i < libsCatTitle.Count; i++)
				{
					libraries.Add(new Libraries(libsCatTitle[i], i + 1));
				}
			}
			else
			{
				for (int j = 0; j < Global.bookManager.libTypes.Count; j++)
				{
					int result = j;
					int.TryParse(Global.bookManager.libTypes[j].id, out result);
					int result2 = j;
					int.TryParse(Global.bookManager.libTypes[j].sort, out result2);
					if (Global.localDataPath.Equals("HyReadCN"))
					{
						libraries.Add(new Libraries(Global.bookManager.libTypes[result2 - 1].description, result));
					}
					else
					{
						libraries.Add(new Libraries(Global.bookManager.libTypes[result2].description, result));
					}
				}
			}
			List<string> everLoggedLibList = Global.bookManager.getEverLoggedLibList();
			if (!everLoggedLibList.Count.Equals(0))
			{
				libraries.Insert(0, new Libraries(LanqMng.getLangString("recentLoginLibs"), -1));
				libraries[0].isLibraryListExpanded = true;
			}
			foreach (KeyValuePair<string, BookProvider> bookProvider in Global.bookManager.bookProviders)
			{
				int num = everLoggedLibList.Count.Equals(0) ? (bookProvider.Value.libType - 1) : bookProvider.Value.libType;
				if (everLoggedLibList.Contains(bookProvider.Value.vendorId))
				{
					libraries[0].showedLibraries.Add(bookProvider.Value);
				}
				if (bookProvider.Value.vendorId == "hyread" || num < 0)
				{
					continue;
				}
				if (bookProvider.Value.vendorId == "free" || bookProvider.Value.vendorId == "freecn")
				{
					bookProvider.Value.isShowed = false;
					continue;
				}
				for (int k = 0; k < libraries.Count; k++)
				{
					if (libraries[k].libGroupType == bookProvider.Value.libType)
					{
						libraries[k].showedLibraries.Add(bookProvider.Value);
						break;
					}
				}
			}
			for (int num2 = libraries.Count - 1; num2 >= 0; num2--)
			{
				if (libraries[num2].showedLibraries.Count == 0)
				{
					libraries.RemoveAt(num2);
				}
			}
			librarieListTreeView.ItemsSource = libraries;
			if (Global.regPath.Equals("NTPCReader"))
			{
				defaultLibName.Visibility = Visibility.Collapsed;
			}
		}

		private void a(object A_0, TextChangedEventArgs A_1)
		{
			a a = new a();
			bool flag = false;
			string text = txtLibKeyword.Text;
			a.a = new List<string>();
			if (text.Contains("台") || text.Contains("臺"))
			{
				flag = true;
				string item = text.Replace("台", "臺");
				a.a.Add(item);
				item = text.Replace("臺", "台");
				a.a.Add(item);
			}
			if (text.Contains("体") || text.Contains("體"))
			{
				flag = true;
				string item2 = text.Replace("体", "體");
				a.a.Add(item2);
				item2 = text.Replace("體", "体");
				a.a.Add(item2);
			}
			if (!flag)
			{
				a.a.Add(text);
			}
			for (int i = 0; i < libraries.Count; i++)
			{
				if (text.Equals(""))
				{
					int count = libraries[i].showedLibraries.Count;
					for (int j = 0; j < count; j++)
					{
						libraries[i].showedLibraries[j].isShowed = true;
					}
					libraries[i].isShowed = true;
					libraries[i].isLibraryListExpanded = (libraries[i].Name.Equals(LanqMng.getLangString("recentLoginLibs")) ? true : false);
					continue;
				}
				List<BookProvider> list = Enumerable.ToList(Enumerable.Where(libraries[i].showedLibraries, a.b ?? (a.b = new Func<BookProvider, bool>(a.d))));
				for (int k = 0; k < list.Count; k++)
				{
					list[k].isShowed = true;
				}
				List<BookProvider> list2 = Enumerable.ToList(Enumerable.Where(libraries[i].showedLibraries, a.c ?? (a.c = new Func<BookProvider, bool>(a.e))));
				for (int l = 0; l < list2.Count; l++)
				{
					list2[l].isShowed = false;
				}
				if (libraries[i].showedLibraries.Count.Equals(list2.Count))
				{
					libraries[i].isShowed = false;
					libraries[i].isLibraryListExpanded = false;
				}
				else
				{
					libraries[i].isShowed = true;
					libraries[i].isLibraryListExpanded = true;
				}
			}
		}

		private void a(object A_0, ContextMenuEventArgs A_1)
		{
			ItemsPresenter obj = (ItemsPresenter)A_0;
			object dataContext = obj.DataContext;
			if (((Libraries)obj.DataContext).libGroupType != -1)
			{
				A_1.Handled = true;
			}
		}

		private void b(object A_0, RoutedEventArgs A_1)
		{
			string clickItemId = (string)((MenuItem)A_0).Tag;
			if (this.libsContextMenuEvent != null)
			{
				this.libsContextMenuEvent(clickItemId);
			}
		}

		public void removeFavLibs(string vendorId)
		{
			if (Global.bookManager.bookProviders.ContainsKey(vendorId))
			{
				BookProvider item = Global.bookManager.bookProviders[vendorId];
				if (libraries[0].showedLibraries.Contains(item))
				{
					libraries[0].showedLibraries.Remove(item);
				}
				if (libraries[0].showedLibraries.Count.Equals(0))
				{
					libraries.RemoveAt(0);
				}
			}
		}

		public void addFavLibs(string vendorId)
		{
			if (Global.bookManager.bookProviders.ContainsKey(vendorId))
			{
				if (!libraries[0].Name.Equals(LanqMng.getLangString("recentLoginLibs")))
				{
					libraries.Insert(0, new Libraries(LanqMng.getLangString("recentLoginLibs"), -1));
					libraries[0].isLibraryListExpanded = true;
				}
				BookProvider item = Global.bookManager.bookProviders[vendorId];
				if (!libraries[0].showedLibraries.Contains(item))
				{
					libraries[0].showedLibraries.Insert(0, item);
				}
			}
		}

		private void a(object A_0, RoutedEventArgs A_1)
		{
			string text = (A_0 as Button).Tag.ToString();
			string name = Global.bookManager.bookProviders[text].name;
			if (this.libsButtonClickEvent != null)
			{
				this.libsButtonClickEvent(text, name);
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/librarytreeview.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				searchLibPanel = (Grid)target;
				break;
			case 2:
				txtLibKeyword = (TextBox)target;
				txtLibKeyword.TextChanged += new TextChangedEventHandler(a);
				break;
			case 3:
				defaultLibName = (Button)target;
				defaultLibName.Click += new RoutedEventHandler(a);
				break;
			case 4:
				librarieListTreeView = (TreeView)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 5:
				((ItemsPresenter)target).ContextMenuOpening += new ContextMenuEventHandler(a);
				break;
			case 6:
				((Button)target).Click += new RoutedEventHandler(a);
				break;
			case 7:
				((MenuItem)target).Click += new RoutedEventHandler(b);
				break;
			}
		}
	}
}
