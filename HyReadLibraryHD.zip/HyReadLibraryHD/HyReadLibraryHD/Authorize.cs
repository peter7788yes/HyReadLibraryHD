using Facebook;
using Microsoft.CSharp.RuntimeBinder;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace HyReadLibraryHD
{
	public class Authorize : Form
	{
		[CompilerGenerated]
		private static class a
		{
			public static CallSite<Func<CallSite, object, object>> a;
		}

		public string postMsg = "";

		private string m_a = "247605462059240";

		private string m_b = "publish_stream";

		[CompilerGenerated]
		private string c;

		private IContainer d;

		private WebBrowser e;

		public string AccessToken
		{
			[CompilerGenerated]
			get
			{
				return c;
			}
			[CompilerGenerated]
			set
			{
				c = value;
			}
		}

		public Authorize()
		{
			a();
		}

		private void a(object A_0, EventArgs A_1)
		{
			string urlString = string.Format("https://www.facebook.com/dialog/oauth?client_id={0}&scope={1}&redirect_uri=http://www.facebook.com/connect/login_success.html&response_type=token", this.m_a, this.m_b);
			e.Navigated += new WebBrowserNavigatedEventHandler(a);
			e.Navigate(urlString);
		}

		private void a(object A_0, WebBrowserNavigatedEventArgs A_1)
		{
			string fragment = A_1.Url.Fragment;
			if (!fragment.Contains("access_token") || !fragment.Contains("#"))
			{
				return;
			}
			Hide();
			string text = new Regex("#").Replace(fragment, "?", 1);
			AccessToken = text.Substring(text.IndexOf('=') + 1, text.LastIndexOf('&') - text.IndexOf('=') - 1);
			try
			{
				object arg = new FacebookClient(AccessToken).Post("me/feed", new global::a<string>(postMsg));
				if (Authorize.a.a == null)
				{
					Authorize.a.a = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "id", typeof(Authorize), new CSharpArgumentInfo[1]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
					}));
				}
				Authorize.a.a.Target(Authorize.a.a, arg);
			}
			catch (Exception value)
			{
				Console.Write(value);
				MessageBox.Show("分享失敗");
			}
		}

		private void b()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Authorize));
			SuspendLayout();
			base.ClientSize = new Size(284, 261);
			base.Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
			base.Name = "Authorize";
			base.StartPosition = FormStartPosition.CenterParent;
			ResumeLayout(false);
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && d != null)
			{
				d.Dispose();
			}
			base.Dispose(disposing);
		}

		private void a()
		{
			e = new WebBrowser();
			SuspendLayout();
			e.Dock = DockStyle.Fill;
			e.Location = new Point(0, 0);
			e.MinimumSize = new Size(20, 20);
			e.Name = "webBrowser";
			e.Size = new Size(1008, 642);
			e.TabIndex = 0;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(1008, 642);
			base.Controls.Add(e);
			base.Name = "Authorize";
			Text = "電子書分享";
			base.Load += new EventHandler(a);
			ResumeLayout(false);
		}
	}
}
