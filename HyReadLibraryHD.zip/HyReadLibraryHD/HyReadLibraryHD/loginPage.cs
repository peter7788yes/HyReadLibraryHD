using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace HyReadLibraryHD
{
	public class loginPage : Window, IComponentConnector
	{
		public static class SoftwareInfo
		{
			internal static HyReadInfo a(string A_0)
			{
				return new HyReadInfo(A_0);
			}
		}

		internal delegate void a();

		internal delegate int b(string A_0, string A_1, string A_2, string A_3);

		[CompilerGenerated]
		private sealed class c
		{
			public IAsyncResult a;

			public loginPage b;

			internal void c(IAsyncResult A_0)
			{
				d d = new d();
				d.c = this;
				if (!b.isCancelled)
				{
					d.b = loginPage.c.EndInvoke(a);
					d.a = "";
					switch (d.b)
					{
					case 0:
						d.a = Global.bookManager.LanqMng.getLangString("withoutLib");
						break;
					case 1:
						d.a = Global.bookManager.bookProviders[b._clickedVendorId].message;
						break;
					case 2:
						d.a = Global.bookManager.LanqMng.getLangString("loginServiceFail") + Global.bookManager.bookProviders[b._clickedVendorId].message;
						break;
					}
					b.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new a(d.d));
				}
			}
		}

		[CompilerGenerated]
		private sealed class d
		{
			public string a;

			public int b;

			public c c;

			internal void d()
			{
				if (!c.b.isCancelled)
				{
					c.b.g.Content = a;
					if (b.Equals(1))
					{
						c.b.Close();
					}
					c.b.m_b = false;
				}
			}
		}

		private ISoftwareInfo m_a;

		public string _clickedVendorId;

		public bool isCancelled;

		private bool m_b;

		internal static b c;

		internal loginPage d;

		internal TextBlock e;

		internal TextBlock f;

		internal Label g;

		internal Grid h;

		internal TextBlock i;

		internal Hyperlink j;

		internal Run k;

		internal TextBlock l;

		internal Hyperlink m;

		internal Run n;

		internal StackPanel o;

		internal ComboBox p;

		internal TextBox q;

		internal PasswordBox r;

		internal StackPanel s;

		internal RadioButton t;

		internal RadioButton u;

		private bool v;

		public loginPage(string clickedVendorId)
		{
			_clickedVendorId = clickedVendorId;
			InitializeComponent();
			this.m_a = SoftwareInfo.a(_clickedVendorId);
			if (_clickedVendorId.Equals("hyread"))
			{
				this.h.Visibility = Visibility.Visible;
			}
			else if (_clickedVendorId.Equals("ntl-ebookftp"))
			{
				this.h.Visibility = Visibility.Visible;
			}
			SetContextOnLoginPage();
		}

		public void SetContextOnLoginPage()
		{
			this.d.Title = this.m_a.softwareTitle() + "-" + Global.bookManager.LanqMng.getLangString("memberLogin");
			this.e.Text = this.m_a.softwareTitle();
			q.Text = this.m_a.originalAccountText();
			r.Password = this.m_a.originalPasswordText();
			Uri uri = this.m_a.iconImagePath();
			if (uri != null)
			{
				try
				{
					base.Icon = BitmapFrame.Create(uri);
				}
				catch
				{
				}
			}
			Uri uri2 = this.m_a.backgroundImagePath();
			if (uri2 != null)
			{
				try
				{
					base.Background = new ImageBrush(BitmapFrame.Create(uri2));
				}
				catch
				{
				}
			}
			k.Text = this.m_a.hyperlinkForgetPassword();
			n.Text = this.m_a.hyperlinkRegister();
			j.NavigateUri = this.m_a.hyperlinkForgetPasswordLink();
			m.NavigateUri = this.m_a.hyperlinkRegisterLink();
			RadioButton radioButton = t;
			TextBlock textBlock = new TextBlock();
			textBlock.Text = this.m_a.loginButtonContent();
			textBlock.Foreground = Brushes.White;
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			textBlock.HorizontalAlignment = HorizontalAlignment.Center;
			radioButton.Content = textBlock;
			RadioButton radioButton2 = u;
			TextBlock textBlock2 = new TextBlock();
			textBlock2.Text = this.m_a.cancelButtonContent();
			textBlock2.Foreground = Brushes.White;
			textBlock2.VerticalAlignment = VerticalAlignment.Center;
			textBlock2.HorizontalAlignment = HorizontalAlignment.Center;
			radioButton2.Content = textBlock2;
			if (this.m_a.helpContent() != null)
			{
				this.f.Text = this.m_a.helpContent();
			}
			List<string> list = this.m_a.comboColibs();
			if (list.Count.Equals(0))
			{
				return;
			}
			o.Visibility = Visibility.Visible;
			foreach (string item in list)
			{
				p.Items.Add(item);
			}
		}

		private void h(object A_0, RoutedEventArgs A_1)
		{
			TextBox textBox = (TextBox)A_0;
			if (textBox.Text == "" || textBox.Text == this.m_a.originalAccountText())
			{
				textBox.Text = "";
			}
		}

		private void g(object A_0, RoutedEventArgs A_1)
		{
			TextBox textBox = (TextBox)A_0;
			string text = textBox.Text;
			if (textBox.Text == "" || textBox.Text == this.m_a.originalAccountText())
			{
				textBox.Text = this.m_a.originalAccountText();
			}
		}

		private void f(object A_0, RoutedEventArgs A_1)
		{
			PasswordBox passwordBox = (PasswordBox)A_0;
			if (passwordBox.Password == "" || passwordBox.Password == this.m_a.originalPasswordText())
			{
				passwordBox.Password = "";
			}
		}

		private void e(object A_0, RoutedEventArgs A_1)
		{
			PasswordBox passwordBox = (PasswordBox)A_0;
			string password = passwordBox.Password;
			if (passwordBox.Password == this.m_a.originalPasswordText())
			{
				passwordBox.Password = this.m_a.originalPasswordText();
			}
		}

		private void d(object A_0, RoutedEventArgs A_1)
		{
			if (this.m_b)
			{
				return;
			}
			this.m_b = true;
			this.g.Content = "";
			if (r.Password.Equals(this.m_a.originalPasswordText()))
			{
				r.Password = "";
			}
			if (!q.Text.Equals(this.m_a.originalAccountText()))
			{
				c obj = new c();
				obj.b = this;
				loginPage.c = new b(a);
				string a_ = "";
				if (!p.Items.Count.Equals(0))
				{
					a_ = this.m_a.comboColibsId()[p.SelectedIndex];
				}
				obj.a = null;
				AsyncCallback a_2 = new AsyncCallback(obj.c);
				obj.a = loginPage.c.BeginInvoke(_clickedVendorId, a_, q.Text, r.Password, a_2, null);
				this.g.Content = Global.bookManager.LanqMng.getLangString("logging");
			}
			else
			{
				this.g.Content = Global.bookManager.LanqMng.getLangString("plsEnterAccountPassword");
			}
		}

		private int a(string A_0, string A_1, string A_2, string A_3)
		{
			try
			{
				return Global.bookManager.login(A_0, A_1, A_2, A_3);
			}
			catch (Exception)
			{
				return -1;
			}
		}

		private void c(object A_0, RoutedEventArgs A_1)
		{
			isCancelled = true;
			this.d.Close();
		}

		private void b(object A_0, RoutedEventArgs A_1)
		{
			Process.Start(new ProcessStartInfo(((Hyperlink)A_1.OriginalSource).NavigateUri.AbsoluteUri));
		}

		private void a(object A_0, RoutedEventArgs A_1)
		{
			Process.Start(new ProcessStartInfo(((Hyperlink)A_1.OriginalSource).NavigateUri.AbsoluteUri));
		}

		private void a(object A_0, KeyEventArgs A_1)
		{
			if (A_1.Key == Key.Return)
			{
				d(A_0, A_1);
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!v)
			{
				v = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/loginpage.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				this.d = (loginPage)target;
				break;
			case 2:
				this.e = (TextBlock)target;
				break;
			case 3:
				this.f = (TextBlock)target;
				break;
			case 4:
				this.g = (Label)target;
				break;
			case 5:
				this.h = (Grid)target;
				break;
			case 6:
				i = (TextBlock)target;
				break;
			case 7:
				j = (Hyperlink)target;
				j.Click += new RoutedEventHandler(b);
				break;
			case 8:
				k = (Run)target;
				break;
			case 9:
				l = (TextBlock)target;
				break;
			case 10:
				m = (Hyperlink)target;
				m.Click += new RoutedEventHandler(a);
				break;
			case 11:
				n = (Run)target;
				break;
			case 12:
				o = (StackPanel)target;
				break;
			case 13:
				p = (ComboBox)target;
				break;
			case 14:
				q = (TextBox)target;
				q.GotFocus += new RoutedEventHandler(h);
				q.LostFocus += new RoutedEventHandler(g);
				break;
			case 15:
				r = (PasswordBox)target;
				r.GotFocus += new RoutedEventHandler(f);
				r.LostFocus += new RoutedEventHandler(e);
				r.KeyDown += new KeyEventHandler(a);
				break;
			case 16:
				s = (StackPanel)target;
				break;
			case 17:
				t = (RadioButton)target;
				t.Click += new RoutedEventHandler(d);
				break;
			case 18:
				u = (RadioButton)target;
				u.Click += new RoutedEventHandler(c);
				break;
			default:
				v = true;
				break;
			}
		}
	}
}
