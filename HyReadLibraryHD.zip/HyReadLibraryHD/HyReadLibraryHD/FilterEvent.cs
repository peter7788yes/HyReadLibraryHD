namespace HyReadLibraryHD
{
	public delegate void FilterEvent(string tagName);
}
