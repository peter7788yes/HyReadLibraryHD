using System.Collections.Generic;

namespace HyReadLibraryHD
{
	public struct NOTE_ARRAYLIST
	{
		public string id;

		public int left;

		public int top;

		public int right;

		public int bottom;

		public List<START_END_PAIR> items;
	}
}
