using Microsoft.CSharp.RuntimeBinder;
using MSHTML;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Navigation;

namespace HyReadLibraryHD
{
	public class SSOWebview : Window, IComponentConnector
	{
		[CompilerGenerated]
		private static class a
		{
			public static CallSite<Func<CallSite, object, object>> a;

			public static CallSite<Func<CallSite, object, string>> b;

			public static CallSite<Func<CallSite, object, object>> c;

			public static CallSite<Func<CallSite, object, string>> d;

			public static CallSite<Func<CallSite, object, object>> e;

			public static CallSite<Func<CallSite, object, string>> f;
		}

		private const int m_a = 42;

		public bool isCancelled = true;

		private string b = "";

		internal Label c;

		internal WebBrowser d;

		private bool e;

		[DllImport("wininet.dll", SetLastError = true)]
		private static extern bool InternetSetOption(IntPtr A_0, int A_1, IntPtr A_2, int A_3);

		public SSOWebview(string VendorId, string loginApi)
		{
			InitializeComponent();
			b = VendorId;
			base.Title = Global.bookManager.bookProviders[b].name + " 登入";
			InternetSetOption(IntPtr.Zero, 42, IntPtr.Zero, 0);
			a(loginApi);
		}

		private void a(string A_0)
		{
			if (string.IsNullOrEmpty(A_0) || A_0.Equals("about:blank"))
			{
				return;
			}
			if (!A_0.StartsWith("http://") && !A_0.StartsWith("https://"))
			{
				A_0 = "http://" + A_0;
			}
			string[] files = Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.Cookies));
			foreach (string path in files)
			{
				try
				{
					File.Delete(path);
				}
				catch
				{
				}
			}
			try
			{
				d.Navigate(new Uri(A_0));
			}
			catch (UriFormatException)
			{
			}
		}

		private void a(object A_0, DependencyPropertyChangedEventArgs A_1)
		{
		}

		private void a(object A_0, NavigationEventArgs A_1)
		{
			HTMLDocument hTMLDocument = (HTMLDocument)d.Document;
			string text = "";
			string text2 = "";
			string colibId = "";
			if (!hTMLDocument.url.Contains("success.jsp?"))
			{
				return;
			}
			try
			{
				if (SSOWebview.a.b == null)
				{
					SSOWebview.a.b = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof(string), typeof(SSOWebview)));
				}
				Func<CallSite, object, string> target = SSOWebview.a.b.Target;
				CallSite<Func<CallSite, object, string>> arg = SSOWebview.a.b;
				if (SSOWebview.a.a == null)
				{
					SSOWebview.a.a = CallSite<Func<CallSite, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "ToString", null, typeof(SSOWebview), new CSharpArgumentInfo[1]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
					}));
				}
				text = target(arg, SSOWebview.a.a.Target(SSOWebview.a.a, hTMLDocument.getElementById("uid").getAttribute("value")));
				if (SSOWebview.a.d == null)
				{
					SSOWebview.a.d = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof(string), typeof(SSOWebview)));
				}
				Func<CallSite, object, string> target2 = SSOWebview.a.d.Target;
				CallSite<Func<CallSite, object, string>> arg2 = SSOWebview.a.d;
				if (SSOWebview.a.c == null)
				{
					SSOWebview.a.c = CallSite<Func<CallSite, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "ToString", null, typeof(SSOWebview), new CSharpArgumentInfo[1]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
					}));
				}
				text2 = target2(arg2, SSOWebview.a.c.Target(SSOWebview.a.c, hTMLDocument.getElementById("sid").getAttribute("value")));
				if (SSOWebview.a.f == null)
				{
					SSOWebview.a.f = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof(string), typeof(SSOWebview)));
				}
				Func<CallSite, object, string> target3 = SSOWebview.a.f.Target;
				CallSite<Func<CallSite, object, string>> f = SSOWebview.a.f;
				if (SSOWebview.a.e == null)
				{
					SSOWebview.a.e = CallSite<Func<CallSite, object, object>>.Create(Binder.InvokeMember(CSharpBinderFlags.None, "ToString", null, typeof(SSOWebview), new CSharpArgumentInfo[1]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
					}));
				}
				colibId = target3(f, SSOWebview.a.e.Target(SSOWebview.a.e, hTMLDocument.getElementById("colibid").getAttribute("value")));
			}
			catch
			{
			}
			if (!text.Equals("") && !text2.Equals(""))
			{
				isCancelled = false;
				try
				{
					Global.bookManager.loginForSSO(b, colibId, text, text2);
				}
				catch (Exception)
				{
				}
			}
			else
			{
				MessageBox.Show("登入失敗");
			}
			Close();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!e)
			{
				e = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/ssowebview.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				c = (Label)target;
				break;
			case 2:
				d = (WebBrowser)target;
				d.LoadCompleted += new LoadCompletedEventHandler(a);
				break;
			default:
				e = true;
				break;
			}
		}
	}
}
