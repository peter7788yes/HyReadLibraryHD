using BookManagerModule;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;

namespace HyReadLibraryHD
{
	public class Libraries : INotifyPropertyChanged
	{
		[CompilerGenerated]
		private PropertyChangedEventHandler a;

		[CompilerGenerated]
		private int b;

		[CompilerGenerated]
		private string c;

		[CompilerGenerated]
		private ObservableCollection<BookProvider> d;

		private bool e;

		private bool f;

		public int libGroupType
		{
			[CompilerGenerated]
			get
			{
				return b;
			}
			[CompilerGenerated]
			set
			{
				b = value;
			}
		}

		public string Name
		{
			[CompilerGenerated]
			get
			{
				return c;
			}
			[CompilerGenerated]
			set
			{
				c = value;
			}
		}

		public ObservableCollection<BookProvider> showedLibraries
		{
			[CompilerGenerated]
			get
			{
				return d;
			}
			[CompilerGenerated]
			set
			{
				d = value;
			}
		}

		public bool isShowed
		{
			get
			{
				return e;
			}
			set
			{
				e = value;
				if (a != null)
				{
					a(this, new PropertyChangedEventArgs("isShowed"));
				}
			}
		}

		public bool isLibraryListExpanded
		{
			get
			{
				return f;
			}
			set
			{
				f = value;
				if (a != null)
				{
					a(this, new PropertyChangedEventArgs("isLibraryListExpanded"));
				}
			}
		}

		public event PropertyChangedEventHandler PropertyChanged
		{
			[CompilerGenerated]
			add
			{
				PropertyChangedEventHandler propertyChangedEventHandler = a;
				PropertyChangedEventHandler propertyChangedEventHandler2;
				do
				{
					propertyChangedEventHandler2 = propertyChangedEventHandler;
					PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Combine(propertyChangedEventHandler2, value);
					propertyChangedEventHandler = Interlocked.CompareExchange(ref a, value2, propertyChangedEventHandler2);
				}
				while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				PropertyChangedEventHandler propertyChangedEventHandler = a;
				PropertyChangedEventHandler propertyChangedEventHandler2;
				do
				{
					propertyChangedEventHandler2 = propertyChangedEventHandler;
					PropertyChangedEventHandler value2 = (PropertyChangedEventHandler)Delegate.Remove(propertyChangedEventHandler2, value);
					propertyChangedEventHandler = Interlocked.CompareExchange(ref a, value2, propertyChangedEventHandler2);
				}
				while ((object)propertyChangedEventHandler != propertyChangedEventHandler2);
			}
		}

		public Libraries(string name, int libGroupType)
		{
			Name = name;
			isShowed = true;
			isLibraryListExpanded = false;
			this.libGroupType = libGroupType;
			showedLibraries = new ObservableCollection<BookProvider>();
		}
	}
}
