using BookFormatLoader;
using BookManagerModule;
using CACodec;
using CefSharp;
using ConfigureManagerModule;
using DataAccessObject;
using DownloadManagerModule;
using HyReadLibraryHD.Properties;
using LocalFilesManagerModule;
using Microsoft.Win32;
using Network;
using NLog;
using ReadPageModule;
using SyncCenterModule;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Xml;

namespace HyReadLibraryHD
{
	public class MainWindow : Window, IComponentConnector, IStyleConnector
	{
		private delegate void a(string A_0);

		private delegate void b(string A_0);

		private delegate void c(string A_0, int A_1);

		private delegate void d(string A_0, Category A_1, string A_2);

		internal delegate void e(BookType A_0, object A_1, int A_2);

		private delegate void f(string A_0, List<UserBookMetadata> A_1);

		private delegate void g(string A_0, List<LendRule> A_1);

		private delegate void h(string A_0, string A_1);

		[CompilerGenerated]
		private sealed class i
		{
			public MainWindow a;

			public BookThumbnail b;
		}

		[CompilerGenerated]
		private sealed class j
		{
			public BookType a;

			public i b;
		}

		[CompilerGenerated]
		private sealed class k
		{
			public object a;

			public j b;

			internal void c(IAsyncResult A_0)
			{
				b.b.a.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new global::k(c));
			}

			internal void c()
			{
				if (!b.b.a.closedByCancelButton)
				{
					if (b.a == BookType.HEJ || b.a == BookType.PHEJ)
					{
						ReadWindow readWindow = new ReadWindow(a, b.b.b.bookID, b.b.b.userId, b.b.b.trialPage, b.a, Global.bookManager, Global.bookManager.LanqMng, true, Global.localDataPath);
						readWindow.Owner = b.b.a;
						readWindow.ShowDialog();
						b.b.a.an.Visibility = Visibility.Collapsed;
						b.b.a.ap.Visibility = Visibility.Collapsed;
						Global.bookManager.pauseTryReadAfterReading("tryread");
						readWindow.Dispose();
						readWindow.Owner = null;
					}
					else
					{
						b.b.a.m_i = new LocalFilesManager(Global.localDataPath, "tryread", "tryread", "tryread");
						string userBookPath = b.b.a.m_i.getUserBookPath(b.b.b.bookID, BookType.EPUB.GetHashCode(), b.b.b.owner);
						epubReadPage epubReadPage = new epubReadPage("tryread", "tryread", "tryread", "free", b.b.b.bookID, userBookPath, "", b.b.b.trialPage);
						epubReadPage.ShowDialog();
						b.b.a.an.Visibility = Visibility.Collapsed;
						b.b.a.ap.Visibility = Visibility.Collapsed;
						Global.bookManager.pauseTryReadAfterReading("tryread");
						epubReadPage.Close();
						epubReadPage.Dispose();
					}
					b.b.a.closedByCancelButton = false;
				}
				else
				{
					b.b.a.ap.Visibility = Visibility.Collapsed;
					b.b.a.an.Visibility = Visibility.Collapsed;
					b.b.a.closedByCancelButton = false;
				}
			}
		}

		[CompilerGenerated]
		private sealed class l
		{
			public MainWindow a;

			public BookThumbnail b;
		}

		[CompilerGenerated]
		private sealed class m
		{
			public BookType a;

			public object b;

			public l c;

			internal void d(IAsyncResult A_0)
			{
				c.a.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new global::k(d));
			}

			internal void d()
			{
				if (!c.a.closedByCancelButton)
				{
					c.a.m_i = new LocalFilesManager(Global.localDataPath, c.b.vendorId, c.b.colibId, c.b.userId);
					string userBookPath = c.a.m_i.getUserBookPath(c.b.bookID, a.GetHashCode(), c.b.owner);
					HEJMetadata bookMetadata = new HEJMetadataReader(userBookPath).getBookMetadata(userBookPath + "\\book.xml", 0, Global.regPath, c.b.vendorId);
					if (bookMetadata.bookType.ToLower().Equals("video"))
					{
						string a_ = "";
						foreach (ManifestItem manifestItem in bookMetadata.manifestItemList)
						{
							if (manifestItem.mediaType.Equals("application/x-mpegURL"))
							{
								a_ = manifestItem.href;
								break;
							}
						}
						c.a.a(userBookPath, c.b, a_);
					}
					else
					{
						ReadWindow readWindow = new ReadWindow(b, c.b.bookID, c.b.userId, c.b.trialPage, a, Global.bookManager, Global.bookManager.LanqMng, true, Global.localDataPath);
						readWindow.ReadWindowDataRequest += new EventHandler<DataRequestEventArgs>(c.a.a);
						readWindow.Owner = c.a;
						c.a.an.Visibility = Visibility.Collapsed;
						c.a.ap.Visibility = Visibility.Collapsed;
						readWindow.ShowDialog();
						readWindow.ReadWindowDataRequest -= new EventHandler<DataRequestEventArgs>(c.a.a);
						c.a.b(b);
						readWindow.Owner = null;
						readWindow.Dispose();
						c.a.closedByCancelButton = false;
						c.a.g();
					}
				}
				else
				{
					c.a.ap.Visibility = Visibility.Collapsed;
					c.a.an.Visibility = Visibility.Collapsed;
					c.a.closedByCancelButton = false;
				}
			}
		}

		[Serializable]
		[CompilerGenerated]
		private sealed class _003C_003Ec
		{
			public static readonly _003C_003Ec _003C_003E9 = new _003C_003Ec();

			public static ThreadStart _003C_003E9__181_0;

			public static ThreadStart _003C_003E9__185_0;

			internal void a()
			{
				Global.bookManager.bugReport();
			}

			internal void b()
			{
				Global.bookManager.noteReport();
			}
		}

		public string curVendorId = Global.bookManager.defaultVendorId;

		private List<TextBlock> m_a;

		public bool firstClickButton;

		public readonly int maxBookPerPage;

		public bool canSendThread;

		private string m_b;

		private global::i m_c;

		private Dictionary<string, int[]> m_d;

		private int m_e;

		private int m_f;

		private int m_g;

		private int m_h;

		private LocalFilesManager m_i;

		private bool m_j;

		private string m_k;

		private int m_l;

		private ConfigurationManager m_m;

		private int m_n;

		private bool m_o;

		private int m_p;

		private string m_q;

		private HttpRequest m_r;

		private Dictionary<string, string> m_s;

		private static Logger m_t = LogManager.GetCurrentClassLogger();

		private int m_u;

		private ObservableCollection<BookThumbnail> m_v;

		private TimeSpan m_w;

		private bool m_x;

		private int m_y;

		private DispatcherTimer m_z;

		private Dictionary<string, FileDownloader> m_aa;

		private bool m_ab;

		private List<string> m_ac;

		private bool m_ad;

		internal static e ae;

		private Dictionary<string, object> m_af;

		private Dictionary<string, object> m_ag;

		public bool closedByCancelButton;

		[CompilerGenerated]
		private EventHandler<DataRequestEventArgs> m_ah;

		private string m_ai;

		public int UpdatingBookProviders;

		public int TotalUpdatingBookProviders;

		public List<UserBookMetadata> updatedBooksThisTime;

		public List<BookProvider> loginProviders;

		[CompilerGenerated]
		private ObservableCollection<LendRule> m_aj;

		private BookThumbnail ak;

		private string al;

		internal MainWindow am;

		internal Canvas an;

		internal TextBlock ao;

		internal RadioButton ap;

		internal Canvas aq;

		internal TextBlock ar;

		internal RadioButton @as;

		internal RadioButton at;

		internal RadioButton au;

		internal ImageBrush av;

		internal TextBlock aw;

		internal Hyperlink ax;

		internal Run ay;

		internal RadioButton az;

		internal RadioButton a0;

		internal RadioButton a1;

		internal TabControl a2;

		internal TabItem a3;

		internal Grid a4;

		internal CategoryComboBox a5;

		internal StackPanel a6;

		internal TextBox a7;

		internal RadioButton a8;

		internal RadioButton a9;

		internal TextBlock ba;

		internal RadioButton bb;

		internal RadioButton bc;

		internal Grid bd;

		internal Grid be;

		internal LibraryTreeView bf;

		internal Grid bg;

		internal RadioButton bh;

		internal ListBox bi;

		internal Canvas bj;

		internal Grid bk;

		internal TextBlock bl;

		internal TextBlock bm;

		internal Canvas bn;

		internal StackPanel bo;

		internal Grid bp;

		internal ListBox bq;

		internal Canvas br;

		internal StackPanel bs;

		internal ListBox bt;

		internal TabItem bu;

		internal Grid bv;

		internal TagCategoriesFilterButton bw;

		internal RadioButton bx;

		internal RadioButton by;

		internal Grid bz;

		internal ListBox b0;

		internal Canvas b1;

		internal StackPanel b2;

		internal CheckBox b3;

		internal CheckBox b4;

		internal CheckBox b5;

		internal CheckBox b6;

		internal CheckBox b7;

		internal CheckBox b8;

		internal CheckBox b9;

		internal CheckBox ca;

		internal CheckBox cb;

		internal CheckBox cc;

		internal CheckBox cd;

		internal Canvas ce;

		internal StackPanel cf;

		internal StackPanel cg;

		internal ComboBox ch;

		internal CheckBox ci;

		internal Button cj;

		internal Button ck;

		internal Button cl;

		internal Button cm;

		internal ComboBox cn;

		internal TextBlock co;

		internal Button cp;

		internal Button cq;

		internal Canvas cr;

		internal Border cs;

		internal TextBlock ct;

		internal Popup cu;

		internal Button cv;

		internal Button cw;

		internal Button cx;

		private bool cy;

		public ObservableCollection<LendRule> LendRuleCollection
		{
			[CompilerGenerated]
			get
			{
				return this.m_aj;
			}
			[CompilerGenerated]
			set
			{
				this.m_aj = value;
			}
		}

		public event EventHandler<DataRequestEventArgs> ReadWindowDataRequest
		{
			[CompilerGenerated]
			add
			{
				EventHandler<DataRequestEventArgs> eventHandler = this.m_ah;
				EventHandler<DataRequestEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<DataRequestEventArgs> value2 = (EventHandler<DataRequestEventArgs>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange(ref this.m_ah, value2, eventHandler2);
				}
				while ((object)eventHandler != eventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				EventHandler<DataRequestEventArgs> eventHandler = this.m_ah;
				EventHandler<DataRequestEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<DataRequestEventArgs> value2 = (EventHandler<DataRequestEventArgs>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange(ref this.m_ah, value2, eventHandler2);
				}
				while ((object)eventHandler != eventHandler2);
			}
		}

		[DllImport("user32.dll")]
		[DebuggerStepThrough]
		private static extern bool IsWindowEnabled(IntPtr A_0);

		public MainWindow()
		{
			List<TextBlock> list = new List<TextBlock>();
			TextBlock textBlock = new TextBlock();
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			textBlock.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock.Foreground = Brushes.White;
			textBlock.Text = "登入";
			list.Add(textBlock);
			TextBlock textBlock2 = new TextBlock();
			textBlock2.VerticalAlignment = VerticalAlignment.Center;
			textBlock2.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock2.Foreground = Brushes.White;
			textBlock2.Text = "登出";
			list.Add(textBlock2);
			TextBlock textBlock3 = new TextBlock();
			textBlock3.VerticalAlignment = VerticalAlignment.Center;
			textBlock3.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock3.Foreground = Brushes.White;
			textBlock3.Text = "已登入";
			list.Add(textBlock3);
			this.m_a = list;
			maxBookPerPage = 24;
			canSendThread = true;
			this.m_b = "BookShelf";
			this.m_e = 4;
			this.m_f = 5;
			this.m_k = "";
			this.m_l = 1;
			this.m_p = 1;
			this.m_q = "";
			this.m_r = new HttpRequest();
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("Accept-Language", Global.langName);
			this.m_s = dictionary;
			this.m_u = -1;
			this.m_w = new TimeSpan(24, 0, 0);
			this.m_x = true;
			this.m_z = new DispatcherTimer();
			this.m_aa = new Dictionary<string, FileDownloader>();
			this.m_ac = new List<string>();
			Dictionary<string, object> dictionary2 = new Dictionary<string, object>();
			dictionary2.Add("SLastPage", new LastPageData());
			dictionary2.Add("SBookmark", new BookMarkData());
			dictionary2.Add("SAnnotation", new NoteData());
			dictionary2.Add("SSpline", new StrokesData());
			this.m_af = dictionary2;
			Dictionary<string, object> dictionary3 = new Dictionary<string, object>();
			dictionary3.Add("EKAnnotation", new EKAnnotationData());
			this.m_ag = dictionary3;
			updatedBooksThisTime = new List<UserBookMetadata>();
			al = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), Global.localDataPath, "PromoOK");
			base._002Ector();
			MainWindow.m_t.Trace("MainWindow constructing");
			InitializeComponent();
			CefSettings cefSettings = new CefSettings();
			cefSettings.CefCommandLineArgs.Add("enable-viewport-meta", "true");
			cefSettings.CefCommandLineArgs.Add("enable-viewport", "true");
			cefSettings.CefCommandLineArgs.Add("enable-file-cookies", "true");
			Cef.Initialize(cefSettings);
			this.m_a[0].Text = Global.bookManager.LanqMng.getLangString("login");
			this.m_a[1].Text = Global.bookManager.LanqMng.getLangString("logout");
			this.m_a[2].Text = Global.bookManager.LanqMng.getLangString("logged");
			this.m_m = new ConfigurationManager(Global.bookManager);
			this.m_p = this.m_m.saveProxyMode;
			this.m_q = this.m_m.saveProxyHttpPort.Replace("|", ":");
			this.m_r = new HttpRequest(this.m_p, this.m_q);
			SystemEvents.PowerModeChanged += new PowerModeChangedEventHandler(a);
			SystemEvents.SessionEnding += new SessionEndingEventHandler(a);
			this.m_i = new LocalFilesManager(Global.localDataPath, "", "", "");
			this.m_i.getCoverFullPath("");
			this.m_c = new global::i(this);
			Console.WriteLine("圖書館:" + Global.bookManager.bookProviders.Count);
			this.m_d = new Dictionary<string, int[]>();
			List<string> list2 = new List<string>();
			MainWindow.m_t.Trace("MainWindow foreach bookProviders");
			foreach (KeyValuePair<string, BookProvider> bookProvider in Global.bookManager.bookProviders)
			{
				list2.Add(bookProvider.Key);
			}
			MainWindow.m_t.Trace("MainWindow foreach providerIds");
			foreach (string item in list2)
			{
				Global.bookManager.bookProviders[item].BookCoverReplaced += new EventHandler<ReplaceBookCoverEventArgs>(a);
				Global.bookManager.bookProviders[item].onlineBookListChangedByCategory += new EventHandler<OnlineBookListChangedByCategoryEventArgs>(a);
				Global.bookManager.bookProviders[item].bookMetadataFetched += new EventHandler<FetchBookMetadataResultEventArgs>(a);
			}
			List<string> loggedProviders = Global.bookManager.getLoggedProviders();
			Global.bookManager.loadExperienceBooksFromDB();
			this.m_n = loggedProviders.Count;
			foreach (string item2 in loggedProviders)
			{
				this.m_ac.Add(item2);
			}
			bf.libsButtonClickEvent += new LibsButtonClickEvent(libsButtonClickEvent);
			bf.libsContextMenuEvent += new LibsContextMenuEvent(a);
			a5.CategoryChanged += new CategoryChangedEvent(a);
			Global.bookManager.bookShelfFilterString = ((this.m_m.savefilterBookStr.Length < 11) ? (this.m_m.savefilterBookStr + "11") : this.m_m.savefilterBookStr);
			Global.bookManager.filterBook("all");
			DownloadManager downloadManager = Global.bookManager.downloadManager;
			downloadManager.DownloadProgressChanged = (EventHandler<DownloadProgressChangedEventArgs>)Delegate.Combine(downloadManager.DownloadProgressChanged, new EventHandler<DownloadProgressChangedEventArgs>(a));
			DownloadManager downloadManager2 = Global.bookManager.downloadManager;
			downloadManager2.SchedulingStateChanged = (EventHandler<SchedulingStateChangedEventArgs>)Delegate.Combine(downloadManager2.SchedulingStateChanged, new EventHandler<SchedulingStateChangedEventArgs>(a));
			f();
			bool flag = false;
			MainWindow.m_t.Trace("MainWindow if _request.checkNetworkStatus()");
			if (this.m_r.checkNetworkStatus() == NetworkStatusCode.OK)
			{
				MainWindow.m_t.Trace("Call setUpLibraryUI");
				h();
				flag = true;
				MainWindow.m_t.Trace("before loadUserBook()");
				q();
				MainWindow.m_t.Trace("after loadUserBook()");
				DispatcherTimer dispatcherTimer = new DispatcherTimer();
				dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 1, 0);
				dispatcherTimer.IsEnabled = true;
				dispatcherTimer.Tick += new EventHandler(a);
			}
			else
			{
				MainWindow.m_t.Trace(" this.Loaded += MainWindow_Loaded;");
				base.Loaded += new RoutedEventHandler(aj);
			}
			if (!this.m_n.Equals(0))
			{
				a0.IsChecked = true;
				aw.Visibility = Visibility.Collapsed;
				a2.SelectedIndex = 1;
				this.m_b = "BookShelf";
			}
			MainWindow.m_t.Trace("MainWindow if networkConnection");
			if (flag)
			{
				if (!Global.localDataPath.Equals("HyReadCN"))
				{
					g("http://ebook.hyread.com.tw/service/getServerTime.jsp");
				}
				else
				{
					g("http://ebook.hyread.com.cn/service/getServerTime.jsp");
				}
			}
			else
			{
				a0.IsChecked = true;
				aw.Visibility = Visibility.Collapsed;
				a2.SelectedIndex = 1;
				this.m_b = "BookShelf";
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnectPlease"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
				MainWindow.m_t.Trace("Call getLastUpdatedNetworkTime");
				long lastUpdatedNetworkTime = Global.bookManager.getLastUpdatedNetworkTime();
				Global.serverTime = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(Convert.ToDouble(lastUpdatedNetworkTime));
			}
			MainWindow.m_t.Trace("MainWindow switch (configMng.saveLanquage.ToUpper())");
			switch (this.m_m.saveLanquage.ToUpper())
			{
			case "ZH-TW":
				cn.SelectedIndex = 2;
				break;
			case "ZH-CN":
				cn.SelectedIndex = 1;
				break;
			case "EN-US":
				cn.SelectedIndex = 0;
				break;
			case "EN":
				cn.SelectedIndex = 0;
				break;
			}
			bw.filterEvent += new FilterEvent(c);
			MainWindow.m_t.Trace("constructed MainWindow");
			if (Global.regPath.Equals("NCLReader"))
			{
				bg.Visibility = Visibility.Collapsed;
				be.Visibility = Visibility.Collapsed;
				bx.Visibility = Visibility.Collapsed;
				a9.Visibility = Visibility.Collapsed;
				bb.Visibility = Visibility.Visible;
				av.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Assets/mainWindow/header-ncl_bg.png", UriKind.RelativeOrAbsolute));
			}
			if (Global.regPath.Equals("HyRead"))
			{
				b();
			}
		}

		private void a(object A_0, SessionEndingEventArgs A_1)
		{
			SystemEvents.PowerModeChanged -= new PowerModeChangedEventHandler(a);
			SystemEvents.SessionEnding -= new SessionEndingEventHandler(a);
			Global.bookManager.downloadManager.forceToPauseAllTasks();
		}

		private void a(object A_0, PowerModeChangedEventArgs A_1)
		{
			switch (A_1.Mode)
			{
			case PowerModes.StatusChange:
				break;
			case PowerModes.Resume:
				g();
				break;
			case PowerModes.Suspend:
				Global.bookManager.downloadManager.forceToPauseAllTasks();
				break;
			}
		}

		private void aj(object A_0, RoutedEventArgs A_1)
		{
			base.Loaded -= new RoutedEventHandler(aj);
			MainWindow.m_t.Trace("before loadUserBook()");
			q();
			MainWindow.m_t.Trace("after loadUserBook()");
		}

		private void a(object A_0, DownloadProgressChangedEventArgs A_1)
		{
			new List<string>();
			if (this.m_v == null || this.m_v.Count == 0)
			{
				return;
			}
			int count = this.m_v.Count;
			for (int i = 0; i < count; i++)
			{
				try
				{
					if (this.m_v[i].owner.Equals(A_1.ownerCode) && this.m_v[i].bookID.Equals(A_1.bookId))
					{
						string text = Global.bookManager.chineseSchedulingState(A_1.schedulingState);
						if (A_1.schedulingState == SchedulingState.DOWNLOADING)
						{
							text = text + "(" + (int)A_1.newProgress + "%)";
						}
						this.m_v[i].downloadStateStr = text;
						int obj = (int)A_1.newProgress % 10;
						if (!this.m_u.Equals(obj))
						{
							Global.bookManager.downloadProgressChange(A_1, i, text);
							this.m_u = obj;
						}
						return;
					}
				}
				catch
				{
				}
			}
		}

		private void a(object A_0, SchedulingStateChangedEventArgs A_1)
		{
			new List<string>();
			int count = this.m_v.Count;
			for (int i = 0; i < count; i++)
			{
				if (this.m_v[i].owner.Equals(A_1.ownerCode) && this.m_v[i].bookID.Equals(A_1.bookId))
				{
					this.m_v[i].downloadState = A_1.newSchedulingState;
					string downloadStateStr = Global.bookManager.chineseSchedulingState(A_1.newSchedulingState);
					this.m_v[i].downloadStateStr = downloadStateStr;
					if (A_1.newSchedulingState == SchedulingState.FINISHED)
					{
						this.m_v[i].downloadStateStr = "";
					}
					Global.bookManager.scheculeStateChange(A_1, i);
					break;
				}
			}
		}

		private void q()
		{
			List<BookThumbnail> list = new List<BookThumbnail>(Global.bookManager.bookShelf.Count);
			for (int i = 0; i < list.Capacity; i++)
			{
				BookThumbnail item = new BookThumbnail(Global.bookManager.LanqMng);
				list.Add(item);
			}
			this.m_v = new ObservableCollection<BookThumbnail>(list);
			b0.ItemsSource = this.m_v;
			b0.SelectedIndex = -1;
			int count = this.m_v.Count;
			for (int j = 0; j < count; j++)
			{
				UserBookMetadata userBookMetadata = Global.bookManager.bookShelf[j];
				int index = j;
				try
				{
					this.m_v[index].bookID = userBookMetadata.bookId;
					this.m_v[index].author = userBookMetadata.author;
					this.m_v[index].title = userBookMetadata.title;
					this.m_v[index].createDate = userBookMetadata.createDate;
					this.m_v[index].imgAddress = userBookMetadata.coverFullPath;
					this.m_v[index].publisher = userBookMetadata.publisher;
					this.m_v[index].publishDate = userBookMetadata.publishDate;
					this.m_v[index].editDate = userBookMetadata.editDate;
					this.m_v[index].mediaExists = userBookMetadata.mediaExists;
					this.m_v[index].mediaType = userBookMetadata.mediaTypes;
					this.m_v[index].author2 = userBookMetadata.author2;
					this.m_v[index].bookType = userBookMetadata.bookType;
					this.m_v[index].globalNo = userBookMetadata.globalNo;
					this.m_v[index].language = userBookMetadata.language;
					this.m_v[index].orientation = userBookMetadata.orientation;
					this.m_v[index].textDirection = userBookMetadata.textDirection;
					this.m_v[index].pageDirection = userBookMetadata.pageDirection;
					this.m_v[index].owner = userBookMetadata.owner;
					this.m_v[index].hyreadType = userBookMetadata.hyreadType;
					this.m_v[index].totalPages = userBookMetadata.totalPages;
					this.m_v[index].volume = userBookMetadata.volume;
					this.m_v[index].cover = userBookMetadata.cover;
					this.m_v[index].coverMD5 = userBookMetadata.coverMD5;
					this.m_v[index].fileSize = userBookMetadata.fileSize;
					this.m_v[index].epubFileSize = userBookMetadata.epubFileSize;
					this.m_v[index].hejFileSize = userBookMetadata.hejFileSize;
					this.m_v[index].phejFileSize = userBookMetadata.phejFileSize;
					this.m_v[index].UIPage = userBookMetadata.UIPage;
					this.m_v[index].vendorId = userBookMetadata.vendorId;
					this.m_v[index].userId = userBookMetadata.userId;
					this.m_v[index].downloadState = userBookMetadata.downloadState;
					this.m_v[index].loanStartTime = userBookMetadata.loanStartTime;
					this.m_v[index].loanDue = userBookMetadata.loanDue;
					this.m_v[index].loanState = userBookMetadata.loanState;
					this.m_v[index].diffDay = userBookMetadata.diffDay;
					this.m_v[index].downloadStateStr = userBookMetadata.downloadStateStr;
					this.m_v[index].canPrint = userBookMetadata.canPrint;
					this.m_v[index].canMark = userBookMetadata.canMark;
					this.m_v[index].kerchief = userBookMetadata.kerchief;
					this.m_v[index].isShowed = userBookMetadata.isShowed;
					this.m_v[index].coverFormat = userBookMetadata.coverFormat;
					this.m_v[index].keyDate = Convert.ToString(userBookMetadata.keyDate);
					this.m_v[index].colibId = userBookMetadata.colibId;
					this.m_v[index].lendId = userBookMetadata.lendId;
					this.m_v[index].renewDay = userBookMetadata.renewDay;
					this.m_v[index].contentServer = userBookMetadata.contentServer;
					this.m_v[index].ecourseOpen = userBookMetadata.ecourseOpen;
					this.m_v[index].ownerName = userBookMetadata.ownerName;
					this.m_v[index].assetUuid = userBookMetadata.assetUuid;
					this.m_v[index].s3Url = userBookMetadata.s3Url;
				}
				catch (Exception ex)
				{
					Console.WriteLine(ex.Message);
				}
			}
		}

		private void k(string A_0)
		{
			if (!curVendorId.Equals(A_0))
			{
				curVendorId = A_0;
				HyreadType hyreadType = Global.bookManager.bookProviders[curVendorId].hyreadType;
				if (!hyreadType.Equals(HyreadType.BOOK_STORE) && !curVendorId.Equals("ntl-ebookftp"))
				{
					bb.Visibility = Visibility.Visible;
				}
				else
				{
					bb.Visibility = Visibility.Collapsed;
				}
				Uri navigateUri = new Uri(b(Global.bookManager.bookProviders[curVendorId]), UriKind.RelativeOrAbsolute);
				ax.NavigateUri = navigateUri;
				p();
			}
		}

		private string b(BookProvider A_0)
		{
			string text = A_0.homePage + (A_0.homePage.EndsWith("/") ? "" : "/");
			if (A_0.loggedIn)
			{
				if (A_0.vendorId == "ntl-ebookftp")
				{
					text = text.Replace("&amp;", "");
					text = text.Replace("$account$", A_0.loginUserId);
					text = text.Replace("$password$", A_0.loginUserPassword);
				}
				else
				{
					string text2 = "";
					text2 = (Global.localDataPath.Equals("HyReadCN") ? j("http://ebook.hyread.com.cn/service/getServerTime.jsp") : j("http://ebook.hyread.com.tw/service/getServerTime.jsp"));
					string str = "<request>";
					str += "<action>login</action>";
					str = str + "<time><![CDATA[" + text2 + "]]></time>";
					object[] obj = new object[4]
					{
						str,
						"<hyreadtype>",
						null,
						null
					};
					HyreadType hyreadType = A_0.hyreadType;
					obj[2] = hyreadType.GetHashCode();
					obj[3] = "</hyreadtype>";
					str = string.Concat(obj);
					str = str + "<unit>" + A_0.vendorId + "</unit>";
					str = str + "<colibid>" + A_0.loginColibId + "</colibid>";
					str = str + "<account><![CDATA[" + A_0.loginUserId + "]]></account>";
					str = str + "<passwd><![CDATA[" + A_0.loginUserPassword + "]]></passwd>";
					str += "<guestIP></guestIP>";
					str += "</request>";
					byte[] bytes = Encoding.Default.GetBytes("hyweb101S00ebook");
					string str2 = Uri.EscapeDataString(new CACodecTools().stringEncode(str, bytes, true));
					text = text + "service/authCenter.jsp?data=" + str2;
				}
			}
			return text;
		}

		private string j(string A_0)
		{
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml("<body></body>");
			XmlDocument xmlDocument2 = this.m_r.postXMLAndLoadXML(A_0, xmlDocument);
			try
			{
				return xmlDocument2.InnerText;
			}
			catch
			{
				return "";
			}
		}

		private void p()
		{
			MainWindow.m_t.Trace("begin switchToLibrary");
			if (Global.bookManager.bookProviders.ContainsKey(curVendorId))
			{
				BookProvider bookProvider = Global.bookManager.bookProviders[curVendorId];
				if (bookProvider.loggedIn)
				{
					if (bookProvider.hyreadType == HyreadType.LIBRARY_CONSORTIUM)
					{
						bc.Content = this.m_a[2];
					}
					else
					{
						bc.Content = this.m_a[1];
					}
				}
				else
				{
					bc.Content = this.m_a[0];
					if (Global.bookManager.bookProviders[curVendorId].loginRequire.Equals("true"))
					{
						a5.ClearItems();
						this.m_c.b.Clear();
						BookThumbnail bookThumbnail = new BookThumbnail(Global.bookManager.LanqMng);
						bookThumbnail.bookID = "";
						bookThumbnail.title = Global.bookManager.LanqMng.getLangString("loginRequireMsg");
						bookThumbnail.author = "";
						bookThumbnail.publisher = "";
						bookThumbnail.imgAddress = "Assets/NoCover.jpg";
						this.m_c.b.Add(bookThumbnail);
						bi.ItemsSource = this.m_c.b;
						return;
					}
				}
				m();
				bookProvider.latestNewsFetched += new EventHandler<FetchLatestNewsResultEventArgs>(a);
				bookProvider.fetchLatestNewsAsync();
				bookProvider.categoriesFetched += new EventHandler<FetchCategoriesResultEventArgs>(a);
				bookProvider.fetchCategoriesAsync();
			}
			MainWindow.m_t.Trace("after switchToLibrary");
		}

		private void a(object A_0, FetchLatestNewsResultEventArgs A_1)
		{
			MainWindow.m_t.Trace("in latestNewsFetched");
			BookProvider obj = (BookProvider)A_0;
			obj.latestNewsFetched -= new EventHandler<FetchLatestNewsResultEventArgs>(a);
			if (obj.vendorId.Equals(curVendorId))
			{
				i(curVendorId);
			}
			MainWindow.m_t.Trace("out latestNewsFetched");
		}

		private void i(string A_0)
		{
			MainWindow.m_t.Trace("in setLatestNews");
			a method = new a(h);
			base.Dispatcher.Invoke(method, A_0);
			MainWindow.m_t.Trace("out setLatestNews");
		}

		private void h(string A_0)
		{
			MainWindow.m_t.Trace("in setLatestNewsDelegate");
			if (Global.bookManager.bookProviders.ContainsKey(A_0))
			{
				int num = 0;
				List<LatestNews> lastVendorNewsFromDB = Global.bookManager.GetLastVendorNewsFromDB(A_0);
				List<LatestNews> latestNews = Global.bookManager.bookProviders[A_0].latestNews;
				if (lastVendorNewsFromDB.Count.Equals(0))
				{
					DateTime dateTime = o();
					for (int i = 0; i < latestNews.Count; i++)
					{
						string text = "";
						text = "Insert into latest_news (id, url, title, is_readed, vendorId, insertTime)";
						text = text + " values('" + latestNews[i].id + "', '" + latestNews[i].url + "', '" + latestNews[i].title + "', " + latestNews[i].isReaded + ", '" + latestNews[i].vendorId + "', '" + dateTime.Date.ToString("yyyy/MM/dd") + "' );";
						if (!latestNews[i].isReaded)
						{
							num++;
						}
						Global.bookManager.UpdateLatestNewsInDB(text);
					}
				}
				else
				{
					List<LatestNews> list = new List<LatestNews>();
					for (int j = 0; j < latestNews.Count; j++)
					{
						bool flag = false;
						for (int k = 0; k < lastVendorNewsFromDB.Count; k++)
						{
							if (latestNews[j].id.Equals(lastVendorNewsFromDB[k].id))
							{
								flag = true;
								list.Add(lastVendorNewsFromDB[k]);
								break;
							}
						}
						if (!flag)
						{
							list.Insert(0, latestNews[j]);
						}
					}
					string query = "Delete from latest_news where vendorId='" + A_0 + "' ";
					Global.bookManager.UpdateLatestNewsInDB(query);
					DateTime dateTime2 = o();
					for (int l = 0; l < list.Count; l++)
					{
						string text2 = "";
						text2 = "Insert into latest_news (id, url, title, is_readed, vendorId, insertTime)";
						text2 = text2 + " values('" + list[l].id + "', '" + list[l].url + "', '" + list[l].title + "', " + list[l].isReaded + ", '" + list[l].vendorId + "', '" + dateTime2.Date.ToString("yyyy/MM/dd") + "' );";
						Global.bookManager.UpdateLatestNewsInDB(text2);
						if (!list[l].isReaded)
						{
							num++;
						}
					}
					Global.bookManager.bookProviders[A_0].latestNews = list;
				}
				if (!num.Equals(0))
				{
					ba.Text = Convert.ToString(num);
				}
				else
				{
					ba.Text = "";
				}
			}
			MainWindow.m_t.Trace("exit setLatestNewsDelegate");
		}

		private DateTime o()
		{
			long lastUpdatedNetworkTime = Global.bookManager.getLastUpdatedNetworkTime();
			return new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(Convert.ToDouble(lastUpdatedNetworkTime));
		}

		private DateTime n()
		{
			long lastUpdatedNetworkTime = Global.bookManager.getLastUpdatedNetworkTime();
			if (new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(Convert.ToDouble(lastUpdatedNetworkTime)).Subtract(DateTime.UtcNow) > this.m_w)
			{
				if (!Global.localDataPath.Equals("HyReadCN"))
				{
					g("http://ebook.hyread.com.tw/service/getServerTime.jsp");
				}
				else
				{
					g("http://ebook.hyread.com.cn/service/getServerTime.jsp");
				}
				return new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
			}
			return Global.serverTime;
		}

		private void g(string A_0)
		{
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml("<body></body>");
			HttpRequest httpRequest = new HttpRequest(this.m_p, this.m_q);
			httpRequest.xmlResponsed += new EventHandler<HttpResponseXMLEventArgs>(a);
			httpRequest.postXMLAndLoadXMLAsync(A_0, xmlDocument);
		}

		private void a(object A_0, HttpResponseXMLEventArgs A_1)
		{
			((HttpRequest)A_0).xmlResponsed -= new EventHandler<HttpResponseXMLEventArgs>(a);
			XmlDocument responseXML = A_1.responseXML;
			if (responseXML != null)
			{
				Global.serverTime = DateTime.Parse(responseXML.InnerText);
				DateTime value = new DateTime(1970, 1, 1);
				long currentTime = Global.serverTime.ToUniversalTime().Subtract(value).Ticks / 10000000;
				Global.bookManager.saveNetworkTime(currentTime);
			}
		}

		private void f(object A_0, MouseButtonEventArgs A_1)
		{
			if (br.Visibility.Equals(Visibility.Visible))
			{
				br.Visibility = Visibility.Collapsed;
			}
		}

		private void g(object A_0, SelectionChangedEventArgs A_1)
		{
			if (((ListBox)A_0).SelectedIndex >= 0)
			{
				LatestNews latestNews = (LatestNews)((ListBox)A_0).SelectedItem;
				latestNews.isReaded = true;
				string query = "Update latest_news set is_readed=True Where id='" + latestNews.id + "' ";
				Global.bookManager.UpdateLatestNewsInDB(query);
				h(latestNews.vendorId);
				if (!latestNews.url.Equals(""))
				{
					Process.Start(latestNews.url);
				}
			}
		}

		private void ai(object A_0, RoutedEventArgs A_1)
		{
			if (br.Visibility.Equals(Visibility.Visible))
			{
				br.Visibility = Visibility.Collapsed;
			}
			else if (!curVendorId.Equals("") && !Global.bookManager.bookProviders[curVendorId].latestNews.Count.Equals(0))
			{
				bt.ItemsSource = Global.bookManager.bookProviders[curVendorId].latestNews;
				br.Visibility = Visibility.Visible;
			}
		}

		private void ah(object A_0, RoutedEventArgs A_1)
		{
			if (be.Visibility == Visibility.Collapsed)
			{
				be.Visibility = Visibility.Visible;
				bh.IsChecked = true;
			}
			else
			{
				be.Visibility = Visibility.Collapsed;
				bh.IsChecked = false;
			}
		}

		private void ag(object A_0, RoutedEventArgs A_1)
		{
			Button button = A_0 as Button;
			string text = button.Tag.ToString();
			if (!text.StartsWith("Group") && !curVendorId.Equals(text))
			{
				ay.Text = button.Uid;
				if (Global.networkAvailable || isNetworkStatusConnected())
				{
					k(text);
				}
			}
		}

		public void libsButtonClickEvent(string clickItemId, string clickItemName)
		{
			if (!clickItemId.StartsWith("Group") && !curVendorId.Equals(clickItemId))
			{
				ay.Text = clickItemName;
				if (Global.networkAvailable || isNetworkStatusConnected())
				{
					k(clickItemId);
				}
			}
		}

		private void m()
		{
			this.m_c.b = new ObservableCollection<BookThumbnail>();
			bi.ItemsSource = this.m_c.b;
		}

		private void a(object A_0, FetchCategoriesResultEventArgs A_1)
		{
			MainWindow.m_t.Trace("in categoriesFethced");
			BookProvider obj = (BookProvider)A_0;
			obj.categoriesFetched -= new EventHandler<FetchCategoriesResultEventArgs>(a);
			if (obj.vendorId.Equals(curVendorId))
			{
				f(curVendorId);
			}
			MainWindow.m_t.Trace("out categoriesFethced");
		}

		private void f(string A_0)
		{
			MainWindow.m_t.Trace("in setCategoriesItem");
			b method = new b(e);
			base.Dispatcher.Invoke(method, A_0);
		}

		private void e(string A_0)
		{
			if (Global.bookManager.bookProviders.ContainsKey(A_0))
			{
				BookProvider bookProvider = Global.bookManager.bookProviders[A_0];
				a5.SetCategoryComboBoxItemSource(bookProvider.categories);
				a5.SelectedIndex = 0;
			}
		}

		private void f(object A_0, SelectionChangedEventArgs A_1)
		{
			if (a5.SelectedIndex < 0)
			{
				return;
			}
			int selectedIndex = a5.SelectedIndex;
			this.m_j = false;
			try
			{
				this.m_c.b.Clear();
				int num = Math.Min(maxBookPerPage, Global.bookManager.bookProviders[curVendorId].categories[selectedIndex].categoryCount);
				for (int i = 0; i < num; i++)
				{
					BookThumbnail item = new BookThumbnail(Global.bookManager.LanqMng);
					this.m_c.b.Add(item);
				}
				bi.ItemsSource = this.m_c.b;
			}
			catch
			{
			}
			DispatcherTimer dispatcherTimer = new DispatcherTimer();
			dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 100);
			dispatcherTimer.IsEnabled = true;
			dispatcherTimer.Tick += new EventHandler(h);
		}

		private void h(object A_0, EventArgs A_1)
		{
			DispatcherTimer obj = (DispatcherTimer)A_0;
			obj.Tick -= new EventHandler(h);
			obj.Stop();
			int selectedIndex = a5.SelectedIndex;
			if (Global.networkAvailable || isNetworkStatusConnected())
			{
				this.m_l = 1;
				Global.bookManager.bookProviders[curVendorId].fetchOnlineBookListAsync(this.m_k, 1, maxBookPerPage, selectedIndex);
			}
		}

		private void a(object A_0, OnlineBookListChangedEventArgs A_1)
		{
			if (!A_1.success)
			{
				Global.networkAvailable = isNetworkStatusConnected();
				return;
			}
			string vendorId = A_1.vendorId;
			int categoryIndex = A_1.categoryIndex;
			c method = new c(a);
			base.Dispatcher.Invoke(method, vendorId, categoryIndex);
		}

		private void a(string A_0, int A_1)
		{
			this.m_d.Clear();
			if (!curVendorId.Equals(A_0) || A_1 != a5.SelectedIndex)
			{
				return;
			}
			List<SimpleBookInfo> books = Global.bookManager.bookProviders[curVendorId].categories[A_1].books;
			int count = books.Count;
			this.m_c.b.Clear();
			if (count.Equals(0))
			{
				BookThumbnail bookThumbnail = new BookThumbnail(Global.bookManager.LanqMng);
				bookThumbnail.bookID = "";
				bookThumbnail.title = Global.bookManager.LanqMng.getLangString("noSearchResults");
				bookThumbnail.author = "";
				bookThumbnail.publisher = "";
				bookThumbnail.imgAddress = "Assets/NoCover.jpg";
				this.m_c.b.Add(bookThumbnail);
			}
			else
			{
				for (int i = 0; i < count; i++)
				{
					if (A_1 != a5.SelectedIndex)
					{
						return;
					}
					if (i < this.m_c.b.Count)
					{
						this.m_c.b[i] = new BookThumbnail(Global.bookManager.LanqMng);
					}
					else
					{
						BookThumbnail bookThumbnail2 = new BookThumbnail(Global.bookManager.LanqMng);
						bookThumbnail2.bookID = books[i].bookId;
						bookThumbnail2.title = books[i].title;
						bookThumbnail2.author = books[i].author;
						bookThumbnail2.publisher = books[i].publisher;
						bookThumbnail2.imgAddress = c(books[i].coverPath, books[i].bookId);
						this.m_c.b.Add(bookThumbnail2);
					}
					if (!this.m_d.ContainsKey(books[i].bookId))
					{
						this.m_d.Add(books[i].bookId, new int[3]
						{
							i,
							0,
							0
						});
					}
					if (Global.bookManager.bookProviders[curVendorId].cacheBookList.books.ContainsKey(books[i].bookId))
					{
						a(books[i].bookId, i, Global.bookManager.bookProviders[curVendorId].cacheBookList.books[books[i].bookId]);
					}
				}
			}
			bi.ItemsSource = this.m_c.b;
			this.m_j = true;
		}

		private void a(Category A_0)
		{
			try
			{
				this.m_c.b.Clear();
				int num = Math.Min(maxBookPerPage, A_0.categoryCount);
				for (int i = 0; i < num; i++)
				{
					BookThumbnail item = new BookThumbnail(Global.bookManager.LanqMng);
					this.m_c.b.Add(item);
				}
				bi.ItemsSource = this.m_c.b;
			}
			catch
			{
			}
			DispatcherTimer dispatcherTimer = new DispatcherTimer();
			dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 100);
			dispatcherTimer.IsEnabled = true;
			dispatcherTimer.Tag = A_0;
			dispatcherTimer.Tick += new EventHandler(g);
		}

		private void g(object A_0, EventArgs A_1)
		{
			DispatcherTimer obj = (DispatcherTimer)A_0;
			obj.Tick -= new EventHandler(h);
			obj.Stop();
			Category category = (Category)obj.Tag;
			this.m_l = 1;
			Global.bookManager.bookProviders[curVendorId].fetchOnlineBookListAsync(this.m_k, 1, maxBookPerPage, category);
		}

		private void a(object A_0, OnlineBookListChangedByCategoryEventArgs A_1)
		{
			if (A_1.success)
			{
				string totalCount = A_1.totalCount;
				string vendorId = A_1.vendorId;
				Category category = A_1.category;
				d method = new d(a);
				base.Dispatcher.Invoke(method, vendorId, category, totalCount);
			}
		}

		private void a(string A_0, Category A_1, string A_2)
		{
			this.m_d.Clear();
			if (!curVendorId.Equals(A_0) || A_1 != a5.SelectedItem)
			{
				return;
			}
			List<SimpleBookInfo> books = A_1.books;
			int count = books.Count;
			this.m_c.b.Clear();
			if (count.Equals(0))
			{
				BookThumbnail bookThumbnail = new BookThumbnail(Global.bookManager.LanqMng);
				bookThumbnail.bookID = "";
				bookThumbnail.title = Global.bookManager.LanqMng.getLangString("noSearchResults");
				bookThumbnail.author = "";
				bookThumbnail.publisher = "";
				bookThumbnail.imgAddress = "Assets/NoCover.jpg";
				this.m_c.b.Add(bookThumbnail);
			}
			else
			{
				for (int i = 0; i < count; i++)
				{
					if (A_1 != a5.SelectedItem)
					{
						return;
					}
					if (i < this.m_c.b.Count)
					{
						this.m_c.b[i] = new BookThumbnail(Global.bookManager.LanqMng);
					}
					else
					{
						BookThumbnail bookThumbnail2 = new BookThumbnail(Global.bookManager.LanqMng);
						bookThumbnail2.bookID = books[i].bookId;
						bookThumbnail2.title = books[i].title;
						bookThumbnail2.author = books[i].author;
						bookThumbnail2.publisher = books[i].publisher;
						bookThumbnail2.vendorId = curVendorId;
						bookThumbnail2.imgAddress = c(books[i].coverPath, books[i].bookId);
						this.m_c.b.Add(bookThumbnail2);
					}
					if (!this.m_d.ContainsKey(books[i].bookId))
					{
						this.m_d.Add(books[i].bookId, new int[3]
						{
							i,
							0,
							0
						});
					}
					if (Global.bookManager.bookProviders[curVendorId].cacheBookList.books.ContainsKey(books[i].bookId))
					{
						a(books[i].bookId, i, Global.bookManager.bookProviders[curVendorId].cacheBookList.books[books[i].bookId]);
					}
				}
			}
			bi.ItemsSource = this.m_c.b;
			this.m_j = true;
			if (!Global.regPath.Equals("NCLReader") && this.m_x && !a7.Text.Equals(""))
			{
				this.m_x = false;
				this.m_y = Convert.ToInt16(A_2);
				string langString = Global.bookManager.LanqMng.getLangString("tatalSearched");
				string langString2 = Global.bookManager.LanqMng.getLangString("book");
				ct.Text = string.Format(langString + " " + A_2 + " " + langString2);
				double left = (SystemParameters.PrimaryScreenWidth - cs.Width) / 2.0;
				double top = (SystemParameters.PrimaryScreenHeight - cs.Height) / 2.0;
				cs.Margin = new Thickness(left, top, 0.0, 0.0);
				cr.Visibility = Visibility.Visible;
				l();
			}
		}

		private void l()
		{
			this.m_z.Interval = new TimeSpan(0, 0, 0, 0, 2000);
			this.m_z.Tick += new EventHandler(f);
			this.m_z.Start();
		}

		private void f(object A_0, EventArgs A_1)
		{
			this.m_z.Stop();
			cr.Visibility = Visibility.Collapsed;
		}

		private void a(object A_0, TextChangedEventArgs A_1)
		{
			this.m_x = true;
			this.m_k = a7.Text;
		}

		private void a(object A_0, KeyEventArgs A_1)
		{
			this.m_x = true;
			if (A_1.Key == Key.Return)
			{
				af(A_0, A_1);
			}
		}

		private void c(object A_0, MouseEventArgs A_1)
		{
		}

		private void af(object A_0, RoutedEventArgs A_1)
		{
			this.m_x = true;
			if (this.m_c.b.Count > 0)
			{
				k();
			}
		}

		private void k()
		{
			Category tag = (Category)a5.SelectedItem;
			try
			{
				this.m_c.b.Clear();
				bi.ItemsSource = this.m_c.b;
			}
			catch
			{
			}
			this.m_l = 1;
			DispatcherTimer dispatcherTimer = new DispatcherTimer();
			dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 100);
			dispatcherTimer.IsEnabled = true;
			dispatcherTimer.Tag = tag;
			dispatcherTimer.Tick += new EventHandler(e);
		}

		private void e(object A_0, EventArgs A_1)
		{
			DispatcherTimer obj = (DispatcherTimer)A_0;
			obj.Tick -= new EventHandler(e);
			obj.Stop();
			Category category = (Category)a5.SelectedItem;
			this.m_k = a7.Text;
			Global.bookManager.bookProviders[curVendorId].fetchOnlineBookListAsync(this.m_k, this.m_l, maxBookPerPage, category);
		}

		private void a(object A_0, ScrollChangedEventArgs A_1)
		{
			ScrollViewer scrollViewer = (ScrollViewer)A_0;
			if (scrollViewer.VerticalOffset.Equals(0.0) || scrollViewer.VerticalOffset != scrollViewer.ScrollableHeight)
			{
				return;
			}
			int num = maxBookPerPage * this.m_l;
			if (a7.Text.Equals(""))
			{
				int categoryCount = ((Category)a5.SelectedItem).categoryCount;
				if (categoryCount < maxBookPerPage || num >= categoryCount)
				{
					return;
				}
				this.m_l++;
				DispatcherTimer dispatcherTimer = new DispatcherTimer();
				dispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 100);
				dispatcherTimer.IsEnabled = true;
				dispatcherTimer.Tick += new EventHandler(e);
				int val = maxBookPerPage * this.m_l;
				bl.Text = Global.bookManager.LanqMng.getLangString("the") + Math.Min(val, categoryCount) + Global.bookManager.LanqMng.getLangString("book") + " / ";
				bm.Text = Global.bookManager.LanqMng.getLangString("total") + categoryCount + Global.bookManager.LanqMng.getLangString("book");
			}
			else
			{
				int count = this.m_c.b.Count;
				if (count < maxBookPerPage || num > count)
				{
					return;
				}
				this.m_l++;
				DispatcherTimer dispatcherTimer2 = new DispatcherTimer();
				dispatcherTimer2.Interval = new TimeSpan(0, 0, 0, 0, 100);
				dispatcherTimer2.IsEnabled = true;
				dispatcherTimer2.Tick += new EventHandler(e);
				bl.Text = Global.bookManager.LanqMng.getLangString("findMoreBook");
				bm.Text = ((this.m_y > 0) ? string.Format(" ( {0} ) ", this.m_y) : "");
			}
			bj.Visibility = Visibility.Visible;
			DispatcherTimer dispatcherTimer3 = new DispatcherTimer();
			dispatcherTimer3.Interval = new TimeSpan(0, 0, 0, 5, 0);
			dispatcherTimer3.IsEnabled = true;
			dispatcherTimer3.Tick += new EventHandler(d);
		}

		private void d(object A_0, EventArgs A_1)
		{
			DispatcherTimer obj = (DispatcherTimer)A_0;
			obj.Tick -= new EventHandler(d);
			obj.Stop();
			if (bj.Visibility == Visibility.Visible)
			{
				bj.Visibility = Visibility.Collapsed;
			}
		}

		private string c(string A_0, string A_1)
		{
			string coverFullPath = this.m_i.getCoverFullPath(A_1);
			string text = Global.bookManager.bookProviders[curVendorId].homePage + "/bookcover/" + A_0;
			if (A_0.StartsWith("http"))
			{
				text = A_0;
			}
			if (File.Exists(coverFullPath))
			{
				return coverFullPath;
			}
			if (curVendorId == "ntl-ebookftp")
			{
				string resourceUri = Global.bookManager.bookProviders[curVendorId].serviceBaseUrl + "/book/" + A_1 + "/cover";
				string postXMLString = "<body><account></account></body>";
				FileDownloader fileDownloader = new FileDownloader(resourceUri, coverFullPath, postXMLString);
				fileDownloader.setProxyPara(this.m_p, this.m_q);
				fileDownloader.downloadStateChanged += new EventHandler<FileDownloaderStateChangedEventArgs>(b);
				fileDownloader.startDownload();
				return "Assets/NoCover.jpg";
			}
			FileDownloader fileDownloader2 = new FileDownloader(text, coverFullPath);
			fileDownloader2.setProxyPara(this.m_p, this.m_q);
			fileDownloader2.downloadStateChanged += new EventHandler<FileDownloaderStateChangedEventArgs>(b);
			fileDownloader2.startDownload();
			return text;
		}

		private void b(object A_0, FileDownloaderStateChangedEventArgs A_1)
		{
			if (!A_1.newDownloaderState.Equals(FileDownloaderState.FINISHED))
			{
				return;
			}
			FileDownloader fileDownloader = (FileDownloader)A_0;
			fileDownloader.downloadStateChanged -= new EventHandler<FileDownloaderStateChangedEventArgs>(b);
			string text = A_1.filename.Replace(".jpg", "");
			for (int i = 0; i < this.m_c.b.Count; i++)
			{
				if (this.m_c.b[i].bookID.Equals(text))
				{
					this.m_c.b[i].imgAddress = A_1.destinationPath;
					break;
				}
			}
			fileDownloader.Dispose();
			fileDownloader = null;
			this.m_aa.Remove(text);
			this.m_ab = false;
			if (this.m_aa.Count <= 0 || this.m_ab)
			{
				return;
			}
			using (Dictionary<string, FileDownloader>.Enumerator enumerator = this.m_aa.GetEnumerator())
			{
				if (enumerator.MoveNext())
				{
					KeyValuePair<string, FileDownloader> current = enumerator.Current;
					this.m_ab = true;
					current.Value.downloadStateChanged += new EventHandler<FileDownloaderStateChangedEventArgs>(b);
					current.Value.startDownload();
				}
			}
		}

		private void c(object A_0, EventArgs A_1)
		{
			((DispatcherTimer)A_0).Stop();
			i();
		}

		private bool j()
		{
			try
			{
				foreach (KeyValuePair<string, int[]> item in this.m_d)
				{
					int num = item.Value[0];
					int num2 = item.Value[1];
					if (num >= this.m_c.b.Count)
					{
						return false;
					}
					if (this.m_c.b[num].bookID == null && num2 != 1)
					{
						this.m_d[item.Key][1] = 1;
						Global.bookManager.bookProviders[curVendorId].fetchBookMetadataAsync(item.Key);
						if (++this.m_g >= this.m_e)
						{
							return true;
						}
					}
				}
			}
			catch
			{
				return false;
			}
			return false;
		}

		private void i()
		{
			foreach (KeyValuePair<string, int[]> item in this.m_d)
			{
				string key = item.Key;
				int num = item.Value[0];
				int num2 = item.Value[2];
				if (num >= this.m_c.b.Count)
				{
					break;
				}
				if (this.m_c.b[num].imgAddress == "Assets/NoCover.jpg" && num2 != 1)
				{
					this.m_d[item.Key][2] = 1;
					string a_ = "http://openebook.hyread.com.tw/hyreadipadservice2/demo/book/" + key + "/cover?userId=123&coverType=s";
					if (Global.localDataPath.Equals("HyReadCN"))
					{
						a_ = "https://service.ebook.hyread.com.cn/hyreadipadservice2/democn/book/" + key + "/cover?userId=123&coverType=s";
					}
					a(item.Key, a_, this.m_i.getCoverFullPath(key));
					if (++this.m_h >= this.m_f)
					{
						break;
					}
				}
			}
		}

		private void a(object A_0, FetchBookMetadataResultEventArgs A_1)
		{
			MainWindow.m_t.Trace("begin bookMetadataFetchedHandler");
			this.m_g--;
			if (!this.m_j)
			{
				return;
			}
			if (!A_1.success && this.m_r.checkNetworkStatus() != 0)
			{
				Global.networkAvailable = false;
			}
			string bookId = A_1.bookId;
			j();
			if (this.m_d.ContainsKey(bookId))
			{
				int num = this.m_d[bookId][0];
				this.m_d[bookId][1] = 0;
				if (num >= this.m_c.b.Count)
				{
					return;
				}
				OnlineBookMetadata bookMetadata = A_1.bookMetadata;
				a(bookId, num, bookMetadata);
			}
			MainWindow.m_t.Trace("after bookMetadataFetchedHandler");
		}

		private void a(string A_0, int A_1, OnlineBookMetadata A_2)
		{
			if (this.m_c.b[A_1].bookID != null && !this.m_c.b[A_1].bookID.Equals(A_0))
			{
				return;
			}
			this.m_c.b[A_1].bookID = A_0;
			this.m_c.b[A_1].author = A_2.author;
			this.m_c.b[A_1].description = A_2.description;
			this.m_c.b[A_1].title = A_2.title;
			this.m_c.b[A_1].createDate = A_2.createDate;
			this.m_c.b[A_1].publisher = A_2.publisher;
			this.m_c.b[A_1].publishDate = A_2.publishDate;
			this.m_c.b[A_1].editDate = A_2.editDate;
			this.m_c.b[A_1].mediaExists = A_2.mediaExists;
			this.m_c.b[A_1].mediaType = A_2.mediaTypes;
			this.m_c.b[A_1].copy = A_2.copy;
			this.m_c.b[A_1].reserveCount = A_2.reserveCount;
			this.m_c.b[A_1].availableCount = A_2.availableCount;
			this.m_c.b[A_1].recommendCount = A_2.recommendCount;
			this.m_c.b[A_1].starCount = A_2.starCount;
			this.m_c.b[A_1].price = A_2.price;
			this.m_c.b[A_1].trialPage = A_2.trialPage;
			this.m_c.b[A_1].format = A_2.format;
			this.m_c.b[A_1].colibId = A_2.colibId;
			try
			{
				if (!Global.bookManager.bookProviders[curVendorId].cacheBookList.books.ContainsKey(A_0))
				{
					Global.bookManager.bookProviders[curVendorId].cacheBookList.books.Add(A_0, A_2);
				}
			}
			catch
			{
			}
		}

		private void a(object A_0, NotifyCollectionChangedEventArgs A_1)
		{
			throw new NotImplementedException();
		}

		private void ae(object A_0, RoutedEventArgs A_1)
		{
			if (curVendorId.Length.Equals(0))
			{
				return;
			}
			if (bc.Content.Equals(this.m_a[1]))
			{
				if (MessageBox.Show(Global.bookManager.LanqMng.getLangString("sureLogout"), Global.bookManager.LanqMng.getLangString("preLogout"), MessageBoxButton.YesNo, MessageBoxImage.Question).Equals(MessageBoxResult.Yes))
				{
					d(curVendorId);
					bc.Content = this.m_a[0];
					if (Global.bookManager.bookProviders[curVendorId].loginRequire.Equals("true"))
					{
						p();
					}
				}
			}
			else if (bc.Content.Equals(this.m_a[0]))
			{
				if (!Global.bookManager.bookProviders.Count.Equals(0))
				{
					if (Global.bookManager.bookProviders[curVendorId].loginMethod.Equals("webSSO"))
					{
						SSOcefSharp sSOcefSharp = new SSOcefSharp(curVendorId, Global.bookManager.bookProviders[curVendorId].loginApi);
						sSOcefSharp.Closing += new CancelEventHandler(c);
						sSOcefSharp.ShowDialog();
					}
					else
					{
						loginPage loginPage = new loginPage(curVendorId);
						loginPage.Closing += new CancelEventHandler(b);
						loginPage.Owner = this;
						loginPage.ShowDialog();
					}
				}
			}
			else
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("unionCannotLogout"), Global.bookManager.LanqMng.getLangString("logged"), MessageBoxButton.OK);
			}
		}

		private void d(string A_0)
		{
			Global.bookManager.logout(A_0);
			MessageBox.Show(Global.bookManager.LanqMng.getLangString("logoutLoseBook"), Global.bookManager.LanqMng.getLangString("loggedOut") + Global.bookManager.bookProviders[A_0].name, MessageBoxButton.OK, MessageBoxImage.Exclamation);
			this.m_ac.Clear();
			foreach (string loggedProvider in Global.bookManager.getLoggedProviders())
			{
				this.m_ac.Add(loggedProvider);
			}
			this.m_o = true;
			if (Global.bookManager.bookProviders[curVendorId].loginRequire.Equals("true"))
			{
				p();
			}
		}

		private void c(object A_0, CancelEventArgs A_1)
		{
			((SSOcefSharp)A_0).Closing -= new CancelEventHandler(c);
			if (((SSOcefSharp)A_0).isCancelled)
			{
				return;
			}
			BookProvider bookProvider = Global.bookManager.bookProviders[curVendorId];
			if (bookProvider.loggedIn)
			{
				HyreadType hyreadType = bookProvider.hyreadType;
				if (hyreadType.GetHashCode().Equals(3))
				{
					bc.Content = this.m_a[2];
					MessageBox.Show(Global.bookManager.LanqMng.getLangString("loginSuccess"), bookProvider.name, MessageBoxButton.OK);
				}
				else
				{
					bc.Content = this.m_a[1];
					MessageBox.Show(Global.bookManager.LanqMng.getLangString("loginSuccess"), bookProvider.name, MessageBoxButton.OK);
				}
				this.m_ac.Clear();
				foreach (string loggedProvider in Global.bookManager.getLoggedProviders())
				{
					this.m_ac.Add(loggedProvider);
				}
				this.m_o = true;
				if (Global.bookManager.bookProviders[curVendorId].loginRequire.Equals("true"))
				{
					p();
				}
			}
			else
			{
				bc.Content = this.m_a[0];
			}
		}

		private void b(object A_0, CancelEventArgs A_1)
		{
			((loginPage)A_0).Closing -= new CancelEventHandler(b);
			if (((loginPage)A_0).isCancelled)
			{
				return;
			}
			BookProvider bookProvider = Global.bookManager.bookProviders[curVendorId];
			if (bookProvider.loggedIn)
			{
				HyreadType hyreadType = bookProvider.hyreadType;
				if (hyreadType.GetHashCode().Equals(3))
				{
					bc.Content = this.m_a[2];
					MessageBox.Show(Global.bookManager.LanqMng.getLangString("loginSuccess"), bookProvider.name, MessageBoxButton.OK);
				}
				else
				{
					bc.Content = this.m_a[1];
					MessageBox.Show(Global.bookManager.LanqMng.getLangString("loginSuccess"), bookProvider.name, MessageBoxButton.OK);
				}
				this.m_ac.Clear();
				foreach (string loggedProvider in Global.bookManager.getLoggedProviders())
				{
					this.m_ac.Add(loggedProvider);
				}
				foreach (UserBookMetadata item in Global.bookManager.getUserBookFromDB(bookProvider.loginVenderId, bookProvider.loginColibId, bookProvider.loginUserId))
				{
					Global.bookManager.bookShelf.Insert(0, item);
				}
				this.m_o = true;
				bf.addFavLibs(curVendorId);
				if (Global.bookManager.bookProviders[curVendorId].loginRequire.Equals("true"))
				{
					p();
				}
			}
			else
			{
				bc.Content = this.m_a[0];
			}
		}

		public bool isNetworkStatusConnected()
		{
			bool flag = false;
			string str = "";
			while (!flag)
			{
				switch (this.m_r.checkNetworkStatus(""))
				{
				case NetworkStatusCode.OK:
					break;
				case NetworkStatusCode.WIFI_NEEDS_LOGIN:
					flag = false;
					str = Global.bookManager.LanqMng.getLangString("wifiNotLogged");
					goto IL_0083;
				case NetworkStatusCode.SERVICE_NOT_AVAILABLE:
					flag = false;
					str = Global.bookManager.LanqMng.getLangString("offlineServer");
					goto IL_0083;
				case NetworkStatusCode.NO_NETWORK:
					flag = false;
					str = Global.bookManager.LanqMng.getLangString("noNetwork");
					goto IL_0083;
				default:
					goto IL_0083;
				}
				flag = true;
				Global.networkAvailable = true;
				break;
				IL_0083:
				if (!MessageBox.Show(str + "，" + Global.bookManager.LanqMng.getLangString("tryAgain"), Global.bookManager.LanqMng.getLangString("netProblems"), MessageBoxButton.YesNo, MessageBoxImage.Exclamation).Equals(MessageBoxResult.Yes))
				{
					return false;
				}
			}
			return true;
		}

		private void ad(object A_0, RoutedEventArgs A_1)
		{
			if (this.m_r.checkNetworkStatus() != 0)
			{
				az.IsChecked = false;
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("cannotViewLibrary"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
				return;
			}
			a2.SelectedIndex = 0;
			aw.Visibility = Visibility.Visible;
			this.m_b = "Library";
			if (bi.Items.Count.Equals(0))
			{
				this.m_b = "BookShelf";
				h();
			}
		}

		private void h()
		{
			if (!this.m_b.Equals("Library"))
			{
				this.m_b = "Library";
				az.IsChecked = true;
				bc.Visibility = Visibility.Visible;
				a5.Visibility = Visibility.Visible;
				bh.Visibility = Visibility.Visible;
				be.Visibility = Visibility.Visible;
				a4.Visibility = Visibility.Visible;
				aw.Visibility = Visibility.Visible;
				p();
			}
		}

		private void ac(object A_0, RoutedEventArgs A_1)
		{
			a2.SelectedIndex = 1;
			aw.Visibility = Visibility.Collapsed;
			this.m_b = "BookShelf";
			if (this.m_o)
			{
				an.Visibility = Visibility.Visible;
				ao.Text = Global.bookManager.LanqMng.getLangString("updateBookcase");
				if (this.m_r.checkNetworkStatus() != 0)
				{
					MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetPlease"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
					an.Visibility = Visibility.Collapsed;
					return;
				}
				this.m_ac = Global.bookManager.getLoggedProviders();
				foreach (string item in this.m_ac)
				{
					BookProvider bookProvider = Global.bookManager.bookProviders[item];
					if (bookProvider.loggedIn)
					{
						bookProvider.userBooksFetched += new EventHandler<FetchUserBookResultEventArgs>(a);
						bookProvider.fetchUserBookAsync();
						UpdatingBookProviders++;
					}
				}
				if (UpdatingBookProviders.Equals(0))
				{
					q();
					an.Visibility = Visibility.Collapsed;
				}
				else
				{
					TotalUpdatingBookProviders = UpdatingBookProviders;
					ao.Text = ao.Text;
				}
				this.m_o = false;
			}
			else
			{
				g();
			}
		}

		private void b(object A_0, MouseEventArgs A_1)
		{
		}

		private void a(object A_0, MouseEventArgs A_1)
		{
			Grid grid = A_0 as Grid;
			Console.WriteLine("ID:" + grid.Tag);
		}

		public void _closeEvent(BookType _bookType, object bookinfo, int curTrialPage)
		{
			try
			{
				if (!_bookType.Equals(BookType.HEJ) && !_bookType.Equals(BookType.PHEJ) && !_bookType.Equals(BookType.EPUB))
				{
					return;
				}
				BookThumbnail bookThumbnail = (BookThumbnail)bookinfo;
				string text = "";
				if (curTrialPage > 0)
				{
					text = new LocalFilesManager(Global.localDataPath, "tryread", "tryread", "tryread").getUserBookPath(bookThumbnail.bookID, _bookType.GetHashCode(), bookThumbnail.owner);
				}
				else
				{
					text = new LocalFilesManager(Global.localDataPath, bookThumbnail.vendorId, bookThumbnail.colibId, bookThumbnail.userId).getUserBookPath(bookThumbnail.bookID, _bookType.GetHashCode(), bookThumbnail.owner);
					b(bookinfo);
				}
				if (!_bookType.Equals(BookType.EPUB))
				{
					bool flag = File.Exists(text + "\\book.xml");
					bool flag2 = File.Exists(text + "\\HYWEB\\thumbs\\thumbs_ok");
					bool flag3 = File.Exists(text + "\\HYWEB\\infos_ok");
					bool flag4 = File.Exists(text + "\\HYWEB\\encryption.xml");
					while (!(flag && flag2 && flag3 && flag4))
					{
						Thread.Sleep(500);
						flag = File.Exists(text + "\\book.xml");
						flag2 = File.Exists(text + "\\HYWEB\\thumbs\\thumbs_ok");
						flag3 = File.Exists(text + "\\HYWEB\\infos_ok");
						flag4 = File.Exists(text + "\\HYWEB\\encryption.xml");
						if (closedByCancelButton)
						{
							break;
						}
					}
				}
				else
				{
					bool flag5 = File.Exists(text + "\\epubs_ok");
					while (!flag5)
					{
						Thread.Sleep(500);
						flag5 = File.Exists(text + "\\epubs_ok");
						if (closedByCancelButton)
						{
							break;
						}
					}
				}
				bookThumbnail = null;
			}
			catch (Exception)
			{
			}
		}

		private void b(object A_0)
		{
			BookThumbnail bookThumbnail = (BookThumbnail)A_0;
			if (bookThumbnail.vendorId.Equals("free"))
			{
				return;
			}
			int userBookSno = Global.bookManager.getUserBookSno(bookThumbnail.vendorId, bookThumbnail.colibId, bookThumbnail.userId, bookThumbnail.bookID);
			foreach (KeyValuePair<string, object> item in this.m_af)
			{
				string key = item.Key;
				AbstractSyncManager syncManager = (AbstractSyncManager)Activator.CreateInstance(typeof(SyncManager<>).MakeGenericType(item.Value.GetType()), "https://cloudservice.ebook.hyread.com.tw/DataService/1/classes/", bookThumbnail.userId, bookThumbnail.vendorId, bookThumbnail.bookID, userBookSno, key, this.m_m.saveProxyMode, this.m_m.saveProxyHttpPort);
				Global.syncCenter.addSyncConditions(key, syncManager);
			}
		}

		private void a(object A_0)
		{
			BookThumbnail bookThumbnail = (BookThumbnail)A_0;
			if (bookThumbnail.vendorId.Equals("free"))
			{
				return;
			}
			int userBookSno = Global.bookManager.getUserBookSno(bookThumbnail.vendorId, bookThumbnail.colibId, bookThumbnail.userId, bookThumbnail.bookID);
			foreach (KeyValuePair<string, object> item in this.m_ag)
			{
				string key = item.Key;
				AbstractSyncManager syncManager = (AbstractSyncManager)Activator.CreateInstance(typeof(SyncManager<>).MakeGenericType(item.Value.GetType()), "https://cloudservice.ebook.hyread.com.tw/DataService/1/classes/", bookThumbnail.userId, bookThumbnail.vendorId, bookThumbnail.bookID, userBookSno, key, this.m_m.saveProxyMode, this.m_m.saveProxyHttpPort);
				Global.syncCenter.addSyncConditions(key, syncManager);
			}
		}

		private void e(object A_0, SelectionChangedEventArgs A_1)
		{
			i i = new i();
			i.a = this;
			i.b = (BookThumbnail)bi.SelectedItem;
			if (i.b == null || !(i.b.bookID != ""))
			{
				return;
			}
			bookDetailPopUp bookDetailPopUp = new bookDetailPopUp(bi.SelectedItem, this.m_b, curVendorId);
			bookDetailPopUp.configMng = this.m_m;
			Matrix transformToDevice = PresentationSource.FromVisual(Application.Current.MainWindow).CompositionTarget.TransformToDevice;
			double num = transformToDevice.M11 * 96.0;
			double m2 = transformToDevice.M22;
			if (((num == 96.0) ? 100 : ((num == 120.0) ? 125 : 150)) > 100)
			{
				bookDetailPopUp.WindowStartupLocation = WindowStartupLocation.Manual;
			}
			if (bookDetailPopUp.IsVisible)
			{
				bookDetailPopUp.Close();
			}
			else
			{
				bookDetailPopUp.Owner = this;
				bookDetailPopUp.ShowDialog();
				if (bookDetailPopUp.closeReason == BookDetailPopUpCloseReason.REQUIRELOGIN)
				{
					ae(A_0, A_1);
				}
				else if (bookDetailPopUp.closeReason == BookDetailPopUpCloseReason.LENDBOOK)
				{
					this.m_o = true;
				}
				else if (bookDetailPopUp.closeReason != 0 && (bookDetailPopUp.closeReason == BookDetailPopUpCloseReason.TRYREADHEJ || bookDetailPopUp.closeReason == BookDetailPopUpCloseReason.TRYREADPHEJ || bookDetailPopUp.closeReason == BookDetailPopUpCloseReason.TRYREADEPUB))
				{
					j j = new j();
					j.b = i;
					j.a = BookType.UNKNOWN;
					MainWindow.ae = new e(_closeEvent);
					bool flag = false;
					if (bookDetailPopUp.closeReason == BookDetailPopUpCloseReason.TRYREADHEJ)
					{
						j.a = BookType.HEJ;
						flag = true;
					}
					else if (bookDetailPopUp.closeReason == BookDetailPopUpCloseReason.TRYREADPHEJ)
					{
						j.a = BookType.PHEJ;
						flag = true;
					}
					else if (bookDetailPopUp.closeReason == BookDetailPopUpCloseReason.TRYREADEPUB)
					{
						j.a = BookType.EPUB;
						flag = true;
					}
					if (!flag || this.m_r.checkNetworkStatus() == NetworkStatusCode.OK)
					{
						k k = new k();
						k.b = j;
						string bookID = k.b.b.b.bookID;
						int trialPages = bookDetailPopUp.trialPages;
						k.a = bi.SelectedItem;
						AsyncCallback a_ = new AsyncCallback(k.c);
						MainWindow.ae.BeginInvoke(k.b.a, k.a, trialPages, a_, null);
						ao.Text = Global.bookManager.LanqMng.getLangString("downloading");
						an.Visibility = Visibility.Visible;
						ap.Visibility = Visibility.Visible;
					}
				}
			}
			bi.SelectedIndex = -1;
			bookDetailPopUp = null;
		}

		private void ab(object A_0, RoutedEventArgs A_1)
		{
			closedByCancelButton = true;
		}

		private void d(object A_0, SelectionChangedEventArgs A_1)
		{
			l l = new l();
			l.a = this;
			l.b = (BookThumbnail)b0.SelectedItem;
			if (l.b == null || l.b.bookID == null)
			{
				return;
			}
			if (n().Equals(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)) && MessageBox.Show(Global.bookManager.LanqMng.getLangString("resetSystemTime"), Global.bookManager.LanqMng.getLangString("warning"), MessageBoxButton.OK, MessageBoxImage.Exclamation).Equals(MessageBoxResult.OK))
			{
				b0.SelectedIndex = -1;
				return;
			}
			DateTime dateTime = o();
			if (Convert.ToDateTime(l.b.loanDue).Date < dateTime.Date && !l.b.vendorId.Equals("free"))
			{
				ak = l.b;
				if (l.b.vendorId.Equals("ntl-ebookftp"))
				{
					at.Visibility = Visibility.Collapsed;
				}
				else
				{
					at.Visibility = Visibility.Visible;
				}
				aq.Visibility = Visibility.Visible;
				return;
			}
			bookShelfDetailPopup bookShelfDetailPopup = new bookShelfDetailPopup(b0.SelectedItem, this.m_b, l.b.vendorId);
			bookShelfDetailPopup.configMng = this.m_m;
			DownloadManager downloadManager = Global.bookManager.downloadManager;
			downloadManager.SchedulingStateChanged = (EventHandler<SchedulingStateChangedEventArgs>)Delegate.Combine(downloadManager.SchedulingStateChanged, new EventHandler<SchedulingStateChangedEventArgs>(bookShelfDetailPopup.scheculeStateChange));
			DownloadManager downloadManager2 = Global.bookManager.downloadManager;
			downloadManager2.DownloadProgressChanged = (EventHandler<DownloadProgressChangedEventArgs>)Delegate.Combine(downloadManager2.DownloadProgressChanged, new EventHandler<DownloadProgressChangedEventArgs>(bookShelfDetailPopup.downloadProgressChange));
			Matrix transformToDevice = PresentationSource.FromVisual(Application.Current.MainWindow).CompositionTarget.TransformToDevice;
			double num = transformToDevice.M11 * 96.0;
			double m2 = transformToDevice.M22;
			if (((num == 96.0) ? 100 : ((num == 120.0) ? 125 : 150)) > 100)
			{
				bookShelfDetailPopup.WindowStartupLocation = WindowStartupLocation.Manual;
			}
			if (bookShelfDetailPopup.IsVisible)
			{
				bookShelfDetailPopup.Close();
			}
			else
			{
				bookShelfDetailPopup.Owner = this;
				bookShelfDetailPopup.ShowDialog();
				DownloadManager downloadManager3 = Global.bookManager.downloadManager;
				downloadManager3.SchedulingStateChanged = (EventHandler<SchedulingStateChangedEventArgs>)Delegate.Remove(downloadManager3.SchedulingStateChanged, new EventHandler<SchedulingStateChangedEventArgs>(bookShelfDetailPopup.scheculeStateChange));
				DownloadManager downloadManager4 = Global.bookManager.downloadManager;
				downloadManager4.DownloadProgressChanged = (EventHandler<DownloadProgressChangedEventArgs>)Delegate.Remove(downloadManager4.DownloadProgressChanged, new EventHandler<DownloadProgressChangedEventArgs>(bookShelfDetailPopup.downloadProgressChange));
				if (bookShelfDetailPopup.closeReason == BookDetailPopUpCloseReason.RETURNBOOK)
				{
					q();
				}
				else if (bookShelfDetailPopup.closeReason == BookDetailPopUpCloseReason.RENEWDAY)
				{
					w(A_0, A_1);
				}
				else if (bookShelfDetailPopup.closeReason != BookDetailPopUpCloseReason.DOWNLOAD && bookShelfDetailPopup.closeReason != 0)
				{
					if (bookShelfDetailPopup.closeReason == BookDetailPopUpCloseReason.DELBOOK)
					{
						Global.bookManager.delBook(l.b.vendorId, l.b.colibId, l.b.userId, l.b.bookID, l.b.owner);
					}
					else if (bookShelfDetailPopup.closeReason == BookDetailPopUpCloseReason.READEPUB)
					{
						object selectedItem = b0.SelectedItem;
						a(selectedItem);
						this.m_i = new LocalFilesManager(Global.localDataPath, l.b.vendorId, l.b.colibId, l.b.userId);
						string userBookPath = this.m_i.getUserBookPath(l.b.bookID, BookType.EPUB.GetHashCode(), l.b.owner);
						string loginUserPassword = Global.bookManager.bookProviders[l.b.vendorId].loginUserPassword;
						epubReadPage epubReadPage = new epubReadPage(l.b.vendorId, l.b.colibId, l.b.userId, loginUserPassword, l.b.bookID, userBookPath, l.b.publisher);
						epubReadPage.ShowDialog();
						epubReadPage.Close();
						epubReadPage.Dispose();
						g();
					}
					else if (bookShelfDetailPopup.closeReason == BookDetailPopUpCloseReason.READHEJ || bookShelfDetailPopup.closeReason == BookDetailPopUpCloseReason.READPHEJ)
					{
						m m = new m();
						m.c = l;
						MainWindow.ae = new e(_closeEvent);
						m.a = BookType.UNKNOWN;
						if (bookShelfDetailPopup.closeReason == BookDetailPopUpCloseReason.READHEJ)
						{
							m.a = BookType.HEJ;
						}
						else if (bookShelfDetailPopup.closeReason == BookDetailPopUpCloseReason.READPHEJ)
						{
							m.a = BookType.PHEJ;
						}
						m.b = b0.SelectedItem;
						AsyncCallback a_ = new AsyncCallback(m.d);
						MainWindow.ae.BeginInvoke(m.a, m.b, 0, a_, null);
						ao.Text = Global.bookManager.LanqMng.getLangString("dataPreparation");
						an.Visibility = Visibility.Visible;
						ap.Visibility = Visibility.Visible;
					}
				}
			}
			b0.SelectedIndex = -1;
			bookShelfDetailPopup = null;
		}

		private void a(string A_0, BookThumbnail A_1, string A_2)
		{
			if (A_2.Equals(""))
			{
				return;
			}
			int userBookSno = Global.bookManager.getUserBookSno(A_1.vendorId, A_1.colibId, A_1.userId, A_1.bookID);
			string sqlCommand = "select hlsLastTime from userbook_metadata Where Sno= " + userBookSno;
			long hlsLastTime = 0L;
			QueryResult queryResult = Global.bookManager.sqlCommandQuery(sqlCommand);
			if (queryResult.fetchRow())
			{
				try
				{
					hlsLastTime = queryResult.getLong("hlsLastTime");
				}
				catch
				{
					hlsLastTime = 0L;
				}
			}
			HlsPlayer hlsPlayer = new HlsPlayer(base.Title, A_1, A_0, A_2, userBookSno, hlsLastTime);
			hlsPlayer.HlsPlayerDataRequest += new EventHandler<DataRequestEventArgs>(b);
			hlsPlayer.ShowDialog();
			hlsPlayer.HlsPlayerDataRequest -= new EventHandler<DataRequestEventArgs>(b);
			hlsPlayer.Dispose();
			an.Visibility = Visibility.Collapsed;
			ap.Visibility = Visibility.Collapsed;
		}

		private void b(object A_0, DataRequestEventArgs A_1)
		{
			Global.bookManager.downloadManager.jumpToBookFile(A_1.bookId, A_1.userId, A_1.filename);
		}

		private void a(object A_0, DataRequestEventArgs A_1)
		{
			Global.bookManager.downloadManager.jumpToBookFile(A_1.bookId, A_1.userId, A_1.filename);
		}

		private void g()
		{
			DateTime dateTime = o();
			int count = Global.bookManager.bookShelf.Count;
			for (int i = 0; i < count; i++)
			{
				if (this.m_v[i].vendorId.Equals("free") || this.m_v[i].vendorId.Equals("hyread"))
				{
					continue;
				}
				DateTime dateTime2 = DateTime.Parse(this.m_v[i].loanDue);
				string text = "";
				try
				{
					text = Global.bookManager.getServerTime().Substring(0, 10);
				}
				catch
				{
				}
				DateTime dateTime3 = DateTime.Parse((!text.Equals("")) ? text : DateTime.Now.ToShortDateString());
				dateTime3 = ((DateTime.Parse(dateTime.ToShortDateString()) > dateTime3) ? DateTime.Parse(dateTime.ToShortDateString()) : dateTime3);
				int num = dateTime2.Subtract(dateTime3).Days + 1;
				if (Global.regPath.Equals("NCLReader"))
				{
					num--;
					if (num < 0)
					{
						Global.bookManager.bookShelf[i].coverFormat = "Gray32Float";
						if (Global.bookManager.bookShelf[i].downloadState.Equals(SchedulingState.DOWNLOADING))
						{
							Global.bookManager.pauseDownloadTaskByBookId(Global.bookManager.bookShelf[i].bookId);
						}
						if (dateTime2.Year.Equals(2000))
						{
							Global.bookManager.bookShelf[i].kerchief.rgb = "Black";
							Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("hasReturned");
						}
						else
						{
							Global.bookManager.bookShelf[i].kerchief.rgb = "Black";
							Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("overdue");
						}
						continue;
					}
					Global.bookManager.bookShelf[i].coverFormat = "Pbgra32";
					if (num == 0)
					{
						Global.bookManager.bookShelf[i].kerchief.rgb = "Aqua";
						Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("dueToday");
						continue;
					}
					Global.bookManager.bookShelf[i].kerchief.rgb = "Aqua";
					if (num < 100)
					{
						Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("surplus") + num + Global.bookManager.LanqMng.getLangString("day");
					}
					else if (num / 365 > 9)
					{
						Global.bookManager.bookShelf[i].kerchief.rgb = "";
						Global.bookManager.bookShelf[i].kerchief.descrip = "";
					}
					else if (num < 365)
					{
						int num2 = num / 30;
						Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("surplus") + num2 + Global.bookManager.LanqMng.getLangString("month");
					}
					else
					{
						Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("surplus") + "1" + Global.bookManager.LanqMng.getLangString("year") + "+";
					}
					continue;
				}
				if (num < 1)
				{
					Global.bookManager.bookShelf[i].coverFormat = "Gray32Float";
					if (Global.bookManager.bookShelf[i].downloadState.Equals(SchedulingState.DOWNLOADING))
					{
						Global.bookManager.pauseDownloadTaskByBookId(Global.bookManager.bookShelf[i].bookId);
					}
					if (dateTime2.Year.Equals(2000))
					{
						Global.bookManager.bookShelf[i].kerchief.rgb = "Black";
						Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("hasReturned");
					}
					else
					{
						Global.bookManager.bookShelf[i].kerchief.rgb = "Black";
						Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("overdue");
					}
					continue;
				}
				Global.bookManager.bookShelf[i].coverFormat = "Pbgra32";
				if (num == 1)
				{
					Global.bookManager.bookShelf[i].kerchief.rgb = "Aqua";
					Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("dueToday");
					continue;
				}
				Global.bookManager.bookShelf[i].kerchief.rgb = "Aqua";
				if (num < 100)
				{
					Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("surplus") + num + Global.bookManager.LanqMng.getLangString("day");
				}
				else if (num / 365 > 9)
				{
					Global.bookManager.bookShelf[i].kerchief.rgb = "";
					Global.bookManager.bookShelf[i].kerchief.descrip = "";
				}
				else if (num < 365)
				{
					int num3 = num / 30;
					Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("surplus") + num3 + Global.bookManager.LanqMng.getLangString("month");
				}
				else
				{
					Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("surplus") + "1" + Global.bookManager.LanqMng.getLangString("year") + "+";
				}
			}
		}

		private void aa(object A_0, RoutedEventArgs A_1)
		{
		}

		private void e(object A_0, MouseButtonEventArgs A_1)
		{
		}

		private void d(object A_0, MouseButtonEventArgs A_1)
		{
		}

		private void a(string A_0, string A_1, string A_2)
		{
			string postXMLString = "<body><userId></userId><bookId>" + A_0 + "</bookId></body>";
			FileDownloader fileDownloader = new FileDownloader(A_1, A_2, postXMLString);
			fileDownloader.setProxyPara(this.m_p, this.m_q);
			fileDownloader.downloadStateChanged += new EventHandler<FileDownloaderStateChangedEventArgs>(a);
			fileDownloader.startDownload();
		}

		private void a(object A_0, FileDownloaderStateChangedEventArgs A_1)
		{
			if (!this.m_j)
			{
				return;
			}
			if (A_1.newDownloaderState == FileDownloaderState.FINISHED)
			{
				string filename = A_1.filename;
				string key = filename.Substring(0, filename.LastIndexOf("."));
				this.m_h--;
				i();
				if (this.m_d.ContainsKey(key))
				{
					int num = this.m_d[key][0];
					if (num < this.m_c.b.Count)
					{
						this.m_c.b[num].imgAddress = A_1.destinationPath;
						this.m_d[key][2] = 0;
					}
				}
			}
			else if (A_1.newDownloaderState == FileDownloaderState.FAILED)
			{
				this.m_h--;
				i();
			}
		}

		public void logWithTime(string message)
		{
		}

		private void z(object A_0, RoutedEventArgs A_1)
		{
		}

		private void y(object A_0, RoutedEventArgs A_1)
		{
		}

		private void x(object A_0, RoutedEventArgs A_1)
		{
			if (b1.Visibility.Equals(Visibility.Visible))
			{
				b1.Visibility = Visibility.Collapsed;
				a1.IsChecked = false;
			}
			else
			{
				b1.Visibility = Visibility.Visible;
			}
		}

		private void c(object A_0, MouseButtonEventArgs A_1)
		{
			if (b1.Visibility.Equals(Visibility.Visible))
			{
				b1.Visibility = Visibility.Collapsed;
			}
		}

		private void w(object A_0, RoutedEventArgs A_1)
		{
			an.Visibility = Visibility.Visible;
			ao.Text = Global.bookManager.LanqMng.getLangString("synchronizationBookcase");
			if (this.m_r.checkNetworkStatus() != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetPlease"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
				an.Visibility = Visibility.Collapsed;
				return;
			}
			List<string> list = new List<string>();
			foreach (string item in this.m_ac)
			{
				list.Add(item);
			}
			this.m_ac.Clear();
			foreach (string loggedProvider in Global.bookManager.getLoggedProviders())
			{
				this.m_ac.Add(loggedProvider);
			}
			if (list != null)
			{
				foreach (string item2 in list)
				{
					bool flag = false;
					foreach (string item3 in this.m_ac)
					{
						if (item3 == item2)
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						d(item2);
						bc.Content = this.m_a[0];
					}
				}
			}
			foreach (string item4 in this.m_ac)
			{
				BookProvider bookProvider = Global.bookManager.bookProviders[item4];
				if (bookProvider.loggedIn)
				{
					bookProvider.userBooksFetched += new EventHandler<FetchUserBookResultEventArgs>(a);
					bookProvider.fetchUserBookAsync();
					UpdatingBookProviders++;
				}
			}
			if (UpdatingBookProviders.Equals(0))
			{
				q();
				an.Visibility = Visibility.Collapsed;
			}
			else
			{
				TotalUpdatingBookProviders = UpdatingBookProviders;
				ao.Text = ao.Text;
			}
		}

		private void a(object A_0, FetchUserBookResultEventArgs A_1)
		{
			BookProvider bookProvider = (BookProvider)A_0;
			bookProvider.userBooksFetched -= new EventHandler<FetchUserBookResultEventArgs>(a);
			List<UserBookMetadata> userBookShelf = A_1.userBookShelf;
			b(bookProvider.vendorId, userBookShelf);
		}

		private void a(object A_0, ReplaceBookCoverEventArgs A_1)
		{
			for (int i = 0; i < this.m_v.Count; i++)
			{
				if (this.m_v[i].bookID.Equals(A_1.bookId))
				{
					this.m_v[i].imgAddress = A_1.bookCoverPath;
					break;
				}
			}
		}

		private void b(string A_0, List<UserBookMetadata> A_1)
		{
			f method = new f(a);
			base.Dispatcher.Invoke(method, A_0, A_1);
		}

		private void a(string A_0, List<UserBookMetadata> A_1)
		{
			if (!Global.bookManager.bookProviders.ContainsKey(A_0))
			{
				return;
			}
			foreach (UserBookMetadata item2 in A_1)
			{
				updatedBooksThisTime.Add(item2);
			}
			if (A_0 != "free")
			{
				BookProvider bookProvider = Global.bookManager.bookProviders[A_0];
				SyncManager<TagData> syncManager = new SyncManager<TagData>("https://cloudservice.ebook.hyread.com.tw/DataService/1/classes/", bookProvider.loginUserId, bookProvider.vendorId, "", 0, "STags", this.m_p, this.m_q);
				Global.syncCenter.addSyncConditions("STags", syncManager);
			}
			UpdatingBookProviders--;
			if (UpdatingBookProviders <= 0)
			{
				if (!updatedBooksThisTime.Count.Equals(0))
				{
					DateTime dateTime = o();
					updatedBooksThisTime = Global.bookManager.resetDownloadSchdulingStatus(updatedBooksThisTime);
					List<UserBookMetadata> list = new List<UserBookMetadata>();
					for (int i = 0; i < Global.bookManager.bookShelf.Count; i++)
					{
						int num = -1;
						if (!Global.bookManager.bookShelf[i].vendorId.Equals("free") && !Global.bookManager.bookShelf[i].vendorId.Equals("hyread"))
						{
							bool flag = false;
							for (int j = 0; j < updatedBooksThisTime.Count; j++)
							{
								if (Global.bookManager.bookShelf[i].bookId.Equals(updatedBooksThisTime[j].bookId) && Global.bookManager.bookShelf[i].owner.Equals(updatedBooksThisTime[j].owner))
								{
									flag = true;
									num = j;
									break;
								}
							}
							if (!flag)
							{
								DateTime dateTime2 = DateTime.Parse(Global.bookManager.bookShelf[i].loanDue);
								string text = "";
								try
								{
									text = Global.bookManager.getServerTime().Substring(0, 10);
								}
								catch
								{
								}
								DateTime dateTime3 = DateTime.Parse((!text.Equals("")) ? text : DateTime.Now.ToShortDateString());
								dateTime3 = ((DateTime.Parse(dateTime.ToShortDateString()) > dateTime3) ? DateTime.Parse(dateTime.ToShortDateString()) : dateTime3);
								int num2 = dateTime2.Subtract(dateTime3).Days + 1;
								if (Global.bookManager.bookShelf[i].downloadState.Equals(SchedulingState.DOWNLOADING))
								{
									Global.bookManager.pauseDownloadTaskByBookId(Global.bookManager.bookShelf[i].bookId);
								}
								if (num2 >= 1 || dateTime2.Year.Equals(2000))
								{
									Global.bookManager.bookShelf[i].kerchief.rgb = "Black";
									Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("hasReturned");
									Global.bookManager.bookShelf[i].loanDue = "2000/01/01";
									Global.bookManager.bookShelf[i].coverFormat = "Gray32Float";
								}
								else if (num2 < 1)
								{
									Global.bookManager.bookShelf[i].kerchief.rgb = "Black";
									Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("overdue");
									Global.bookManager.bookShelf[i].coverFormat = "Gray32Float";
								}
								UserBookMetadata item = Global.bookManager.bookShelf[i];
								list.Add(item);
							}
							else
							{
								DateTime dateTime4 = DateTime.Parse(updatedBooksThisTime[num].loanDue);
								string text2 = "";
								try
								{
									text2 = Global.bookManager.getServerTime().Substring(0, 10);
								}
								catch
								{
								}
								DateTime dateTime5 = DateTime.Parse((!text2.Equals("")) ? text2 : DateTime.Now.ToShortDateString());
								dateTime5 = ((DateTime.Parse(dateTime.ToShortDateString()) > dateTime5) ? DateTime.Parse(dateTime.ToShortDateString()) : dateTime5);
								int num3 = dateTime4.Subtract(dateTime5).Days + 1;
								Global.bookManager.bookShelf[i].coverFormat = "Pbgra32";
								if (Global.regPath.Equals("NCLReader"))
								{
									num3--;
									if (num3 == 0)
									{
										Global.bookManager.bookShelf[i].kerchief.rgb = "Aqua";
										Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("dueToday");
										Global.bookManager.bookShelf[i].loanDue = updatedBooksThisTime[num].loanDue;
									}
									else
									{
										Global.bookManager.bookShelf[i].kerchief.rgb = "Aqua";
										if (num3 < 100)
										{
											Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("surplus") + num3 + Global.bookManager.LanqMng.getLangString("day");
										}
										else if (num3 < 365)
										{
											int num4 = num3 / 30;
											Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("surplus") + num4 + Global.bookManager.LanqMng.getLangString("month");
										}
										else
										{
											Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("surplus") + "1" + Global.bookManager.LanqMng.getLangString("year") + "+";
										}
										Global.bookManager.bookShelf[i].loanDue = updatedBooksThisTime[num].loanDue;
									}
									Global.bookManager.bookShelf[i].mediaTypes = updatedBooksThisTime[num].mediaTypes;
								}
								else
								{
									if (num3 == 1)
									{
										Global.bookManager.bookShelf[i].kerchief.rgb = "Aqua";
										Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("dueToday");
										Global.bookManager.bookShelf[i].loanDue = updatedBooksThisTime[num].loanDue;
									}
									else
									{
										Global.bookManager.bookShelf[i].kerchief.rgb = "Aqua";
										if (num3 < 100)
										{
											Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("surplus") + num3 + Global.bookManager.LanqMng.getLangString("day");
										}
										else if (num3 < 365)
										{
											int num5 = num3 / 30;
											Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("surplus") + num5 + Global.bookManager.LanqMng.getLangString("month");
										}
										else
										{
											Global.bookManager.bookShelf[i].kerchief.descrip = Global.bookManager.LanqMng.getLangString("surplus") + "1" + Global.bookManager.LanqMng.getLangString("year") + "+";
										}
										Global.bookManager.bookShelf[i].loanDue = updatedBooksThisTime[num].loanDue;
									}
									Global.bookManager.bookShelf[i].mediaTypes = updatedBooksThisTime[num].mediaTypes;
								}
							}
						}
						if (num > -1 && Global.bookManager.bookShelf[i].coverFullPath.Equals("Assets/NoCover.jpg"))
						{
							Global.bookManager.bookShelf[i].coverFullPath = updatedBooksThisTime[num].coverFullPath;
						}
					}
					foreach (UserBookMetadata item3 in updatedBooksThisTime)
					{
						bool flag2 = false;
						foreach (UserBookMetadata item4 in Global.bookManager.bookShelf)
						{
							if (item4.bookId.Equals(item3.bookId) && item4.owner.Equals(item3.owner))
							{
								flag2 = true;
								break;
							}
						}
						if (!flag2)
						{
							Global.bookManager.bookShelf.Insert(0, item3);
						}
					}
					updatedBooksThisTime.AddRange(list);
					Global.bookManager.saveLatestUserBooks(updatedBooksThisTime);
					Global.bookManager.filterBook(bw.curTagName);
					updatedBooksThisTime.Clear();
					q();
				}
				an.Visibility = Visibility.Collapsed;
			}
			else
			{
				ao.Text = ao.Text;
			}
		}

		private void b(object A_0, EventArgs A_1)
		{
			ch.Items.Clear();
			ItemCollection items = ch.Items;
			ComboBoxItem comboBoxItem = new ComboBoxItem();
			comboBoxItem.Content = Global.bookManager.LanqMng.getLangString("borrowHistory");
			items.Add(comboBoxItem);
			ch.SelectedIndex = 0;
			loginProviders = new List<BookProvider>();
			foreach (KeyValuePair<string, BookProvider> bookProvider in Global.bookManager.bookProviders)
			{
				BookProvider value = bookProvider.Value;
				value.setProxyPara(this.m_p, this.m_q);
				if (value.loggedIn && !value.vendorId.Equals("hyread") && value.loginColibId.Equals(""))
				{
					loginProviders.Add(value);
					ch.Items.Add(value.name);
				}
			}
		}

		private void c(object A_0, SelectionChangedEventArgs A_1)
		{
			if (ch.SelectedIndex - 1 >= 0)
			{
				BookProvider bookProvider = loginProviders[ch.SelectedIndex - 1];
				string empty = string.Empty;
				if (Global.regPath.Equals("NCLReader"))
				{
					empty = bookProvider.loanHistoryUrl;
					empty = empty + "?account2=" + bookProvider.loginUserId;
					empty = empty + "&passwd2=" + bookProvider.loginUserPassword;
					empty += "&page=2";
				}
				else
				{
					List<string> lendHistroy = Global.bookManager.getLendHistroy(bookProvider);
					string text = lendHistroy[2] + (lendHistroy[2].EndsWith("/") ? "" : "/");
					empty = text + "service/authCenter.jsp?data=" + lendHistroy[1] + "&rdurl=" + lendHistroy[3];
				}
				Process.Start(empty);
			}
		}

		private void b(object A_0, MouseButtonEventArgs A_1)
		{
			if (ce.Visibility.Equals(Visibility.Visible))
			{
				ce.Visibility = Visibility.Collapsed;
				a1.IsChecked = false;
			}
		}

		private void v(object A_0, RoutedEventArgs A_1)
		{
			if (ce.Visibility.Equals(Visibility.Visible))
			{
				ce.Visibility = Visibility.Collapsed;
				a1.IsChecked = false;
			}
			else
			{
				co.Text = Assembly.GetExecutingAssembly().GetName().Version.ToString();
				ce.Visibility = Visibility.Visible;
			}
		}

		private void u(object A_0, RoutedEventArgs A_1)
		{
			if (bn.Visibility.Equals(Visibility.Visible))
			{
				bn.Visibility = Visibility.Collapsed;
			}
			else if (!curVendorId.Equals(""))
			{
				if (LendRuleCollection == null)
				{
					LendRuleCollection = new ObservableCollection<LendRule>();
				}
				else
				{
					LendRuleCollection.Clear();
				}
				BookProvider bookProvider = Global.bookManager.bookProviders[curVendorId];
				bookProvider.lendRuleFetched += new EventHandler<FetchLendRuleResultEventArgs>(a);
				bookProvider.fetchLendRuleAsync();
				bq.Visibility = Visibility.Collapsed;
				bp.Visibility = Visibility.Visible;
				bn.Visibility = Visibility.Visible;
			}
		}

		private void a(object A_0, FetchLendRuleResultEventArgs A_1)
		{
			BookProvider obj = (BookProvider)A_0;
			obj.lendRuleFetched -= new EventHandler<FetchLendRuleResultEventArgs>(a);
			if (obj.vendorId.Equals(curVendorId))
			{
				b(curVendorId, A_1.curVendorLendRules);
			}
		}

		private void b(string A_0, List<LendRule> A_1)
		{
			g method = new g(a);
			base.Dispatcher.Invoke(method, A_0, A_1);
		}

		private void a(string A_0, List<LendRule> A_1)
		{
			if (!Global.bookManager.bookProviders.ContainsKey(A_0))
			{
				return;
			}
			int count = A_1.Count;
			if (!count.Equals(0))
			{
				LendRuleCollection.Clear();
				for (int i = 0; i < count; i++)
				{
					LendRuleCollection.Add(A_1[i]);
				}
				bq.Visibility = Visibility.Visible;
				bp.Visibility = Visibility.Collapsed;
				bq.ItemsSource = LendRuleCollection;
			}
		}

		private void a(object A_0, MouseButtonEventArgs A_1)
		{
			if (bn.Visibility.Equals(Visibility.Visible))
			{
				bn.Visibility = Visibility.Collapsed;
			}
		}

		private void c(string A_0)
		{
			MainWindow.m_t.Trace("begin tagCatFilterButton_filterEvent");
			Global.bookManager.filterBook(A_0);
			q();
			MainWindow.m_t.Trace("after tagCatFilterButton_filterEvent");
		}

		private void f()
		{
			string bookShelfFilterString = Global.bookManager.bookShelfFilterString;
			b5.IsChecked = ((bookShelfFilterString.Substring(0, 1) == "1") ? true : false);
			b6.IsChecked = ((bookShelfFilterString.Substring(1, 1) == "1") ? true : false);
			b7.IsChecked = ((bookShelfFilterString.Substring(2, 1) == "1") ? true : false);
			b8.IsChecked = ((bookShelfFilterString.Substring(3, 1) == "1") ? true : false);
			b9.IsChecked = ((bookShelfFilterString.Substring(4, 1) == "1") ? true : false);
			ca.IsChecked = ((bookShelfFilterString.Substring(5, 1) == "1") ? true : false);
			cb.IsChecked = ((bookShelfFilterString.Substring(6, 1) == "1") ? true : false);
			cc.IsChecked = ((bookShelfFilterString.Substring(7, 1) == "1") ? true : false);
			cd.IsChecked = ((bookShelfFilterString.Substring(8, 1) == "1") ? true : false);
			b3.IsChecked = ((bookShelfFilterString.Substring(9, 1) == "1") ? true : false);
			b4.IsChecked = ((bookShelfFilterString.Substring(10, 1) == "1") ? true : false);
			ci.IsChecked = cb.IsChecked;
		}

		private void t(object A_0, RoutedEventArgs A_1)
		{
			base.Cursor = Cursors.Wait;
			string text = "";
			string str = text;
			Nullable<bool> isChecked = b5.IsChecked;
			bool flag = true;
			text = str + (((isChecked.GetValueOrDefault() == flag) & isChecked.HasValue) ? "1" : "0");
			string str2 = text;
			isChecked = b6.IsChecked;
			flag = true;
			text = str2 + (((isChecked.GetValueOrDefault() == flag) & isChecked.HasValue) ? "1" : "0");
			string str3 = text;
			isChecked = b7.IsChecked;
			flag = true;
			text = str3 + (((isChecked.GetValueOrDefault() == flag) & isChecked.HasValue) ? "1" : "0");
			string str4 = text;
			isChecked = b8.IsChecked;
			flag = true;
			text = str4 + (((isChecked.GetValueOrDefault() == flag) & isChecked.HasValue) ? "1" : "0");
			string str5 = text;
			isChecked = b9.IsChecked;
			flag = true;
			text = str5 + (((isChecked.GetValueOrDefault() == flag) & isChecked.HasValue) ? "1" : "0");
			string str6 = text;
			isChecked = ca.IsChecked;
			flag = true;
			text = str6 + (((isChecked.GetValueOrDefault() == flag) & isChecked.HasValue) ? "1" : "0");
			string str7 = text;
			isChecked = cb.IsChecked;
			flag = true;
			text = str7 + (((isChecked.GetValueOrDefault() == flag) & isChecked.HasValue) ? "1" : "0");
			string str8 = text;
			isChecked = cc.IsChecked;
			flag = true;
			text = str8 + (((isChecked.GetValueOrDefault() == flag) & isChecked.HasValue) ? "1" : "0");
			string str9 = text;
			isChecked = cd.IsChecked;
			flag = true;
			text = str9 + (((isChecked.GetValueOrDefault() == flag) & isChecked.HasValue) ? "1" : "0");
			string str10 = text;
			isChecked = b3.IsChecked;
			flag = true;
			text = str10 + (((isChecked.GetValueOrDefault() == flag) & isChecked.HasValue) ? "1" : "0");
			string str11 = text;
			isChecked = b4.IsChecked;
			flag = true;
			text = str11 + (((isChecked.GetValueOrDefault() == flag) & isChecked.HasValue) ? "1" : "0");
			ci.IsChecked = cb.IsChecked;
			if (text != Global.bookManager.bookShelfFilterString)
			{
				this.m_m.savefilterBookStr = text;
				Global.bookManager.bookShelfFilterString = text;
				Global.bookManager.filterBook(bw.curTagName);
				q();
			}
			base.Cursor = Cursors.Arrow;
		}

		private void a(object A_0, EventArgs A_1)
		{
			DispatcherTimer dispatcherTimer = (DispatcherTimer)A_0;
			dispatcherTimer.Stop();
			bool flag = false;
			int count = this.m_v.Count;
			for (int i = 0; i < count; i++)
			{
				UserBookMetadata userBookMetadata = Global.bookManager.bookShelf[i];
				string coverFullPath = this.m_i.getCoverFullPath(userBookMetadata.bookId);
				if (File.Exists(coverFullPath))
				{
					this.m_v[i].imgAddress = coverFullPath;
				}
				else if (this.m_v[i].imgAddress == "Assets/NoCover.jpg")
				{
					flag = true;
				}
			}
			if (flag)
			{
				dispatcherTimer.Start();
			}
		}

		private void s(object A_0, RoutedEventArgs A_1)
		{
			if (MessageBox.Show(Global.bookManager.LanqMng.getLangString("resetFactoryAlert"), Global.bookManager.LanqMng.getLangString("sureReset"), MessageBoxButton.YesNo, MessageBoxImage.Exclamation).Equals(MessageBoxResult.Yes))
			{
				an.Visibility = Visibility.Visible;
				ao.Text = Global.bookManager.LanqMng.getLangString("reset");
				new Thread(new ThreadStart(a)).Start();
			}
		}

		private void e()
		{
			Global.bookManager.resetDatabase();
			try
			{
				this.m_ad = true;
				h();
			}
			catch
			{
			}
			d();
			b(Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\" + Global.localDataPath + "\\cover");
			Environment.Exit(Environment.ExitCode);
		}

		private void b(string A_0)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(A_0);
			FileInfo[] files = directoryInfo.GetFiles();
			foreach (FileInfo fileInfo in files)
			{
				try
				{
					fileInfo.Delete();
				}
				catch
				{
				}
			}
			DirectoryInfo[] directories = directoryInfo.GetDirectories();
			foreach (DirectoryInfo directoryInfo2 in directories)
			{
				b(directoryInfo2.FullName);
			}
		}

		private void d()
		{
			DirectoryInfo[] directories = new DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\" + Global.localDataPath).GetDirectories();
			foreach (DirectoryInfo directoryInfo in directories)
			{
				if (directoryInfo.Name.Length == 32)
				{
					try
					{
						Directory.Delete(directoryInfo.FullName, true);
					}
					catch
					{
					}
				}
			}
		}

		private void r(object A_0, RoutedEventArgs A_1)
		{
			if (MessageBox.Show(Global.bookManager.LanqMng.getLangString("sureDelFavoriteLibs"), Global.bookManager.LanqMng.getLangString("delFavorite"), MessageBoxButton.YesNo, MessageBoxImage.Exclamation).Equals(MessageBoxResult.Yes))
			{
				string sqlCommand = "DELETE from local_user where keepLogin = false";
				Global.bookManager.sqlCommandNonQuery(sqlCommand);
			}
		}

		private void b(object A_0, SelectionChangedEventArgs A_1)
		{
		}

		private void a(object A_0, CancelEventArgs A_1)
		{
			GC.Collect();
			Thread.Sleep(1000);
			string userDataPath = new LocalFilesManager(Global.localDataPath, "tryread", "tryread", "tryread").getUserDataPath();
			try
			{
				Directory.Delete(userDataPath, true);
			}
			catch
			{
				Thread.Sleep(3000);
				Directory.Delete(userDataPath, true);
			}
			List<string> deleteAfterShutDown = Global.bookManager.deleteAfterShutDown;
			for (int i = 0; i < deleteAfterShutDown.Count; i++)
			{
				if (!File.Exists(deleteAfterShutDown[i] + "//book.xml"))
				{
					Directory.Delete(deleteAfterShutDown[i], true);
				}
			}
			Global.bookManager.downloadManager.pauseAllTasks();
			SystemEvents.PowerModeChanged -= new PowerModeChangedEventHandler(a);
			c();
		}

		private void q(object A_0, RoutedEventArgs A_1)
		{
			if (!((Hyperlink)A_1.OriginalSource).NavigateUri.AbsoluteUri.Equals(""))
			{
				Process.Start(new ProcessStartInfo(((Hyperlink)A_1.OriginalSource).NavigateUri.AbsoluteUri));
			}
		}

		private void p(object A_0, RoutedEventArgs A_1)
		{
			aq.Visibility = Visibility.Collapsed;
			ak = null;
			b0.SelectedIndex = -1;
		}

		private void o(object A_0, RoutedEventArgs A_1)
		{
			BookProvider bookProvider = Global.bookManager.bookProviders[ak.vendorId];
			bookProvider.lendBookFetched += new EventHandler<FetchLendBookResultEventArgs>(a);
			bookProvider.lendBookAsnyc(ak.bookID, null, ak.owner);
			aq.Visibility = Visibility.Collapsed;
			ak = null;
			b0.SelectedIndex = -1;
		}

		private void n(object A_0, RoutedEventArgs A_1)
		{
			Global.bookManager.returnBook(ak.vendorId, ak.colibId, ak.userId, ak.bookID, ak.owner);
			q();
			aq.Visibility = Visibility.Collapsed;
			ak = null;
			b0.SelectedIndex = -1;
		}

		private void a(object A_0, FetchLendBookResultEventArgs A_1)
		{
			BookProvider bookProvider = (BookProvider)A_0;
			bookProvider.lendBookFetched -= new EventHandler<FetchLendBookResultEventArgs>(a);
			if (A_1.success)
			{
				b(bookProvider.vendorId, A_1.message);
			}
		}

		private void b(string A_0, string A_1)
		{
			h method = new h(a);
			base.Dispatcher.Invoke(method, A_0, A_1);
		}

		private void a(string A_0, string A_1)
		{
			if (!Global.bookManager.bookProviders.ContainsKey(A_0) || A_1.Equals(""))
			{
				return;
			}
			if (A_1.Contains(Global.bookManager.LanqMng.getLangString("lend")))
			{
				MessageBox.Show(A_1, Global.bookManager.LanqMng.getLangString("lendMsg"));
			}
			else
			{
				MessageBox.Show(A_1);
			}
			an.Visibility = Visibility.Visible;
			ao.Text = Global.bookManager.LanqMng.getLangString("updateBookcase");
			if (this.m_r.checkNetworkStatus() != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetPlease"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
				an.Visibility = Visibility.Collapsed;
				return;
			}
			this.m_ac.Clear();
			foreach (string loggedProvider in Global.bookManager.getLoggedProviders())
			{
				this.m_ac.Add(loggedProvider);
			}
			foreach (string item in this.m_ac)
			{
				BookProvider bookProvider = Global.bookManager.bookProviders[item];
				if (bookProvider.loggedIn)
				{
					bookProvider.userBooksFetched += new EventHandler<FetchUserBookResultEventArgs>(a);
					bookProvider.fetchUserBookAsync();
					UpdatingBookProviders++;
				}
			}
			if (UpdatingBookProviders.Equals(0))
			{
				q();
				an.Visibility = Visibility.Collapsed;
			}
			else
			{
				TotalUpdatingBookProviders = UpdatingBookProviders;
				ao.Text = ao.Text;
			}
		}

		private void m(object A_0, RoutedEventArgs A_1)
		{
			ProxySetupWindow proxySetupWindow = new ProxySetupWindow();
			proxySetupWindow.ConfigMng = this.m_m;
			proxySetupWindow.ShowDialog();
		}

		private void a(object A_0, SelectionChangedEventArgs A_1)
		{
			CultureInfo cultureInfo = cn.SelectedItem as CultureInfo;
			if (HyReadLibraryHD.Properties.Resources.Culture != null && !HyReadLibraryHD.Properties.Resources.Culture.Equals(cultureInfo))
			{
				this.m_m.saveLanquage = cultureInfo.Name;
				CulturesHelper.ChangeCulture(cultureInfo);
				Global.bookManager.LanqMng.setLanquage(cultureInfo.Name);
				Global.bookManager.setLanquage(cultureInfo.Name);
			}
		}

		private void a(object A_0, ContextMenuEventArgs A_1)
		{
			if (((BookManagerModule.Libraries)((Button)A_0).DataContext).libGroupType != -1)
			{
				A_1.Handled = true;
			}
		}

		private void l(object A_0, RoutedEventArgs A_1)
		{
			string a_ = (string)((MenuItem)A_0).Tag;
			a(a_);
		}

		private void a(string A_0)
		{
			if (MessageBox.Show(Global.bookManager.LanqMng.getLangString("sureDeleteRecentLibs") + Global.bookManager.bookProviders[A_0].name + "?", Global.bookManager.LanqMng.getLangString("delete") + Global.bookManager.LanqMng.getLangString("recentLoginLibs"), MessageBoxButton.YesNo, MessageBoxImage.Exclamation).Equals(MessageBoxResult.Yes))
			{
				string sqlCommand = "DELETE from local_user where vendorId = '" + A_0 + "'";
				Global.bookManager.sqlCommandNonQuery(sqlCommand);
				if (Global.bookManager.bookProviders[A_0].loggedIn)
				{
					d(A_0);
				}
				if (curVendorId.Equals(A_0))
				{
					bc.Content = this.m_a[0];
				}
				bf.removeFavLibs(A_0);
			}
		}

		private void k(object A_0, RoutedEventArgs A_1)
		{
			new Thread(_003C_003Ec._003C_003E9__181_0 ?? (_003C_003Ec._003C_003E9__181_0 = new ThreadStart(_003C_003Ec._003C_003E9.a))).Start();
			MessageBox.Show(Global.bookManager.LanqMng.getLangString("bugreportMsg"));
			ce.Visibility = Visibility.Collapsed;
			a1.IsChecked = false;
		}

		private void c()
		{
			OperatingSystem oSVersion = Environment.OSVersion;
			if (oSVersion.Platform.GetHashCode() != 2 || oSVersion.Version.Major.GetHashCode() != 5 || oSVersion.Version.Minor.GetHashCode() != 1 || !Directory.Exists("c:\\windows\\prefetch\\"))
			{
				return;
			}
			string[] files = Directory.GetFiles("c:\\windows\\prefetch\\", "*.pf");
			foreach (string path in files)
			{
				try
				{
					File.Delete(path);
				}
				catch
				{
				}
			}
		}

		private void j(object A_0, RoutedEventArgs A_1)
		{
			string bookShelfFilterString = Global.bookManager.bookShelfFilterString;
			Nullable<bool> isChecked = ci.IsChecked;
			bool flag = true;
			char a_ = ((isChecked.GetValueOrDefault() == flag) & isChecked.HasValue) ? '1' : '0';
			cb.IsChecked = ci.IsChecked;
			bookShelfFilterString = a(6, a_, bookShelfFilterString);
			if (bookShelfFilterString != Global.bookManager.bookShelfFilterString)
			{
				this.m_m.savefilterBookStr = bookShelfFilterString;
				Global.bookManager.bookShelfFilterString = bookShelfFilterString;
				Global.bookManager.filterBook(bw.curTagName);
				q();
			}
		}

		private static string a(int A_0, char A_1, string A_2)
		{
			char[] array = A_2.ToCharArray();
			array[A_0] = A_1;
			return string.Join("", array);
		}

		private void i(object A_0, RoutedEventArgs A_1)
		{
			new Thread(_003C_003Ec._003C_003E9__185_0 ?? (_003C_003Ec._003C_003E9__185_0 = new ThreadStart(_003C_003Ec._003C_003E9.b))).Start();
			MessageBox.Show(Global.bookManager.LanqMng.getLangString("notereportMsg"));
			ce.Visibility = Visibility.Collapsed;
			a1.IsChecked = false;
		}

		private void h(object A_0, RoutedEventArgs A_1)
		{
			Global.bookManager.resetEntranceDate();
			MainWindow.m_t.Trace("ThreadStart fetchBookProviders");
			new Thread(new ThreadStart(Global.bookManager.fetchBookProviders)).Start();
		}

		private void g(object A_0, RoutedEventArgs A_1)
		{
			MessageBox.Show(Global.bookManager.LanqMng.getLangString("serviceInfoMsg"));
		}

		private void f(object A_0, RoutedEventArgs A_1)
		{
			if (!Global.localDataPath.Equals("HyRead"))
			{
				cp.Visibility = Visibility.Collapsed;
			}
		}

		private void e(object A_0, RoutedEventArgs A_1)
		{
			string text = Global.bookManager.bookProviders[curVendorId].homePage + "/policy.jsp";
			if (Global.bookManager.bookProviders[curVendorId].loggedIn)
			{
				text = a(Global.bookManager.bookProviders[curVendorId]);
			}
			if (!text.Equals(""))
			{
				Process.Start(text);
			}
		}

		private string a(BookProvider A_0)
		{
			string text = A_0.homePage + (A_0.homePage.EndsWith("/") ? "" : "/");
			if (A_0.loggedIn)
			{
				if (A_0.vendorId == "ntl-ebookftp")
				{
					text = text.Replace("&amp;", "");
					text = text.Replace("$account$", A_0.loginUserId);
					text = text.Replace("$password$", A_0.loginUserPassword);
				}
				else
				{
					string text2 = "";
					text2 = (Global.localDataPath.Equals("HyReadCN") ? j("http://ebook.hyread.com.cn/service/getServerTime.jsp") : j("http://ebook.hyread.com.tw/service/getServerTime.jsp"));
					string str = "<request>";
					str += "<action>login</action>";
					str = str + "<time><![CDATA[" + text2 + "]]></time>";
					object[] obj = new object[4]
					{
						str,
						"<hyreadtype>",
						null,
						null
					};
					HyreadType hyreadType = A_0.hyreadType;
					obj[2] = hyreadType.GetHashCode();
					obj[3] = "</hyreadtype>";
					str = string.Concat(obj);
					str = str + "<unit>" + A_0.vendorId + "</unit>";
					str = str + "<colibid>" + A_0.loginColibId + "</colibid>";
					str = str + "<account><![CDATA[" + A_0.loginUserId + "]]></account>";
					str = str + "<passwd><![CDATA[" + A_0.loginUserPassword + "]]></passwd>";
					str += "<guestIP></guestIP>";
					str += "</request>";
					byte[] bytes = Encoding.Default.GetBytes("hyweb101S00ebook");
					string str2 = Uri.EscapeDataString(new CACodecTools().stringEncode(str, bytes, true));
					text = text + "service/authCenter.jsp?data=" + str2;
					text += "&rdurl=/policy.jsp";
				}
			}
			return text;
		}

		private void b()
		{
			Version version = Environment.OSVersion.Version;
			DateTime t = Convert.ToDateTime("2017/05/25");
			bool flag = false;
			if (version.Major >= 10 || version.ToString().Equals("6.2.9200.0"))
			{
				cq.Visibility = Visibility.Visible;
				flag = true;
			}
			if (!File.Exists(al) && flag && DateTime.Now >= t)
			{
				cu.IsOpen = true;
			}
		}

		private void d(object A_0, RoutedEventArgs A_1)
		{
			File.Create(al);
			cu.IsOpen = false;
		}

		private void c(object A_0, RoutedEventArgs A_1)
		{
			Process.Start(new ProcessStartInfo("https://www.microsoft.com/zh-tw/store/p/hyread-3/9wzdncrddp30"));
			cu.IsOpen = false;
		}

		private void b(object A_0, RoutedEventArgs A_1)
		{
			cu.IsOpen = false;
		}

		private void a(object A_0, RoutedEventArgs A_1)
		{
			Process.Start(new ProcessStartInfo("https://www.microsoft.com/zh-tw/store/p/hyread-3/9wzdncrddp30"));
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!cy)
			{
				cy = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/mainwindow.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				am = (MainWindow)target;
				am.Closing += new CancelEventHandler(a);
				am.Loaded += new RoutedEventHandler(f);
				break;
			case 3:
				an = (Canvas)target;
				break;
			case 4:
				ao = (TextBlock)target;
				break;
			case 5:
				ap = (RadioButton)target;
				ap.Click += new RoutedEventHandler(ab);
				break;
			case 6:
				aq = (Canvas)target;
				break;
			case 7:
				ar = (TextBlock)target;
				break;
			case 8:
				@as = (RadioButton)target;
				@as.Click += new RoutedEventHandler(n);
				break;
			case 9:
				at = (RadioButton)target;
				at.Click += new RoutedEventHandler(o);
				break;
			case 10:
				au = (RadioButton)target;
				au.Click += new RoutedEventHandler(p);
				break;
			case 11:
				av = (ImageBrush)target;
				break;
			case 12:
				aw = (TextBlock)target;
				break;
			case 13:
				ax = (Hyperlink)target;
				ax.Click += new RoutedEventHandler(q);
				break;
			case 14:
				ay = (Run)target;
				break;
			case 15:
				az = (RadioButton)target;
				az.Click += new RoutedEventHandler(ad);
				break;
			case 16:
				a0 = (RadioButton)target;
				a0.Click += new RoutedEventHandler(ac);
				break;
			case 17:
				a1 = (RadioButton)target;
				a1.Click += new RoutedEventHandler(v);
				break;
			case 18:
				a2 = (TabControl)target;
				a2.SelectionChanged += new SelectionChangedEventHandler(b);
				break;
			case 19:
				a3 = (TabItem)target;
				break;
			case 20:
				a4 = (Grid)target;
				break;
			case 21:
				a5 = (CategoryComboBox)target;
				break;
			case 22:
				a6 = (StackPanel)target;
				break;
			case 23:
				a7 = (TextBox)target;
				a7.TextChanged += new TextChangedEventHandler(a);
				a7.KeyDown += new KeyEventHandler(a);
				a7.MouseEnter += new MouseEventHandler(c);
				break;
			case 24:
				a8 = (RadioButton)target;
				a8.Click += new RoutedEventHandler(af);
				break;
			case 25:
				a9 = (RadioButton)target;
				a9.Click += new RoutedEventHandler(ai);
				break;
			case 26:
				ba = (TextBlock)target;
				break;
			case 27:
				bb = (RadioButton)target;
				bb.Click += new RoutedEventHandler(u);
				break;
			case 28:
				bc = (RadioButton)target;
				bc.Click += new RoutedEventHandler(ae);
				break;
			case 29:
				bd = (Grid)target;
				break;
			case 30:
				be = (Grid)target;
				break;
			case 31:
				bf = (LibraryTreeView)target;
				break;
			case 32:
				bg = (Grid)target;
				break;
			case 33:
				bh = (RadioButton)target;
				bh.Click += new RoutedEventHandler(ah);
				break;
			case 34:
				bi = (ListBox)target;
				bi.SelectionChanged += new SelectionChangedEventHandler(e);
				break;
			case 36:
				bj = (Canvas)target;
				break;
			case 37:
				bk = (Grid)target;
				break;
			case 38:
				bl = (TextBlock)target;
				break;
			case 39:
				bm = (TextBlock)target;
				break;
			case 40:
				bn = (Canvas)target;
				bn.MouseLeftButtonDown += new MouseButtonEventHandler(a);
				break;
			case 41:
				bo = (StackPanel)target;
				break;
			case 42:
				bp = (Grid)target;
				break;
			case 43:
				bq = (ListBox)target;
				break;
			case 44:
				br = (Canvas)target;
				br.MouseLeftButtonDown += new MouseButtonEventHandler(f);
				break;
			case 45:
				bs = (StackPanel)target;
				break;
			case 46:
				bt = (ListBox)target;
				bt.SelectionChanged += new SelectionChangedEventHandler(g);
				break;
			case 47:
				bu = (TabItem)target;
				break;
			case 48:
				bv = (Grid)target;
				break;
			case 49:
				bw = (TagCategoriesFilterButton)target;
				break;
			case 50:
				bx = (RadioButton)target;
				bx.Click += new RoutedEventHandler(x);
				break;
			case 51:
				by = (RadioButton)target;
				by.Click += new RoutedEventHandler(w);
				break;
			case 52:
				bz = (Grid)target;
				break;
			case 53:
				b0 = (ListBox)target;
				b0.SelectionChanged += new SelectionChangedEventHandler(d);
				break;
			case 54:
				b1 = (Canvas)target;
				b1.MouseLeftButtonDown += new MouseButtonEventHandler(c);
				break;
			case 55:
				b2 = (StackPanel)target;
				break;
			case 56:
				b3 = (CheckBox)target;
				b3.Click += new RoutedEventHandler(t);
				break;
			case 57:
				b4 = (CheckBox)target;
				b4.Click += new RoutedEventHandler(t);
				break;
			case 58:
				b5 = (CheckBox)target;
				b5.Click += new RoutedEventHandler(t);
				break;
			case 59:
				b6 = (CheckBox)target;
				b6.Click += new RoutedEventHandler(t);
				break;
			case 60:
				b7 = (CheckBox)target;
				b7.Click += new RoutedEventHandler(t);
				break;
			case 61:
				b8 = (CheckBox)target;
				b8.Click += new RoutedEventHandler(t);
				break;
			case 62:
				b9 = (CheckBox)target;
				b9.Click += new RoutedEventHandler(t);
				break;
			case 63:
				ca = (CheckBox)target;
				ca.Click += new RoutedEventHandler(t);
				break;
			case 64:
				cb = (CheckBox)target;
				cb.Click += new RoutedEventHandler(t);
				break;
			case 65:
				cc = (CheckBox)target;
				cc.Click += new RoutedEventHandler(t);
				break;
			case 66:
				cd = (CheckBox)target;
				cd.Click += new RoutedEventHandler(t);
				break;
			case 67:
				ce = (Canvas)target;
				ce.MouseLeftButtonDown += new MouseButtonEventHandler(b);
				break;
			case 68:
				cf = (StackPanel)target;
				break;
			case 69:
				cg = (StackPanel)target;
				break;
			case 70:
				ch = (ComboBox)target;
				ch.DropDownOpened += new EventHandler(b);
				ch.SelectionChanged += new SelectionChangedEventHandler(c);
				break;
			case 71:
				ci = (CheckBox)target;
				ci.Click += new RoutedEventHandler(j);
				break;
			case 72:
				cj = (Button)target;
				cj.Click += new RoutedEventHandler(r);
				break;
			case 73:
				ck = (Button)target;
				ck.Click += new RoutedEventHandler(s);
				break;
			case 74:
				cl = (Button)target;
				cl.Click += new RoutedEventHandler(m);
				break;
			case 75:
				cm = (Button)target;
				cm.Click += new RoutedEventHandler(k);
				break;
			case 76:
				cn = (ComboBox)target;
				cn.SelectionChanged += new SelectionChangedEventHandler(a);
				break;
			case 77:
				co = (TextBlock)target;
				break;
			case 78:
				cp = (Button)target;
				cp.Click += new RoutedEventHandler(g);
				break;
			case 79:
				cq = (Button)target;
				cq.Click += new RoutedEventHandler(a);
				break;
			case 80:
				cr = (Canvas)target;
				break;
			case 81:
				cs = (Border)target;
				break;
			case 82:
				ct = (TextBlock)target;
				break;
			case 83:
				cu = (Popup)target;
				break;
			case 84:
				cv = (Button)target;
				cv.Click += new RoutedEventHandler(d);
				break;
			case 85:
				cw = (Button)target;
				cw.Click += new RoutedEventHandler(c);
				break;
			case 86:
				cx = (Button)target;
				cx.Click += new RoutedEventHandler(b);
				break;
			default:
				cy = true;
				break;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 2:
				((Button)target).Click += new RoutedEventHandler(e);
				break;
			case 35:
				((ScrollViewer)target).ScrollChanged += new ScrollChangedEventHandler(a);
				break;
			}
		}

		[CompilerGenerated]
		private void a()
		{
			e();
		}
	}
}
