using BookManagerModule;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Xml;

namespace HyReadLibraryHD
{
	public class lenbookOfMultiLibrary : Form
	{
		public int lendButtonSelectIndex = -1;

		private List<ExtLibInfo> m_a = new List<ExtLibInfo>();

		private IContainer m_b;

		private DataGridView c;

		private DataGridViewTextBoxColumn d;

		private DataGridViewTextBoxColumn e;

		private DataGridViewButtonColumn f;

		public lenbookOfMultiLibrary(List<ExtLibInfo> listExtLibInfo)
		{
			a();
			this.m_a = listExtLibInfo;
			b();
			Text = Global.bookManager.LanqMng.getLangString("extOfLoan");
			d.HeaderText = Global.bookManager.LanqMng.getLangString("serviceLib");
			e.HeaderText = Global.bookManager.LanqMng.getLangString("countOfLend");
			f.HeaderText = Global.bookManager.LanqMng.getLangString("lend") + "/" + Global.bookManager.LanqMng.getLangString("reserve");
		}

		private void b()
		{
			foreach (ExtLibInfo item in this.m_a)
			{
				if (item.availableCount > 0)
				{
					c.Rows.Add(item.name, item.availableCount, Global.bookManager.LanqMng.getLangString("nowLending"));
				}
				else
				{
					c.Rows.Add(item.name, item.availableCount, Global.bookManager.LanqMng.getLangString("iWantReserve"));
				}
			}
		}

		private string a(XmlNode A_0)
		{
			if (A_0 == null)
			{
				return "";
			}
			if (A_0.HasChildNodes)
			{
				return A_0.InnerText;
			}
			return "";
		}

		private void a(object A_0, DataGridViewCellEventArgs A_1)
		{
			if (A_1.ColumnIndex == 2 && A_1.RowIndex >= 0 && A_1.RowIndex < this.m_a.Count)
			{
				lendButtonSelectIndex = A_1.RowIndex;
				Close();
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.m_b != null)
			{
				this.m_b.Dispose();
			}
			base.Dispose(disposing);
		}

		private void a()
		{
			DataGridViewCellStyle dataGridViewCellStyle = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
			DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
			c = new DataGridView();
			d = new DataGridViewTextBoxColumn();
			e = new DataGridViewTextBoxColumn();
			f = new DataGridViewButtonColumn();
			((ISupportInitialize)c).BeginInit();
			SuspendLayout();
			dataGridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle.BackColor = SystemColors.Control;
			dataGridViewCellStyle.Font = new Font("新細明體", 12f, FontStyle.Regular, GraphicsUnit.Point, 136);
			dataGridViewCellStyle.ForeColor = SystemColors.WindowText;
			dataGridViewCellStyle.SelectionBackColor = SystemColors.Highlight;
			dataGridViewCellStyle.SelectionForeColor = SystemColors.HighlightText;
			dataGridViewCellStyle.WrapMode = DataGridViewTriState.True;
			c.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			c.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			c.Columns.AddRange(d, e, f);
			dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
			dataGridViewCellStyle2.BackColor = SystemColors.Window;
			dataGridViewCellStyle2.Font = new Font("新細明體", 11.25f, FontStyle.Regular, GraphicsUnit.Point, 136);
			dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
			dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
			dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
			c.DefaultCellStyle = dataGridViewCellStyle2;
			c.Location = new Point(3, -1);
			c.Name = "dataGridView1";
			c.RowTemplate.Height = 24;
			c.Size = new Size(417, 148);
			c.TabIndex = 0;
			c.CellContentClick += new DataGridViewCellEventHandler(a);
			d.HeaderText = "服務館別";
			d.Name = "name";
			d.ReadOnly = true;
			d.Width = 150;
			e.HeaderText = "可借冊數";
			e.Name = "available";
			e.ReadOnly = true;
			dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle3.BackColor = Color.FromArgb(64, 64, 64);
			dataGridViewCellStyle3.ForeColor = Color.White;
			f.DefaultCellStyle = dataGridViewCellStyle3;
			f.HeaderText = "借閱/預約";
			f.Name = "lenbookBtn";
			base.AutoScaleDimensions = new SizeF(6f, 12f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(425, 151);
			base.Controls.Add(c);
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "lenbookOfMultiLibrary";
			base.StartPosition = FormStartPosition.CenterParent;
			Text = "延伸借閱";
			((ISupportInitialize)c).EndInit();
			ResumeLayout(false);
		}
	}
}
