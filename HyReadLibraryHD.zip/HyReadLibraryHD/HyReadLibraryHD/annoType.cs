namespace HyReadLibraryHD
{
	public enum annoType
	{
		PEN,
		NOTE
	}
}
