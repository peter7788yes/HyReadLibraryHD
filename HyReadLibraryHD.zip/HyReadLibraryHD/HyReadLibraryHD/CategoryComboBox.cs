using BookManagerModule;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;

namespace HyReadLibraryHD
{
	public class CategoryComboBox : UserControl, IComponentConnector, IStyleConnector
	{
		private Popup LastOpenPopup;

		internal ComboBox catComboBox;

		private bool _contentLoaded;

		public int SelectedIndex
		{
			get
			{
				return catComboBox.SelectedIndex;
			}
			set
			{
				catComboBox.SelectedIndex = value;
			}
		}

		public object SelectedItem
		{
			get
			{
				ContentPresenter contentPresenter = FindVisualChildByName<ContentPresenter>(catComboBox, "ContentSite");
				if (contentPresenter == null)
				{
					return catComboBox.SelectedItem;
				}
				return contentPresenter.Content;
			}
			set
			{
				catComboBox.SelectedItem = value;
			}
		}

		public new Visibility Visibility
		{
			get
			{
				return catComboBox.Visibility;
			}
			set
			{
				catComboBox.Visibility = value;
			}
		}

		public event CategoryChangedEvent CategoryChanged;

		public void SetCategoryComboBoxItemSource(List<Category> categories)
		{
			catComboBox.SelectionChanged += new SelectionChangedEventHandler(a);
			catComboBox.ItemsSource = categories;
		}

		public CategoryComboBox()
		{
			InitializeComponent();
		}

		public void ClearItems()
		{
			ContentPresenter contentPresenter = FindVisualChildByName<ContentPresenter>(catComboBox, "ContentSite");
			if (contentPresenter != null)
			{
				contentPresenter.Content = null;
			}
		}

		private void a(object A_0, SelectionChangedEventArgs A_1)
		{
			if (catComboBox.SelectedIndex < 0)
			{
				A_1.Handled = true;
				return;
			}
			Category category = (Category)catComboBox.SelectedItem;
			ContentPresenter contentPresenter = FindVisualChildByName<ContentPresenter>(catComboBox, "ContentSite");
			if (contentPresenter != null)
			{
				contentPresenter.Content = category;
			}
			if (category != null)
			{
				this.CategoryChanged(category);
			}
			catComboBox.SelectionChanged -= new SelectionChangedEventHandler(a);
			A_1.Handled = true;
		}

		public static T FindVisualChildByName<T>(DependencyObject parent, string name) where T : DependencyObject
		{
			if (parent != null)
			{
				for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
				{
					DependencyObject child = VisualTreeHelper.GetChild(parent, i);
					if (child.GetValue(FrameworkElement.NameProperty) as string== name)
					{
						return child as T;
					}
					T val = FindVisualChildByName<T>(child, name);
					if (val != null)
					{
						return val;
					}
				}
			}
			return null;
		}

		private void a(object A_0, RoutedEventArgs A_1)
		{
			Popup popup = (Popup)((Button)A_0).Tag;
			if (LastOpenPopup != null && LastOpenPopup != popup && LastOpenPopup.IsOpen)
			{
				LastOpenPopup.IsOpen = false;
			}
			LastOpenPopup = popup;
			LastOpenPopup.IsOpen = !LastOpenPopup.IsOpen;
			A_1.Handled = true;
		}

		private void a(object A_0, MouseButtonEventArgs A_1)
		{
			Category category = (Category)((StackPanel)A_0).Tag;
			ContentPresenter contentPresenter = FindVisualChildByName<ContentPresenter>(catComboBox, "ContentSite");
			if (contentPresenter != null)
			{
				contentPresenter.Content = category;
			}
			if (category != null)
			{
				this.CategoryChanged(category);
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/categorycombobox.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 3)
			{
				catComboBox = (ComboBox)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((StackPanel)target).MouseLeftButtonDown += new MouseButtonEventHandler(a);
				break;
			case 2:
			{
				EventSetter eventSetter = new EventSetter();
				eventSetter.Event = ButtonBase.ClickEvent;
				eventSetter.Handler = new RoutedEventHandler(a);
				((Style)target).Setters.Add(eventSetter);
				break;
			}
			}
		}
	}
}
