using BookManagerModule;
using CACodec;
using ConfigureManagerModule;
using DataAccessObject;
using DownloadManagerModule;
using LocalFilesManagerModule;
using Network;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Threading;
using System.Xml;
using Utility;

namespace HyReadLibraryHD
{
	public class bookDetailPopUp : Window, IComponentConnector
	{
		private delegate void a(string A_0, Dictionary<string, string> A_1, List<string> A_2);

		private delegate void b(string A_0, string A_1);

		[CompilerGenerated]
		private sealed class c
		{
			public bookDetailPopUp a;

			public BookProvider b;

			public string c;

			internal void d()
			{
				a.a();
			}

			internal void e()
			{
				ReserveBook reserveBook = new ReserveBook();
				reserveBook.Owner = a;
				reserveBook.serviceBaseUrl = b.serviceBaseUrl;
				reserveBook.colibId = b.loginColibId;
				reserveBook.userId = b.loginUserId;
				reserveBook.password = b.loginUserPassword;
				reserveBook.serialId = c;
				reserveBook.bookId = a.m_j;
				reserveBook.hyreadType = a.ae.hyreadType;
				reserveBook.vendorId = b.vendorId;
				reserveBook.authId = a.ae.authId;
				reserveBook.ownerCode = a.ae.ownerCode;
				reserveBook.ShowDialog();
				a.b(b.vendorId, "");
			}
		}

		private List<ExtLibInfo> m_a = new List<ExtLibInfo>();

		private object m_b;

		private string m_c = "";

		private string m_d = "";

		public BookDetailPopUpCloseReason closeReason;

		private string m_e = "";

		private BookThumbnail m_f;

		private BookProvider m_g;

		private string m_h = "";

		private string m_i = "";

		private string m_j = "";

		private string m_k = "";

		private HyreadType m_l;

		private string m_m = "";

		private string m_n = "";

		private string m_o = "";

		public int trialPages;

		private string m_p = "";

		private string q = "";

		public ConfigurationManager configMng;

		private NetworkStatusCode r;

		private int s = 1;

		private string t = "";

		private HttpRequest u = new HttpRequest();

		private Dictionary<string, string> v;

		private Dictionary<string, string> w;

		private static Dictionary<string, string> x = new Dictionary<string, string>();

		private List<TextBlock> y;

		private List<TextBlock> z;

		private string aa;

		private string ab;

		private int ac;

		private bool ad;

		private ExtLibInfo ae;

		internal bookDetailPopUp af;

		internal Grid ag;

		internal Image ah;

		internal TextBlock ai;

		internal TextBlock aj;

		internal TextBlock ak;

		internal TextBlock al;

		internal TextBlock am;

		internal TextBlock an;

		internal TextBlock ao;

		internal StackPanel ap;

		internal TextBlock aq;

		internal StackPanel ar;

		internal TextBlock @as;

		internal StackPanel at;

		internal TextBlock au;

		internal StackPanel av;

		internal TextBlock aw;

		internal StackPanel ax;

		internal TextBlock ay;

		internal StackPanel az;

		internal TextBlock a0;

		internal StackPanel a1;

		internal TextBlock a2;

		internal StackPanel a3;

		internal TextBlock a4;

		internal StackPanel a5;

		internal Grid a6;

		internal RadioButton a7;

		internal RadioButton a8;

		internal RadioButton a9;

		internal RadioButton ba;

		internal RadioButton bb;

		internal RadioButton bc;

		internal RadioButton bd;

		internal RadioButton be;

		internal StackPanel bf;

		internal Grid bg;

		internal RadioButton bh;

		internal RadioButton bi;

		internal TextBlock bj;

		internal Grid bk;

		internal RadioButton bl;

		internal RadioButton bm;

		internal TextBlock bn;

		internal Grid bo;

		internal RadioButton bp;

		internal RadioButton bq;

		internal TextBlock br;

		internal RadioButton bs;

		internal RadioButton bt;

		internal ScrollViewer bu;

		internal TextBlock bv;

		internal Grid bw;

		internal Popup bx;

		internal extLendUserControl by;

		private bool bz;

		public bookDetailPopUp(object selectedItem, string inWhichPage, string curVendorId)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			dictionary.Add("Accept-Language", Global.langName);
			v = dictionary;
			w = new Dictionary<string, string>();
			List<TextBlock> list = new List<TextBlock>();
			TextBlock textBlock = new TextBlock();
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			textBlock.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock.Foreground = Brushes.White;
			textBlock.Text = Global.bookManager.LanqMng.getLangString("iWantReserve");
			list.Add(textBlock);
			TextBlock textBlock2 = new TextBlock();
			textBlock2.VerticalAlignment = VerticalAlignment.Center;
			textBlock2.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock2.Foreground = Brushes.White;
			textBlock2.Text = Global.bookManager.LanqMng.getLangString("nowLending");
			list.Add(textBlock2);
			TextBlock textBlock3 = new TextBlock();
			textBlock3.VerticalAlignment = VerticalAlignment.Center;
			textBlock3.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock3.Foreground = Brushes.White;
			textBlock3.Text = Global.bookManager.LanqMng.getLangString("read");
			list.Add(textBlock3);
			TextBlock textBlock4 = new TextBlock();
			textBlock4.VerticalAlignment = VerticalAlignment.Center;
			textBlock4.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock4.Foreground = Brushes.White;
			textBlock4.Text = Global.bookManager.LanqMng.getLangString("readAndDownload");
			list.Add(textBlock4);
			TextBlock textBlock5 = new TextBlock();
			textBlock5.VerticalAlignment = VerticalAlignment.Center;
			textBlock5.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock5.Foreground = Brushes.White;
			textBlock5.Text = Global.bookManager.LanqMng.getLangString("pauseDownload");
			list.Add(textBlock5);
			TextBlock textBlock6 = new TextBlock();
			textBlock6.VerticalAlignment = VerticalAlignment.Center;
			textBlock6.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock6.Foreground = Brushes.White;
			textBlock6.Text = Global.bookManager.LanqMng.getLangString("continueDownload");
			list.Add(textBlock6);
			TextBlock textBlock7 = new TextBlock();
			textBlock7.VerticalAlignment = VerticalAlignment.Center;
			textBlock7.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock7.Foreground = Brushes.White;
			textBlock7.Text = Global.bookManager.LanqMng.getLangString("cannotReserve");
			list.Add(textBlock7);
			TextBlock textBlock8 = new TextBlock();
			textBlock8.VerticalAlignment = VerticalAlignment.Center;
			textBlock8.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock8.Foreground = Brushes.White;
			textBlock8.Text = Global.bookManager.LanqMng.getLangString("PlayTrailer");
			list.Add(textBlock8);
			y = list;
			List<TextBlock> list2 = new List<TextBlock>();
			TextBlock textBlock9 = new TextBlock();
			textBlock9.VerticalAlignment = VerticalAlignment.Center;
			textBlock9.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock9.Foreground = Brushes.White;
			textBlock9.Text = Global.bookManager.LanqMng.getLangString("read");
			list2.Add(textBlock9);
			TextBlock textBlock10 = new TextBlock();
			textBlock10.VerticalAlignment = VerticalAlignment.Center;
			textBlock10.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock10.Foreground = Brushes.White;
			textBlock10.Text = Global.bookManager.LanqMng.getLangString("pauseDownload");
			list2.Add(textBlock10);
			TextBlock textBlock11 = new TextBlock();
			textBlock11.VerticalAlignment = VerticalAlignment.Center;
			textBlock11.HorizontalAlignment = HorizontalAlignment.Center;
			textBlock11.Foreground = Brushes.White;
			textBlock11.Text = Global.bookManager.LanqMng.getLangString("continueDownload");
			list2.Add(textBlock11);
			z = list2;
			aa = "";
			ab = "";
			ae = new ExtLibInfo();
			base._002Ector();
			Matrix transformToDevice = PresentationSource.FromVisual(Application.Current.MainWindow).CompositionTarget.TransformToDevice;
			double num = transformToDevice.M11 * 96.0;
			double m2 = transformToDevice.M22;
			if (((num == 96.0) ? 100 : ((num == 120.0) ? 125 : 150)) > 100)
			{
				base.WindowStartupLocation = WindowStartupLocation.Manual;
			}
			r = u.checkNetworkStatus();
			this.m_b = selectedItem;
			this.m_d = inWhichPage;
			this.m_c = curVendorId;
			InitializeComponent();
			base.Loaded += new RoutedEventHandler(a);
		}

		private void a(object A_0, EventArgs A_1)
		{
			s = configMng.saveProxyMode;
			t = configMng.saveProxyHttpPort;
			u = new HttpRequest(s, t);
			this.m_f = (BookThumbnail)this.m_b;
			this.m_j = this.m_f.bookID;
			if (this.m_d.Equals("Library"))
			{
				this.m_g = Global.bookManager.bookProviders[this.m_c];
				this.m_k = (this.m_g.loggedIn ? this.m_g.loginUserId : "free");
				this.m_h = this.m_g.serviceBaseUrl;
				this.m_i = this.m_g.homePage;
			}
			else if (this.m_d.Equals("BookShelf"))
			{
				try
				{
					this.m_g = Global.bookManager.bookProviders[this.m_f.vendorId];
					BookProvider bookProvider = Global.bookManager.bookProviders[this.m_f.owner];
					a0.Text = bookProvider.name;
				}
				catch
				{
				}
			}
			a5.Visibility = Visibility.Collapsed;
			bf.Visibility = Visibility.Collapsed;
			if (this.m_d.Equals("Library"))
			{
				a5.Visibility = Visibility.Visible;
				ar.Visibility = Visibility.Collapsed;
				at.Visibility = Visibility.Collapsed;
				ap.Visibility = Visibility.Visible;
				av.Visibility = Visibility.Collapsed;
				ax.Visibility = Visibility.Collapsed;
				az.Visibility = Visibility.Collapsed;
				a1.Visibility = Visibility.Collapsed;
				bu.Height = 120.0;
				a8.Visibility = Visibility.Collapsed;
				setLibraryUIValue();
			}
			else if (this.m_d.Equals("BookShelf"))
			{
				a8.Visibility = Visibility.Collapsed;
				bf.Visibility = Visibility.Visible;
				bv.Visibility = Visibility.Collapsed;
				ap.Visibility = Visibility.Collapsed;
				av.Visibility = Visibility.Visible;
				ax.Visibility = Visibility.Visible;
				az.Visibility = Visibility.Visible;
				ar.Visibility = Visibility.Collapsed;
				at.Visibility = Visibility.Collapsed;
				a1.Visibility = Visibility.Visible;
				if (this.m_f.hyreadType == HyreadType.BOOK_STORE || this.m_f.vendorId.Equals("free"))
				{
					az.Visibility = Visibility.Collapsed;
					a1.Visibility = Visibility.Collapsed;
				}
				setBookShelfUIValue();
			}
			ag.DataContext = this.m_f;
			base.Loaded -= new RoutedEventHandler(a);
		}

		public void setLibraryUIValue()
		{
			bk.Visibility = Visibility.Collapsed;
			bg.Visibility = Visibility.Collapsed;
			bo.Visibility = Visibility.Collapsed;
			bb.Visibility = Visibility.Collapsed;
			ba.Visibility = Visibility.Collapsed;
			bc.Visibility = Visibility.Collapsed;
			this.m_g.bookInfoFetched += new EventHandler<FetchBookInfoResultEventArgs>(a);
			this.m_g.fetchBookInfoAsync(this.m_j);
		}

		private void a(object A_0, FetchBookInfoResultEventArgs A_1)
		{
			BookProvider obj = (BookProvider)A_0;
			obj.bookInfoFetched -= new EventHandler<FetchBookInfoResultEventArgs>(a);
			if (obj.vendorId.Equals(this.m_c))
			{
				Dictionary<string, string> bookInfoMeta = A_1.bookInfoMeta;
				List<string> mediaType = A_1.mediaType;
				b(this.m_c, bookInfoMeta, mediaType);
			}
		}

		private void b(string A_0, Dictionary<string, string> A_1, List<string> A_2)
		{
			a method = new a(a);
			base.Dispatcher.Invoke(method, A_0, A_1, A_2);
		}

		private void a(string A_0, Dictionary<string, string> A_1, List<string> A_2)
		{
			if (!Global.bookManager.bookProviders.ContainsKey(A_0))
			{
				return;
			}
			if (this.m_d.Equals("BookShelf") && this.m_f != null)
			{
				if (x.ContainsKey(this.m_j))
				{
					return;
				}
				string text = A_1.ContainsKey("editDate") ? A_1["editDate"] : "";
				x.Add(this.m_j, text);
				if (!(text != "") || Convert.ToDateTime(text).Equals(Convert.ToDateTime(this.m_p)) || MessageBox.Show(Global.bookManager.LanqMng.getLangString("renewBookAlert"), Global.bookManager.LanqMng.getLangString("renewBook"), MessageBoxButton.YesNo) != MessageBoxResult.Yes)
				{
					return;
				}
				string text2 = A_1.ContainsKey("title") ? A_1["title"] : "";
				string text3 = A_1.ContainsKey("author") ? A_1["author"] : "";
				string text4 = A_1.ContainsKey("publisher") ? A_1["publisher"] : "";
				string text5 = A_1.ContainsKey("publishDate") ? A_1["publishDate"] : "";
				string text6 = "update book_metadata set title='" + text2 + "', author='" + text3 + "', ";
				text6 = text6 + " publisher='" + text4 + "', publishDate='" + text5 + "' where bookId='" + this.m_j + "' ";
				Global.bookManager.sqlCommandNonQuery(text6);
				text6 = "update userbook_metadata set lastCreateDate='" + text + "' ";
				text6 = text6 + " where bookId='" + this.m_j + "'  and colibid = '" + this.m_m + "'  and account = '" + this.m_k + "'  and owner = '" + this.m_n + "'  ";
				Global.bookManager.sqlCommandNonQuery(text6);
				text6 = "Delete from book_media_type where bookId='" + this.m_j + "' ";
				Global.bookManager.sqlCommandNonQuery(text6);
				List<string> list = new List<string>();
				foreach (string item in A_2)
				{
					list.Add(item);
					text6 = "Insert into book_media_type(bookId, media_type) values ('" + this.m_j + "', '" + item + "')";
					Global.bookManager.sqlCommandNonQuery(text6);
				}
				this.m_f.mediaType = list;
				closeReason = BookDetailPopUpCloseReason.DELBOOK;
				Close();
				return;
			}
			string text7 = A_1.ContainsKey("bookId") ? A_1["bookId"] : "";
			if (!this.m_j.Equals(text7) || text7.Equals(""))
			{
				return;
			}
			this.m_f.bookID = (A_1.ContainsKey("bookId") ? A_1["bookId"] : "");
			this.m_f.title = (A_1.ContainsKey("title") ? A_1["title"] : "");
			this.m_f.author = (A_1.ContainsKey("author") ? A_1["author"] : "");
			this.m_f.publisher = (A_1.ContainsKey("publisher") ? A_1["publisher"] : "");
			this.m_f.publishDate = (A_1.ContainsKey("publishDate") ? A_1["publishDate"] : "");
			this.m_f.copy = (A_1.ContainsKey("copy") ? A_1["copy"] : "");
			string htmlstring = A_1.ContainsKey("description") ? A_1["description"] : "";
			this.m_f.description = DelHTML(htmlstring);
			this.m_f.createDate = (A_1.ContainsKey("createDate") ? A_1["createDate"] : "");
			this.m_f.editDate = (A_1.ContainsKey("editDate") ? A_1["editDate"] : "");
			this.m_f.mediaType = A_2;
			this.m_f.recommendCount = c(A_1["recommendCount"]);
			this.m_f.starCount = (A_1.ContainsKey("starCount") ? c(A_1["starCount"]) : 0);
			this.m_f.trialPage = (A_1.ContainsKey("trialPage") ? c(A_1["trialPage"]) : 0);
			trialPages = this.m_f.trialPage;
			q = (A_1.ContainsKey("price") ? A_1["price"] : "");
			string text8 = A_1.ContainsKey("drm") ? A_1["drm"] : "";
			if (!text8.Equals(""))
			{
				getBookRightsAsync(text8, true);
			}
			string text9 = "";
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			for (int i = 0; i < this.m_f.mediaType.Count; i++)
			{
				if (this.m_f.mediaType[i].Contains("application/epub+phej+zip") || this.m_f.mediaType[i].Contains("application/phej") || this.m_f.mediaType[i].Contains("application/pdf"))
				{
					flag = true;
				}
				else if (this.m_f.mediaType[i].Contains("application/epub+hej+zip") || this.m_f.mediaType[i].Contains("application/hej"))
				{
					flag2 = true;
				}
				else if (this.m_f.mediaType[i].Contains("application/epub+zip"))
				{
					flag3 = true;
				}
			}
			if (flag)
			{
				text9 += "PDF";
				bg.Visibility = Visibility.Visible;
				if (trialPages > 0)
				{
					bb.Visibility = Visibility.Visible;
				}
			}
			else if (flag2)
			{
				text9 += "JPEG";
				bk.Visibility = Visibility.Visible;
				if (trialPages > 0)
				{
					ba.Visibility = Visibility.Visible;
				}
			}
			else if (flag3)
			{
				text9 += "EPUB";
				bo.Visibility = Visibility.Visible;
				if (trialPages > 0)
				{
					bc.Visibility = Visibility.Visible;
				}
			}
			if (A_0.Equals("ntl-ebookftp"))
			{
				bb.Visibility = Visibility.Collapsed;
				ba.Visibility = Visibility.Collapsed;
				bc.Visibility = Visibility.Collapsed;
			}
			else if (!Global.regPath.Equals("NCLReader") && this.m_g.loggedIn)
			{
				be.Visibility = Visibility.Visible;
			}
			aq.Text = text9;
			string str = A_1.ContainsKey("ext") ? A_1["ext"] : "";
			aa = (A_1.ContainsKey("bookType") ? A_1["bookType"] : "");
			if (aa.ToLower().Equals("video"))
			{
				aq.Text = "Video";
				aj.Text = aj.Text + " / " + Global.bookManager.LanqMng.getLangString("Director");
				al.Text = al.Text + " / " + Global.bookManager.LanqMng.getLangString("Publisher");
				an.Text = an.Text + " / " + Global.bookManager.LanqMng.getLangString("IssueDate");
				bb.Visibility = Visibility.Collapsed;
				ba.Visibility = Visibility.Collapsed;
				bc.Visibility = Visibility.Collapsed;
				bd.Visibility = Visibility.Visible;
			}
			ab = (A_1.ContainsKey("trailer") ? A_1["trailer"] : "");
			int num = 0;
			string text10 = "0";
			if (str != "")
			{
				this.m_a = new List<ExtLibInfo>();
				str = "<ext>" + str + "</ext>";
				XmlDocument xmlDocument = new XmlDocument();
				xmlDocument.LoadXml(str);
				foreach (XmlNode item2 in xmlDocument.SelectNodes("/ext/library"))
				{
					Dictionary<string, string> dictionary = new Dictionary<string, string>();
					foreach (XmlNode item3 in item2)
					{
						string name = item3.Name;
						string value = a(item3);
						dictionary.Add(name, value);
					}
					ExtLibInfo extLibInfo = new ExtLibInfo();
					extLibInfo.name = (dictionary.ContainsKey("name") ? dictionary["name"] : "");
					extLibInfo.hyreadType = (dictionary.ContainsKey("hyreadType") ? dictionary["hyreadType"] : "");
					extLibInfo.ownerCode = (dictionary.ContainsKey("ownerCode") ? dictionary["ownerCode"] : "");
					extLibInfo.copy = (dictionary.ContainsKey("copy") ? Convert.ToInt32(dictionary["copy"]) : 0);
					extLibInfo.reserveCount = (dictionary.ContainsKey("reserveCount") ? Convert.ToInt32(dictionary["reserveCount"]) : 0);
					extLibInfo.availableCount = (dictionary.ContainsKey("availableCount") ? Convert.ToInt32(dictionary["availableCount"]) : 0);
					extLibInfo.authId = (dictionary.ContainsKey("authId") ? dictionary["authId"] : "");
					if (extLibInfo.copy == -1 || extLibInfo.copy > 0)
					{
						this.m_a.Add(extLibInfo);
					}
					ac += extLibInfo.availableCount;
					num += extLibInfo.copy;
					text10 = (dictionary.ContainsKey("isReserve") ? dictionary["isReserve"] : "0");
				}
			}
			else if (ac == 0 && this.m_g.hyreadType != HyreadType.BOOK_STORE)
			{
				ac = (A_1.ContainsKey("availableCount") ? Convert.ToInt32(A_1["availableCount"]) : 0);
			}
			if (!Global.regPath.Equals("NCLReader"))
			{
				if (this.m_a.Count > 1)
				{
					ar.Visibility = Visibility.Collapsed;
					at.Visibility = Visibility.Collapsed;
					a8.Visibility = Visibility.Visible;
				}
				else if (this.m_g.hyreadType != HyreadType.BOOK_STORE)
				{
					if (this.m_a.Count > 0)
					{
						@as.Text = this.m_a[0].availableCount.ToString();
						au.Text = this.m_a[0].reserveCount.ToString();
						a0.Text = this.m_a[0].name;
						ac = this.m_a[0].availableCount;
					}
					ar.Visibility = Visibility.Visible;
					at.Visibility = Visibility.Visible;
					az.Visibility = Visibility.Visible;
					a8.Visibility = Visibility.Visible;
				}
			}
			if (Global.regPath.Equals("NCLReader"))
			{
				@as.Text = this.m_a[0].availableCount.ToString();
				au.Text = this.m_a[0].reserveCount.ToString();
				ac = this.m_a[0].availableCount;
				az.Visibility = Visibility.Collapsed;
				a3.Visibility = Visibility.Collapsed;
				ar.Visibility = Visibility.Visible;
				at.Visibility = Visibility.Visible;
				a8.Visibility = Visibility.Visible;
			}
			if (!Global.regPath.Equals("NCLReader") && num == 0 && this.m_g.hyreadType != HyreadType.BOOK_STORE)
			{
				a7.Visibility = Visibility.Visible;
				a8.Visibility = Visibility.Collapsed;
				a9.Visibility = Visibility.Collapsed;
			}
			if (ac <= 0)
			{
				a8.Content = y[0];
				if (!q.Equals(""))
				{
					a9.Visibility = Visibility.Visible;
				}
				else
				{
					a9.Visibility = Visibility.Collapsed;
				}
				if (text10.Equals("0"))
				{
					a8.Content = y[6];
					a8.IsEnabled = false;
				}
			}
			else
			{
				a8.Content = y[1];
				a9.Visibility = Visibility.Collapsed;
			}
		}

		public static string DelHTML(string Htmlstring)
		{
			Htmlstring = Regex.Replace(Htmlstring, "<script[^>]*?>.*?</script>", "", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "<(.[^>]*)>", "", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "([/r/n])[/s]+", "", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "-->", "", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "<!--.*", "", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&(quot|#34);", "/", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&(amp|#38);", "&", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&(lt|#60);", "<", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&(gt|#62);", ">", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&(nbsp|#160);", " ", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&(iexcl|#161);", "/xa1", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&(cent|#162);", "/xa2", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&(pound|#163);", "/xa3", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&(copy|#169);", "/xa9", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&#(/d+);", "", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&hellip;", "...", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&ldquo;", "\"", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&rdquo;", "\"", RegexOptions.IgnoreCase);
			Htmlstring = Regex.Replace(Htmlstring, "&middot;", ".", RegexOptions.IgnoreCase);
			Htmlstring.Replace("<", "");
			Htmlstring.Replace(">", "");
			return Htmlstring;
		}

		private string a(string A_0, HyreadType A_1, string A_2, string A_3, string A_4, string A_5)
		{
			string result = "";
			string text = "";
			string url = A_0 + "/user/check";
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml("<body></body>");
			a("account", A_4, xmlDocument);
			a("password", A_5, xmlDocument);
			if (A_3.Equals(""))
			{
				a("colibId", A_2, xmlDocument);
			}
			else
			{
				a("colibId", A_3, xmlDocument);
			}
			a("hyreadType", Convert.ToString(A_1.GetHashCode()), xmlDocument);
			XmlDocument xmlDocument2 = u.postXMLAndLoadXML(url, xmlDocument, v);
			try
			{
				text = xmlDocument2.SelectSingleNode("//result/text()").Value;
				result = xmlDocument2.SelectSingleNode("//serialId/text()").Value;
			}
			catch
			{
			}
			if (text.ToUpper().Equals("TRUE"))
			{
				return result;
			}
			return "";
		}

		public void setBookShelfUIValue()
		{
			this.m_o = this.m_f.vendorId;
			this.m_m = this.m_f.colibId;
			this.m_k = this.m_f.userId;
			this.m_n = this.m_f.owner;
			this.m_j = this.m_f.bookID;
			this.m_l = this.m_f.hyreadType;
			this.m_c = this.m_o;
			string text = "";
			bool flag = false;
			bool flag2 = false;
			bool flag3 = false;
			for (int i = 0; i < this.m_f.mediaType.Count; i++)
			{
				if (this.m_f.mediaType[i].Contains("application/epub+phej+zip") || this.m_f.mediaType[i].Contains("application/phej") || this.m_f.mediaType[i].Contains("application/pdf"))
				{
					flag = true;
				}
				else if (this.m_f.mediaType[i].Contains("application/epub+hej+zip") || this.m_f.mediaType[i].Contains("application/hej"))
				{
					flag2 = true;
				}
				if (this.m_f.mediaType[i].Contains("application/epub+zip") || this.m_f.mediaType[i].Equals("application/epub"))
				{
					flag3 = true;
				}
			}
			bool flag4 = false;
			bool flag5 = false;
			bool flag6 = false;
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			string sqlCommand = "SELECT  b.bookType, b.downloadState, b.downloadPercent from downloadstatus a, downloadstatusDetail b where a.sno in ( select ub.sno from userbook_metadata as ub where ub.vendorid = '" + this.m_o + "'  and ub.colibid = '" + this.m_m + "'  and ub.account = '" + this.m_k + "'  and ub.bookid = '" + this.m_j + "'  and ub.owner = '" + this.m_n + "' )  and a.sno = b.sno ";
			QueryResult queryResult = Global.bookManager.sqlCommandQuery(sqlCommand);
			bt.Visibility = Visibility.Collapsed;
			bj.Text = "";
			br.Text = "";
			bn.Text = "";
			while (queryResult.fetchRow())
			{
				int @int = queryResult.getInt("booktype");
				int int2 = queryResult.getInt("downloadPercent");
				if (int2 == 100)
				{
					switch (queryResult.getInt("bookType"))
					{
					case 1:
						flag5 = true;
						break;
					case 2:
						flag4 = true;
						break;
					case 4:
						flag6 = true;
						break;
					}
				}
				else
				{
					switch (@int)
					{
					case 1:
						num2 = queryResult.getInt("downloadState");
						break;
					case 2:
						num = queryResult.getInt("downloadState");
						break;
					case 4:
						num3 = queryResult.getInt("downloadState");
						break;
					}
				}
				if (queryResult.getInt("downloadState") != 10)
				{
					bt.Visibility = Visibility.Visible;
				}
				if (int2 != 0 && int2 != 100)
				{
					if (@int == BookType.PHEJ.GetHashCode())
					{
						bj.Text = int2 + " %";
					}
					if (@int == BookType.EPUB.GetHashCode())
					{
						br.Text = int2 + " %";
					}
					if (@int == BookType.HEJ.GetHashCode())
					{
						bn.Text = int2 + " %";
					}
				}
			}
			bk.Visibility = Visibility.Collapsed;
			bg.Visibility = Visibility.Collapsed;
			bo.Visibility = Visibility.Collapsed;
			if (flag)
			{
				text += "PDF";
				bg.Visibility = Visibility.Visible;
				if (flag4)
				{
					bh.IsEnabled = true;
					bh.Content = y[2];
					bi.IsEnabled = false;
				}
				else
				{
					bh.IsEnabled = true;
					bh.Content = y[3];
					bi.Visibility = Visibility.Visible;
					switch (num)
					{
					case 2:
						bi.Content = y[4];
						break;
					case 3:
						bi.Content = y[5];
						break;
					case 1:
						bi.Content = y[4];
						break;
					}
				}
			}
			else if (flag2)
			{
				text += "JPEG";
				bk.Visibility = Visibility.Visible;
				if (flag5)
				{
					bl.IsEnabled = true;
					bl.Content = y[2];
					bm.IsEnabled = false;
				}
				else
				{
					bl.IsEnabled = true;
					bl.Content = y[3];
					bm.Visibility = Visibility.Visible;
					switch (num2)
					{
					case 2:
						bm.Content = y[4];
						break;
					case 3:
						bm.Content = y[5];
						break;
					case 1:
						bm.Content = y[4];
						break;
					}
				}
			}
			if (flag3)
			{
				TextBlock textBlock = new TextBlock();
				textBlock.VerticalAlignment = VerticalAlignment.Center;
				textBlock.HorizontalAlignment = HorizontalAlignment.Center;
				textBlock.Foreground = Brushes.White;
				textBlock.Text = Global.bookManager.LanqMng.getLangString("iWantReserve");
				text += ((flag2 || flag) ? ", EPUB" : "EPUB");
				bo.Visibility = Visibility.Visible;
				if (flag6)
				{
					bp.IsEnabled = true;
					bp.Content = z[0];
					bq.IsEnabled = false;
				}
				else
				{
					bp.IsEnabled = false;
					bp.Visibility = Visibility.Collapsed;
					bq.Visibility = Visibility.Visible;
					switch (num3)
					{
					case 2:
						bq.Content = z[1];
						break;
					case 3:
						bq.Content = z[2];
						break;
					case 1:
						bq.Content = z[1];
						break;
					}
				}
			}
			aq.Text = text;
			if (this.m_l == HyreadType.BOOK_STORE || this.m_k == "free")
			{
				bs.Visibility = Visibility.Collapsed;
			}
			else
			{
				bs.Visibility = Visibility.Visible;
			}
			a(flag3, flag2, flag);
			ag.DataContext = this.m_f;
			if (r == NetworkStatusCode.OK && (flag4 || flag6 || flag5))
			{
				this.m_g.bookInfoFetched += new EventHandler<FetchBookInfoResultEventArgs>(a);
				this.m_g.fetchBookInfoAsync(this.m_j);
			}
		}

		private void a(bool A_0, bool A_1, bool A_2)
		{
			string sqlCommand = "SELECT epub_filesize, hej_filesize, phej_filesize, expireDate, readTimes, LastCreateDate, canPrint  from userbook_metadata as a  where a.vendorid = '" + this.m_o + "'  and a.colibid = '" + this.m_m + "'  and a.account = '" + this.m_k + "'  and a.bookid = '" + this.m_j + "'  and a.owner = '" + this.m_n + "' ";
			QueryResult queryResult = Global.bookManager.sqlCommandQuery(sqlCommand);
			if (queryResult.fetchRow())
			{
				CACodecTools cACodecTools = new CACodecTools();
				this.m_p = queryResult.getString("LastCreateDate");
				ay.Text = queryResult.getInt("readTimes").ToString();
				string text = cACodecTools.stringDecode(queryResult.getString("expireDate"), true);
				if (text.Contains(" "))
				{
					text = text.Substring(0, text.IndexOf(" "));
				}
				a2.Text = text;
				float num = 0f;
				num = ((A_0 && queryResult.getInt("epub_filesize") > 0) ? ((float)queryResult.getInt("epub_filesize")) : num);
				num = ((A_1 && queryResult.getInt("hej_filesize") > 0) ? ((float)queryResult.getInt("hej_filesize")) : num);
				num = ((A_2 && queryResult.getInt("phej_filesize") > 0) ? ((float)queryResult.getInt("phej_filesize")) : num);
				float num2 = 1048576f;
				aw.Text = string.Format("{0:0.0 MB}", (num > num2) ? (num / num2) : 0f);
			}
		}

		public void getBookRightsAsync(string drmStr, bool base64)
		{
			if (base64)
			{
				drmStr = new CACodecTools().Base64Decode(drmStr);
			}
			bool flag = false;
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml(drmStr);
			if (xmlDocument != null)
			{
				try
				{
					foreach (XmlNode item in xmlDocument.SelectNodes("/drm/functions"))
					{
						if (item.InnerText.Contains("canPrint"))
						{
							flag = true;
							break;
						}
					}
				}
				catch
				{
				}
			}
			this.m_f.printRights = (flag ? "Yes" : "No");
		}

		private void a(object A_0, HttpResponseXMLEventArgs A_1)
		{
			if (this.m_f == null)
			{
				return;
			}
			((HttpRequest)A_0).xmlResponsed -= new EventHandler<HttpResponseXMLEventArgs>(a);
			XmlDocument responseXML = A_1.responseXML;
			CACodecTools cACodecTools = new CACodecTools();
			bool flag = false;
			string text = "";
			try
			{
				text = responseXML.InnerText;
				if (text != "")
				{
					string xml = cACodecTools.stringDecode(text, true);
					responseXML.LoadXml(xml);
					foreach (XmlNode item in responseXML.SelectNodes("/drm/functions"))
					{
						if (item.InnerText.Contains("canPrint"))
						{
							flag = true;
							break;
						}
					}
				}
			}
			catch
			{
			}
			this.m_f.printRights = (flag ? "Yes" : "No");
			if (this.m_d.Equals("BookShelf") && text != "")
			{
				string sqlCommand = "UPDATE userbook_metadata SET bookRightsDRM ='" + text + "'  WHERE userbook_metadata.vendorid = '" + this.m_o + "'  and userbook_metadata.colibid = '" + this.m_m + "'  and userbook_metadata.account = '" + this.m_k + "'  and userbook_metadata.bookid = '" + this.m_j + "'  and userbook_metadata.owner = '" + this.m_n + "' ";
				try
				{
					Global.bookManager.sqlCommandNonQuery(sqlCommand);
				}
				catch
				{
				}
			}
		}

		private string a(SchedulingState A_0)
		{
			switch (A_0)
			{
			case SchedulingState.DOWNLOADING:
				return Global.bookManager.LanqMng.getLangString("downloading");
			case SchedulingState.FAILED:
				return Global.bookManager.LanqMng.getLangString("downloadFailed");
			case SchedulingState.FINISHED:
				return Global.bookManager.LanqMng.getLangString("downloaded");
			case SchedulingState.PAUSED:
				return Global.bookManager.LanqMng.getLangString("pauseDownload");
			case SchedulingState.SCHEDULING:
				return Global.bookManager.LanqMng.getLangString("scheduling");
			case SchedulingState.UNKNOWN:
				return Global.bookManager.LanqMng.getLangString("download");
			case SchedulingState.WAITING:
				return Global.bookManager.LanqMng.getLangString("waitDownload");
			default:
				return "";
			}
		}

		private int c(string A_0)
		{
			try
			{
				if (!A_0.Equals(""))
				{
					return Convert.ToInt32(A_0);
				}
			}
			catch
			{
			}
			return 0;
		}

		private void a(ref decimal A_0, string A_1)
		{
			try
			{
				if (!A_1.Equals(""))
				{
					A_0 = Convert.ToDecimal(A_1);
				}
			}
			catch
			{
			}
		}

		private void a(ref int A_0, string A_1)
		{
			try
			{
				if (!A_1.Equals(""))
				{
					A_0 = Convert.ToInt32(A_1);
				}
			}
			catch
			{
			}
		}

		private void a(ref double A_0, string A_1)
		{
			try
			{
				if (!A_1.Equals(""))
				{
					A_0 = Convert.ToDouble(A_1);
				}
			}
			catch
			{
			}
		}

		private string a(XmlNode A_0)
		{
			if (A_0 == null)
			{
				return "";
			}
			if (A_0.HasChildNodes)
			{
				return A_0.InnerText;
			}
			return "";
		}

		private static void a(string A_0, string A_1, XmlDocument A_2)
		{
			XmlElement newChild = A_2.CreateElement(A_0);
			XmlText newChild2 = A_2.CreateTextNode(A_1);
			A_2.DocumentElement.AppendChild(newChild);
			A_2.DocumentElement.LastChild.AppendChild(newChild2);
		}

		private void p(object A_0, RoutedEventArgs A_1)
		{
			closeReason = BookDetailPopUpCloseReason.NONE;
			Close();
		}

		private void o(object A_0, RoutedEventArgs A_1)
		{
			if (!this.m_g.loggedIn)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("pleaseLoginFirst"));
				closeReason = BookDetailPopUpCloseReason.REQUIRELOGIN;
				Close();
			}
			else if (bv.Text.StartsWith(Global.bookManager.LanqMng.getLangString("loading")))
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("loadingWaitLend"));
			}
			else if (!ad)
			{
				if (this.m_a.Count > 1)
				{
					by.setListBox(this.m_a);
					by.selectEventHandlerEvent += new EventHandler<selectEventArgs>(a);
					bx.IsOpen = true;
				}
				else if (this.m_a.Count > 0)
				{
					ae = this.m_a[0];
					this.m_g.loginSerialFetched += new EventHandler<FetchLoginSerialResultEventArgs>(a);
					this.m_g.getLoginSerialAsync();
				}
				ad = true;
			}
		}

		private void a(object A_0, selectEventArgs A_1)
		{
			bx.IsOpen = false;
			foreach (ExtLibInfo item in this.m_a)
			{
				if (item.ownerCode.Equals(A_1.vendorId))
				{
					ae = item;
					ac = item.availableCount;
					this.m_g.loginSerialFetched += new EventHandler<FetchLoginSerialResultEventArgs>(a);
					this.m_g.getLoginSerialAsync();
					break;
				}
			}
		}

		private void a(object A_0, FetchLoginSerialResultEventArgs A_1)
		{
			c c = new c();
			c.a = this;
			c.b = (BookProvider)A_0;
			c.b.loginSerialFetched -= new EventHandler<FetchLoginSerialResultEventArgs>(a);
			if (!A_1.success && !Global.localDataPath.Equals("HyReadCN"))
			{
				return;
			}
			c.c = A_1.serialId;
			if (A_1.result.ToUpper().Equals("TRUE"))
			{
				if (ac <= 0)
				{
					if (Global.regPath.Equals("NCLReader"))
					{
						base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new k(c.d));
					}
					else
					{
						base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new k(c.e));
					}
					return;
				}
				string serviceBaseUrl = c.b.serviceBaseUrl;
				HyreadType hyreadType = c.b.hyreadType;
				if (hyreadType.Equals(HyreadType.LIBRARY_CONSORTIUM))
				{
					serviceBaseUrl = Global.bookManager.bookProviders[c.b.loginColibId].serviceBaseUrl;
				}
				c.b.serialId = c.c;
				c.b.lendBookFetched += new EventHandler<FetchLendBookResultEventArgs>(a);
				c.b.lendBookAsnyc(this.m_j, ae, "", serviceBaseUrl);
			}
			else
			{
				b(c.b.vendorId, "");
			}
		}

		private void a()
		{
			XMLTool xMLTool = new XMLTool();
			string url = this.m_g.serviceBaseUrl + "/hdbook/reservebook";
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml("<body></body>");
			HyreadType hyreadType = this.m_g.hyreadType;
			xMLTool.appendChildToXML("hyreadType", Convert.ToString(hyreadType.GetHashCode()), xmlDocument);
			xMLTool.appendChildToXML("colibId", this.m_g.loginColibId, xmlDocument);
			xMLTool.appendChildToXML("userId", this.m_g.loginUserId, xmlDocument);
			xMLTool.appendChildToXML("serialId", this.m_g.loginUserPassword, xmlDocument);
			xMLTool.appendChildToXML("bookId", this.m_j, xmlDocument);
			xMLTool.appendChildToXML("device", "3", xmlDocument);
			XmlDocument xmlDocument2 = new HttpRequest().postXMLAndLoadXML(url, xmlDocument);
			try
			{
				string value = xmlDocument2.SelectSingleNode("//result/text()").Value;
				MessageBox.Show(xmlDocument2.SelectSingleNode("//message/text()").Value);
			}
			catch
			{
				MessageBox.Show((xmlDocument2.SelectSingleNode("//result/text()").Value == "true") ? Global.bookManager.LanqMng.getLangString("reserveSuccess") : Global.bookManager.LanqMng.getLangString("reserveFailure"));
			}
			Close();
		}

		private void a(object A_0, FetchLendBookResultEventArgs A_1)
		{
			BookProvider bookProvider = (BookProvider)A_0;
			bookProvider.lendBookFetched -= new EventHandler<FetchLendBookResultEventArgs>(a);
			if (A_1.success)
			{
				b(bookProvider.vendorId, A_1.message);
			}
		}

		private void b(string A_0, string A_1)
		{
			b method = new b(a);
			base.Dispatcher.Invoke(method, A_0, A_1);
		}

		private void a(string A_0, string A_1)
		{
			if (!Global.bookManager.bookProviders.ContainsKey(A_0))
			{
				return;
			}
			if (!A_1.Equals(""))
			{
				if (A_1.Contains(Global.bookManager.LanqMng.getLangString("lend")))
				{
					MessageBox.Show(A_1, Global.bookManager.LanqMng.getLangString("lendMsg"));
				}
				else
				{
					MessageBox.Show(A_1);
				}
			}
			closeReason = BookDetailPopUpCloseReason.LENDBOOK;
			base.Cursor = Cursors.None;
			Close();
		}

		private void a(BookType A_0, bool A_1, bool A_2)
		{
			if (r != 0)
			{
				return;
			}
			BookThumbnail bookThumbnail = (BookThumbnail)this.m_b;
			bookThumbnail.assetUuid = ((bookThumbnail.assetUuid == null) ? "" : bookThumbnail.assetUuid);
			bookThumbnail.s3Url = ((bookThumbnail.s3Url == null) ? "" : bookThumbnail.s3Url);
			string serviceBaseUrl = this.m_g.serviceBaseUrl;
			string contentServer = this.m_g.contentServer.Equals("") ? serviceBaseUrl : this.m_g.contentServer;
			if (A_2)
			{
				if (Global.localDataPath.Equals("HyReadCN"))
				{
					serviceBaseUrl = serviceBaseUrl.Substring(0, serviceBaseUrl.LastIndexOf("/") + 1) + "freecn";
					contentServer = serviceBaseUrl;
					b(serviceBaseUrl);
					Global.bookManager.startOrResumeDownload(bookThumbnail.assetUuid, bookThumbnail.s3Url, contentServer, serviceBaseUrl, "freecn", "", "free", this.m_j, A_0.GetHashCode(), A_2, bookThumbnail.owner, A_1, trialPages);
				}
				else
				{
					serviceBaseUrl = serviceBaseUrl.Substring(0, serviceBaseUrl.LastIndexOf("/") + 1) + "free";
					contentServer = serviceBaseUrl;
					b(serviceBaseUrl);
					Global.bookManager.startOrResumeDownload(bookThumbnail.assetUuid, bookThumbnail.s3Url, contentServer, serviceBaseUrl, this.m_g.vendorId, this.m_g.loginColibId, "free", this.m_j, A_0.GetHashCode(), A_2, bookThumbnail.owner, A_1, trialPages);
				}
			}
			else
			{
				Global.bookManager.startOrResumeDownload(bookThumbnail.assetUuid, bookThumbnail.s3Url, contentServer, serviceBaseUrl, this.m_g.vendorId, this.m_g.loginColibId, this.m_k, this.m_j, A_0.GetHashCode(), A_2, bookThumbnail.owner, A_1, trialPages);
			}
		}

		private void b(string A_0)
		{
			string userDataPath = new LocalFilesManager(Global.localDataPath, "tryread", "tryread", "tryread").getUserDataPath();
			if (!File.Exists(userDataPath + "\\HyHDWL.ps2"))
			{
				FileDownloader fileDownloader = new FileDownloader(A_0 + "/user/free.p12", userDataPath + "\\HyHDWL.ps2", "");
				fileDownloader.setProxyPara(s, t);
				fileDownloader.startDownload();
			}
		}

		private void n(object A_0, RoutedEventArgs A_1)
		{
			if (r != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetCannotDownload"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
			}
			a(BookType.PHEJ, false, false);
			closeReason = BookDetailPopUpCloseReason.DOWNLOAD;
			Close();
		}

		private void m(object A_0, RoutedEventArgs A_1)
		{
			if (r != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetCannotDownload"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
			}
			a(BookType.HEJ, false, false);
			closeReason = BookDetailPopUpCloseReason.DOWNLOAD;
			Close();
		}

		private bool a(int A_0)
		{
			string userBookPath = new LocalFilesManager(Global.localDataPath, this.m_f.vendorId, this.m_f.colibId, this.m_f.userId).getUserBookPath(this.m_j, A_0, this.m_f.owner);
			bool flag = File.Exists(userBookPath + "\\book.xml");
			bool flag2 = File.Exists(userBookPath + "\\HYWEB\\thumbs\\thumbs_ok");
			bool flag3 = File.Exists(userBookPath + "\\HYWEB\\infos_ok");
			if (!flag || !flag2 || !flag3)
			{
				return false;
			}
			return true;
		}

		private void l(object A_0, RoutedEventArgs A_1)
		{
			BookThumbnail bookThumbnail = (BookThumbnail)this.m_b;
			if (!a(1) && r != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetCannotDownload"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
				Close();
			}
			else
			{
				a(BookType.HEJ, true, false);
				closeReason = BookDetailPopUpCloseReason.READHEJ;
				Close();
			}
		}

		private void k(object A_0, RoutedEventArgs A_1)
		{
			BookThumbnail bookThumbnail = (BookThumbnail)this.m_b;
			if (!a(2) && r != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetCannotDownload"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
				Close();
			}
			else
			{
				a(BookType.PHEJ, true, false);
				closeReason = BookDetailPopUpCloseReason.READPHEJ;
				Close();
			}
		}

		private void j(object A_0, RoutedEventArgs A_1)
		{
			if (r != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("netDisconnetCannotDownload"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
				Close();
			}
			else
			{
				a(BookType.EPUB, false, false);
				closeReason = BookDetailPopUpCloseReason.DOWNLOAD;
				Close();
			}
		}

		private void i(object A_0, RoutedEventArgs A_1)
		{
			closeReason = BookDetailPopUpCloseReason.READEPUB;
			Close();
		}

		private void h(object A_0, RoutedEventArgs A_1)
		{
			a(BookType.HEJ, true, true);
			closeReason = BookDetailPopUpCloseReason.TRYREADHEJ;
			Close();
		}

		private void g(object A_0, RoutedEventArgs A_1)
		{
			a(BookType.PHEJ, true, true);
			closeReason = BookDetailPopUpCloseReason.TRYREADPHEJ;
			Close();
		}

		private void f(object A_0, RoutedEventArgs A_1)
		{
			a(BookType.EPUB, true, true);
			closeReason = BookDetailPopUpCloseReason.TRYREADEPUB;
			Close();
		}

		private void e(object A_0, RoutedEventArgs A_1)
		{
			if (MessageBox.Show(Global.bookManager.LanqMng.getLangString("readAgainReDownload"), Global.bookManager.LanqMng.getLangString("areEmptyFile"), MessageBoxButton.YesNo) == MessageBoxResult.Yes)
			{
				closeReason = BookDetailPopUpCloseReason.DELBOOK;
			}
			Close();
		}

		private void d(object A_0, RoutedEventArgs A_1)
		{
			if (r != 0)
			{
				MessageBox.Show(Global.bookManager.LanqMng.getLangString("offlineCannotReturn"), Global.bookManager.LanqMng.getLangString("netAnomaly"));
				return;
			}
			base.Cursor = Cursors.Wait;
			string url = this.m_g.serviceBaseUrl + "/book/return/" + this.m_j;
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml("<body></body>");
			a("account", this.m_k, xmlDocument);
			a("hyreadType", Convert.ToString(this.m_l.GetHashCode()), xmlDocument);
			if (this.m_l == HyreadType.LIBRARY_CONSORTIUM)
			{
				a("ownerCode", this.m_n, xmlDocument);
			}
			else
			{
				a("ownerCode", this.m_m, xmlDocument);
			}
			string innerText = u.postXMLAndLoadXML(url, xmlDocument, v).InnerText;
			BookThumbnail bookThumbnail = (BookThumbnail)this.m_b;
			Global.bookManager.returnBook(this.m_o, this.m_m, this.m_k, this.m_j, bookThumbnail.owner);
			closeReason = BookDetailPopUpCloseReason.RETURNBOOK;
			base.Cursor = Cursors.None;
			Close();
		}

		private void c(object A_0, RoutedEventArgs A_1)
		{
			string text = this.m_i.EndsWith("/") ? this.m_i : (this.m_i + "/");
			if (this.m_g.loggedIn)
			{
				string text2 = a("http://ebook.hyread.com.tw/service/getServerTime.jsp");
				text2 = a("http://ebook.hyread.com.cn/service/getServerTime.jsp");
				string str = "<request>";
				str += "<action>login</action>";
				str = str + "<time><![CDATA[" + text2 + "]]></time>";
				object[] obj = new object[4]
				{
					str,
					"<hyreadtype>",
					null,
					null
				};
				HyreadType hyreadType = this.m_g.hyreadType;
				obj[2] = hyreadType.GetHashCode();
				obj[3] = "</hyreadtype>";
				str = string.Concat(obj);
				str = str + "<unit>" + this.m_g.vendorId + "</unit>";
				str += "<colibid></colibid>";
				str = str + "<account><![CDATA[" + this.m_g.loginUserId + "]]></account>";
				str = str + "<passwd><![CDATA[" + this.m_g.loginUserPassword + "]]></passwd>";
				str += "<guestIP></guestIP>";
				str += "</request>";
				byte[] bytes = Encoding.Default.GetBytes("hyweb101S00ebook");
				string text3 = Uri.EscapeDataString(new CACodecTools().stringEncode(str, bytes, true));
				text = text + "service/authCenter.jsp?data=" + text3 + "&rdurl=/bookDetail.jsp?id=" + this.m_j;
				Process.Start(text);
				Close();
			}
		}

		private void b(object A_0, RoutedEventArgs A_1)
		{
			string text = "http://ebook.hyread.com.tw";
			if (this.m_g.hyreadType != HyreadType.BOOK_STORE)
			{
				text = text + "/bookDetail.jsp?id=" + this.m_j;
			}
			else if (this.m_g.loggedIn)
			{
				string str = a("http://ebook.hyread.com.tw/service/getServerTime.jsp");
				string str2 = "<request>";
				str2 += "<action>login</action>";
				str2 = str2 + "<time><![CDATA[" + str + "]]></time>";
				str2 += "<hyreadtype>2</hyreadtype>";
				str2 += "<unit>hyread</unit>";
				str2 += "<colibid></colibid>";
				str2 = str2 + "<account><![CDATA[" + this.m_g.loginUserId + "]]></account>";
				str2 = str2 + "<passwd><![CDATA[" + this.m_g.loginUserPassword + "]]></passwd>";
				str2 += "<guestIP></guestIP>";
				str2 += "</request>";
				byte[] bytes = Encoding.Default.GetBytes("hyweb101S00ebook");
				string text2 = Uri.EscapeDataString(new CACodecTools().stringEncode(str2, bytes, true));
				text = text + "/service/authCenter.jsp?data=" + text2 + "&rdurl=/bookDetail.jsp?id=" + this.m_j;
			}
			else
			{
				text = text + "/bookDetail.jsp?id=" + this.m_j;
			}
			Process.Start(text);
			Close();
		}

		private string a(string A_0)
		{
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml("<body></body>");
			return u.postXMLAndLoadXML(A_0, xmlDocument).InnerText;
		}

		private void a(object A_0, CancelEventArgs A_1)
		{
			this.m_f = null;
			this.m_g = null;
			this.m_b = null;
			this.m_h = "";
			this.m_i = "";
			this.m_j = "";
			this.m_k = "";
			this.m_m = "";
			this.m_n = "";
			this.m_o = "";
			w = null;
			BindingOperations.ClearAllBindings(this);
		}

		private void a(object A_0, RoutedEventArgs A_1)
		{
			new MoviePlayer(ab, true).ShowDialog();
			Close();
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!bz)
			{
				bz = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/bookdetailpopup.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				af = (bookDetailPopUp)target;
				af.Closing += new CancelEventHandler(a);
				break;
			case 2:
				ag = (Grid)target;
				break;
			case 3:
				ah = (Image)target;
				break;
			case 4:
				ai = (TextBlock)target;
				break;
			case 5:
				aj = (TextBlock)target;
				break;
			case 6:
				ak = (TextBlock)target;
				break;
			case 7:
				al = (TextBlock)target;
				break;
			case 8:
				am = (TextBlock)target;
				break;
			case 9:
				an = (TextBlock)target;
				break;
			case 10:
				ao = (TextBlock)target;
				break;
			case 11:
				ap = (StackPanel)target;
				break;
			case 12:
				aq = (TextBlock)target;
				break;
			case 13:
				ar = (StackPanel)target;
				break;
			case 14:
				@as = (TextBlock)target;
				break;
			case 15:
				at = (StackPanel)target;
				break;
			case 16:
				au = (TextBlock)target;
				break;
			case 17:
				av = (StackPanel)target;
				break;
			case 18:
				aw = (TextBlock)target;
				break;
			case 19:
				ax = (StackPanel)target;
				break;
			case 20:
				ay = (TextBlock)target;
				break;
			case 21:
				az = (StackPanel)target;
				break;
			case 22:
				a0 = (TextBlock)target;
				break;
			case 23:
				a1 = (StackPanel)target;
				break;
			case 24:
				a2 = (TextBlock)target;
				break;
			case 25:
				a3 = (StackPanel)target;
				break;
			case 26:
				a4 = (TextBlock)target;
				break;
			case 27:
				a5 = (StackPanel)target;
				break;
			case 28:
				a6 = (Grid)target;
				break;
			case 29:
				a7 = (RadioButton)target;
				break;
			case 30:
				a8 = (RadioButton)target;
				a8.Click += new RoutedEventHandler(o);
				break;
			case 31:
				a9 = (RadioButton)target;
				a9.Click += new RoutedEventHandler(b);
				break;
			case 32:
				ba = (RadioButton)target;
				ba.Click += new RoutedEventHandler(h);
				break;
			case 33:
				bb = (RadioButton)target;
				bb.Click += new RoutedEventHandler(g);
				break;
			case 34:
				bc = (RadioButton)target;
				bc.Click += new RoutedEventHandler(f);
				break;
			case 35:
				bd = (RadioButton)target;
				bd.Click += new RoutedEventHandler(a);
				break;
			case 36:
				be = (RadioButton)target;
				be.Click += new RoutedEventHandler(c);
				break;
			case 37:
				bf = (StackPanel)target;
				break;
			case 38:
				bg = (Grid)target;
				break;
			case 39:
				bh = (RadioButton)target;
				bh.Click += new RoutedEventHandler(k);
				break;
			case 40:
				bi = (RadioButton)target;
				bi.Click += new RoutedEventHandler(n);
				break;
			case 41:
				bj = (TextBlock)target;
				break;
			case 42:
				bk = (Grid)target;
				break;
			case 43:
				bl = (RadioButton)target;
				bl.Click += new RoutedEventHandler(l);
				break;
			case 44:
				bm = (RadioButton)target;
				bm.Click += new RoutedEventHandler(m);
				break;
			case 45:
				bn = (TextBlock)target;
				break;
			case 46:
				bo = (Grid)target;
				break;
			case 47:
				bp = (RadioButton)target;
				bp.Click += new RoutedEventHandler(i);
				break;
			case 48:
				bq = (RadioButton)target;
				bq.Click += new RoutedEventHandler(j);
				break;
			case 49:
				br = (TextBlock)target;
				break;
			case 50:
				bs = (RadioButton)target;
				bs.Click += new RoutedEventHandler(d);
				break;
			case 51:
				bt = (RadioButton)target;
				bt.Click += new RoutedEventHandler(e);
				break;
			case 52:
				bu = (ScrollViewer)target;
				break;
			case 53:
				bv = (TextBlock)target;
				break;
			case 54:
				bw = (Grid)target;
				break;
			case 55:
				bx = (Popup)target;
				break;
			case 56:
				by = (extLendUserControl)target;
				break;
			default:
				bz = true;
				break;
			}
		}
	}
}
