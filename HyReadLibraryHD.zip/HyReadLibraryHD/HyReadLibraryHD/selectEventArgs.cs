using System;
using System.Runtime.CompilerServices;

namespace HyReadLibraryHD
{
	public class selectEventArgs : EventArgs
	{
		[CompilerGenerated]
		private string a;

		public string vendorId
		{
			[CompilerGenerated]
			get
			{
				return a;
			}
			[CompilerGenerated]
			set
			{
				a = value;
			}
		}
	}
}
