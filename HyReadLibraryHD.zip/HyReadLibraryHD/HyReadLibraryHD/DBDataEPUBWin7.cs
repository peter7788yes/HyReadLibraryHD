using CACodec;
using DigitalBookEPUBModule.Portable;
using DigitalBookEPUBModule.Portable.Interface;
using HyReadLibraryHD.DataObject;
using Microsoft.Runtime.CompilerServices;
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HyReadLibraryHD
{
	public class DBDataEPUBWin7 : DigitalBookEPUBData
	{
		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct a : IAsyncStateMachine
		{
			public int a;

			public AsyncTaskMethodBuilder<XDocument> b;

			public string c;

			public string d;

			public DBDataEPUBWin7 e;

			public string f;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument> m_g;

			private void g()
			{
				int num = a;
				DBDataEPUBWin7 dBDataEPUBWin = e;
				XDocument result;
				try
				{
					Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument> awaiter;
					if (num != 0)
					{
						string filePath = c + "\\" + d;
						awaiter = AwaitExtensions.GetAwaiter(dBDataEPUBWin.getDocumentSafely(filePath, f));
						if (!awaiter.IsCompleted)
						{
							num = (a = 0);
							this.m_g = awaiter;
							b.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = this.m_g;
						this.m_g = default(Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument>);
						num = (a = -1);
					}
					result = awaiter.GetResult();
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult(result);
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in g
				this.g();
			}

			[DebuggerHidden]
			private void g(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in g
				this.g(A_0);
			}
		}

		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct b : IAsyncStateMachine
		{
			public int a;

			public AsyncTaskMethodBuilder<bool> b;

			public string c;

			private void d()
			{
				bool result;
				try
				{
					result = File.Exists(c);
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult(result);
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in d
				this.d();
			}

			[DebuggerHidden]
			private void d(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in d
				this.d(A_0);
			}
		}

		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct c : IAsyncStateMachine
		{
			public int a;

			public AsyncTaskMethodBuilder<XDocument> b;

			public string c;

			public string d;

			public DBDataEPUBWin7 e;

			public byte[] f;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument> m_g;

			private void g()
			{
				int num = a;
				DBDataEPUBWin7 dBDataEPUBWin = e;
				XDocument result;
				try
				{
					Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument> awaiter;
					if (num != 0)
					{
						string filePath = c + "\\" + d;
						awaiter = AwaitExtensions.GetAwaiter(dBDataEPUBWin.getDocumentSafely(filePath, f));
						if (!awaiter.IsCompleted)
						{
							num = (a = 0);
							this.m_g = awaiter;
							b.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = this.m_g;
						this.m_g = default(Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument>);
						num = (a = -1);
					}
					result = awaiter.GetResult();
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult(result);
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in g
				this.g();
			}

			[DebuggerHidden]
			private void g(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in g
				this.g(A_0);
			}
		}

		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct d : IAsyncStateMachine
		{
			public int a;

			public AsyncTaskMethodBuilder<XDocument> b;

			public string c;

			public string d;

			public DBDataEPUBWin7 e;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument> m_f;

			private void f()
			{
				int num = a;
				DBDataEPUBWin7 dBDataEPUBWin = e;
				XDocument result;
				try
				{
					Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument> awaiter;
					if (num != 0)
					{
						string filePath = c + "\\" + d;
						awaiter = AwaitExtensions.GetAwaiter(dBDataEPUBWin.getDocumentSafely(filePath, ""));
						if (!awaiter.IsCompleted)
						{
							num = (a = 0);
							this.m_f = awaiter;
							b.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = this.m_f;
						this.m_f = default(Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument>);
						num = (a = -1);
					}
					result = awaiter.GetResult();
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult(result);
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in f
				this.f();
			}

			[DebuggerHidden]
			private void f(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in f
				this.f(A_0);
			}
		}

		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct e : IAsyncStateMachine
		{
			public int a;

			public AsyncTaskMethodBuilder<XDocument> b;

			public DBDataEPUBWin7 c;

			public string d;

			public string e;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument> m_f;

			private void f()
			{
				int num = a;
				DBDataEPUBWin7 dBDataEPUBWin = c;
				XDocument result;
				try
				{
					Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument> awaiter;
					if (num != 0)
					{
						new XDocument();
						awaiter = AwaitExtensions.GetAwaiter(dBDataEPUBWin.getDocumentSafely(d, e));
						if (!awaiter.IsCompleted)
						{
							num = (a = 0);
							this.m_f = awaiter;
							b.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = this.m_f;
						this.m_f = default(Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument>);
						num = (a = -1);
					}
					result = awaiter.GetResult();
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult(result);
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in f
				this.f();
			}

			[DebuggerHidden]
			private void f(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in f
				this.f(A_0);
			}
		}

		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct f : IAsyncStateMachine
		{
			public int a;

			public AsyncTaskMethodBuilder<XDocument> b;

			public DBDataEPUBWin7 c;

			public string d;

			public byte[] e;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument> m_f;

			private void f()
			{
				int num = a;
				DBDataEPUBWin7 dBDataEPUBWin = c;
				XDocument result;
				try
				{
					Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument> awaiter;
					if (num != 0)
					{
						awaiter = AwaitExtensions.GetAwaiter(dBDataEPUBWin.getDocumentSafely(d, e));
						if (!awaiter.IsCompleted)
						{
							num = (a = 0);
							this.m_f = awaiter;
							b.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = this.m_f;
						this.m_f = default(Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument>);
						num = (a = -1);
					}
					result = awaiter.GetResult();
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult(result);
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in f
				this.f();
			}

			[DebuggerHidden]
			private void f(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in f
				this.f(A_0);
			}
		}

		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct g : IAsyncStateMachine
		{
			public int a;

			public AsyncTaskMethodBuilder<XDocument> b;

			public string c;

			public string d;

			public DBDataEPUBWin7 e;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument> m_f;

			private void f()
			{
				int num = a;
				DBDataEPUBWin7 dBDataEPUBWin = e;
				XDocument result;
				try
				{
					Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument> awaiter;
					if (num != 0)
					{
						string filePath = c + d;
						awaiter = AwaitExtensions.GetAwaiter(dBDataEPUBWin.getDocumentSafely(filePath, ""));
						if (!awaiter.IsCompleted)
						{
							num = (a = 0);
							this.m_f = awaiter;
							b.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = this.m_f;
						this.m_f = default(Microsoft.Runtime.CompilerServices.TaskAwaiter<XDocument>);
						num = (a = -1);
					}
					result = awaiter.GetResult();
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult(result);
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in f
				this.f();
			}

			[DebuggerHidden]
			private void f(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in f
				this.f(A_0);
			}
		}

		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct h : IAsyncStateMachine
		{
			public int a;

			public AsyncTaskMethodBuilder<XDocument> b;

			public DBDataEPUBWin7 c;

			public string d;

			public byte[] e;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter<bool> m_f;

			private void f()
			{
				int num = a;
				DBDataEPUBWin7 dBDataEPUBWin = c;
				XDocument result;
				try
				{
					Microsoft.Runtime.CompilerServices.TaskAwaiter<bool> awaiter;
					if (num != 0)
					{
						awaiter = AwaitExtensions.GetAwaiter(dBDataEPUBWin.isFileExist(d));
						if (!awaiter.IsCompleted)
						{
							num = (a = 0);
							this.m_f = awaiter;
							b.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = this.m_f;
						this.m_f = default(Microsoft.Runtime.CompilerServices.TaskAwaiter<bool>);
						num = (a = -1);
					}
					if (!awaiter.GetResult())
					{
						goto IL_00cb;
					}
					Stream stream = new CACodecTools().fileAESDecode(d, e, false);
					StreamReader streamReader = new StreamReader(stream, Encoding.UTF8);
					string text;
					try
					{
						text = streamReader.ReadToEnd();
					}
					finally
					{
						if (num < 0 && streamReader != null)
						{
							((IDisposable)streamReader).Dispose();
						}
					}
					stream.Close();
					try
					{
						result = XDocument.Parse(text, LoadOptions.None);
					}
					catch (Exception)
					{
						goto IL_00cb;
					}
					goto end_IL_000e;
					IL_00cb:
					result = null;
					end_IL_000e:;
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult(result);
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in f
				this.f();
			}

			[DebuggerHidden]
			private void f(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in f
				this.f(A_0);
			}
		}

		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct i : IAsyncStateMachine
		{
			public int a;

			public AsyncTaskMethodBuilder<XDocument> b;

			public DBDataEPUBWin7 c;

			public string d;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter<bool> m_e;

			private void e()
			{
				int num = a;
				DBDataEPUBWin7 dBDataEPUBWin = c;
				XDocument result;
				try
				{
					Microsoft.Runtime.CompilerServices.TaskAwaiter<bool> awaiter;
					if (num != 0)
					{
						awaiter = AwaitExtensions.GetAwaiter(dBDataEPUBWin.isFileExist(d));
						if (!awaiter.IsCompleted)
						{
							num = (a = 0);
							this.m_e = awaiter;
							b.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = this.m_e;
						this.m_e = default(Microsoft.Runtime.CompilerServices.TaskAwaiter<bool>);
						num = (a = -1);
					}
					if (!awaiter.GetResult())
					{
						goto IL_0082;
					}
					try
					{
						result = XDocument.Load(d);
					}
					catch (Exception)
					{
						goto IL_0082;
					}
					goto end_IL_000e;
					IL_0082:
					result = null;
					end_IL_000e:;
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult(result);
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in e
				this.e();
			}

			[DebuggerHidden]
			private void e(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in e
				this.e(A_0);
			}
		}

		public DBDataEPUBWin7(string bookPath, byte[] desKey)
			: base(bookPath, desKey)
		{
		}

		public DBDataEPUBWin7(string bookPath, string bookDataFoldername)
			: base(bookPath, bookDataFoldername)
		{
		}

		[AsyncStateMachine(typeof(a))]
		protected override Task<XDocument> getBookXMLDocument(string bookPath, string XMLFilename, string convertId = "")
		{
			a stateMachine = default(a);
			stateMachine.e = this;
			stateMachine.c = bookPath;
			stateMachine.d = XMLFilename;
			stateMachine.f = convertId;
			stateMachine.b = AsyncTaskMethodBuilder<XDocument>.Create();
			stateMachine.a = -1;
			AsyncTaskMethodBuilder<XDocument> b = stateMachine.b;
			b.Start(ref stateMachine);
			return stateMachine.b.Task;
		}

		[AsyncStateMachine(typeof(b))]
		protected override Task<bool> isFileExist(string targetPath)
		{
			b stateMachine = default(b);
			stateMachine.c = targetPath;
			stateMachine.b = AsyncTaskMethodBuilder<bool>.Create();
			stateMachine.a = -1;
			AsyncTaskMethodBuilder<bool> b = stateMachine.b;
			b.Start(ref stateMachine);
			return stateMachine.b.Task;
		}

		[AsyncStateMachine(typeof(c))]
		protected override Task<XDocument> getContainerXmlDocument(string bookPath, string XMLFilename, string convertId = "", byte[] desKey = null)
		{
			c stateMachine = default(c);
			stateMachine.e = this;
			stateMachine.c = bookPath;
			stateMachine.d = XMLFilename;
			stateMachine.f = desKey;
			stateMachine.b = AsyncTaskMethodBuilder<XDocument>.Create();
			stateMachine.a = -1;
			AsyncTaskMethodBuilder<XDocument> b = stateMachine.b;
			b.Start(ref stateMachine);
			return stateMachine.b.Task;
		}

		protected override IEpubObject getIEpubObject()
		{
			return new EpubObject();
		}

		[AsyncStateMachine(typeof(d))]
		protected override Task<XDocument> getiBookDisplayOptionsDocument(string bookPath, string XMLFilename)
		{
			d stateMachine = default(d);
			stateMachine.e = this;
			stateMachine.c = bookPath;
			stateMachine.d = XMLFilename;
			stateMachine.b = AsyncTaskMethodBuilder<XDocument>.Create();
			stateMachine.a = -1;
			AsyncTaskMethodBuilder<XDocument> b = stateMachine.b;
			b.Start(ref stateMachine);
			return stateMachine.b.Task;
		}

		[AsyncStateMachine(typeof(e))]
		protected override Task<XDocument> getTocDocument(string tocFilePath, string convertId = "")
		{
			e stateMachine = default(e);
			stateMachine.c = this;
			stateMachine.d = tocFilePath;
			stateMachine.e = convertId;
			stateMachine.b = AsyncTaskMethodBuilder<XDocument>.Create();
			stateMachine.a = -1;
			AsyncTaskMethodBuilder<XDocument> b = stateMachine.b;
			b.Start(ref stateMachine);
			return stateMachine.b.Task;
		}

		[AsyncStateMachine(typeof(f))]
		protected override Task<XDocument> getTocDocument(string tocFilePath, byte[] desKey)
		{
			f stateMachine = default(f);
			stateMachine.c = this;
			stateMachine.d = tocFilePath;
			stateMachine.e = desKey;
			stateMachine.b = AsyncTaskMethodBuilder<XDocument>.Create();
			stateMachine.a = -1;
			AsyncTaskMethodBuilder<XDocument> b = stateMachine.b;
			b.Start(ref stateMachine);
			return stateMachine.b.Task;
		}

		[AsyncStateMachine(typeof(g))]
		protected override Task<XDocument> getSmilDocument(string bookPath, string XMLFilename)
		{
			g stateMachine = default(g);
			stateMachine.e = this;
			stateMachine.c = bookPath;
			stateMachine.d = XMLFilename;
			stateMachine.b = AsyncTaskMethodBuilder<XDocument>.Create();
			stateMachine.a = -1;
			AsyncTaskMethodBuilder<XDocument> b = stateMachine.b;
			b.Start(ref stateMachine);
			return stateMachine.b.Task;
		}

		[AsyncStateMachine(typeof(h))]
		protected Task<XDocument> getDocumentSafely(string filePath, byte[] desKey)
		{
			h stateMachine = default(h);
			stateMachine.c = this;
			stateMachine.d = filePath;
			stateMachine.e = desKey;
			stateMachine.b = AsyncTaskMethodBuilder<XDocument>.Create();
			stateMachine.a = -1;
			AsyncTaskMethodBuilder<XDocument> b = stateMachine.b;
			b.Start(ref stateMachine);
			return stateMachine.b.Task;
		}

		[AsyncStateMachine(typeof(i))]
		protected Task<XDocument> getDocumentSafely(string filePath, string convertId)
		{
			i stateMachine = default(i);
			stateMachine.c = this;
			stateMachine.d = filePath;
			stateMachine.b = AsyncTaskMethodBuilder<XDocument>.Create();
			stateMachine.a = -1;
			AsyncTaskMethodBuilder<XDocument> b = stateMachine.b;
			b.Start(ref stateMachine);
			return stateMachine.b.Task;
		}

		private string a([CallerMemberName] string A_0 = "")
		{
			return A_0;
		}
	}
}
