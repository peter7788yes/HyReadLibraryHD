using System.Runtime.CompilerServices;

namespace HyReadLibraryHD
{
	public class TagListData
	{
		[CompilerGenerated]
		private string a;

		[CompilerGenerated]
		private bool b;

		public string tagName
		{
			[CompilerGenerated]
			get
			{
				return a;
			}
			[CompilerGenerated]
			set
			{
				a = value;
			}
		}

		public bool hasTag
		{
			[CompilerGenerated]
			get
			{
				return b;
			}
			[CompilerGenerated]
			set
			{
				b = value;
			}
		}
	}
}
