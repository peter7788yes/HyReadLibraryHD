using System;
using System.Collections.Generic;

namespace HyReadLibraryHD
{
	public interface ISoftwareInfo
	{
		string softwareTitle();

		string originalAccountText();

		string originalPasswordText();

		Uri iconImagePath();

		Uri backgroundImagePath();

		string hyperlinkForgetPassword();

		Uri hyperlinkForgetPasswordLink();

		string hyperlinkRegister();

		Uri hyperlinkRegisterLink();

		string loginButtonContent();

		string cancelButtonContent();

		List<string> comboColibs();

		string helpContent();

		List<string> comboColibsId();
	}
}
