using BookManagerModule;
using System;
using System.Collections.Generic;

namespace HyReadLibraryHD
{
	public class HyReadInfo : ISoftwareInfo
	{
		private string a;

		public HyReadInfo(string clickedVendorId)
		{
			a = clickedVendorId;
		}

		public string softwareTitle()
		{
			return Global.bookManager.bookProviders[a].name;
		}

		public string originalAccountText()
		{
			return Global.bookManager.LanqMng.getLangString("plsEnterAccount");
		}

		public string originalPasswordText()
		{
			return Global.bookManager.LanqMng.getLangString("plsEnterPassword");
		}

		public Uri iconImagePath()
		{
			string uriString = "";
			if (uriString != "")
			{
				return new Uri(uriString, UriKind.RelativeOrAbsolute);
			}
			return null;
		}

		public Uri backgroundImagePath()
		{
			string uriString = "";
			if (uriString != "")
			{
				return new Uri(uriString, UriKind.RelativeOrAbsolute);
			}
			return null;
		}

		public Uri hyperlinkForgetPasswordLink()
		{
			return new Uri(Global.bookManager.bookProviders[a].forgetPassword, UriKind.RelativeOrAbsolute);
		}

		public Uri hyperlinkRegisterLink()
		{
			return new Uri(Global.bookManager.bookProviders[a].applyAccount, UriKind.RelativeOrAbsolute);
		}

		public string hyperlinkForgetPassword()
		{
			return Global.bookManager.LanqMng.getLangString("forgotPassword");
		}

		public string hyperlinkRegister()
		{
			return Global.bookManager.LanqMng.getLangString("registMember");
		}

		public string loginButtonContent()
		{
			return Global.bookManager.LanqMng.getLangString("login");
		}

		public string cancelButtonContent()
		{
			return Global.bookManager.LanqMng.getLangString("cancel");
		}

		public List<string> comboColibs()
		{
			List<string> list = new List<string>();
			try
			{
				foreach (KeyValuePair<string, CoLib> colib in Global.bookManager.bookProviders[a].colibs)
				{
					CoLib value = colib.Value;
					list.Add(value.colibName);
				}
				return list;
			}
			catch
			{
				return list;
			}
		}

		public List<string> comboColibsId()
		{
			List<string> list = new List<string>();
			try
			{
				foreach (KeyValuePair<string, CoLib> colib in Global.bookManager.bookProviders[a].colibs)
				{
					CoLib value = colib.Value;
					list.Add(value.venderId);
				}
				return list;
			}
			catch
			{
				return list;
			}
		}

		public string helpContent()
		{
			return Global.bookManager.bookProviders[a].help;
		}
	}
}
