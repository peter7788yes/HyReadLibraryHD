namespace HyReadLibraryHD
{
	public class handleCoordinate
	{
		public int left;

		public int top;

		public int right;

		public int buttom;
	}
}
