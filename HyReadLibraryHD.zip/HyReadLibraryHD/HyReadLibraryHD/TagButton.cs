using BookManagerModule;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Markup;

namespace HyReadLibraryHD
{
	public class TagButton : UserControl, IComponentConnector, IStyleConnector
	{
		public TagData tagData;

		private ObservableCollection<TagListData> tagDataList = new ObservableCollection<TagListData>();

		private List<string> tagList;

		internal Button tagButton;

		internal Popup tagPopup;

		internal Grid tagPanelGrid;

		internal TextBox tagNameTextBox;

		internal Button insertButton;

		internal ListBox tagListBox;

		private bool _contentLoaded;

		public event NewTagNameEvent newTagChangedEvent;

		public TagButton()
		{
			InitializeComponent();
		}

		private void d(object A_0, RoutedEventArgs A_1)
		{
			tagPopup.IsOpen = !tagPopup.IsOpen;
			if (!tagPopup.IsOpen)
			{
				return;
			}
			tagDataList.Clear();
			tagList = Global.bookManager.getAllTagCategories();
			for (int i = 0; i < tagList.Count; i++)
			{
				TagListData tagListData = new TagListData();
				tagListData.tagName = tagList[i];
				tagListData.hasTag = (tagData.tags.Contains(tagList[i]) ? true : false);
				if (!tagDataList.Contains(tagListData))
				{
					tagDataList.Add(tagListData);
				}
			}
			tagListBox.ItemsSource = tagDataList;
		}

		private void a(object A_0, KeyEventArgs A_1)
		{
			if (A_1.Key == Key.Return)
			{
				string text = tagNameTextBox.Text;
				d(text);
			}
		}

		private void c(object A_0, RoutedEventArgs A_1)
		{
			string text = tagNameTextBox.Text;
			d(text);
		}

		private void d(string A_0)
		{
			if (!string.IsNullOrEmpty(A_0) && !tagList.Contains(A_0))
			{
				if (Enumerable.Contains(A_0, ','))
				{
					A_0 = A_0.Replace(',', '，');
				}
				c(A_0);
				b(A_0);
			}
		}

		private void c(string A_0)
		{
			Global.bookManager.saveTagCategory(A_0);
			ObservableCollection<TagListData> observableCollection = tagDataList;
			TagListData tagListData = new TagListData();
			tagListData.tagName = A_0;
			tagListData.hasTag = true;
			observableCollection.Add(tagListData);
			tagNameTextBox.Text = "";
		}

		private void b(string A_0)
		{
			DateTime value = new DateTime(1970, 1, 1);
			long updatetime = DateTime.Now.ToUniversalTime().Subtract(value).Ticks / 10000000;
			tagData.updatetime = updatetime;
			tagData.tags = ((tagData.tags == "") ? A_0 : (tagData.tags + "," + A_0));
			Global.bookManager.saveTagData(true, tagData);
			if (this.newTagChangedEvent != null)
			{
				this.newTagChangedEvent(tagData.tags);
			}
		}

		private void a(string A_0)
		{
			DateTime value = new DateTime(1970, 1, 1);
			long updatetime = DateTime.Now.ToUniversalTime().Subtract(value).Ticks / 10000000;
			tagData.updatetime = updatetime;
			List<string> list = Enumerable.ToList(tagData.tags.Split(new char[1]
			{
				','
			}, StringSplitOptions.RemoveEmptyEntries));
			list.Remove(A_0);
			string text = "";
			foreach (string item in list)
			{
				text = text + item + ",";
			}
			text = ((text == "") ? "" : text.Substring(0, text.LastIndexOf(',')));
			tagData.tags = text;
			Global.bookManager.saveTagData(true, tagData);
			if (this.newTagChangedEvent != null)
			{
				this.newTagChangedEvent(tagData.tags);
			}
		}

		private void b(object A_0, RoutedEventArgs A_1)
		{
			string a_ = (string)((CheckBox)A_0).Content;
			b(a_);
		}

		private void a(object A_0, RoutedEventArgs A_1)
		{
			string a_ = (string)((CheckBox)A_0).Content;
			a(a_);
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/tagbutton.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				tagButton = (Button)target;
				tagButton.Click += new RoutedEventHandler(d);
				break;
			case 2:
				tagPopup = (Popup)target;
				break;
			case 3:
				tagPanelGrid = (Grid)target;
				break;
			case 4:
				tagNameTextBox = (TextBox)target;
				tagNameTextBox.KeyDown += new KeyEventHandler(a);
				break;
			case 5:
				insertButton = (Button)target;
				insertButton.Click += new RoutedEventHandler(c);
				break;
			case 6:
				tagListBox = (ListBox)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never)]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 7)
			{
				((CheckBox)target).Checked += new RoutedEventHandler(b);
				((CheckBox)target).Unchecked += new RoutedEventHandler(a);
			}
		}
	}
}
