namespace HyReadLibraryHD
{
	public class START_END_PAIR
	{
		public int start;

		public int end;

		public string selectText;

		public int penColorIndex;

		public string noteText;

		public string rangy;
	}
}
