using CefSharp;
using CefSharp.Wpf;
using HtmlAgilityPack;
using Microsoft.Runtime.CompilerServices;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Markup;

namespace HyReadLibraryHD
{
	public class SSOcefSharp : Window, IComponentConnector
	{
		[StructLayout(LayoutKind.Auto)]
		[CompilerGenerated]
		private struct a : IAsyncStateMachine
		{
			public int a;

			public AsyncVoidMethodBuilder b;

			public SSOcefSharp c;

			private Microsoft.Runtime.CompilerServices.TaskAwaiter<string> m_d;

			private void d()
			{
				int num = a;
				SSOcefSharp sSOcefSharp = c;
				try
				{
					Microsoft.Runtime.CompilerServices.TaskAwaiter<string> awaiter;
					if (num != 0)
					{
						awaiter = AwaitExtensions.GetAwaiter(sSOcefSharp.c.GetSourceAsync());
						if (!awaiter.IsCompleted)
						{
							num = (a = 0);
							this.m_d = awaiter;
							b.AwaitUnsafeOnCompleted(ref awaiter, ref this);
							return;
						}
					}
					else
					{
						awaiter = this.m_d;
						this.m_d = default(Microsoft.Runtime.CompilerServices.TaskAwaiter<string>);
						num = (a = -1);
					}
					string result = awaiter.GetResult();
					string text = string.Empty;
					string text2 = string.Empty;
					string empty = string.Empty;
					HtmlDocument htmlDocument = new HtmlDocument();
					htmlDocument.LoadHtml(result);
					HtmlNodeCollection htmlNodeCollection = htmlDocument.DocumentNode.SelectNodes("//input[@name]");
					if (htmlNodeCollection != null)
					{
						IEnumerator<HtmlNode> enumerator = ((IEnumerable<HtmlNode>)htmlNodeCollection).GetEnumerator();
						try
						{
							while (enumerator.MoveNext())
							{
								HtmlNode current = enumerator.Current;
								if (current.Attributes["name"].Value.Equals("uid"))
								{
									text = current.Attributes["value"].Value;
								}
								if (current.Attributes["name"].Value.Equals("sid"))
								{
									text2 = current.Attributes["value"].Value;
								}
								Console.WriteLine(text + ", " + text2);
							}
						}
						finally
						{
							if (num < 0 && enumerator != null)
							{
								enumerator.Dispose();
							}
						}
						if (!text.Equals("") && !text2.Equals(""))
						{
							sSOcefSharp.isCancelled = false;
							try
							{
								Global.bookManager.loginForSSO(sSOcefSharp.b, empty, text, text2);
							}
							catch (Exception)
							{
							}
							sSOcefSharp.Dispatcher.Invoke(new Action(sSOcefSharp.a), new object[0]);
						}
					}
				}
				catch (Exception exception)
				{
					a = -2;
					b.SetException(exception);
					return;
				}
				a = -2;
				b.SetResult();
			}

			void IAsyncStateMachine.MoveNext()
			{
				//ILSpy generated this explicit interface implementation from .override directive in d
				this.d();
			}

			[DebuggerHidden]
			private void d(IAsyncStateMachine A_0)
			{
				b.SetStateMachine(A_0);
			}

			void IAsyncStateMachine.SetStateMachine(IAsyncStateMachine A_0)
			{
				//ILSpy generated this explicit interface implementation from .override directive in d
				this.d(A_0);
			}
		}

		private const int m_a = 42;

		public bool isCancelled = true;

		private string b = "";

		internal ChromiumWebBrowser c;

		private bool d;

		public SSOcefSharp()
		{
			InitializeComponent();
		}

		[DllImport("wininet.dll", SetLastError = true)]
		private static extern bool InternetSetOption(IntPtr A_0, int A_1, IntPtr A_2, int A_3);

		public SSOcefSharp(string VendorId, string loginApi)
		{
			InitializeComponent();
			b = VendorId;
			base.Title = Global.bookManager.bookProviders[b].name + " 登入";
			InternetSetOption(IntPtr.Zero, 42, IntPtr.Zero, 0);
			base.Visibility = Visibility.Visible;
			a(loginApi);
		}

		private void a(string A_0)
		{
			if (string.IsNullOrEmpty(A_0) || A_0.Equals("about:blank"))
			{
				return;
			}
			if (!A_0.StartsWith("http://") && !A_0.StartsWith("https://"))
			{
				A_0 = "http://" + A_0;
			}
			string[] files = Directory.GetFiles(Environment.GetFolderPath(Environment.SpecialFolder.Cookies));
			foreach (string path in files)
			{
				try
				{
					File.Delete(path);
				}
				catch
				{
				}
			}
			try
			{
				c.Load(A_0);
			}
			catch (UriFormatException)
			{
			}
		}

		[AsyncStateMachine(typeof(a))]
		private void a(object A_0, NavStateChangedEventArgs A_1)
		{
			a stateMachine = default(a);
			stateMachine.c = this;
			stateMachine.b = AsyncVoidMethodBuilder.Create();
			stateMachine.a = -1;
			AsyncVoidMethodBuilder asyncVoidMethodBuilder = stateMachine.b;
			asyncVoidMethodBuilder.Start(ref stateMachine);
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!d)
			{
				d = true;
				Uri resourceLocator = new Uri("/HyReadLibraryHD;component/ssocefsharp.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				c = (ChromiumWebBrowser)target;
				c.NavStateChanged += new EventHandler<NavStateChangedEventArgs>(a);
			}
			else
			{
				d = true;
			}
		}

		[CompilerGenerated]
		private void a()
		{
			Close();
		}
	}
}
