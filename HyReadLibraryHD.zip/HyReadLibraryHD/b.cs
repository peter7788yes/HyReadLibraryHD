using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

[CompilerGenerated]
internal sealed class b<a, b>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly a a;

	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly b m_b;

	public a file
	{
		get
		{
			return this.a;
		}
	}

	public b line
	{
		get
		{
			return this.b;
		}
	}

	[DebuggerHidden]
	public b(a A_0, b A_1)
	{
		this.a = A_0;
		this.b = A_1;
	}

	[DebuggerHidden]
	public override bool Equals(object value)
	{
		global::b<a, b> b = value as global::b<a, b>;
		if (b != null && EqualityComparer<a>.Default.Equals(this.a, b.a))
		{
			return EqualityComparer<b>.Default.Equals(this.b, b.b);
		}
		return false;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return (1797869008 * -1521134295 + EqualityComparer<a>.Default.GetHashCode(this.a)) * -1521134295 + EqualityComparer<b>.Default.GetHashCode(this.b);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		object[] array = new object[2];
		a val = this.a;
		ref a reference = ref val;
		a val2 = default(a);
		object obj;
		if (val2 == null)
		{
			val2 = reference;
			reference = ref val2;
			if (val2 == null)
			{
				obj = null;
				goto IL_0046;
			}
		}
		obj = reference.ToString();
		goto IL_0046;
		IL_0046:
		array[0] = obj;
		b val3 = this.b;
		ref b reference2 = ref val3;
		b val4 = default(b);
		object obj2;
		if (val4 == null)
		{
			val4 = reference2;
			reference2 = ref val4;
			if (val4 == null)
			{
				obj2 = null;
				goto IL_0081;
			}
		}
		obj2 = reference2.ToString();
		goto IL_0081;
		IL_0081:
		array[1] = obj2;
		return string.Format(null, "{{ file = {0}, line = {1} }}", array);
	}
}
