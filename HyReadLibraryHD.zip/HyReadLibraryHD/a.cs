using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;

[CompilerGenerated]
internal sealed class a<a>
{
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	private readonly a m_a;

	public a message
	{
		get
		{
			return this.a;
		}
	}

	[DebuggerHidden]
	public a(a A_0)
	{
		this.a = A_0;
	}

	[DebuggerHidden]
	public override bool Equals(object value)
	{
		global::a<a> a = value as global::a<a>;
		if (a != null)
		{
			return EqualityComparer<a>.Default.Equals(this.a, a.a);
		}
		return false;
	}

	[DebuggerHidden]
	public override int GetHashCode()
	{
		return -1401644745 * -1521134295 + EqualityComparer<a>.Default.GetHashCode(this.a);
	}

	[DebuggerHidden]
	public override string ToString()
	{
		object[] array = new object[1];
		a val = this.a;
		ref a reference = ref val;
		a val2 = default(a);
		object obj;
		if (val2 == null)
		{
			val2 = reference;
			reference = ref val2;
			if (val2 == null)
			{
				obj = null;
				goto IL_0046;
			}
		}
		obj = reference.ToString();
		goto IL_0046;
		IL_0046:
		array[0] = obj;
		return string.Format(null, "{{ message = {0} }}", array);
	}
}
