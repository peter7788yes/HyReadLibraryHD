using CefSharp;
using HyReadLibraryHD;
using System.Windows.Forms;

internal class g : IRequestHandler
{
	public bool OnBeforeBrowse(IWebBrowser browser, IRequest request, bool isRedirect)
	{
		return false;
	}

	public bool OnBeforeResourceLoad(IWebBrowser browser, IRequest request, IResponse response)
	{
		if (request.Url == "file:///")
		{
			return false;
		}
		if (epubReadPage.pathToBookOEBPS == null)
		{
			return false;
		}
		if (request.Url.StartsWith("file:///"))
		{
			if (request.Url.EndsWith("ios_epub_pen.png"))
			{
				response.Redirect(Application.StartupPath + "\\ios_epub_pen.png");
				return false;
			}
			if (request.Url.EndsWith("playbutton.png"))
			{
				response.Redirect(Application.StartupPath + "\\playbutton.png");
				return false;
			}
			if (request.Url.EndsWith("audiobutton.png"))
			{
				response.Redirect(Application.StartupPath + "\\audiobutton.png");
				return false;
			}
			if (request.Url.Contains(epubReadPage.pathToBookOEBPS.Replace("\\", "/")))
			{
				return false;
			}
			response.Redirect(request.Url.Replace("file:///", epubReadPage.pathToBookOEBPS));
		}
		return false;
	}

	public bool OnCertificateError(IWebBrowser browser, CefErrorCode errorCode, string requestUrl)
	{
		return false;
	}

	public void OnPluginCrashed(IWebBrowser browser, string pluginPath)
	{
	}

	public bool GetAuthCredentials(IWebBrowser browser, bool isProxy, string host, int port, string realm, string scheme, ref string username, ref string password)
	{
		return false;
	}

	public void OnRenderProcessTerminated(IWebBrowser browser, CefTerminationStatus status)
	{
	}

	public bool OnBeforePluginLoad(IWebBrowser browser, string url, string policyUrl, IWebPluginInfo info)
	{
		return true;
	}
}
