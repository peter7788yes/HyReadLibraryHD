using CefSharp;

internal class d : IDragHandler
{
	public bool OnDragEnter(IWebBrowser browser, IDragData dragdata, DragOperationsMask mask)
	{
		return true;
	}
}
