using BookManagerModule;
using HyReadLibraryHD;
using System.Collections.ObjectModel;
using System.Windows.Threading;

internal class i
{
	public string a;

	public ObservableCollection<BookThumbnail> b;

	private BookProvider c;

	private Dispatcher d;

	private MainWindow e;

	public i(MainWindow A_0)
	{
		e = A_0;
		b = new ObservableCollection<BookThumbnail>();
	}
}
