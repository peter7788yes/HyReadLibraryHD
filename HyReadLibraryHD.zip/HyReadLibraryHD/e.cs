using CefSharp;

internal class e : IMenuHandler
{
	public bool OnBeforeContextMenu(IWebBrowser browser)
	{
		return false;
	}
}
