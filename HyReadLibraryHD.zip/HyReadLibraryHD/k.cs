internal delegate void k();
