using DigitalBookEPUBModule.Portable.Interface;
using System.Runtime.CompilerServices;

namespace HyReadLibraryHD.DataObject
{
	public class EpubObject : IEpubObject
	{
		[CompilerGenerated]
		private int a;

		[CompilerGenerated]
		private string b;

		[CompilerGenerated]
		private string c;

		public int spineIndex
		{
			[CompilerGenerated]
			get
			{
				return a;
			}
			[CompilerGenerated]
			set
			{
				a = value;
			}
		}

		public string htmlPath
		{
			[CompilerGenerated]
			get
			{
				return b;
			}
			[CompilerGenerated]
			set
			{
				b = value;
			}
		}

		public string htmlContent
		{
			[CompilerGenerated]
			get
			{
				return c;
			}
			[CompilerGenerated]
			set
			{
				c = value;
			}
		}

		public virtual void resetEpubObject()
		{
			htmlPath = "";
			htmlContent = "";
		}
	}
}
